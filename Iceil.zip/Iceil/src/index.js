import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import reportWebVitals from './reportWebVitals';
import LoginPage from './components/LoginComponents/LoginPage';
import ImageWaterMarkDownload from './components/Test Components/ImageWaterMarkDownload';
import ImageWaterMarkUpload from './components/Test Components/ImageWaterMarkUpload';
import VideoUploaderViewer from './components/Test Components/VideoUploaderViewer';
import MenuUpload from './components/Admin Components/MenuUpload/MenuUpload';
import AddUser from './components/Admin Components/User Management/AddUser';
import AddMenu from './components/Admin Components/Configuration/Menu/AddMenu';
import AdminSideBar from './components/Admin Components/SideBar/SideBar';
import { DBConfig } from './components/Common Components/CommonComponents';
import { initDB } from 'react-indexed-db';
import ImageCropper from './components/Test Components/ImageCropper';
import ImageCropper2 from './components/Test Components/ImageCropper2';
import TextFieldComponent from './components/Test Components/TextField';



initDB(DBConfig);

if (window.location.pathname.toLowerCase() === "/login") {
 // alert("IF");
  var url_string = window.location.href;
  var newurl = '/login';
  window.history.replaceState({}, document.title, newurl);
  ReactDOM.render(
    <BrowserRouter>
      <Routes>
        <Route path="login" element={<LoginPage />} />
      </Routes>
    </BrowserRouter>,

    document.getElementById('root'));
} else {
 // alert("ELSE");
  ReactDOM.render(
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage />} />
      </Routes>
    </BrowserRouter>,

    document.getElementById('root'));

}
// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
