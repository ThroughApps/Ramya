//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import $ from 'jquery';
import moment from 'moment-timezone';
import CryptoJS from 'crypto-js';
import { initDB, IndexedDB, AccessDB, useIndexedDB } from 'react-indexed-db';
import { titleCase } from "title-case";

import LoginPage from '../LoginComponents/LoginPage';
import { withStyles, createStyles } from "@material-ui/core/styles";
import { createTheme } from "@material-ui/core/styles";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022


/*
FUNCTION USED FOR CONVERTING FLAT ARRAY INTO 
TREE FORMAT 
USED IN - AddMenu.js - IMPLEMENTED BY PRIYANKA - 19-04-2022
*/
export const List_To_Tree_With_KeyNameChange_With_RootMenu = function (list, idAttr, parentAttr, childrenAttr) {

    const newArrayOfObj = list.map(({ parentMenuId: parent, menuId: id, menuName: label, ...rest }) => ({ parent, id, label, ...rest }));

    var menuArrayOfObj = newArrayOfObj.map(obj => obj.parent == '' ? { ...obj, parent: null } : obj);
    //console.log("menuArrayOfObj :", menuArrayOfObj);



    if (!idAttr) idAttr = 'id';
    if (!parentAttr) parentAttr = 'parent';
    if (!childrenAttr) childrenAttr = 'children';
    var treeList = [];
    var lookup = {};
    menuArrayOfObj.forEach(function (obj) {
        lookup[obj[idAttr]] = obj;
        obj[childrenAttr] = [];
    });
    menuArrayOfObj.forEach(function (obj) {
        if (obj[parentAttr] != null) {
            lookup[obj[parentAttr]][childrenAttr].push(obj);
        } else {
            treeList.push(obj);
        }
    });

    /*  var newMenuData = {
          "parent": null,
          "label": "New Root Menu",
          "id": "",
          "module": "New Root Menu",
          "children": []
      }
  
      treeList.push(newMenuData);
      */


    return treeList;

}

/*
FUNCTION USED FOR CONVERTING FLAT ARRAY INTO 
TREE FORMAT 
USED IN - MenuUpload.js - IMPLEMENTED BY PRIYANKA - 20-04-2022
*/
export const List_To_Tree_With_KeyNameChange_Without_RootMenu = function (list, idAttr, parentAttr, childrenAttr) {

    const newArrayOfObj = list.map(({ parentMenuId: parent, menuId: id, menuName: label, ...rest }) => ({ parent, id, label, ...rest }));

    var menuArrayOfObj = newArrayOfObj.map(obj => obj.parent == '' ? { ...obj, parent: null } : obj);
    // //console.log("menuArrayOfObj :", menuArrayOfObj);



    if (!idAttr) idAttr = 'id';
    if (!parentAttr) parentAttr = 'parent';
    if (!childrenAttr) childrenAttr = 'children';
    var treeList = [];
    var lookup = {};
    menuArrayOfObj.forEach(function (obj) {
        lookup[obj[idAttr]] = obj;
        obj[childrenAttr] = [];
    });
    menuArrayOfObj.forEach(function (obj) {
        if (obj[parentAttr] != null) {
            lookup[obj[parentAttr]][childrenAttr].push(obj);
        } else {
            //  //console.log("TREE LIST OBJ :",obj);
            //  obj.checked = true;
            //  //console.log("TREE LIST OBJ AFTER SETTINF CHECKED :",obj);
            treeList.push(obj);
        }
    });




    return treeList;

}

/*
FUNCTION USED FOR CONVERTING FLAT ARRAY INTO 
TREE FORMAT 
USED IN - SideBar.js of FRANCHISE COMPONENT - IMPLEMENTED BY PRIYANKA - 27-04-2022
*/


export const List_To_Tree_With_KeyNameChange_For_SideBar = function (list) {

    var newArrayOfObj = list.map(({ parentMenuId: parentId, menuId: id, menuName: label, ...rest }) => ({ parentId, id, label, ...rest }));

    var menuArrayOfObj = newArrayOfObj.map(obj => obj.parentId == '' ? { ...obj, parentId: null } : obj);
    // //console.log("menuArrayOfObj :", menuArrayOfObj);

    //  var sideBarMenuData = arrayData.map(({children,comapnyId,date, ...rest}) => ({...rest}));

    var sideBarMenuData = menuArrayOfObj.map(({ parentId, label, id }) => ({ parentId, label, id }));

    //  //console.log("sideBarMenuData :", sideBarMenuData);

    var listData = ["Saved Images", "Quotation", "Technical Know-How", "FAQ","AboutMe", "Logout"];

    $.each(listData, function (i, item) {
        var newMenuData = {
            "parentId": null,
            "label": item,
            "id": item,
        }
        sideBarMenuData.push(newMenuData);

    })


    return sideBarMenuData;

}

/*
FUNCTION USED FOR CONVERTING FLAT ARRAY INTO 
TREE FORMAT 
USED IN - SearchComponent.js (RENDERED IN ImageGallery.js, ChooseyourImage.js, VideoGallery.js)
 of FRANCHISE COMPONENT - IMPLEMENTED BY PRIYANKA - 11-05-2022
*/


export const List_To_Tree_With_KeyNameChange_For_SearchBar = function (list) {

    var newArrayOfObj = list.map(({ menuId: key, menuName: value, ...rest }) => ({ key, value }));

    var menuArrayOfObj = newArrayOfObj.map(obj => obj.key == '' ? { ...obj, key: null } : obj);
    //console.log("menuArrayOfObj :", menuArrayOfObj);

    //  var sideBarMenuData = arrayData.map(({children,comapnyId,date, ...rest}) => ({...rest}));

    var sideBarMenuData = menuArrayOfObj.map(({ key, value }) => ({ key, value }));

    //console.log("SERACH BAR DATA :", sideBarMenuData);

    return sideBarMenuData;

}

/*
FUNCTION USED FOR GETTING DATE & TIME FOR A TIMEZONE
USED IN - AddMenu.js - IMPLEMENTED BY PRIYANKA - 20-04-2022
*/
export const TimeZoneDateTime = (timeZone) => {


    var empZone = timeZone;
    //console.log("empZone :", empZone);


    var offset = moment.tz(moment.utc(), empZone).utcOffset();
    var offsetValue = Number(offset) / 60; //CONVERTING MIN INTO HRS
    var timings = CalcTime(empZone, offsetValue);
    var todayDate = GetTimeZoneDate(offsetValue);
    var currenttime = timings.toLocaleTimeString([], { hour12: false });

    var date_Time = {
        date: todayDate,
        time: currenttime,
    }

    return date_Time;
}

export const CalcTime = (city, offset) => {
    // create Date object for current location
    var d = new Date();


    // convert to msec
    // subtract local time zone offset
    // get UTC time in msec
    var utc = d.getTime() + (d.getTimezoneOffset() * 60000);

    // create new Date object for different city
    // using supplied offset
    var nd = new Date(utc + (3600000 * offset));

    // return time as a string
    return nd;
}


export const GetTimeZoneDate = (offset) => {
    //  var offset = -8;
    var todayDate = new Date(new Date().getTime() + offset * 3600 * 1000).toUTCString().replace(/ GMT$/, "")


    var d1 = new Date(todayDate);
    var d2 = d1.getFullYear() + "-"
        + ('0' + (d1.getMonth() + 1)).slice(-2) + "-"
        + ('0' + d1.getDate()).slice(-2);


    return d2;

}

/*
FUNCTION USED FOR SETTING LOCAL STORAGE VALUES-USED IN ALL PAGES
IMPLEMENTED BY DURGA - 03-05-2022
*/
export const SetLocalStorageData = (fieldName, fieldValue) => {

    var key = "IceilPrintSolutions";
    localStorage.setItem((fieldName), CryptoJS.AES.encrypt((fieldValue), key));
}


/*
FUNCTION USED FOR GETTING LOCAL STORAGE VALUES
ALMOST USED IN ALL PAGES
IMPLEMENTED BY PRIYANKA - 28-04-2022
*/
export const GetLocalStorageData = (fieldName) => {

    var key = "IceilPrintSolutions";

    var localStorageData = CryptoJS.AES.decrypt(localStorage.getItem(fieldName), key).toString(CryptoJS.enc.Utf8);

    return localStorageData;

}



/*
FUNCTION USED FOR INITIALISING INDEXED DB
USED IN ADD TO CART FUNCTIONALITY OF
SAVED IMAGE
IMPLEMENTED BY PRIYANKA - 03-05-2022
*/
export const DBConfig = {
    name: 'CartDB',
    version: 1,
    objectStoresMeta: [
        {
            store: 'AddToCart',
            storeConfig: { keyPath: 'id', autoIncrement: true },
            storeSchema: [
                { name: 'uploadid', keypath: 'uploadid', options: { unique: false } },
                { name: 'image', keypath: 'image', options: { unique: false } },
            ]
        }
    ]
};

/*
FUNCTION USED FOR CLEARING INDEXED DB
USED IN ADD TO CART FUNCTIONALITY OF
SAVED IMAGE
IMPLEMENTED BY PRIYANKA - 04-05-2022
*/
export const ClearTable = (tableName) => {

    const { clear } = useIndexedDB(tableName);

    clear().then(() => {
        //console.log('CART TABLE All Clear!');
    });

};

/*
FUNCTION USED FOR ADDING DATA TO INDEXED DB
USED IN ADD TO CART FUNCTIONALITY OF
SAVED IMAGE
IMPLEMENTED BY PRIYANKA - 04-05-2022
*/
export const AddDataToTable = (tableName, id, image) => {

    const { add } = useIndexedDB(tableName);

    add({ uploadid: id, image: image }).then(
        event => {
            //console.log('ID Generated: ', event);
        },
        error => {
            //console.log(error);
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Adding item to cart failed, try after sometime',
                showConfirmButton: false,
                timer: 2000
            })
        }
    );

};

/*
FUNCTION USED FOR GETTING DATA FROM INDEXED DB
TO CHECK IF IT ALREADY EXIST IN THE DB
USED IN ADD TO CART FUNCTIONALITY OF
SAVED IMAGE AddtoCart
IMPLEMENTED BY PRIYANKA - 04-05-2022
*/
export const CheckDataInTable = async (tableName, id, image) => {

    const { getByIndex } = useIndexedDB(tableName);

    return new Promise((resolve, reject) => {
        getByIndex('uploadid', id).then(dbData => {
            resolve(dbData);
            //console.log("CheckDataInTable dbData :", dbData);

        });

    })
};


/*
FUNCTION USED FOR CLEARING INDEXED DB
USED IN GENERATE QUOTATION
IMPLEMENTED BY DURGA - 15-05-2022
*/
export const GetAllData = () => {
    var imageData = [];
    //console.log("GetCartDBData quotation ");
    const { getAll } = useIndexedDB('AddToCart');
    return getAll().then(DBData => {
        imageData = DBData;
        //console.log("generate quotation GetCartDBData", imageData);
        ////console.log("GET INDEX DB DATA GEN QUOTATION :", JSON.stringify(DBData));
        if (imageData.length > 0) {
            //console.log("if");
            return imageData;
        }
    });
};


/*
FUNCTION USED TO CONVERT THE 
ENTERED TEXT INTO CAMEL CASE
IMPLEMENETED BY PRIYANKA - 20-05-2022
*/
export const CapitalCaseFunc = function (textValue) {

    var lowerval = textValue.toLowerCase();
    var capitalCase = titleCase(lowerval);

    return capitalCase;

}

/*
FUNCTION USED TO CHECK LENGTH OF THE TEXT 
ENTERED
IMPLEMENETED BY PRIYANKA - 20-05-2022
*/
export const TextLengthFunc = function (textValue, lengthValue) {

    var lengthValidationData = false;
    if (textValue.length <= lengthValue) {
        lengthValidationData = true;
    }
    return lengthValidationData;

}


/*
FUNCTION USED FOR LOGOUT OF THE ACCOUNT
COMMON TO BOTH ADMIN & FRANCHISE MODULE
IMPLEMENTED BY PRIYANKA - 19-05-2022
*/
export const LogOut = async (tableName, module) => {

    localStorage.clear();

    if (module == "Franchise") {
        const { clear } = useIndexedDB(tableName);

        clear().then(() => {
            // alert('All Clear!');
        });
    }

    ReactDOM.render(
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<LoginPage />} />
            </Routes>
        </BrowserRouter>,
        document.getElementById("root")
    );

}


export function GetVideoThumbNail(file, seekTo = 0.0) {
    console.log("getting video cover for file: ", file);
    return new Promise((resolve, reject) => {
        // load the file to a video player
        const videoPlayer = document.createElement('video');
        videoPlayer.setAttribute('src', URL.createObjectURL(file));
        videoPlayer.load();
        videoPlayer.addEventListener('error', (ex) => {
            reject("error when loading video file", ex);
        });
        // load metadata of the video to get video duration and dimensions
        videoPlayer.addEventListener('loadedmetadata', () => {
            // seek to user defined timestamp (in seconds) if possible
            if (videoPlayer.duration < seekTo) {
                reject("video is too short.");
                return;
            }
            // delay seeking or else 'seeked' event won't fire on Safari
            setTimeout(() => {
              videoPlayer.currentTime = seekTo;
            }, 200);
            // extract video thumbnail once seeking is complete
            videoPlayer.addEventListener('seeked', () => {
                console.log('video is now paused at %ss.', seekTo);
                // define a canvas to have the same dimension as the video
                const canvas = document.createElement("canvas");
                canvas.width = videoPlayer.videoWidth;
                canvas.height = videoPlayer.videoHeight;
                // draw the video frame to canvas
                const ctx = canvas.getContext("2d");
                ctx.drawImage(videoPlayer, 0, 0, canvas.width, canvas.height);
                // return the canvas image as a blob
                ctx.canvas.toBlob(
                    blob => {
                        console.log(" ***** blob for video :",blob);
                        var file = new File([blob], "my_image.png",{type:"image/png", lastModified:new Date().getTime()})
                        console.log(" ***** file for video uploaded :",file);
                      //  FileSaver.saveAs(file, "image.jpg");
                        resolve(file);
                    },
                    "image/jpeg",
                    0.75 /* quality */
                );
            });
        });
    });
}

const defaultColor = "#ff0000";
    const hoverColor = "#0000ff";
    const focusColor = "#00ff00";

export  const theme = createTheme({
    overrides: {
      MuiOutlinedInput: {
        root: {
          "&:hover $notchedOutline": {
            borderColor: hoverColor
          },
          "&$focused $notchedOutline": {
            borderColor: focusColor
          }
        },
        notchedOutline: {
          borderColor: defaultColor
        },
        input: {
          color: "red"
        }
      },
      MuiFormLabel: {
        asterisk: {
          color: "red",
          "&$error": {
            color: "#db3131"
          }
        }
      }
    }
  });


export function Get_TextField_MUI_Styling() {
    const defaultColor = "#ff0000";
    const hoverColor = "#0000ff";
    const focusColor = "#00ff00";
    
    const theme1 = createTheme({
        overrides: {
            MuiOutlinedInput: {
                root: {
                    "&:hover $notchedOutline": {
                        borderColor: 'white'
                    },
                    "&$focused $notchedOutline": {
                        borderColor: 'white'
                    }
                },
                notchedOutline: {
                    borderColor: 'white'
                },
                input: {
                    color: "red"
                }
            },
            MuiFormLabel: {
                root: {
                    asterisk: {
                        color: "#ff0000",
                        "&$error": {
                            color: "#db3131"
                        }
                    },
                    MuiInputLabel: {
                        root: {
                            color: "rgb(255 255 255)"
                        }
                    }
                }

            },
           

        }
    });
 
    return theme;
}

export function dataURLtoFile(dataurl, filename) {

    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);

    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }

    return new File([u8arr], filename, { type: mime });
}
