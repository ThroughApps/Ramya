//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import SelectSearch from 'react-select';
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import _ from "underscore";
import { Truncate_2DecimalPlaces, CheckNumberFormat_WithoutDecimal } from "../../Validation Components/FormErrors";
// import statement for class component css
import '../../StyleCss.css';
import { initDB, IndexedDB, AccessDB, useIndexedDB } from 'react-indexed-db';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
// import statement for react component css
import "react-table-v6/react-table.css";
import "react-sliding-pane/dist/react-sliding-pane.css"
import Popup from 'react-popup';
// import statement for react class component
import { FranchiseQuotationImage, FranchiseQuotationProduct } from '../../Admin Components/Quotation/QuotationComponent'
import { ErrorClass } from '../../Validation Components/Loginvalidation';
import { GetLocalStorageData, GetAllData, TimeZoneDateTime, ClearTable } from "../../Common Components/CommonComponents";
import { DBConfig } from "../../Common Components/CommonComponents";
//const { add } = useIndexedDB('AddToCart');

var imageData = [];
var tableName = "AddToCart";

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class Quotation extends React.Component {

    constructor() {
        super();
        //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 29-04-2022
        var today = new Date();
        var tempDate = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
        var tempTime = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();

        this.state = {
            date: tempDate,
            time: tempTime,
            productOptions: [],
            quantity: 1,
            rate: '',
            totalAmount: 0,
            totalIteminCart: 0,
            amountToBePaid: 0,
            gstTax: 0,
            selectedProductName: '',
            cartData: [],
            imageCartData: [],
            isQuotationEditPaneOpen: false,
            isQuotationViewPaneOpen: false,
            formErrors: {
                quantity: 1,
            },
            formValid: false,
            quantityValid: true,
            submitValid: false,
        }
        this.quotationEdit = this.quotationEdit.bind(this);
        this.quotationView = this.quotationView.bind(this);
        this.AddtoCartFunc = this.AddtoCartFunc.bind(this);
        this.CancelFunc = this.CancelFunc.bind(this);
        this.SetSubmitValid = this.SetSubmitValid.bind(this);
    }

    quotationEdit() {
        var self = this;
        self.state.isQuotationEditPaneOpen = true;
        self.setState({
            isQuotationEditPaneOpen: self.state.isQuotationEditPaneOpen,
        })
    }
    quotationView() {
        var self = this;
        self.state.isQuotationViewPaneOpen = true;
        self.setState({
            isQuotationViewPaneOpen: self.state.isQuotationViewPaneOpen,
        })
    }
    CloseQuotationEdit() {
        this.state.isQuotationEditPaneOpen = false;
        this.setState({
            isQuotationEditPaneOpen: this.state.isQuotationEditPaneOpen,
        })
    }
    CloseQuotationView() {
        this.state.isQuotationViewPaneOpen = false;
        this.setState({
            isQuotationViewPaneOpen: this.state.isQuotationViewPaneOpen,
        })
    }
    componentDidMount() {


        var self = this;

        this.GetData();

        //AFTER GET THE PRODUCT DETAILS ITERATE THE ARRAY AND PUSH THE PRODUCTLIST INTO REACT ARRAY-IMPLEMENTED BY DURGA 27-04-2022 //
        var productOptions = [];
        $.each(self.state.productArrayList, function (i, item) {
            if (item.visibilityStatus == 1) {
                productOptions.push({ label: item.productName, value: item.productCode });
            }
        })

        self.state.productOptions = productOptions;
        self.setState({
            productOptions: productOptions,
        })

        //TO CHECK THE INDEXEDDB HAVING DATA IF IT HAVING RENDER THAT IN GENERATE QUOTATION PAGE-IMPLEMENTED BY DURGA 17-05-2022//
        var result = GetAllData();

        result.then(function (response) {

            if (response == undefined) {
                //alert("no items in indexed db");
            } else {
                //alert("items in indexed db");  
                imageData = response;
                window.FranchiseQuotationImageComponent.RenderImage(response);

                ////console.log("imageCartData",imageData);
                self.state.submitValid = false;
                if (imageData.length > 0) {
                    self.state.submitValid = true;
                }

                self.setState({ imageCartData: imageData })

                //console.log("statedata-imageCartData", self.state.imageCartData);
            }

        })

        // this.GetCartDBData();
    }
    /*SAMPLE FOR GETTING DATA FROM INDEXED DB
    WILL BE USED IN QUOTATION MODULE
    IMPLEMENTED BY DURGA - 15-05-2022*/
    GetCartDBData() {

        var imageData = [];
        imageData = GetAllData();
        // //console.log("GetCartDBData quotation",imageData);

        // const { getAll } = useIndexedDB('AddToCart');
        // getAll().then(DBData => {
        //     imageData=DBData;
        //     //console.log("generate quotation GetCartDBData",imageData);
        //     //console.log("GET INDEX DB DATA GEN QUOTATION :", JSON.stringify(DBData));
        // });

        this.setState({ imageCartData: imageData })
        //console.log("imageCartData", this.state.imageCartData);

        // //console.log("GetCartDBData quotation",imageData);
    }

    /* USED TO GET THE PRODUCT LIST DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 27-04-2022 */
    GetData() {
        var self = this;

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("FranchiseCompanyId"),
            }),
            url: "http://15.206.129.105:8080/IceilLiveAPI/FranchiseQuotationWebService/SelectProductDetails",
            contentType: "application/json",
            dataType: 'json',
            async: false,

            success: function (data, textStatus, jqXHR) {
                // //console.log("data",data);
                if (data.productList != null) {
                    self.state.productArrayList = data.productList;
                    self.setState({ productArrayList: self.state.productArrayList })
                    //  //console.log("self ProductList data", self.state.productArrayList);
                }

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            },
        });
    }

    /*HANDLE THE PRODUCT SELECTION,RATE & TAX  FIELDS
    SET & POPUP IN UI IMPLEMENTED BY DURGA 27-04-2022 */

    handleProductDetails(e) {

        var self = this;
        const name = e.name;
        const value = e.value;
        this.state.selectedProductName = e;
        ////console.log(e);

        var productDetails = _.findWhere(this.state.productArrayList, { productCode: value });

        //console.log("productdetails", productDetails);

        self.state.ratePerUnit = productDetails.rate;
        self.state.sgst = productDetails.sgst;
        self.state.cgst = productDetails.cgst;
        self.state.igst = productDetails.igst;
        self.state.hsnCode = productDetails.hsnCode;
        self.state.productId = productDetails.productId;
        self.state.quantity = 1;

        //console.log("quantity", self.state.quantity);

        //RATEPERUNIT=>Rate per product //RATE=> Quantity * Rate per product
        var RateTemp = Number(self.state.ratePerUnit) * Number(self.state.quantity); //1-quantity
        RateTemp = Truncate_2DecimalPlaces(RateTemp);
        self.state.rate = RateTemp;
        //console.log("RateTemp", RateTemp);

        this.setState({
            selectedProductName: this.state.selectedProductName,
            ratePerUnit: self.state.ratePerUnit,
            sgst: self.state.sgst,
            cgst: self.state.cgst,
            igst: self.state.igst,
            rate: self.state.rate,
            hsnCode: self.state.hsnCode,
            productId: self.state.productId
        })

        //console.log("rate after set state", this.state.rate);

        // this.validateField('quantity', this.state.quantity);	

        var productdetailValid = false;
        if (this.state.selectedProductName != " ") {
            productdetailValid = true;
            //console.log("checking", this.state.selectedProductName);
        }
        else {
            productdetailValid = false;
            //console.log("checking", this.state.selectedProductName);
            //console.log("productdetailValid", productdetailValid);
        }
        this.setState({
            productdetailValid: productdetailValid
        }, this.validateForm)
    }
    /*USED TO VALIDATE THE NECESSARY FIELDS IMPLEMENTED BY RAMYA - 13-05-2022*/

    validateField(fieldName, value) {
        //console.log("fieldName :", fieldName + " vLAUE :", value);
        let fieldValidationErrors = this.state.formErrors;
        let quantityValid = this.state.quantityValid;
        //console.log("qunatityc %%", quantityValid);
        switch (fieldName) {
            case 'quantity':
                if (value.length == "" || value == "0") {
                    fieldValidationErrors.quantity = 'Should not be Empty or zero';
                    quantityValid = false;
                    //console.log("quantity", value)
                    //console.log("3");
                    this.setState({ rate: '' })
                }
                // else if(value.length>1 && value.length<=4)	
                // {		

                //     //console.log("value.length",value.length);

                //   quantityValid=value.match(/^[0-9]+$/);     ///^[0-9\b]+$/
                //   fieldValidationErrors.quantity = quantityValid ? '' : ' is InCorrect';	
                //   //console.log("false part-2nd else");
                // }		
                else if (value > 1000) {
                    fieldValidationErrors.quantity = 'Sorry! You are Exceeding the Limit';
                    quantityValid = false;
                    //console.log("1");
                    this.setState({ rate: '' })
                }
                // else if(value == "1" ){	
                //     fieldValidationErrors.quantity = ''; 	
                //     quantityValid= true;	
                //     //console.log("quantity111", value)	
                //     //console.log("state quantity", this.state.quantity)	
                //     //console.log("4");
                // }	
                else {
                    //console.log("true part");

                    quantityValid = false;
                    if (value.match(/^[0-9\b]+$/)) {
                        quantityValid = true
                    }
                    //(/^[0-9]+$/);   
                    //console.log("aa checking * quaval", quantityValid);
                    fieldValidationErrors.quantity = quantityValid ? '' : ' is InCorrect';
                    // quantityValid=true;
                    //console.log("checking * quaval", quantityValid);
                    this.setState({ rate: '' })
                }
                break;
            default:
                break;
        }
        //console.log("is quantity valid", quantityValid);

        if (quantityValid == true) {
            //console.log("is value value88", value);
            var quantity = value;

            this.state.rate = Number(this.state.ratePerUnit) * Number(quantity); //1-quantity

            this.state.rate = Truncate_2DecimalPlaces(this.state.rate);

            //console.log("quantity set ***rate ", this.state.rate);
            this.setState({
                quantity: quantity,
                rate: this.state.rate
            })

            //console.log("is quantity rate", this.state.rate);
        }
        this.setState({
            formErrors: fieldValidationErrors,
            quantityValid: quantityValid
            //  hsnCodeValid:hsnCodeValid,	
        }, this.validateForm);
    }
    validateForm() {
        this.setState({
            formValid:
                this.state.productdetailValid
                && this.state.quantityValid
        });
        //console.log("quantityValid", this.state.quantityValid)
        //console.log("productdetailValid", this.state.productdetailValid)
    }

    /*HANDLE ADDTOCARTFUNC THE PRODUCT SELECTION,RATE WITH TAX CALCULATION 
    SET & POPUP THE TAX,TOTAL RATE FIELDS IN UI- IMPLEMENTED BY DURGA 28-04-2022 */
    AddtoCartFunc() {
        $("#submit").prop("disabled", false);
        //console.log("this.state.quantity", this.state.quantity);
        var self = this;
        ////console.log("this.state.prodectname",this.state.selectedProductName) ;

        this.state.productName = this.state.selectedProductName.label;
        this.state.productCode = this.state.selectedProductName.value;

        //TO CHECK IF THE PRODCUT IS ALREADY EXIST IN CART OR NOT! //
        var cartDataCopy = [...this.state.cartData];
        var index = _.findIndex(cartDataCopy, { ProductCode: this.state.productCode });
        //console.log("index", index);


        if (index != -1) {
            Swal.fire({
                position: 'center',
                icon: 'info',
                title: 'Product Already Exist on Cart',
                text: 'Do You Want to Update Qty! ',
                showConfirmButton: true,
                showCancelButton: true,
                confirmButtonText: 'Yes,Update!',
                cancelButtonText: 'No, keep it'
            }).then((result) => {
                if (result.value) {
                    //console.log(result.value);
                    //console.log("print", cartDataCopy[index], cartDataCopy[index].Quantity);

                    cartDataCopy[index].Quantity = Number(cartDataCopy[index].Quantity) + Number(this.state.quantity); //add current quantity with existing quantity

                    var Recalculate = Number(cartDataCopy[index].RatePerUnit) * Number(this.state.quantity); // add newrate with existing rate
                    Recalculate = Truncate_2DecimalPlaces(Recalculate);
                    cartDataCopy[index].Rate = Number(cartDataCopy[index].Rate) + Number(Recalculate);
                    cartDataCopy[index].Rate = Truncate_2DecimalPlaces(cartDataCopy[index].Rate);

                    cartDataCopy[index].TotalAmount = Number(cartDataCopy[index].Rate);

                    var currentgstTax = Number(cartDataCopy[index].GstTax) * Number(this.state.quantity);
                    cartDataCopy[index].GstTax = Number(cartDataCopy[index].GstTax) + Number(currentgstTax)
                    cartDataCopy[index].GstTax = Truncate_2DecimalPlaces(cartDataCopy[index].GstTax);


                    cartDataCopy[index].AmountToBePaid = Number(cartDataCopy[index].AmountToBePaid) + (Number(Recalculate) + Number(currentgstTax));
                    cartDataCopy[index].AmountToBePaid = Truncate_2DecimalPlaces(cartDataCopy[index].AmountToBePaid);

                    this.setState({ cartData: cartDataCopy })
                    //console.log("add quantity", cartDataCopy);
                    //console.log("add quantity", this.state.cartData);

                    this.state.totalAmount = Number(this.state.totalAmount) + Number(Recalculate);
                    this.state.totalAmount = Truncate_2DecimalPlaces(this.state.totalAmount);

                    this.state.gstTax = Number(this.state.gstTax) + Number(currentgstTax);
                    this.state.gstTax = Truncate_2DecimalPlaces(this.state.gstTax);

                    this.state.amountToBePaid = Number(this.state.amountToBePaid) + (Number(Recalculate) + Number(currentgstTax));
                    this.state.amountToBePaid = Truncate_2DecimalPlaces(this.state.amountToBePaid);

                    this.setState({
                        totalAmount: this.state.totalAmount,
                        gstTax: this.state.gstTax,
                        amountToBePaid: this.state.amountToBePaid,
                    })
                    this.productCancel();

                }
                else {
                    this.productCancel();
                }
            })
        }
        else {

            //TOTAL ITEM ON CART CALCULATION//
            this.state.totalIteminCart = this.state.totalIteminCart + 1;

            //CODE FOR CALCULATING RATEWITHTAX BY USING 3 TAX FRM DATA ARRAY IMPLEMENTED BY DURGA 27-04-2022 */
            //FORMULA= Rate+( (Rate*cgst%/100) + (Rate*sgst%/100) + (Rate*igst%/100) );
            // var productRateTemp=Truncate_2DecimalPlaces( Number(parseInt(productDetails.rate))+(
            // (productDetails.rate*productDetails.cgst/100)+
            // (productDetails.rate*productDetails.sgst/100)+
            // (productDetails.rate*productDetails.igst/100)));

            //Total Amount-[RATE*QUANTITY]
            //GST Tax-[SUMMATION OF TOTAL TAX PER PRODUCT]
            //Amount to be paid-[SUMMATION OF TOTAL AMOUNT + SUMMATION OF GSTTAX]
            //Total Item on Cart-[NUMBER OF ITEMS IN CART]

            //TOTAL AMOUNT CALCULATION//
            //console.log("this.state.totalAmount b4", this.state.totalAmount);
            this.state.totalAmount = Number(this.state.totalAmount) + Number(this.state.rate);
            this.state.totalAmount = Truncate_2DecimalPlaces(this.state.totalAmount);

            //console.log("this.state.totalAmount after", this.state.totalAmount);

            //TOTAL GST CALCULATION//
            //console.log("this.state.gstTax b4", this.state.gstTax);

            var CGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.cgst)) / 100;
            this.state.CGSTAmount = Truncate_2DecimalPlaces(CGSTAmount);

            var SGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.sgst)) / 100;
            this.state.SGSTAmount = Truncate_2DecimalPlaces(SGSTAmount);

            var IGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.igst)) / 100;
            this.state.IGSTAmount = Truncate_2DecimalPlaces(IGSTAmount);

            // this.state.gstTax=CGSTAmount+SGSTAmount;
            //         if(IGSTAmount!=0)
            //         {
            //             this.state.gstTax=IGSTAmount;
            //         }

            var currentgstTax = (CGSTAmount + SGSTAmount + IGSTAmount) * self.state.quantity; //AS OF 3 TAX ADDING FUTURE CHANGE BASED ON REGION SELECTION
            currentgstTax = Truncate_2DecimalPlaces(currentgstTax);

            this.state.gstTax = Number(this.state.gstTax) + Number(currentgstTax);

            this.state.gstTax = Truncate_2DecimalPlaces(this.state.gstTax);
            //console.log("this.state.gstTax after", this.state.gstTax);

            //AMOUNT TO BE PAID CALCULATION//

            //console.log("amountToBePaid b4", this.state.amountToBePaid);
            var currentamountToBePaid = Number(this.state.rate) + Number(currentgstTax);

            //console.log("currentamountToBePaid", currentamountToBePaid);

            this.state.amountToBePaid = Number(this.state.amountToBePaid) + currentamountToBePaid;
            this.state.amountToBePaid = Truncate_2DecimalPlaces(this.state.amountToBePaid);

            //console.log("amountToBePaid after", this.state.amountToBePaid);

            this.setState({
                productName: this.state.productName,
                productCode: this.state.productCode,
                totalIteminCart: this.state.totalIteminCart,

                CGSTAmount: this.state.CGSTAmount,
                IGSTAmount: this.state.IGSTAmount,
                SGSTAmount: this.state.SGSTAmount,

                totalAmount: this.state.totalAmount,
                gstTax: this.state.gstTax,
                amountToBePaid: this.state.amountToBePaid,
            })

            var newCartData = {
                ProductName: this.state.productName,
                ProductCode: this.state.productCode,
                ProductId: this.state.productId,
                HSNCode: this.state.hsnCode,
                Rate: this.state.rate,
                Quantity: this.state.quantity,
                CGST: this.state.cgst,
                SGST: this.state.sgst,
                IGST: this.state.igst,
                RatePerUnit: this.state.ratePerUnit,
                TotalAmount: this.state.rate,
                GstTax: currentgstTax,
                AmountToBePaid: currentamountToBePaid,
            }

            this.state.cartData.unshift(newCartData); //unshift-adds new items to the beginning of an array
            this.setState({ cartdata: this.state.cartdata })
            this.productClear();

        }

        this.state.formValid = false;
        this.state.submitValid = true;

        this.setState({
            formValid: false,
            submitValid: true,
        })
    }
    //CLEAR THE FIELDS FOR PRODUCT WHEN CLICKS THE CANCEL BUTTON -- IMPLEMENTED BY RAMYA 15-05-2022
    productCancel() {
        this.productClear();
        // $("#AddtoCart").prop("disabled", true);
    }
    //CLEAR THE FIELDS FOR PRODUCT -- IMPLEMENTED BY RAMYA 15-05-2022
    productClear() {
        this.state.selectedProductName = "";
        this.state.ratePerUnit = "";
        this.state.rate = "";
        this.state.quantity = "1";
        this.state.cgst = "";
        this.state.sgst = "";
        this.state.igst = "";
        this.state.formValid = false;
        this.setState({
            selectedProductName: this.state.selectedProductName,
            ratePerUnit: this.state.ratePerUnit,
            Rate: this.state.rate,
            Quantity: this.state.quantity,
            CGST: this.state.cgst,
            SGST: this.state.sgst,
            IGST: this.state.igst,
            formValid: false
        })
    }

    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        //console.log("e.target.value;", e.target.value);
        this.setState({ [name]: value },
            () => { this.validateField(name, value) });
    }

    // handleUserInput=(e)=>
    // {

    // //console.log("e",e);
    // if(e.target.name="quantity")
    // {
    //    var quantity=e.target.value;
    //     //console.log("this.state.quantitye",quantity);
    //     this.state.rate=Number(this.state.ratePerUnit) * Number(quantity); //1-quantity
    //     this.state.rate=Truncate_2DecimalPlaces( this.state.rate);

    //     this.setState({quantity:quantity,rate:this.state.rate})
    // }

    // //console.log("this.state.quantity",this.state.quantity);
    // }
    /*HANDLE THE PRODUCT DELETE RESET THE TOTAL AMOUNT,TOTALGST,TOTALITEMINCART-
    IMPLEMENTED BY DURGA 27-04-2022 */

    handleProductDelete = (e) => {
        //  //console.log("e",e.target.id);

        var cartDataCopy = [...this.state.cartData]; // make a separate copy of the array

        var index = _.findIndex(cartDataCopy, { ProductCode: e.target.id });
        //console.log("cartDataCopy", cartDataCopy); //console.log("one", index); //console.log("cartDataCopy", cartDataCopy[index]);

        // Total Amount-Total Amount
        // GST Tax-GST Tax
        // Amount to be paid -Total Amount-GST Tax
        // Total Item on Cart--
        //Truncate_2DecimalPlaces //Number(

        this.state.totalAmount = Number(this.state.totalAmount) - Number(cartDataCopy[index].TotalAmount);
        this.state.totalAmount = Truncate_2DecimalPlaces(this.state.totalAmount);

        this.state.gstTax = Number(this.state.gstTax) - Number(cartDataCopy[index].GstTax);
        this.state.gstTax = Truncate_2DecimalPlaces(this.state.gstTax);

        this.state.amountToBePaid = Number(this.state.amountToBePaid) - Number(cartDataCopy[index].AmountToBePaid);
        this.state.amountToBePaid = Truncate_2DecimalPlaces(this.state.amountToBePaid);

        this.state.totalIteminCart = this.state.totalIteminCart - 1;

        cartDataCopy.splice(index, 1);

        this.setState({
            totalAmount: this.state.totalAmount,
            gstTax: this.state.gstTax,
            amountToBePaid: this.state.amountToBePaid,
            totalIteminCart: this.state.totalIteminCart,
            cartData: cartDataCopy
        })

        //console.log("this.state.imageCartData.length", this.state.imageCartData.length);
        //console.log("this.state.imageCartData", this.state.imageCartData);
        if (cartDataCopy.length == 0 && this.state.imageCartData.length == 0) {
            this.state.submitValid = false;
            this.setState({ submitValid: this.state.submitValid })
        }

    }
    /*USED TO CONVERT THE IMAGE ARRAY AS BLOB - IMPLEMENTED BY DURGA 27-05-2022 */
    /*FUNCTION USED TO HANDLE THE UPLOADED IMAGE(IMAGE/PNG/JPEG)- IMPLEMENTED BY PRIYANKA - 20-04-2022 [From MenuUpload.js ]*/
    ImageConvertasBlob() {
        var self = this;
        //console.log("imageCartData-inside blob convert", this.state.imageCartData);
        var tempimagedata = this.state.imageCartData;
        var convertedimagedata = this.state.imageCartData;

        //console.log("tempimagedata-inside blob convert", tempimagedata);

        for (var i = 0; i < tempimagedata.length; i++) {

            var blobFile = tempimagedata[i].image;
            // quality value for webp and jpeg formats.
            const quality = 80;
            // output width. 0 will keep its original width and 'auto' will calculate its scale from height.
            const width = 200;
            // output height. 0 will keep its original height and 'auto' will calculate its scale from width.
            const height = "auto";
            // file format: png, jpeg, bmp, gif, webp. If null, original format will be used.
            const format = 'png';

            var imageData;

            fromBlob(blobFile, quality, width, height, format).then((blob) => {


                // will generate a url to the converted file
                blobToURL(blob).then((url) => (
                    // self.state.url = url,
                    // self.setState({ url: self.state.url }),
                    // imageData = {
                    //   data: self.state.url,
                    //   size: self.state.convertedFileSize
                    // },
                    //self.state.imageArray.push(imageData),
                    // imageArray.push(self.state.url),
                    //self.setState({ imageArray: self.state.imageArray }) 
                    convertedimagedata[i].image = url
                ))

            });

        }

        //console.log("after-orignal blob convert", tempimagedata);
        //console.log("after blob convert", convertedimagedata);

    }
    /*HANDLE SUMBIT FOR ADD THE NEW QUOTATION - IMPLEMENTED BY DURGA 27-04-2022 */
    handleSubmit = (e) => {

        var self = this;
        //console.log("GetFranchiseId", GetLocalStorageData("FranchiseId"));

        //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 29-04-2022
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        //console.log("dateTimeData :", dateTimeData);
        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.setState({
            date: this.state.date,
            time: this.state.time,
        })
        //console.log("dte time chceck", this.state.date, this.state.time);
        //console.log("this.state.cartData", this.state.cartData);
        //console.log("totalamount", this.state.totalAmount, "this.state.amountToBePaid", this.state.amountToBePaid,
          //  "this.state.gsttax", this.state.gstTax);
        //CONVERTING IMAGE ARRAY AS A BLOB 
        // if(!this.state.imageCartData.length==0)
        // {
        //    this.ImageConvertasBlob();
        // }

        $.ajax({
            type: 'POST',
            data: JSON.stringify({

                companyId: GetLocalStorageData("FranchiseCompanyId"),
                cartProductList: JSON.stringify(this.state.cartData),
                cartImageList: JSON.stringify(this.state.imageCartData),
                date: this.state.date,
                time: this.state.time,
                totalIteminCart: this.state.totalIteminCart,
                totalAmount: this.state.totalAmount,
                amounttobePaid: this.state.amountToBePaid,
                totalGstTax: this.state.gstTax,
                franchiseId: GetLocalStorageData("FranchiseId"),
                userName: GetLocalStorageData("FranchiseUserName"),

            }),
            url: "http://15.206.129.105:8080/IceilLiveAPI/FranchiseQuotationWebService/AddQuotation",
            contentType: "application/json",
            dataType: 'json',
            async: false,

            success: function (data, textStatus, jqXHR) {

                //console.log(data);

                // alert("Quotation Added Successfully!");
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    text: 'Quotation Added Successfully!',
                    showConfirmButton: false,
                    timer: 2000
                })

                self.CancelFunc();

            },
            error: function (data) {
                //console.log("insert error");
            },

        });

        this.state.submitValid = true;
        this.setState({
            submitValid: true,
        })


    }
    /*HANDLE THE PRODUCT SELECTION,RATE & TAX  FIELDS
    SET & POPUP IN UI CANCEL FUNC -IMPLEMENTED BY DURGA 27-04-2022 */

    CancelFunc() {
        $("#submit").prop("disabled", true);
        var self = this;

        // self.state.date='';
        // self.state.time='';
        self.state.quantity = '';
        self.state.totalAmount = '';
        self.state.totalIteminCart = '';
        self.state.amountToBePaid = 0;
        self.state.gstTax = 0;
        self.state.selectedProductName = '';
        self.state.cartData = [];
        self.state.imageCartData = [];

        self.state.ratePerUnit = '';
        self.state.sgst = '';
        self.state.cgst = '';
        self.state.igst = '';
        self.state.rate = '';

        self.setState({
            ratePerUnit: self.state.ratePerUnit,
            sgst: self.state.sgst,
            cgst: self.state.cgst,
            igst: self.state.igst,
            rate: self.state.rate,
            // date:self.state.date,
            // time:self.state.time,
            quantity: self.state.quantity,
            totalAmount: self.state.totalAmount,
            totalIteminCart: self.state.totalIteminCart,
            amountToBePaid: self.state.amountToBePaid,
            gstTax: self.state.gstTax,
            selectedProductName: self.state.selectedProductName,
            cartData: self.state.cartData,
            imageCartData: self.state.imageCartData,
        })
        //console.log("B4 CANCEL INDEX DB DATA-imageCartData", self.state.imageCartData);

        //USED FOR CLEAR IMAGE CART DATA AFTER QUOTATION SUBMIT
        window.FranchiseQuotationImageComponent.RenderImage(self.state.imageCartData);
        //console.log("B4 CANCEL INDEX DB DATA");
        //FUNCTION USED FOR CLEARING INDEXED DB AFTER QUOTATION SUBMIT
        ClearTable(tableName);
    }
    /*HANDLE SUBMIT BUTTON ENABLE/DISABLE BASED ON IMAGE DELETE FUNC -IMPLEMENTED BY DURGA 11-06-2022 */
    SetSubmitValid(tempimageCartData) {
        //console.log("tempimageCartData", tempimageCartData);
        this.setState({ imageCartData: tempimageCartData })
        //console.log("self.state.imageCartData", this.state.imageCartData);
        if (this.state.cartData.length == 0) {
            this.state.submitValid = false;
            this.setState({ submitValid: this.state.submitValid })
        }

    }

    render() {
        return (
            <div className="mt-40">
                <div className="row">
                    <div className="col-md-3">
                        <label>Product <span class="mandatoryfields">*</span></label>
                        <div>
                            {/* FIELD USED TO create Product - it's non-mandatory field */}
                            <SelectSearch options={this.state.productOptions} value={this.state.selectedProductName}
                                // isMulti={false}
                                onChange={(e) => this.handleProductDetails(e)} name="productName" placeholder="Select Product" />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <label>Rate/Unit</label>
                        <div>
                            {/* FIELD USED TO create Rate/Unit - it's mandatory field  */}
                            <input className="textfield" type="number" value={this.state.ratePerUnit} id="ratePerUnit" name="ratePerUnit" readOnly />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <label>Quantity <span class="mandatoryfields">*</span></label>
                        <div>
                            {/* FIELD USED TO create quantity - it's mandatory field min="1" */}
                            <input className="textfield" type="text" maxlength="4" onChange={this.handleUserInput} value={this.state.quantity} id="quantity" name="quantity" />

                            <ErrorClass errorContent={this.state.formErrors.quantity} />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <label>SGST(%)</label>
                        <div>
                            {/* FIELD USED TO create sGST(%) - it's mandatory field  */}
                            <input className="textfield" type="number" value={this.state.sgst} id="sgst" name="sgst" readOnly />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <label>CGST(%)</label>
                        <div>
                            {/* FIELD USED TO create CGST(%) - it's mandatory field  */}
                            <input className="textfield" type="number" value={this.state.cgst} id="cgst" name="cgst" readOnly />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <label>IGST(%)</label>
                        <div>
                            {/* FIELD USED TO create iGST(%) - it's mandatory field  */}
                            <input className="textfield" type="number" value={this.state.igst} id="igst" name="igst" readOnly />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <label>Rate</label>
                        <div>
                            {/* FIELD USED TO create Rate - it's mandatory field  */} {/*AddtoCartFunc*/}
                            <input className="textfield" type="number" id="rate" value={this.state.rate} name="rate" readOnly />
                        </div>
                    </div>
                    <div className="text-center mt-40">

                        <button className="btn btn-primary btn-submit" id="AddtoCart" onClick={() => this.AddtoCartFunc()} disabled={!this.state.formValid} ><i class="fa fa-cart-plus" aria-hidden="true" ></i> Add to cart</button>
                        <button className="btn btn-primary btn-cancel" onClick={() => this.productCancel()}><i class="fa fa-times" aria-hidden="true"></i> Cancel</button>
                    </div>
                </div>
                <div className="row card-box mt-40">
                    <div className="col-md-3">
                        <label>Total Amount</label>
                        <div>
                            {/* FIELD USED TO create Total Amount */}
                            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" />
                        </div></div>
                    <div className="col-md-3">
                        <label>GST Tax</label>
                        <div>
                            {/* FIELD USED TO create GST Tax */}
                            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.gstTax} id="gstTax" name="gstTax" />
                        </div></div>
                    <div className="col-md-3">
                        <label>Amount to be paid</label>
                        <div>
                            {/* FIELD USED TO create Amount to be paid*/}
                            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.amountToBePaid} id="amountToBePaid" name="amountToBePaid" />
                        </div></div>
                    <div className="col-md-3">
                        <label>Total Item on Cart</label>
                        <div>
                            {/* FIELD USED TO create Total Amount */}
                            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.totalIteminCart} id="totalIteminCart" name="totalIteminCart" />
                        </div></div>

                </div>
                <FranchiseQuotationImage SetSubmitValid={this.SetSubmitValid} ImageCartDBData={this.state.imageCartData} />
                {/* <FranchiseQuotationProduct /> */}
                {
                    this.state.cartData.map((element) => (
                        <div className="row mt-20 card-box Quotationproduct">
                            <div className="col-md-6">
                                <div className="row quotation-card-box">
                                    <div className="col-md-6">
                                        <label>Product Name</label>
                                        <div>
                                            {/* FIELD USED TO create Product */}
                                            <input className="textfield" type="text" onChange={this.handleUserInput} value={element.ProductName} id="product" name="product" readOnly />
                                        </div></div>
                                    <div className="col-md-6">
                                        <label>Product Code </label>
                                        <div>
                                            {/* FIELD USED TO create Product Code */}
                                            <input className="textfield" type="text" onChange={this.handleUserInput} value={element.ProductCode} id="productCode" name="productCode" readOnly />
                                        </div></div>
                                    <div className="col-md-6">
                                        <label>Rate </label>
                                        <div>
                                            {/* FIELD USED TO create Rate  */}
                                            <input className="textfield" type="text" onChange={this.handleUserInput} value={element.Rate} id="rate" name="rate" readOnly />
                                        </div></div>
                                    <div className="col-md-6">
                                        <label>HSN Code</label>
                                        <div>
                                            {/* FIELD USED TO create HSN Code  */}
                                            <input className="textfield" type="text" onChange={this.handleUserInput} value={element.HSNCode} id="hsnCode" name="hsnCode" readOnly />
                                        </div></div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="quotation-card-box">
                                    <table className="table">
                                        <tbody>
                                            <tr>
                                                <td>Rate/Unit</td>
                                                <td>{element.RatePerUnit}</td>
                                            </tr>
                                            <tr>
                                                <td>Quantity</td>
                                                <td>{element.Quantity}</td>
                                            </tr>
                                            <tr>
                                                <td>CGST(%)</td>
                                                <td>{element.CGST}</td>
                                            </tr>
                                            <tr>
                                                <td>SGST(%)</td>
                                                <td>{element.SGST}</td>
                                            </tr>
                                            <tr>
                                                <td>IGST(%)</td>
                                                <td>{element.IGST}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div className="text-center">
                                <button className="btn btn-primary btn-submit" id={element.ProductCode} onClick={this.handleProductDelete}>Delete</button>
                            </div>
                        </div>
                    ))
                }
                <div className="text-center mt-20">
                    {/* <button id="submit" className="btn btn-primary btn-submit"  onClick={this.handleSubmit}>Submit</button> */}
                    <button id="submit" className="btn btn-primary btn-submit" disabled={!this.state.submitValid} onClick={this.handleSubmit}>Submit</button>
                    <button className="btn btn-primary btn-cancel" onClick={this.CancelFunc}>Cancel</button>
                </div>
            </div>
        )
    }
}
export default Quotation;
