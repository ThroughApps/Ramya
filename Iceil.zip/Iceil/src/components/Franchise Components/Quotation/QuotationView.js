 //IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import $ from 'jquery';
import _ from 'underscore';
import Swal from 'sweetalert2/dist/sweetalert2.js';
// import statement for image
import image1 from '../../images/image1.png'
import { GetLocalStorageData } from "../../Common Components/CommonComponents";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022
class QuotationView extends React.Component{
       constructor(){
         super();      
    this.state= {
        cartData:[],
        imageCartData:[],
        quotationNo:'',
        status:'',
        submittedDate:'',
        totalIteminCart:'',
        totalAmount:'',
        gstTax:'',
        amountPaid:'',
        }
    }
componentDidMount()
{
    console.log(this.props.selectedData);
    this.GetData();
}

/* USED TO GET THE QUOTATION DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 29-04-2022 */
GetData()
{
var self=this;
$.ajax({
    type: 'POST',
    data: JSON.stringify({
        quotationNo: this.props.selectedData.quotationNo,
        companyId: GetLocalStorageData("FranchiseCompanyId"),
    }),
    
    url: "http://15.206.129.105:8080/IceilLiveAPI/FranchiseQuotationWebService/SelectQuotation",
    contentType: "application/json",
    dataType: 'json',
    async: false,
    crossDomain:true, 
    success: function (data, textStatus, jqXHR) {
    console.log("data",data.viewQuotationList);
    
        if(data.viewQuotationList!=null|| data.viewQuotationList!=undefined)
        {
        
            var productQuotationList = _.where(data.viewQuotationList, { type: "Product" });
            var ImageQuotationList = _.where(data.viewQuotationList, { type: "Image" });

            var cartDataCopy=productQuotationList;

            self.state.quotationNo= data.viewQuotationList[0].quotationNo;

            self.state.status= data.viewQuotationList[0].status;

        if (self.state.status == 0) {//Status= 0 - Quotation submitted 

            self.state.status = 'Submitted';
            }
            else if(self.state.status== 1) {//Status=1 - Cancelled  
            self.state.status = 'Cancelled';
            }
            else if(self.state.status == 2) { //Status=2 - Accepeted-inprogress 
            self.state.status = 'Inprogress';
            }
            else if(self.state.status == 3) {//Status=3 - Completed    
            self.state.status = 'Completed';
            }
            else if(self.state.status == 4) { //Status=4 - Edited
            self.state.status = 'Edited';
            }                
            self.state.submittedDate= data.viewQuotationList[0].date;
            self.state.totalIteminCart= data.viewQuotationList[0].totalIteminCart;
            self.state.totalAmount= data.viewQuotationList[0].totalAmount;
            self.state.gstTax= data.viewQuotationList[0].totalGstTax;
            self.state.amountPaid= data.viewQuotationList[0].amounttobePaid;

            self.setState({
                imageCartData:ImageQuotationList,
                cartData:cartDataCopy,
                quotationNo:self.state.quotationNo,
                status:self.state.status,
                submittedDate:self.state.submittedDate,
                totalIteminCart:self.state.totalIteminCart,
                totalAmount:self.state.totalAmount,
                gstTax:self.state.gstTax,
                amountPaid:self.state.amountPaid,

            })

            console.log("this.state.cartdata",self.state.cartData);
        }

    },
error: function (data) {
    Swal.fire({
    position: 'center',
    icon: 'error',
    title: 'Network Connection Problem',
    showConfirmButton: false,
    timer: 2000
    })
},
});


}

    render(){
        return( 
<div className="container-fluid">
    <div className="row">
         
            <div className="col-md-3">
            <label>Quotation No</label>    
            <div>      
            {/* FIELD USED TO VIEW Quotation No */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.quotationNo} id="quotationNo" name="quotationNo" readOnly />
            </div>
            </div>
            <div className="col-md-3"><label>Status</label>    
            <div>      
            {/* FIELD USED TO VIEW Status  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.status} id="status" name="status" readOnly />
            </div></div>
            <div className="col-md-3"><label>Submitted Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Submitted Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.submittedDate} id="submittedDate" name="submittedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Accepted Date </label>    
            <div>      
            {/* FIELD USED TO VIEW Accepted Date  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.acceptedDate } id="acceptedDate" name="acceptedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Completed Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Completed Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.completedDate} id="completedDate" name="completedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Cancelled Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Submitted Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.cancelledDate} id="cancelledDate" name="cancelledDate" readOnly />
            </div>
            </div>
            </div>
            <div className="row card-box">
             <div className="col-md-3">
            <label>Total Amount</label>    
            <div>      
            {/* FIELD USED TO view Total Amount */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>GST Tax</label>    
            <div>      
            {/* FIELD USED TO view GST Tax */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.gstTax} id="gstTax" name="gstTax" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Amount to be paid</label>    
            <div>      
            {/* FIELD USED TO view Amount to be paid*/}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.amountPaid} id="amountPaid" name="amountPaid" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Total Item on Cart</label>    
            <div>      
            {/* FIELD USED TO view Total Amount */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalIteminCart} id="totalIteminCart" name="totalIteminCart" readOnly/>
            </div></div>
  
            </div>
            {
             this.state.imageCartData.map((imageElement)=>(
            <div className="row mt-20 card-box Quotationimage">
            <div className="col-md-6">
                <div className="row quotation-card-box">
            <div class="col-md-6 text-center">
                <div class="card-box-img">
                    <img src={imageElement.imageData} />                    
                    </div>
                    </div>
                    <div class="col-md-6 text-left mt-20">
                    <p>Image Type: <span>Nature</span><br/>Image Pixel: <span>307 * 170</span><br/>Rate: <span>400</span></p>
                    </div>
                </div>
                </div>
                <div className="col-md-6">
                <div className="quotation-card-box">
            <table className="table">
                <tbody>
                    <tr>
                        <td>Rate/Unit</td>
                        <td>150</td>
                    </tr>
                    <tr>
                        <td>Quantity</td>
                        <td>15</td>
                    </tr>
                    <tr>
                        <td>CGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>SGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>IGST(%)</td>
                        <td>14</td>
                    </tr>
                </tbody>
            </table>
            </div>
            </div>
            </div>
            ))
            }
   
            {
                this.state.cartData.map((element) =>(
                     <div className="row mt-20 card-box Quotationproduct">
                        <div className="col-md-6">
                            <div className="row quotation-card-box">
                            <div className="col-md-6">
                        <label>Product Name</label>    
                        <div>      
                        {/* FIELD USED TO create Product */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.productName} id="product" name="product" readOnly/>
                        </div></div>
                        <div className="col-md-6">
                        <label>Product Code </label>    
                        <div>      
                        {/* FIELD USED TO create Product Code */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.productCode} id="productCode" name="productCode" readOnly/>
                        </div></div> 
                        <div className="col-md-6">
                        <label>Rate </label>    
                        <div>      
                        {/* FIELD USED TO create Rate  */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.rate} id="rate" name="rate" readOnly/>
                        </div></div>   
                        <div className="col-md-6">
                        <label>HSN Code</label>    
                        <div>      
                        {/* FIELD USED TO create HSN Code  */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.hsnCode} id="hsnCode" name="hsnCode" readOnly/>
                        </div></div>     
                            </div>
                            </div>
                            <div className="col-md-6">
                            <div className="quotation-card-box">
                        <table className="table">
                            <tbody>
                                <tr>
                                    <td>Rate/Unit</td>
                                    <td>{element.ratePerUnit}</td>
                                </tr>
                                <tr>
                                    <td>Quantity</td>
                                    <td>{element.quantity}</td>
                                </tr>
                                <tr>
                                    <td>CGST(%)</td>
                                    <td>{element.cgst}</td>
                                </tr>
                                <tr>
                                    <td>SGST(%)</td>
                                    <td>{element.sgst}</td>
                                </tr>
                                <tr>
                                    <td>IGST(%)</td>
                                    <td>{element.igst}</td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                        </div>
                        
                        </div>
                ))
            }                       
    </div>
        );
    }
}
export default QuotationView;
