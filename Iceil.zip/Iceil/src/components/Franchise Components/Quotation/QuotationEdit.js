//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
// import statement for image

import {QuotationImage, QuotationProduct} from './QuotationComponent';

class QuotationEdit extends React.Component{
       constructor(){
         super();      
    this.state= {

        }
    }
    render(){
        return( 
<div className="container-fluid">
    <div className="row">
            <div className="col-md-3">
            <label>Franchise</label>    
            <div>      
            {/* FIELD USED TO VIEW Franchise */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.franchise} id="franchise" name="franchise" readOnly />
            </div>
            </div>
            <div className="col-md-3">
            <label>Quotation No</label>    
            <div>      
            {/* FIELD USED TO VIEW Quotation No */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.quotationNo} id="quotationNo" name="quotationNo" readOnly />
            </div>
            </div>
            <div className="col-md-3"><label>Status</label>    
            <div>      
            {/* FIELD USED TO VIEW Status  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.status} id="status" name="status" readOnly />
            </div></div>
            <div className="col-md-3"><label>Submitted Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Submitted Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.submittedDate} id="submittedDate" name="submittedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Accepted Date </label>    
            <div>      
            {/* FIELD USED TO VIEW Accepted Date  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.acceptedDate } id="acceptedDate" name="acceptedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Completed Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Completed Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.completedDate} id="completedDate" name="completedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Cancelled Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Submitted Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.cancelledDate} id="cancelledDate" name="cancelledDate" readOnly />
            </div>
            </div>
            </div>
            <div className="row card-box">
             <div className="col-md-3">
            <label>Total Amount</label>    
            <div>      
            {/* FIELD USED TO edit Total Amount */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>GST Tax</label>    
            <div>      
            {/* FIELD USED TO edit GST Tax */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.gstTax} id="gstTax" name="gstTax" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Amount to be paid</label>    
            <div>      
            {/* FIELD USED TO edit Amount to be paid*/}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.amountPaid} id="amountPaid" name="amountPaid" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Total Item on Cart</label>    
            <div>      
            {/* FIELD USED TO edit Total Amount */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" readOnly/>
            </div></div>
  
            </div>
            <QuotationImage />
            <QuotationProduct />
   <div className="text-center mt-20">
                <button className="btn btn-primary btn-submit">Submit</button>
                <button className="btn btn-primary btn-cancel">Cancel</button>
            </div>
    </div>
        );
    }
}

export default QuotationEdit;