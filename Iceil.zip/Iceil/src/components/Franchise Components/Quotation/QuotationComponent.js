//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from "react";
import Modal from 'react-modal';
import '../../StyleCss.css';
// import statement for image
import image1 from '../../images/image1.png'
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import _ from 'underscore';

import * as FiIcons from 'react-icons/fi';
import ReactTooltip from 'react-tooltip';
import SlidingPane from "react-sliding-pane";
import EditImage from "../../Franchise Components/ChooseYour Image/EditImage";
// import statement for react class component
import {EditImageIcon} from '../../Assets Components/Icon Components/Iconcomponents';
import { Truncate_2DecimalPlaces} from "../../Validation Components/FormErrors";
import { ErrorClass } from '../../Validation Components/Loginvalidation';
const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    }
};
/**CLASS COMPONENTS ,FUNCTION NAME AND ITS STRUCTURE ARE DONE BY UI TEAM FUNCTIONS IMPLEMENTED BY DURGA** */
export class QuotationImage extends React.Component{
constructor(){
         super();  
         window.QuotationImageComponent=this;  
    this.state= {
        formErrors: {
            cgst: '',
            sgst: '',
            igst: '',
            hsnCode:'',
            quantity:'',
            rate:'',
            ratePerUnit:'',
        },
        cgstValid:true,
        sgstValid:true,
        igstValid:true,
        hsnCodeValid:true,
        quantityValid:true,
        rateValid:true,
        ratePerUnitValid:true,
        imageCartData:[],
        quotationEditmodalIsOpen: false,
        quotationEditproductmodalIsOpen: false,        
        }
        this.SetImageList=this.SetImageList.bind(this);
        this.editImage = this.editImage.bind(this);
}
componentDidMount()
    {
        var self=this;
        self.state.imageCartData=this.props.imageCartData;
        self.setState({
            imageCartData: self.state.imageCartData
        })
}
/* USED TO GET THE IMAGE CART DATA FROM QUOTATION Edit COMPONENTS- IMPLEMENTED BY DURGA 29-04-2022 */
SetImageList(imageCartData)
{
    var self=this;
    console.log("this.state.props",imageCartData);
    self.state.imageCartData=imageCartData;
    self.setState({
        imageCartData:self.state.imageCartData
    })
}
editImage(){
    var self= this;
    console.log("editImage wprks fine");
    self.state.quotationEditmodalIsOpen = true;
    self.setState({
        quotationEditmodalIsOpen: self.state.quotationEditmodalIsOpen
    })
}
closeModalQuotationEdit(){
    var self = this;

    self.state.quotationEditmodalIsOpen = false;
    self.state.quotationEditcloseModal = true;


    self.setState({
        quotationEditmodalIsOpen: self.state.quotationEditmodalIsOpen,
        quotationEditcloseModal: self.state.quotationEditcloseModal
    })
}
handleUserInput(e) {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({ [name]: value },
        () => { this.validateField(name, value) });
        //this.props.ImageReplaceNewValueFunc
}
validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let cgstValid=this.state.cgstValid;
    let igstValid=this.state.igstValid;
    let sgstValid=this.state.sgstValid;       
    let rateValid=this.state.rateValid;
    let ratePerUnitValid=this.state.ratePerUnitValid;
    let hsnCodeValid=this.state.hsnCodeValid;
    let quantityValid=this.state.quantityValid;
    switch (fieldName) {
        case 'sgst':
            if (value.length>5)
            {
                fieldValidationErrors.sgst = 'Sorry! You are Exceeding the Limit'; 
                sgstValid=false;
            }
            else if(value.length>0 && value.length<=5)
            {
            if(value<100)
            {
            sgstValid=value.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/);
            fieldValidationErrors.sgst = sgstValid ? '' : ' is InCorrect';
            }
            else
            {
                fieldValidationErrors.sgst ='Percentage Should be in the Range of 100 [Numbers & Decimals] Only!';  
                sgstValid=true; 
            }
            }
            else
            {
                fieldValidationErrors.sgst = ''; 
                sgstValid=true; 
            }
            break;
        case 'igst':
                if (value.length>5)
                {
                fieldValidationErrors.igst = 'Sorry! You are Exceeding the Limit'; 
                igstValid=false;
                }
                else if(value.length>0 && value.length<=5)
                {
                if(value<100)
                {
                    igstValid=value.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/);  
                    fieldValidationErrors.igst = igstValid ? '' : ' is InCorrect';
                }
                else
                {
                    fieldValidationErrors.igst = 'Percentage Should be in the Range of 100 [Numbers & Decimals] Only!';  
                    igstValid=false;
                }

                }
                else{
                fieldValidationErrors.igst = ''; 
                igstValid=true;
                
                }
                break;
        case 'cgst':
                if (value.length>5)
                {
                fieldValidationErrors.cgst = 'Sorry! You are Exceeding the Limit'; 
                cgstValid=false;
                }
                else if(value.length>0 && value.length<=5)
                {
                if(value<100)
                {
                cgstValid=value.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/);   // /^[0-9]*$/ ...^[1-9]\d*(\.\d+)?$    /^[1-2]\d*(\.\d+)?$/
                fieldValidationErrors.cgst = cgstValid ? '' : ' is InCorrect';
                }
                else
                {
                    fieldValidationErrors.cgst = 'Percentage Should be in the Range of 100 [Numbers & Decimals] Only!';  
                cgstValid=false;
                }
                }
                else
                {
                fieldValidationErrors.cgst = ''; 
                cgstValid=true;
                }
                break;
        case 'hsnCode':
                if(value.length>49 )
                {
                    fieldValidationErrors.hsnCode='Sorry! You are Exceeding the Limit';
                }
                
                else{
                    hsnCodeValid=true;
                    fieldValidationErrors.hsnCode='';
                }
            break;
        case 'rate':
                if (value>1000000)
                    {
                            fieldValidationErrors.rate = 'Sorry! You are Exceeding the Limit'; 
                            rateValid= false;
                    }
                    else if(value.length>0 && value.length<=7)
                    {
                        rateValid = value.match(/^[0-9]*$/);
                        fieldValidationErrors.rate = rateValid ? '' : ' is InCorrect';
                    }
                    else
                    {
                        fieldValidationErrors.rate= ''; 
                            rateValid = true;
                    }
                break;
        case 'ratePerUnit':
                    if (value>1000)
                        {
                                fieldValidationErrors.ratePerUnit = 'Sorry! You are Exceeding the Limit'; 
                                ratePerUnitValid= false;
                        }
                        else if(value.length>0 && value.length<=4)
                        {
                            ratePerUnitValid = value.match(/^[0-9]*$/);
                            fieldValidationErrors.ratePerUnit = ratePerUnitValid ? '' : ' is InCorrect';
                        }
                        else
                        {
                            fieldValidationErrors.ratePerUnit= ''; 
                            ratePerUnitValid = true;
                        }
                    break;
        case 'quantity':
                        if (value>1000)
                        {
                            fieldValidationErrors.quantity = 'Sorry! You are Exceeding the Limit'; 
                            quantityValid=false;
                        }
                        else if(value.length>0 && value.length<=4)
                        {
                            
                            quantityValid=value.match(/^[0-9]+$/);   ///^[0-9]*$/
                            fieldValidationErrors.quantity = quantityValid ? '' : ' is InCorrect';
                        }
                        else{
                            fieldValidationErrors.quantity = ''; 
                            quantityValid=true;
                        }
                        break;
        default:
        break;
    }
    this.setState({
        formErrors: fieldValidationErrors,
        sgstValid:sgstValid,
        cgstValid:cgstValid,
        igstValid:igstValid,
        rateValid:rateValid,
        ratePerUnitValid:ratePerUnitValid,
        hsnCodeValid:hsnCodeValid,
    }, this.validateForm);
 }
validateForm() {

this.setState({
    formValid:
    this.state.sgstValid
    && this.state.cgstValid
    && this.state.igstValid
    && this.state.rateValid
    && this.state.ratePerUnitValid
    && this.state.hsnCodeValid
});
}
render(){
        return( 
            <div>
            {
                this.state.imageCartData.map((imageElement) => (
                <div className="row mt-20 card-box Quotationimage">
                    <div className="col-md-6">
                        <div className="row quotation-card-box">
                    <div class="col-md-6 text-center">
                        <div class="card-box-img">
                            <img src={imageElement.imageData} />  
                            {/* <div className="img-editicon">               
                        <EditImageIcon onEditImage={this.editImageIcon} />     
                        </div>  */}
                            </div>
                            </div>
                            <div class="col-md-6 text-left mt-20">
                            <p>Image Type: <span>Nature</span><br/>Image Pixel: <span>307 * 170</span><br/>Rate: <span>400</span></p>
                            </div>
                        </div>
                        </div>
                        <div className="col-md-6">
                        <div className="quotation-card-box">
                    <table className="table">
                        <tbody>
                            <tr>
                                <td>Rate/Unit</td>
                                <td>150</td>
                            </tr>
                            <tr>
                                <td>Quantity</td>
                                <td>15</td>
                            </tr>
                            <tr>
                                <td>CGST(%)</td>
                                <td>14</td>
                            </tr>
                            <tr>
                                <td>SGST(%)</td>
                                <td>14</td>
                            </tr>
                            <tr>
                                <td>IGST(%)</td>
                                <td>14</td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                    </div>
                    <div className="text-center">
                        <button className="btn btn-primary btn-submit" onClick={this.editImage}>Edit Image</button>
                    </div>


                    {/* edit product */}
                    <Modal isOpen={this.state.quotationEditmodalIsOpen}
                        //  onAfterOpen={this.customerafterOpenModal}
                        onRequestClose={this.state.quotationEditcloseModal}
                        style={customStyles}
                        contentLabel="Example Modal"
                    >            {/* edit image  */}
                    <div className="container">
                    < div class="updatedevice" id="updatedevice" onClick={() => this.closeModalProductType()} style={{ textAlign: "center" }}><span style={{ fontSize: '1em', color: 'white', float:'right',marginTop:"-30px",marginRight:"-20px" }}>
                            <i class="glyphicon glyphicon-remove" style={{
                                border: "none",
                                padding: "6px 7px 5px 7px",
                                fontSize: "1em",
                                color: "black",
                                borderRadius: "18px",
                            }}>   </i>

                        </span>


                        </div>
                        <h4>Edit-Quotation (Image)</h4>
                   
                
                        <div class="text-center">
                        <button type="button" class="btn-default " onClick={() => this.closeModalQuotationEdit()}
                            style={{
                                borderRadius: "18px",
                                backgroundColor: "#263eac",
                                color: "white",
                                width: "75px",
                                marginTop: "20px"
                            }}>
                            <span class="glyphicon glyphicon-ok" style={{ fontWeight: "800" }} ></span> Ok
                        </button>
                        </div>
                        </div>
                        </Modal>                 
                </div>
                ))
            }
             </div>
        );
}
}
var tempcartData=[];
export class QuotationProduct extends React.Component{
    constructor(){
        super();  
        window.QuotationProductComponent=this;    
   this.state= {
        cartData:[],
        selectedData:[],
        productName:'',
        productCode:'',
        ratePerUnit:'',
        cgst:'',
        sgst:'',
        igst:'',
        rate:'',
        quantity:'',
       quotationId:'',
       formErrors: {
        cgst: '',
        sgst: '',
        igst: '',
        hsnCode:'',
        quantity:'',
        rate:'',
        ratePerUnit:'',
    },
    formValid:true,
    cgstValid:true,
    sgstValid:true,
    igstValid:true,
    hsnCodeValid:true,
    quantityValid:true,
    rateValid:true,
    ratePerUnitValid:true,
    }

       this.editProduct = this.editProduct.bind(this);
   }

componentDidMount()
{
console.log("props stateData",this.props.stateData);
}
/* USED TO GET THE PRODUCT CART DATA FROM QUOTATION Edit COMPONENT- IMPLEMENTED BY DURGA 29-04-2022 */
SetProductList(cartData)
{
    var self=this;
    console.log("this.state.props",cartData);
    self.state.cartData=cartData;
    self.setState({
        cartData:self.state.cartData
    })
}
editProduct(element,productCode) {
    var self = this;

    console.log("testing value",element.quotationNo);
    console.log(productCode,element);
    tempcartData=element;
    self.state.productName=element.productName;
    self.state.productCode=element.productCode;
    self.state.ratePerUnit=element.ratePerUnit;
    self.state.cgst=element.cgst;
    self.state.sgst=element.sgst;
    self.state.igst=element.igst;
    self.state.rate=element.rate;
    self.state.quantity=element.quantity;
    self.state.quotationId=element.quotationId;
    self.state.productId=element.productId;
    self.state.hsnCode=element.hsnCode;
    self.state.selectedData=tempcartData;

    self.setState({
        productName:self.state.productName,
        productCode:self.state.productCode,
        ratePerUnit:self.state.ratePerUnit,
        cgst:self.state.cgst,
        sgst:self.state.sgst,
        igst:self.state.igst,
        rate:self.state.rate,
        quantity:self.state.quantity,
        quotationId:self.state.quotationId,
        productId:self.state.productId,
        hsnCode: self.state.hsnCode,
        selectedData:self.state.selectedData})

    console.log("testing value-tempcartData",self.state.selectedData);
    console.log("testing value-tempcartData",self.state.selectedData.productName);
    
    var index=_.findIndex(this.state.cartData, { ProductCode:  self.state.productCode}); 
    console.log("index",index);

    console.log("wprks not fine 1st time");
    self.state.quotationEditproductmodalIsOpen = true;
    self.setState({
        quotationEditproductmodalIsOpen: self.state.quotationEditproductmodalIsOpen
    })
}
/* USED TO CALCULATE THE PRODUCT TAX AFTER EDIT AND SEND TO QUOTATION Edit COMPONENT- IMPLEMENTED BY DURGA 29-04-2022 */
RateCalculationFunc()
{
    var self=this;
 
//TOTAL ITEM ON CART CALCULATION//
    
//CODE FOR CALCULATING RATEWITHTAX BY USING 3 TAX FRM DATA ARRAY IMPLEMENTED BY DURGA 27-04-2022 //
  //FORMULA= Rate+( (Rate*cgst%/100) + (Rate*sgst%/100) + (Rate*igst%/100) );
  //RATE WITHTAX//
  console.log("b4 rate", self.state.rate);
    //  var productRateTemp=Truncate_2DecimalPlaces( Number(parseInt(self.state.ratePerUnit))+(
    //  (self.state.ratePerUnit*self.state.cgst/100)+
    //  (self.state.ratePerUnit*self.state.sgst/100)+
    //  (self.state.ratePerUnit*self.state.igst/100))); 
    //  self.state.rate=productRateTemp;
    //self.setState({rate:self.state.rate })
    // console.log("rate", self.state.rate);

 //Total Amount-[RATE*QUANTITY]
 //GST Tax-[SUMMATION OF TOTAL TAX PER PRODUCT]
 //Amount to be paid-[SUMMATION OF TOTAL AMOUNT + SUMMATION OF GSTTAX]
 //Total Item on Cart-[NUMBER OF ITEMS IN CART]

 //Total Amount//
   //this.state.rate=this.state.ratePerUnit*this.state.quantity;

//TOTAL GST CALCULATION//
console.log("this.state.gstTax b4",this.state.gstTax);
  var CGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.cgst)) / 100;
  this.state.CGSTAmount = Truncate_2DecimalPlaces(CGSTAmount);

  var SGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.sgst)) / 100;
  this.state.SGSTAmount = Truncate_2DecimalPlaces(SGSTAmount);

  var IGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.igst)) / 100;
  this.state.IGSTAmount = Truncate_2DecimalPlaces(IGSTAmount);


  var currentgstTax=(CGSTAmount+SGSTAmount+IGSTAmount)*self.state.quantity;
  currentgstTax=Truncate_2DecimalPlaces(currentgstTax);

  console.log("currentgstTax",currentgstTax);

  this.state.gstTax=currentgstTax;

 
  //AMOUNT TO BE PAID CALCULATION//
//totalamt,amttobepaid,totaltax,cgctsgst igst

var newCartData = {
    productName: this.state.productName,
    productCode:this.state.productCode,
    productId:this.state.productId,
    hsnCode:this.state.hsnCode,
    rate: this.state.rate,
    cgst:this.state.cgst,
    sgst:this.state.sgst,
    igst:this.state.igst,
    ratePerUnit:this.state.ratePerUnit,
    gstTax:currentgstTax,
    quotationId:this.state.quotationId,
    quantity:this.state.quantity,
  }
//amt tobe paid, cmnyid,date,time,total amount,total gst,totalitemincart 

//hsncode,poductid,quotid, status,
console.log("final-this.state.cartdata", newCartData);
this.props.ReplaceNewValueFunc(newCartData);
}
closeModalQuotationEditproduct() {
    var self = this;
    this.RateCalculationFunc();
    //this.updateQuotation();
    self.state.quotationEditproductmodalIsOpen = false;
    self.state.quotationEditproductcloseModal = true;


    self.setState({
        quotationEditproductmodalIsOpen: self.state.quotationEditproductmodalIsOpen,
        quotationEditproductcloseModal: self.state.quotationEditproductcloseModal
    })
}
handleProductDetails=(e)=>
{
    console.log("printing e",e);
    const name = e.target.name;
    const value = e.target.value;
  
    this.setState({ [name]: value },() => { this.validateField(name, value) });   
}
validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let cgstValid=this.state.cgstValid;
    let igstValid=this.state.igstValid;
    let sgstValid=this.state.sgstValid;       
    let rateValid=this.state.rateValid;
    let ratePerUnitValid=this.state.ratePerUnitValid;
    let hsnCodeValid=this.state.hsnCodeValid;
    let quantityValid=this.state.quantityValid;
    switch (fieldName) {
        case 'sgst':
            if (value.length>5)
            {
              fieldValidationErrors.sgst = 'Sorry! You are Exceeding the Limit'; 
              sgstValid=false;
            }
            else if(value.length>0 && value.length<=5)
          {
            if(value<100)
            {
            sgstValid=value.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/);
            fieldValidationErrors.sgst = sgstValid ? '' : ' is InCorrect';
            }
            else
            {
              fieldValidationErrors.sgst ='Percentage Should be in the Range of 100 [Numbers & Decimals] Only!';  
              sgstValid=false; 
            }
          }
            else
            {
              fieldValidationErrors.sgst = ''; 
              sgstValid=true; 
            }
            break;
        case 'igst':
              if (value.length>5)
              {
                fieldValidationErrors.igst = 'Sorry! You are Exceeding the Limit'; 
                igstValid=false;
              }
              else if(value.length>0 && value.length<=5)
              {
                if(value<100)
                {
                  igstValid=value.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/);  
                  fieldValidationErrors.igst = igstValid ? '' : ' is InCorrect';
                }
                else
                {
                  fieldValidationErrors.igst = 'Percentage Should be in the Range of 100 [Numbers & Decimals] Only!';  
                  igstValid=false;
                }

              }
              else{
                fieldValidationErrors.igst = ''; 
                igstValid=true;
              
              }
              break;
        case 'cgst':
               if (value.length>5)
              {
                fieldValidationErrors.cgst = 'Sorry! You are Exceeding the Limit'; 
                cgstValid=false;
              }
              else if(value.length>0 && value.length<=5)
              {
                if(value<100)
                {
                cgstValid=value.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/);   // /^[0-9]*$/ ...^[1-9]\d*(\.\d+)?$    /^[1-2]\d*(\.\d+)?$/
                fieldValidationErrors.cgst = cgstValid ? '' : ' is InCorrect';
                }
                else
                {
                  fieldValidationErrors.cgst = 'Percentage Should be in the Range of 100 [Numbers & Decimals] Only!';  
                cgstValid=false;
                }
              }
              else
              {
                fieldValidationErrors.cgst = ''; 
                cgstValid=true;
              }
              break;
        // case 'hsnCode':
        //         if(value.length>49 )
        //         {
        //             fieldValidationErrors.hsnCode='Sorry! You are Exceeding the Limit';
        //             hsnCodeValid=false;
        //         }
               
        //         else{
        //             hsnCodeValid=true;
        //             fieldValidationErrors.hsnCode='';
        //         }
        //     break;
        case 'rate':
                if (value>1000000)
                    {
                          fieldValidationErrors.rate = 'Sorry! You are Exceeding the Limit'; 
                          rateValid= false;
                    }
                    else if(value.length>0 && value.length<=7)
                    {
                        rateValid = value.match(/^[0-9]*$/);
                        fieldValidationErrors.rate = rateValid ? '' : ' is InCorrect';
                    }
                    else
                    {
                      fieldValidationErrors.rate= ''; 
                         rateValid = true;
                    }
                break;
        case 'ratePerUnit':
                    if (value>1000)
                        {
                              fieldValidationErrors.ratePerUnit = 'Sorry! You are Exceeding the Limit'; 
                              ratePerUnitValid= false;
                        }
                        else if(value.length>0 && value.length<=4)
                        {
                          //  ratePerUnitValid = value.match(/^[0-9]*$/);
                            ratePerUnitValid = value.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/);
                            fieldValidationErrors.ratePerUnit = ratePerUnitValid ? '' : ' is InCorrect';
                        }
                        else
                        {
                          fieldValidationErrors.ratePerUnit= ''; 
                          ratePerUnitValid = true;
                        }
                    break;
        case 'quantity':
                        if (value>1000)
                        {
                          fieldValidationErrors.quantity = 'Sorry! You are Exceeding the Limit'; 
                          quantityValid=false;
                        }
                        else if(value.length>0 && value.length<=4)
                        {
                          
                          quantityValid=value.match(/^[0-9]+$/);   ///^[0-9]*$/
                          fieldValidationErrors.quantity = quantityValid ? '' : ' is InCorrect';
                        }
                        else{
                          fieldValidationErrors.quantity = ''; 
                          quantityValid=true;
                        }
                        break;
        default:
        break;
    }
    this.setState({
      formErrors: fieldValidationErrors,
      sgstValid:sgstValid,
      cgstValid:cgstValid,
      igstValid:igstValid,
      rateValid:rateValid,
      ratePerUnitValid:ratePerUnitValid,
    //  hsnCodeValid:hsnCodeValid,
    }, this.validateForm);
  }
  validateForm() {

    this.setState({
      formValid:
      this.state.sgstValid
      && this.state.cgstValid
      && this.state.igstValid
      && this.state.rateValid
      && this.state.ratePerUnitValid
    //  && this.state.hsnCodeValid
    });
  }

   render(){
       return( 
           <div>
               {
                this.state.cartData.map((element) => (
                <div className="row mt-20 card-box Quotationproduct">
                    <div className="col-md-6">
                        <div className="row quotation-card-box">
                            <div className="col-md-6">
                                <label>Product Name</label>
                                <div>
                                    {/* FIELD USED TO create Product */}
                                    <input className="textfield" type="text"   value={element.productName} id="product" name="product" readOnly />
                                </div></div>
                            <div className="col-md-6">
                                <label>Product Code </label>
                                <div>
                                    {/* FIELD USED TO create Product Code */}
                                    <input className="textfield" type="text"  value={element.productCode} id="productCode" name="productCode" readOnly />
                                </div></div>
                            <div className="col-md-6">
                                <label>Rate </label>
                                <div>
                                    {/* FIELD USED TO create Rate  */}
                                    <input className="textfield" type="text"  value={element.rate} id="rate" name="rate" readOnly />
                                </div></div>
                            <div className="col-md-6">
                                <label>HSN Code</label>
                                <div>
                                    {/* FIELD USED TO create HSN Code  */}
                                    <input className="textfield" type="text"  value={element.hsnCode} id="hsnCode" name="hsnCode" readOnly />
                                </div></div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="quotation-card-box">
                            <table className="table">
                                <tbody>
                                    <tr>
                                        <td>Rate/Unit</td>
                                        <td>{element.ratePerUnit}</td>
                                    </tr>
                                    <tr>
                                        <td>Quantity</td>
                                        <td>{element.quantity}</td>
                                    </tr>
                                    <tr>
                                        <td>CGST(%)</td>
                                        <td>{element.cgst}</td>
                                    </tr>
                                    <tr>
                                        <td>SGST(%)</td>
                                        <td>{element.sgst}</td>
                                    </tr>
                                    <tr>
                                        <td>IGST(%)</td>
                                        <td>{element.igst}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

              
                    <div className="text-center"> 
                        <button className="btn btn-primary btn-submit" onClick={()=>this.editProduct(element,element.productCode)}>Edit Product</button>
                    </div>
                    </div>
                ))
            }
                 <Modal
                            isOpen={this.state.quotationEditproductmodalIsOpen}
                            //  onAfterOpen={this.customerafterOpenModal}
                            onRequestClose={this.state.quotationEditproductcloseModal}
                            style={customStyles}
                            contentLabel="Example Modal"> {/* edit image  */}
                            <div className="container">
                                < div class="updatedevice" id="updatedevice" onClick={() => this.closeModalProductType()} style={{ textAlign: "center" }}><span style={{ fontSize: '1em', color: 'white', float: 'right', marginTop: "-30px", marginRight: "-20px" }}>
                                    <i class="glyphicon glyphicon-remove" style={{
                                        border: "none",
                                        padding: "6px 7px 5px 7px",
                                        fontSize: "1em",
                                        color: "black",
                                        borderRadius: "18px",
                                    }}>   </i>

                                </span>
                            </div>
                            <h4>Edit-Quotation (Product)</h4>
                            <div className="row">
                                <div className="col-md-3">
                                    <label>Product</label>
                                    <div>
                                        {/* FIELD USED TO edit Product */}
                                        <input className="textfield" type="text"  value={this.state.productName} readOnly id="product" name="productName" />
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>Product Code</label>
                                    <div>
                                        {/* FIELD USED TO edit Product */}
                                        <input className="textfield" type="text"  value={this.state.productCode} readOnly id="productCode" name="productCode"  />
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>HSN Code</label>
                                    <div>
                                        {/* FIELD USED TO edit hsn */}
                                        <input className="textfield" type="text"  value={this.state.hsnCode} readOnly id="hsnCode" name="hsnCode"  />
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>Rate/Unit </label>
                                    <div>
                                        {/* FIELD USED TO edit Rate/Unit  */}
                                        <input className="textfield" type="text" maxlength="4" value={this.state.ratePerUnit} onChange={this.handleProductDetails} id="ratePerUnit" name="ratePerUnit" />
                                        <ErrorClass errorContent={this.state.formErrors.ratePerUnit}/>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>Rate</label>
                                    <div>
                                        {/* FIELD USED TO edit Rate/Unit  */}
                                        <input className="textfield" type="text" maxlength="10" value={this.state.rate}onChange={this.handleProductDetails} id="rate" name="rate" />
                                        <ErrorClass errorContent={this.state.formErrors.rate}/>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>CGST(%) </label>
                                    <div>
                                        {/* FIELD USED TO edit CGST(%)  */}
                                        <input className="textfield" type="text" maxlength="5" value={this.state.cgst} onChange={this.handleProductDetails} id="cgst" name="cgst" />
                                        <ErrorClass errorContent={this.state.formErrors.cgst}/>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>IGST(%) </label>
                                    <div>
                                        {/* FIELD USED TO edit iGST(%)  */}
                                        <input className="textfield" type="text" maxlength="5"  value={this.state.igst} onChange={this.handleProductDetails} id="igst" name="igst" />
                                        <ErrorClass errorContent={this.state.formErrors.igst}/>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>SGST(%) </label>
                                    <div>
                                        {/* FIELD USED TO edit sGST(%)  */}
                                        <input className="textfield" type="text" maxlength="5" value={this.state.sgst}onChange={this.handleProductDetails} id="sgst" name="sgst" />
                                        <ErrorClass errorContent={this.state.formErrors.sgst}/>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <label>Quantity</label>
                                    <div>
                                        {/* FIELD USED TO edit quantity  */}
                                        <input className="textfield" type="text"  maxlength="4" value={this.state.quantity} readOnly id="quantity" name="quantity" />
                                        <ErrorClass errorContent={this.state.formErrors.quantity}/>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="button"  class="btn btn-primary btn-submit" onClick={() => this.closeModalQuotationEditproduct()} disabled={!this.state.formValid}
                                    style={{
                                        borderRadius: "18px",
                                        backgroundColor: "#263eac",
                                        color: "white",
                                        width: "75px",
                                        marginTop: "20px"
                                    }}

                                >
                                    <span class="glyphicon glyphicon-ok" style={{ fontWeight: "800" }} ></span> Ok
                                </button>
                            </div>
                        </div>
                </Modal>
        
            </div>
 
        );
    }  
}
export class FranchiseQuotationImage extends React.Component{
    constructor(){
      super();    
      window.FranchiseQuotationImageComponent=this;
 this.state= {
     imageCartData:[],
 }
 this.RenderImage=this.RenderImage.bind(this);
 this.EditImage = this.EditImage.bind(this);
 this.SetcroppedImgSrc=this.SetcroppedImgSrc.bind(this);
 }
 componentDidMount()
{
   // alert("quot compkgyug.l");
    var self=this;
    console.log("this.props",this.props.ImageCartDBData);
    self.state.imageCartData=this.props.ImageCartDBData;

    self.setState({imageCartDate:self.state.imageCartData})
    console.log("this.props",self.state.imageCartData);
}
/* USED TO GET THE IMAGE CART DATA FROM Franchise QUOTATION COMPONENTS- IMPLEMENTED BY DURGA 29-04-2022 */
 RenderImage(image)
 {
    var self=this;
    var imageData=image;
    console.log("image quotaion data",imageData);
    self.state.imageCartData  =imageData;
    self.setState({imageCartData:self.state.imageCartData})
 }
 editImageIcon(){
  //  alert("Edit image Icon page");
}
/* USED TO STORE THE CROPPED IMAGE AFTER DONE EDIT- IMPLEMENTED BY DURGA 29-04-2022 */
SetcroppedImgSrc(croppedImgSrc,croppedUploadId)
{
    var self=this;
    var tempImageCartData=self.state.imageCartData;

    console.log("croppedUploadId",croppedUploadId,"tempImageCartData",tempImageCartData);

    if(index!=-1)
    {
        var index = _.findIndex(tempImageCartData, {uploadid : croppedUploadId.toString()}); 
     
         console.log("index",index);
         tempImageCartData[index].image=croppedImgSrc;
     
         self.setState({imageCartData:tempImageCartData}) 
         console.log("imageCartData",self.state.imageCartData);
    }

}
/*USED TO OPEN THE SLIDEPANE IMAGE EDIT */
EditImage(image, id) {
    // alert("dit image page");
    console.log("id-croppedUploadId",id);
    var self = this;
    self.state.isImageEditPaneOpen = true;
    self.state.editImage = image;
    self.state.uploadId = id;

    self.setState({
        isImageEditPaneOpen: self.state.isImageEditPaneOpen,
        editImage: self.state.editImage,
        uploadId: self.state.uploadId,
    })
}
/*USED TO CLOSE THE SLIDEPANE IMAGE EDIT */
CloseImageEdit() {
    this.state.isImageEditPaneOpen = false;
    this.setState({
        isImageEditPaneOpen: this.state.isImageEditPaneOpen,
    })
}
 render(){
     return( 
         <div>
         {
 this.state.imageCartData.map((element) =>(
         <div className="row mt-20 card-box Quotationimage">
         <div className="col-md-6">
             <div className="row quotation-card-box">
         <div class="col-md-6 text-center">
             <div class="card-box-img">
                 <img src={element.image} />
                 <div className="img-editicon">               
                 {/* <EditImageIcon onEditImage={this.editImageIcon} />  */}
                 <FiIcons.FiEdit alt="edit image" data-tip data-for="EditImage" onClick={() => this.EditImage(element.image, element.uploadid)} />
                 <ReactTooltip id="EditImage" place="top" effect="solid">Edit Image</ReactTooltip>
                 </div>
                 </div>
                 </div>
                 <div class="col-md-6 text-left mt-20">
                 <p>Image Type: <span>Nature</span><br/>Image Pixel: <span>307 * 170</span><br/>Rate: <span>400</span></p>
                 </div>
             </div>
             </div>
             <div className="col-md-6">
             <div className="quotation-card-box">
         <table className="table">
             <tbody>
                 <tr>
                     <td>Rate/Unit</td>
                     <td>150</td>
                 </tr>
                 <tr>
                     <td>Quantity</td>
                     <td>15</td>
                 </tr>
                 <tr>
                     <td>CGST(%)</td>
                     <td>14</td>
                 </tr>
                 <tr>
                     <td>SGST(%)</td>
                     <td>14</td>
                 </tr>
                 <tr>
                     <td>IGST(%)</td>
                     <td>14</td>
                 </tr>
             </tbody>
         </table>
         </div>
         </div>
         {/* <div className="text-center">
             <button className="btn btn-primary btn-submit" onClick={this.editImage}>Delete</button>
         </div> */}
         </div>

))
}

    <SlidingPane
        className="some-custom-class"
        overlayClassName="some-custom-overlay-class"
        isOpen={this.state.isImageEditPaneOpen}
        title={"Saved Image - Edit"}
        // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
        onRequestClose={() => {
            // triggered on "<" on left top click or on outside click
            // setState({ isPaneOpen: false });
            this.CloseImageEdit()
        }}
    >
        <EditImage image={this.state.editImage} uploadId={this.state.uploadId}
            module={"Generate Quotation"} CloseSlidingPane={this.CloseImageEdit}
            pageCalledFrom={"Generate Quotation"} RenderImages={this.RenderImages} SetcroppedImgSrc={this.SetcroppedImgSrc}/>
    </SlidingPane>       
</div>
     );
 }
}

export class FranchiseQuotationProduct extends React.Component{
    constructor(){
        super();      
   this.state= {

       }
   }
   render(){
       return( 
<div className="row mt-20 card-box Quotationproduct">
<div className="col-md-6">
    <div className="row quotation-card-box">
    <div className="col-md-6">
<label>Product Name</label>    
<div>      
{/* FIELD USED TO create Product */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.product} id="product" name="product" readOnly/>
</div></div>
<div className="col-md-6">
<label>Product Code </label>    
<div>      
{/* FIELD USED TO create Product Code */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.productCode} id="productCode" name="productCode" readOnly/>
</div></div> 
<div className="col-md-6">
<label>Rate </label>    
<div>      
{/* FIELD USED TO create Rate  */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rate} id="rate" name="rate" readOnly/>
</div></div>   
<div className="col-md-6">
<label>HSN Code</label>    
<div>      
{/* FIELD USED TO create HSN Code  */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.hsnCode } id="hsnCode" name="hsnCode" readOnly/>
</div></div>     
    </div>
    </div>
    <div className="col-md-6">
    <div className="quotation-card-box">
<table className="table">
    <tbody>
        <tr>
            <td>Rate/Unit</td>
            <td>150</td>
        </tr>
        <tr>
            <td>Quantity</td>
            <td>15</td>
        </tr>
        <tr>
            <td>CGST(%)</td>
            <td>14</td>
        </tr>
        <tr>
            <td>SGST(%)</td>
            <td>14</td>
        </tr>
        <tr>
            <td>IGST(%)</td>
            <td>14</td>
        </tr>
    </tbody>
</table>
</div>
</div>
<div className="text-center">
                <button className="btn btn-primary btn-submit">Delete</button>
            </div>
</div>
       );
   }
}