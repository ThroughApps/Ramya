//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import ReactTable from "react-table-v6";
import SlidingPane from "react-sliding-pane";
import $ from 'jquery';

import _ from 'underscore';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import Pagination from "react-js-pagination";
import moment from 'moment';
import { GetLocalStorageData, TimeZoneDateTime } from '../../Common Components/CommonComponents';
import MonthYearPicker from 'react-month-year-picker';
//import datepicker from 'jquery-ui/ui/widgets/datepicker'; //FilterOptions

// import statement for react class component

import { FranchiseQuotationStatusDropDown } from '../../Assets Components/DropdownComponents/DropdownComponent';
import { QuotationViewIcons } from '../../Assets Components/Icon Components/Iconcomponents';
import QuotationView from "../../Franchise Components/Quotation/QuotationView";

// import statement for react component css
//import './datepicker.css';
import "react-table-v6/react-table.css";
import "react-sliding-pane/dist/react-sliding-pane.css";
import "../../Admin Components/Quotation/QuotationCss.css";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var quotationList;

var dataCount = 0;
var dataCountArray = [];
var itemData = 1;
var pageArray = [];
var pageData_Status;
var days1;
class QuotationList extends React.Component {
  constructor() {
    super();
    this.state = {
      totlaItemCount: 0,
      itemsPerPage: 10,
      activePage: 1,
      month: "",
     // presentyear: 2022,
      quotationData: [],
      columns: [
        {
          Header: 'SNO',
          accessor: 'SNO'
        },
        {
          Header: 'QuotationNumber',
          accessor: 'QuotationNumber'
        },
        {
          Header: 'Amount',
          accessor: 'Amount'
        },
        {
          Header: 'Status',
          accessor: 'Status'
        }
      ],
      fromDate: '',
      toDate: '',
      isQuotationViewPaneOpen: false,
    }
    // this.setState({
    //   columns: this.state.columns,
    // })
    this.quotationView = this.quotationView.bind(this);
    this.handleStatus = this.handleStatus.bind(this);
    this.PopulateQuotationData = this.PopulateQuotationData.bind(this);
  }
  componentDidMount() {
    dataCount = 0;
    dataCountArray = [];
    itemData = 1;
    pageArray = [];

    dataCountArray.push(0);
    pageArray.push(1);
    var self = this;

    $("#tableOverflow1").hide();
    console.log("quotation list page");
   


    /* GETTING DATE & TIME FOR DATEPICKER
     - IMPLEMENTED BY RAMYA - 14-05-2022
     */
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    console.log("dateTimeData :", dateTimeData);
    var year = dateTimeData.date.split("-")[0];
    var month = dateTimeData.date.split("-")[1];
    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.state.currentYear = year;
    this.state.currentMonthNumber=month; 
    this.state.currentMonth = moment(month, 'M').format('MMMM');

    this.setState({
      date: this.state.date,
      time: this.state.time,
      currentYear: this.state.currentYear,
      currentMonth: this.state.currentMonth,
      currentMonthNumber: this.state.currentMonthNumber
    })
    console.log("currentMonth", this.state.currentMonth, "this.state.currentYear", this.state.currentYear);
    //alert("currentdate"+this.state.currentYear);
    this.GetMonthData(this.state.currentMonthNumber, this.state.currentYear);

    $(document).ready(function () {
      $("#monthselect").click(function () {
          $(".month-year-picker").toggleClass("active");
      });        

  });
  $(document).ready(function () {
  $(".month-year-picker .month-picker > div > div").click(function () {
      $(".month-year-picker").removeClass("active");
    
  });  
  
}); 
  }
/*HANDLE DATEPICKER MONTH AND YEAR ONCHANGE-IMPLEMENTED BY DURGA 23-05-2022 */
onChangeYear(year)
{
 // console.log("year",year);
  this.state.currentYear=year;
  this.setState({ currentYear:this.state.currentYear})
  this.GetMonthData(this.state.currentMonthNumber, this.state.currentYear);
  
}
onChangeMonth(month)
{
    this.state.currentMonthNumber=month;
    this.state.currentMonth = moment(month, 'M').format('MMMM');
    console.log("onChangeMonth",month,"this.state.currentMonth",this.state.currentMonth);
    this.setState({
      currentMonthNumber:this.state.currentMonthNumber,
      currentMonth:this.state.currentMonth})

    this.GetMonthData(this.state.currentMonthNumber, this.state.currentYear);
}
/* USED TO CONVERT THE NO DAYS IN A MONTH-IMPLEMENTED BY DURGA 29-04-2022 */   //[Ref:garageapp] 
GetMonthData(selectedMonth, year) {
  itemData = 1;
  this.state.totlaItemCount = 0;
  dataCountArray = [];
  dataCount = 0;
  pageArray = [];
  dataCountArray.push(dataCount);
  pageArray.push(1);

    console.log("indie getmonth", selectedMonth, year);
    this.state.year = year;
    this.setState({ year: this.state.year })
    var today = new Date();
    var currentMonth = today.getMonth() + 1;
    days1 = new Date(year, selectedMonth, 0).getDate();

    if (
      selectedMonth == "01" || //"January" March May July August october december
      selectedMonth == "03" ||
      selectedMonth == "05" ||
      selectedMonth == "07" ||
      selectedMonth == "08" ||
      selectedMonth == "10" ||
      selectedMonth == "12"
    ) {
      if (selectedMonth == currentMonth) {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + today.getDate();
      } else {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + "31";
      }

      this.setState({
        fromDate: this.state.fromDate,
        toDate: this.state.toDate,
        month: this.state.month
      });

      console.log("this.state.fromDate", this.state.fromDate, this.state.toDate, this.state.month);
    } else if (
      selectedMonth == "04" || //April june september november
      selectedMonth == "06" ||
      selectedMonth == "09" ||
      selectedMonth == "11"
    ) {
      if (selectedMonth == currentMonth) {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + today.getDate();
      } else {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + "30";
      }
      this.setState({
        fromDate: this.state.fromDate,
        toDate: this.state.toDate,
        month: this.state.month
      });
    } else if (selectedMonth == "02") { //february 
      if (year % 100 == 0 && year % 400 == 0 && year % 4 == 0) {
        if (selectedMonth == currentMonth) {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate =
            year + "-" + selectedMonth + "-" + today.getDate();
        } else {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate = year + "-" + selectedMonth + "-" + "29";
        }
        this.setState({
          fromDate: this.state.fromDate,
          toDate: this.state.toDate,
          month: this.state.month
        });
      } else {
        if (selectedMonth == currentMonth) {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate =
            year + "-" + selectedMonth + "-" + today.getDate();
        } else {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate = year + "-" + selectedMonth + "-" + "28";
        }
        this.setState({
          fromDate: this.state.fromDate,
          toDate: this.state.toDate,
          month: this.state.month
        });
      }
    }
    this.GetData();
  }

/* USED TO GET THE QUOTATION LIST DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 29-04-2022 */
GetData() {
    var CurrentDate = new Date();
    var GivenDate = new Date(this.state.fromDate);
    var self = this;
    if (this.state.fromDate.trim().length > 0 && this.state.toDate.trim().length > 0) {
      if (GivenDate > CurrentDate) {
        this.state.fromDate = "";
        this.state.today = "";

        Swal.fire({
          position: 'center',
          icon: 'error',
          title: "You Cannot See Reports For Future Dates.",
          showConfirmButton: false,
          timer: 2000
        })
      }
      else {

      }
    }
    //May 2022
    console.log("get data", dataCount, this.state.totalItemCount);
    console.log("toDate", this.state.toDate, "fromDate", this.state.fromDate, "year", this.state.year);

    var self = this;
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        dataCount: dataCount,
        totlaItemCount: this.state.totalItemCount,
        franchiseId: GetLocalStorageData("FranchiseId"), //to render datas based on which franchise login
        fromDate: this.state.fromDate,
        toDate: this.state.toDate,
      }),
      url: "http://15.206.129.105:8080/IceilLiveAPI/FranchiseQuotationWebService/SelectQuotationDetails",
      contentType: "application/json",
      dataType: 'json',
      async: false,

      success: function (data, textStatus, jqXHR) {

        console.log("datalist", data);
                      //data.imageQuotationList
        quotationList = data.quotationList;
        console.log(quotationList);
        self.state.totlaItemCount = data.totlaItemCount;

        if (data.quotationList !== null && data.quotationList.length != 0) {
          var no = 0;
          if (itemData == "1") {
            self.state.totlaItemCount = data.totlaItemCount;

            itemData = Number(itemData) + 1;
          }
          self.PopulateQuotationData(quotationList);
        } else {
          itemData = "1";
          self.state.totlaItemCount = 0;
        }
       
      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      },
    });
  }
GetColumns() {
if(!this.state.quotationData.length==0)
{
    return Object.keys(this.state.quotationData[0]).map(key => {

      return {
        Header: key,
        accessor: key,

      };

    });
  }
}
/* USED TO POPULATE QUOTATION LIST INTO TABLE- IMPLEMENTED BY DURGA 22-04-2022 */
PopulateQuotationData(quotationList) {
    var self = this;
    var count = dataCount;
    console.log("populate data", quotationList);
    self.state.quotationData = [];

    self.setState({ quotationData: self.state.quotationData })
  //  $("#tableHeadings").empty();

    var tab = '<thead><tr class="headcolor"><th>SNO</th><th>Id</th><th>Amount</th><th>Status</th></tr></thead>';
    var tempStatus;
    $.each(quotationList, function (i, item) {

      count = Number(count) + 1;
      console.log(item.rate, item.status);

      if (item.status == 0) {//Status= 0 - Quotation submitted 

        tempStatus = <span style={{ color: "blue", fontWeight: "700" }}>Submitted</span>
      }
      else if (item.status == 1) {//Status=1 - Cancelled  
        tempStatus = <span style={{ color: "red", fontWeight: "700" }}>Cancelled</span>
      }
      else if (item.status == 2) { //Status=2 - Accepeted-inprogress 
        tempStatus = <span style={{ color: "#FFD700", fontWeight: "700" }}>Inprogress</span>
      }
      else if (item.status == 3) {//Status=3 - Completed    
        tempStatus = <span style={{ color: "green", fontWeight: "700" }}>Completed</span>
      }
      else if (item.status == 5) { //Status=5 - Edited
        tempStatus = <span style={{ color: "#800080", fontWeight: "700" }}>Edited</span>
      }

      tab += '<tbody id= "myTable" ><tr  id="tabletextcol" ><td>' + count + '</td>'
        + '<td>' + item.quotationNo+ '</td>'
        + '<td>' + item. amounttobePaid+ '</td>'
        + '<td>' + tempStatus + '</td>'

      self.state.quotationData[i] = {

        "SNO": count,
        "QuotationNumber": item.quotationNo,
        "Amount": item.amounttobePaid,
        "Status": tempStatus
      }
    });

   // $("#tableHeadings").append(tab);

   // self.state.columns = this.GetColumns();

    self.setState({

     // TableColumns: self.state.columns,
      quotationData: self.state.quotationData,
    });
    console.log("data", self.state.quotationData);

  }
/* USED TO HANDLE THE PAGINATION- IMPLEMENTED BY DURGA 29-04-2022 */
  handlePageChange(pageNumber) {

    this.state.activePage = pageNumber;
    this.setState({ activePage: pageNumber });

    var self = this;


    pageData_Status = false;
    pageData_Status = _.contains(pageArray, this.state.activePage);

    dataCount = 0;
    self.state.oldPageAcces = "false";
    self.setState({
      oldPageAcces: self.state.oldPageAcces
    });

    if (pageData_Status == false) {

      pageArray.push(pageNumber);
      dataCount = Math.round((Number(dataCount)) + ((Number(pageNumber) - 1) * 10));
      dataCountArray.push(dataCount);

    } else if (pageData_Status == true) {

      var currentPageIndex = _.indexOf(pageArray, this.state.activePage);
      dataCount = dataCountArray[currentPageIndex];

    }
    this.GetData();
  }

  /* HANDLE ROW SELECTION-USED TO STORE THE SELECTED ROW DATAS [IN TABLE WHILE SELECTING THE ROW]- IMPLEMENTED BY DURGA 22-04-2022 */
  onTrRowClick = (state, rowInfo, column, instance) => {
    var self = this;

    if (typeof rowInfo !== "undefined") {
      return {
        onClick: (e, handleOriginal) => {
          this.setState({
            selected: rowInfo.index
          });
          if (handleOriginal) {
            handleOriginal()
          }


          this.state.rowIndexValue = rowInfo.index;

          console.log("index value", this.state.rowIndexValue);
          console.log("index value", quotationList[rowInfo.index]);

          this.state.selectedData = quotationList[rowInfo.index];
          this.setState({
            rowIndexValue: this.state.rowIndexValue,
            selectedData: this.state.selectedData
          });

          console.log("selectedData", this.state.selectedData);

        },
        style: {
          background: rowInfo.index === this.state.selected ? '#00afec' : ' ',
        },
      }
    }
    else {
      return {
        onClick: (e, handleOriginal) => {
          if (handleOriginal) {
            handleOriginal()
          }
        },
        style: {

        },
      }
    }
  };
  quotationView() {
    var self = this;
    if (self.state.rowIndexValue === undefined ||self.state.rowIndexValue === "") {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        text: 'Kindly, Select the Quotation to View! ',
        timer: 2000
      })
    }
    else {
      self.state.isQuotationViewPaneOpen = true;
      self.setState({
        isQuotationViewPaneOpen: self.state.isQuotationViewPaneOpen,
      })
    }
    self.state.rowIndexValue = "";
    self.state.selected =-1;
    self.setState({
      rowIndexValue: self.state.rowIndexValue,
      selected:self.state.selected
    })
  }
  CloseQuotationView() {
    this.state.isQuotationViewPaneOpen = false;
    this.setState({
      isQuotationViewPaneOpen: this.state.isQuotationViewPaneOpen,
    })
  }
  handleStatus = (e) => {
    var self = this;
    console.log("e", e, "e.toString()", e.toString());

    var tempstatus = e.toString();

    console.log("this.state.staus", tempstatus);
    console.log("quotationList", tempstatus);

    //  var result = FilterOptions(quotationList, tempstatus);
    // if(result!=null)
    // {
    //   console.log("result",result);
    //   self.PopulateQuotationData(result);
    // }

    //  self.setState({ staus:tempstatus});
  }
  render() {
    return (
      <div>
        <div className="text-center mt-40">
        <h3>{this.state.currentMonth} - <span> {this.state.currentYear} </span></h3>
        </div>
        <div className="row mt-20">
          <div class="top-menus">
            {/* FIELD USED TO get the status */}
            <FranchiseQuotationStatusDropDown quotationList={quotationList} PopulateQuotationData={this.PopulateQuotationData} />

            {/* FIELD USED TO get the month and year */}
            <div className="site_dropstyle">
              <label>Select Month</label>
              <div>
                <input className="form-control" value={this.state.currentMonth + " " + this.state.currentYear} type="text" id="monthselect" />
                <MonthYearPicker
                  selectedMonth={this.state.month}
                  selectedYear={this.state.currentYear}
                  minYear={2010}
                  maxYear={2030}
                  onChangeYear={this.onChangeYear.bind(this)}
                  onChangeMonth={this.onChangeMonth.bind(this)}
                />
              </div>
            </div>
            <QuotationViewIcons onQuotationView={this.quotationView} />
          </div>

          <div id="tableOverflow1">
            <table style={{ margin: "auto" }} class="table table-bordered" id="tableHeadings">
            </table>
          </div>
          <div style={{ marginTop: '50px' }}>
            <ReactTable
              data={this.state.quotationData}
              columns={this.state.columns}
              noDataText="No Data Available"
              filterable
              defaultPageSize={10}
              className="-striped -highlight"
              defaultFilterMethod={(filter, row, column) => {
                const id = filter.pivotId || filter.id;
                return row[id] !== undefined
                  ? String(row[id])
                    .toLowerCase()
                    .indexOf(filter.value.toLowerCase()) !== -1
                  : true;
              }}
              showPaginationTop={false}
              showPaginationBottom={true}
              getTrProps={this.onTrRowClick}
            /></div>

          <div style={{ marginBottom: "3%" }} className="pull-right" id="paginationdiv">

            <Pagination
              activePage={this.state.activePage}
              itemsCountPerPage={this.state.itemsPerPage}
              totalItemsCount={this.state.totlaItemCount}
              pageRangeDisplayed={5}
              itemClass="page-item"
              linkClass="page-link"
              onChange={this.handlePageChange.bind(this)}
            /></div>

        </div>
        <SlidingPane
          className="some-custom-class"
          overlayClassName="some-custom-overlay-class"
          isOpen={this.state.isQuotationViewPaneOpen}
          title={"Quotation View"}
          onRequestClose={() => {
            this.CloseQuotationView()
          }} >
          <QuotationView selectedData={this.state.selectedData} />
        </SlidingPane>
      </div>
    );
  }
}

export default QuotationList;
