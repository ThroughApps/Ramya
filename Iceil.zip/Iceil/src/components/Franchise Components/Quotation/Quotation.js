//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import ReactTable from "react-table-v6";
import SlidingPane from "react-sliding-pane";
import YearMonthPicker from 'react-year-month-picker'
import $ from 'jquery';
import MonthYearPicker from 'react-month-year-picker';
// import statement for class component css
import '../../StyleCss.css';
import './QuotationCss.css';

// import statement for react component css
import "react-table-v6/react-table.css";
import "react-sliding-pane/dist/react-sliding-pane.css";

// import statement for react class component
import {FranchiseDropDown, StatusDropDown} from '../../Assets Components/DropdownComponents/DropdownComponent';
import {QuotationListIcons} from '../../Assets Components/Icon Components/Iconcomponents';
import QuotationEdit from './QuotationEdit'
import QuotationView from "./QuotationView";

class Quotation extends React.Component{
    constructor(){
        super();
        this.state={
            scheduled: null,
            month: 10,
            year: 2018,
            data: [],
            columns: [],
            isQuotationEditPaneOpen: false,
            isQuotationViewPaneOpen: false,
        }
        this.quotationEdit = this.quotationEdit.bind(this);
        this.quotationView = this.quotationView.bind(this);
    }
    componentDidMount(){
        this.state.columns = [
            {
                Header: 'S.No',
                accessor: 'S.No'
            },
            {
                Header: 'Id',
                accessor: 'Id'
            },
            {
                Header: 'Franchise',
                accessor: 'Franchise'
            },
            {
                Header: 'Amount',
                accessor: 'Amount'
            },
            {
                Header: 'Status',
                accessor: 'Status'
            }
        ]

        this.setState({
            columns: this.state.columns,
        })
        $(document).ready(function () {
            $("#monthselect").click(function () {
                $(".month-year-picker").show();
            });            
        });
    }
quotationEdit(){
    var self=this;
    self.state.isQuotationEditPaneOpen = true;
    self.setState({
        isQuotationEditPaneOpen: self.state.isQuotationEditPaneOpen,
    }) 
}
quotationView(){
    var self=this;
    self.state.isQuotationViewPaneOpen = true;
    self.setState({
        isQuotationViewPaneOpen: self.state.isQuotationViewPaneOpen,
    }) 
}
quotationAccept(){}
quotationCancel(){}
quotationComplete(){}
CloseQuotationEdit() {
    this.state.isQuotationEditPaneOpen = false;
    this.setState({
        isQuotationEditPaneOpen: this.state.isQuotationEditPaneOpen,
    })
}
CloseQuotationView() {
    this.state.isQuotationViewPaneOpen = false;
    this.setState({
        isQuotationViewPaneOpen: this.state.isQuotationViewPaneOpen,
    })
}
render(){
    return(
        <div>
<div className="toptitle">
<h3>Quotation</h3>
</div>
<div className="container-fluid">
    <div className="text-center">
        <h3>{this.state.month} - <span> {this.state.year} </span></h3>
    </div>
<div className="row mt-40">
<div class="top-menus">
{/* FIELD USED TO get the franchise */}
<FranchiseDropDown />
{/* FIELD USED TO get the status */}
<StatusDropDown />
{/* FIELD USED TO get the month and year */}
<div className="site_dropstyle">
    <label>Select Month</label>
    <div>
        <input className="form-control" type="text" id="monthselect" />
    <MonthYearPicker
          selectedMonth={this.state.month}
          selectedYear={this.state.year}
          minYear={2000}
          maxYear={2030}
          onChangeYear={year => this.setState({ year: year })}
          onChangeMonth={month => this.setState({ month: month })}
        />
        {/* <button>ok</button> */}
         {/* <YearMonthPicker
          closeOnSelect
          onChange={this.handleChange.bind(this)}
        /> */}
              </div>
              </div>
<QuotationListIcons  onQuotationEdit={this.quotationEdit} onQuotationView={this.quotationView} onQuotationAccept={this.quotationAccept} onQuotationCancel={this.quotationCancel} onQuotationComplete={this.quotationComplete} />
</div>
<ReactTable
                        data={this.state.data}
                        columns={this.state.columns}
                        noDataText="No Data Available"
                        filterable
                        defaultPageSize={10}
                        className="-striped -highlight"
                        defaultFilterMethod={(filter, row, column) => {
                            const id = filter.pivotId || filter.id;
                            return row[id] !== undefined
                                ? String(row[id])
                                    .toLowerCase()
                                    .indexOf(filter.value.toLowerCase()) !== -1
                                : true;
                        }}
                        showPaginationTop={false}
                        showPaginationBottom={true}
                        getTrProps={this.onTrRowClick}
                    />
</div>
</div>
    <SlidingPane
                    className="some-custom-class"
                    overlayClassName="some-custom-overlay-class"
                    isOpen={this.state.isQuotationEditPaneOpen}
                    title={"Quotation Edit"}
                    // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                    onRequestClose={() => {
                        // triggered on "<" on left top click or on outside click
                        // setState({ isPaneOpen: false });
                        this.CloseQuotationEdit()
                    }}
                >
                    {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
                    <QuotationEdit />
                </SlidingPane>
                <SlidingPane
                    className="some-custom-class"
                    overlayClassName="some-custom-overlay-class"
                    isOpen={this.state.isQuotationViewPaneOpen}
                    title={"Quotation View"}
                    // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                    onRequestClose={() => {
                        // triggered on "<" on left top click or on outside click
                        // setState({ isPaneOpen: false });
                        this.CloseQuotationView()
                    }}
                >
                    {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
                    <QuotationView />
                </SlidingPane>
        </div>
    )
}
}
export default Quotation;