import React, { Component } from 'react';
import $ from 'jquery';
import _ from 'underscore';
import './FAQCSS.css';
import { GetLocalStorageData } from '../../Common Components/CommonComponents';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

const styles = {
    sidebar: {
        width: 256,
        height: "100%"
    },
    sidebarLink: {
        display: "block",
        padding: "16px 0px",
        //   color: "#757575",
        textDecoration: "none"
    },
    divider: {
        margin: "8px 0",
        height: 1,
        backgroundColor: "#757575"
    },
    content: {
        padding: "16px",
        height: "100%",
        backgroundColor: "white"
    }
};

/*
THIS PAGE WAS IMPLEMENTED BY PRIYANKA ON 13-05-2022
WITH UI & CORRESPONDING FUNCTIONALITY
LATER NANDHINI ADDED FEW UI ENHANCEMENTS
*/

class FAQ extends Component {
    constructor(props) {
        super(props)
        this.state = {
            questionAnswerArray: [],
            moduleId: "",
            moduleName: "",
            questionAnswer: [],
        }

        this.PopulateMenuData = this.PopulateMenuData.bind(this);
        this.SetQuestion_And_Answer = this.SetQuestion_And_Answer.bind(this);
        this.MenuLinkClick = this.MenuLinkClick.bind(this);

    }

    /*
THIS FUNCTION LOADS IMMEDIATLY AFTER THE PAGE IS LOADED
 IMPLEMENTED BY PRIYANKA ON 13-05-2022
*/
    componentDidMount() {

        //BY DEFAULT GET THE FAQ MENU, QUESTION & ANSWER DATA
        this.GetData();
        $(document).ready(function() {
            $(".faqitems").click(function () {
                if(!$(this).hasClass('active'))
                {
                    $(".faqitems.active").removeClass("active");
                    $(this).addClass("active");        
                }
            });
        });
    }

    /*
THIS FUNCTION USED TO GET THE MENU, QUESTION & ANSWER 
ADDED INTO THE FAQ
IMPLEMENTED BY PRIYANKA ON 13-05-2022
*/
    GetData() {

        var self = this;
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("FranchiseCompanyId"),
                module: "FAQ",
            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/FranchiseFAQ/SelectFAQData",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                //console.log("FAQ DATA :", data);

                if (data.moduleList.length > 0) {
                    self.state.questionAnswerArray = data.faqDataList;
                    self.setState({
                        questionAnswerArray: self.state.questionAnswerArray,
                    })

                    self.PopulateMenuData(data.moduleList);
                }

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });
    }

    /*
    FUNCTION USED TO POPULATE MENU FOR FAQ
    IMPLEMENETD BY PRIYANKA - 13-05-2022
    */
    PopulateMenuData(moduleList) {

        var self = this;
        var links = [];

        this.state.menu = [];
        this.setState({
            menu: this.state.menu
        })

        $.each(moduleList, function (i, item) {

            links.push(
                <a className='faqitems' key={item.moduleId} href="#" style={styles.sidebarLink} onClick={() => self.MenuLinkClick(item.moduleId, item.moduleName)}>
                    {item.moduleName}
                </a>
            );

        })

        this.state.menu = links;
        this.state.moduleId = moduleList[0].moduleId;
        this.state.moduleName = moduleList[0].moduleName;
        this.setState({
            menu: this.state.menu,
            moduleId: this.state.moduleId,
            moduleName:this.state.moduleName
        })

        //console.log(" POPULATE MENU DATA :", this.state.menu);


        this.SetQuestion_And_Answer();
    }


    /*
FUNCTION USED TO POPULATE QUESTION & ANSWER FOR FAQ
BY DEFAULT FIRST MENU Q & A WILL BE DISPLAYED AFTER WHICH
THE SELECTED MENU Q & A WILL BE DISPLAYED
IMPLEMENETD BY PRIYANKA - 13-05-2022
*/
    SetQuestion_And_Answer() {

        var currentQuestionAnswer = _.where(this.state.questionAnswerArray, { moduleId: this.state.moduleId });
        //console.log("currentQuestionAnswer :", currentQuestionAnswer);
        var questionAnswer = [];
        $.each(currentQuestionAnswer, function (i, item) {
            questionAnswer.push(<div><p class="question"><i class="fa fa-question-circle" aria-hidden="true"></i> {item.question}</p>
                <p class="answer"><i class="fa fa-chevron-right" aria-hidden="true"></i>{item.answer}</p></div>)
        })

        this.state.questionAnswer = questionAnswer;
        this.setState({
            questionAnswer: this.state.questionAnswer
        })
    }


    /*
  THIS FUNCTION LOADS QUESTION & ANSWER
  OF THE MENU SELECTED
   IMPLEMENTED BY PRIYANKA ON 13-05-2022
  */
    MenuLinkClick(moduleId, moduleName) {
        //  alert("moduleId :" + moduleId, " moduleName :" + moduleName);

        this.state.moduleId = moduleId;
        this.state.moduleName = moduleName;
        this.setState({
            moduleId: this.state.moduleId,
            moduleName: this.state.moduleName
        })

        this.SetQuestion_And_Answer();
    }


    render() {

        return (

            <div class="" style={{ backgroundColor: "" }}>
                <div class="franchise-toptitle toptitle">
                    <h4>FAQ</h4>
                </div>
                <div class="container-fluid" style={{height: "100vh"}}>
                <div class="sidenav" id="faqmenus">
                    {this.state.menu}
                </div>

                <div class="main">
                    <h2>{this.state.moduleName}</h2>
                    {this.state.questionAnswer.length>0 ?
                    this.state.questionAnswer :  <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>                   
                    }
                    
                </div>
            </div >
            </div>
        );
    }
}
export default FAQ;


