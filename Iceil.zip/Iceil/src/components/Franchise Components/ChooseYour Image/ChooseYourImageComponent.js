//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import CryptoJS from 'crypto-js';
import ReactTooltip from 'react-tooltip';
import Pagination from "react-js-pagination";
import SlidingPane from "react-sliding-pane";

import EditImage_Cropper from "./EditImage_Cropper";

import "react-sliding-pane/dist/react-sliding-pane.css";

// import statement for react class component
import * as BsIcons from 'react-icons/bs';
import * as FaIcons from 'react-icons/fa';
import * as FiIcons from 'react-icons/fi';


// import statement for react component css
import '../Saved Image/SavedImageCss.css'
import { dataURLtoFile, GetLocalStorageData } from "../../Common Components/CommonComponents";
import Search from "../../Assets Components/Search Components/SearchComponent";
import { AddToCart_ChooseYourImage_To_SavedImages, GetFileName, GetImageFileFromAWS } from "../../AWS/AWSFunctionality";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022


class ChooseYourImageComponent extends React.Component {
    constructor() {
        super();

        window.ChooseYourImage_Component = this;

        this.state = {
            imageArray: [],
            folderPath: "Saved Images" + "/" + GetLocalStorageData("FranchiseId"),
        }
        this.EditImage = this.EditImage.bind(this);
        this.CloseImageEdit = this.CloseImageEdit.bind(this);
    }
    componentDidMount() {

        //console.log("IMAGE GALLERY this.props :", this.props);
        //   this.SetImageGalleryData(this.props.menuId, this.props.menuName, this.props.folderPath);

    }

    SetChooseYourImageData(imageArray) {

        /* this.state.imageArray = [];
         this.setState({
             imageArray: this.state.imageArray
         })
 
         this.state.imageArray = imageArray;
         this.setState({
             imageArray: this.state.imageArray
         })
         */
        this.RenderImages(imageArray);
    }


    /*
   FUNCTION USED TO RENDER THE IMAGES AFTER THE CHNAGES LIKE EDIT, DELETE
   IMPLEMENTED BY PRIYANKA - 09-07-2022
   */
    RenderImages(mediaDataList) {

        var self = this;

        self.state.imageArray = [];
        self.setState({
            imageArray: self.state.imageArray,
        })

        if (mediaDataList.length > 0) {

            /*
                        self.state.totalItemsCount = data.dataCount;
                        self.setState({
                            totalItemsCount: self.state.totalItemsCount
                        });
            */
            $.each(mediaDataList, function (i, item) {
                // use a data url as an image source - ADDING WATERMARK TO THE IMAGE

                var imageUrl="https://d5g1cpur5okjb.cloudfront.net/"+item.Key;

                var imageData = {
                   // data: url,
                  // filePath: item.filePath,
                    data:"https://d5g1cpur5okjb.cloudfront.net/"+item.Key,
                    filePath: item.Key
                   
                };

                var previewImageData = {
                    src: imageUrl,
                    alt: 'ImageSlideShow'
                };
                //  self.state.imageArray.push(url);
                //   self.state.previewImageArray.push(previewImageData);
                self.state.imageArray.push(imageData);
                self.setState({
                    //     previewImageArray: self.state.previewImageArray,
                    imageArray: self.state.imageArray,
                })

                
               /* watermark([item.data])
                    .dataUrl(watermark.text.lowerRight('Iceil', '30px serif', '#fff', 0.5))
                    .then(function (url) {
                        //document.querySelector('img').src = url;
                        console.log("IMAGE GALLERY WATER MARK URL :", url);

                        var imageData = {
                            data: url,
                            filePath: item.filePath
                        };

                        var previewImageData = {
                            src: url,
                            alt: 'ImageSlideShow'
                        };
                        //  self.state.imageArray.push(url);
                        //   self.state.previewImageArray.push(previewImageData);
                        self.state.imageArray.push(imageData);
                        self.setState({
                            //     previewImageArray: self.state.previewImageArray,
                            imageArray: self.state.imageArray,
                        })
                        console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray);

                    })
                    */

            })
        }

        Loading_Component.ModalCloseFun()

    }

    /*USED TO OPEN THE SLIDEPANE IMAGE EDIT */
    EditImage(image, filePath) {
        // alert("dit image page");
        var self = this;
       /* self.state.isImageEditPaneOpen = true;
        self.state.editImage = image;
        // self.state.uploadId = id;

        self.setState({
            isImageEditPaneOpen: self.state.isImageEditPaneOpen,
            editImage: self.state.editImage,
            //   uploadId: self.state.uploadId
        })*/

        var downloadFileArray = [];
        downloadFileArray.push({ Key: filePath })
        GetImageFileFromAWS(downloadFileArray).then(function (response) {
 
            if (response !== "Error") {
 
                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)
 
              
                self.state.isImageEditPaneOpen = true;
                self.state.editImage = response[0].data;
                // self.state.uploadId = id;
        
                self.setState({
                    isImageEditPaneOpen: self.state.isImageEditPaneOpen,
                    editImage: self.state.editImage,
                    //   uploadId: self.state.uploadId
                })
               
               
 
            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }
 
        })
    }

    /*USED TO CLOSE THE SLIDEPANE IMAGE EDIT */
    CloseImageEdit() {
        this.state.isImageEditPaneOpen = false;
        this.setState({
            isImageEditPaneOpen: this.state.isImageEditPaneOpen,
        })
    }

    /*
   FUNCTION USED TO ADD THE IMAGES 
   OPTED FOR THE ADDING TO CART ON CLICKING THE 
   ADD TO CART ICON - IMPLEMENTED BY PRIYANKA
   */
    AddtoCart(image, filePath) {





        var self = this;
        var metaData = {

        }
        var keyName;

        GetFileName(self.state.folderPath).then(function (response) {

            if (response !== "Error") {
                console.log("** RESPONSE CONTENTS :", response.Contents)


                var fileNameArray = response.Contents.map(function (el) {


                    var splitData = (el.Key).split(/[\s/]+/);
                    var onlyFilename = splitData[splitData.length - 1];
                    return onlyFilename.split(".")[0]
                });

                if (fileNameArray.length < 10) {
                    var fileNameArrayInt = fileNameArray.map(Number);
                    /*  var lastFileName = response.Contents[contentsLength].Key;
                      console.log("lastFileName :", lastFileName);
                      var splitData = lastFileName.split(/[\s/]+/)
                      var keyName = splitData[splitData.length - 1]
                      */

                    console.log("fileNameArrayInt :", fileNameArrayInt);

                    keyName = Math.max(...fileNameArrayInt);
                    keyName = Number(keyName) + Number(1);

                    AddToCart_ChooseYourImage_To_SavedImages(filePath, self.state.folderPath + "/" + keyName).then(function (response) {

                        if (response !== "Error") {

                            console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

                            Swal.fire({
                                position: 'center',
                                icon: 'success',
                                text: 'Image added to cart Successfully',
                                showConfirmButton: false,
                                timer: 2000
                            })

                        } else {
                            Swal.fire({
                                position: 'center',
                                icon: 'error',
                                title: 'Network Connection Problem',
                                showConfirmButton: false,
                                timer: 2000
                            })
                        }

                    })
                } else {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Saved images can have only 10 images, kindly delete the existing image to add new image into the cart',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        });






    }

    /*
    FUNCTION USED FOR DOWNLOADING THE IMAGE
    IMPLEMENTED BY PRIYANKA - 28-04-2022
    */

    DownloadImage(data) {
       // FileSaver.saveAs(data, "image.jpg");

       var downloadFileArray = [];
       downloadFileArray.push({ Key: data.filePath })
       GetImageFileFromAWS(downloadFileArray).then(function (response) {

           if (response !== "Error") {

               console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

              /* watermark([response[0].data])
               .dataUrl(watermark.text.lowerRight('Iceil', '100px Josefin Slab', '#fff', 0.4))
               .then(function (url) {
                   //document.querySelector('img').src = url;
                   console.log("IMAGE GALLERY WATER MARK URL :", url);

                   FileSaver.saveAs(url, "image.jpg");

               })
               */
              
                var file = dataURLtoFile(response[0].data, 'image.jpg');
               console.log("**** ----- DownloadImage :", file);
               FileSaver.saveAs(file, "image.jpg");
              

           } else {
               Swal.fire({
                   position: 'center',
                   icon: 'error',
                   title: 'Network Connection Problem',
                   showConfirmButton: false,
                   timer: 2000
               })
           }

       })

    }


    render() {
        // console.log(" *** COMPO RENDER this.state.imagearray :", this.state.imageArray)
        return (
                <div className="card-box">
                    <h4>{this.state.menuName}</h4>
                    <div className="chooseimage">
                        {(this.state.imageArray.length > 0 ?
                            (this.state.imageArray.map((data) => (
                                data.data != null && data.data != undefined && data.data != 'data:image/png;base64,'
                                    ? (
                                        <div class="chooseimage1">
                                            <img id="image" src={data.data} alt="Red dot" />

                                            <div className="chooseimageicons">
                                                <ul>
                                                    <li><FaIcons.FaCartPlus alt="add to cart" data-tip data-for="AddtoCart" onClick={() => this.AddtoCart(data.data, data.filePath)} /></li>
                                                    <li><FaIcons.FaEdit alt="edit image" data-tip data-for="EditImage" onClick={() => this.EditImage(data.data, data.filePath)} /></li>
                                                    <li><FaIcons.FaDownload alt="logo" data-tip data-for="DownloadImag" onClick={() => this.DownloadImage(data)} /></li>
                                                </ul>
                                                <ReactTooltip id="AddtoCart" place="top" effect="solid">Add to Cart</ReactTooltip>
                                                <ReactTooltip id="EditImage" place="top" effect="solid">Edit Image</ReactTooltip>
                                                <ReactTooltip id="DownloadImag" place="top" effect="solid">Download Image</ReactTooltip>
                                            </div>
                                        </div>)
                                    :
                                    (<div> </div>)
                            ))) : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data </p>
                            </div>)

                        )}

                    </div>

                    <SlidingPane
                        className="some-custom-class"
                        overlayClassName="some-custom-overlay-class"
                        isOpen={this.state.isImageEditPaneOpen}
                        title={"Choose Your Image - Edit"}
                        // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                        onRequestClose={() => {
                            // triggered on "<" on left top click or on outside click
                            // setState({ isPaneOpen: false });
                            this.CloseImageEdit()
                        }}
                    >
                        {/*  <EditImage image={this.state.editImage} 
                        uploadId={this.state.uploadId} module={"Saved Images"} 
                        CloseSlidingPane={this.CloseImageEdit}
                         pageCalledFrom={"Choose Your Image"} />
                         */}
                        <EditImage_Cropper image={this.state.editImage}
                            uploadId={this.state.uploadId} module={"Choose Your Image"}
                            CloseSlidingPane={this.CloseImageEdit}
                            pageCalledFrom={"Choose Your Image"} />
                    </SlidingPane>
                </div>
        );
    }
}

export default ChooseYourImageComponent;

