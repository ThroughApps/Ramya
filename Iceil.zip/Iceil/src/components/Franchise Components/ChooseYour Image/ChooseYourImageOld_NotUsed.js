//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import SlidingPane from "react-sliding-pane";
import CryptoJS from 'crypto-js';
import ReactTooltip from 'react-tooltip';
import Pagination from "react-js-pagination";

import * as BsIcons from 'react-icons/bs';
import * as FaIcons from 'react-icons/fa';
import * as FiIcons from 'react-icons/fi';

import "react-sliding-pane/dist/react-sliding-pane.css";
// import statement for react class component

// import statement for react component css
import '../../Franchise Components/Saved Image/SavedImageCss.css';
import { ChooseImageIcons } from "../../Assets Components/Icon Components/Iconcomponents";
import EditImage from "./EditImage";
import { GetLocalStorageData, TimeZoneDateTime } from "../../Common Components/CommonComponents";
import Search from "../../Assets Components/Search Components/SearchComponent";
import EditImage_Cropper from "./EditImage_Cropper";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class ChooseYourImage extends React.Component {
    constructor() {
        super();

        window.ChooseYourImageComponent = this;

        this.state = {
            imageArray: [],
            menuId: '',
            activePage: 0,
            totalItemsCount: 0,
            itemsCountPerPage: 5,
            startCount: 0,
            endCount: 5,
            isImageEditPaneOpen: false,
            uploadId: "",
        }
        this.EditImage = this.EditImage.bind(this);
        this.CloseImageEdit = this.CloseImageEdit.bind(this);
    }

    componentDidMount() {

      //  alert("CHOOSE YOUR IMAGE DID MOUNR");

        //console.log("CHOOSE YOUR IMAGE this.props :", this.props);
        this.SetChooseYourImageData(this.props.menuId,this.props.menuName);

        /*
    GETTING DATE & TIME FOR THE CURRENT LOGIN
    - IMPLEMENTED BY PRIYANKA - 04-05-2022
    */
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        //console.log("dateTimeData :", dateTimeData);

        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.setState({
            date: this.state.date,
            time: this.state.time,
        })
    }


    /*
   FUNCTION USED FOR CALLING THE DISPLAY THE DATA
   IMPLEMENTED BY PRIYANKA - 29-04-2022
   */
    SetChooseYourImageData(menuId,menuName) {

      // alert("SetChooseYourImageData");
        this.state.menuId = menuId;
        this.state.menuName = menuName;

        this.state.imageArray = [];
        this.state.activePage = 0;
        this.state.totalItemsCount = 0;
        this.state.startCount = 0;
        this.state.endCount = 5;

        this.setState({
            imageArray: [],
            activePage: 0,
            totalItemsCount: 0,
            startCount: 0,
            endCount: 5,
            menuId:this.state.menuId,
            menuName:this.state.menuName,
        })

        //CALLING FUNCTION TO RENDER THE MEDIA DATA FOR DISPLAY - IMPLEMENETED BY PRIYANKA - 27-04-2022
        this.GetData_For_ChildMenu();
    }

    /*
FUNCTION USED TO RENDER THE DATA BASED ON LAST CHILD MENU SELECTED FROM SIDE BAR 
- IMPLEMENETED BY PRIYANKA - 29-04-2022
*/
    GetData_For_ChildMenu() {

        var self = this;

        self.state.imageArray = [];
        self.setState({
            imageArray: self.state.imageArray,
        })
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("FranchiseCompanyId"),
                menuId: this.state.menuId,
                startCount: this.state.startCount,
                endCount: this.state.endCount,
            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/MediaData/MediaDisplayData",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                //console.log("CHOOSE YOUR IMAGE MediaDisplayData DATA :", data);

                if (data.mediaDataList.length > 0) {

                    self.state.totalItemsCount = data.dataCount;
                    self.setState({
                        totalItemsCount: self.state.totalItemsCount
                    });

                    $.each(data.mediaDataList, function (i, item) {
                        // use a data url as an image source - ADDING WATERMARK TO THE IMAGE
                        watermark([item.data])
                            .dataUrl(watermark.text.lowerRight('Iceil', '30px serif', '#fff', 0.5))
                            .then(function (url) {
                                //document.querySelector('img').src = url;
                                //console.log("IMAGE GALLERY WATER MARK URL :", url);

                                var imageData = {
                                    image: url,
                                    id: item.uploadId
                                };

                                //  self.state.imageArray.push(url);
                                self.state.imageArray.push(imageData);
                                self.setState({
                                    imageArray: self.state.imageArray,
                                })
                                //console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray);

                            })

                    })
                }

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });


    }

    /*USED TO OPEN THE SLIDEPANE IMAGE EDIT */
    EditImage(image, id) {
        // alert("dit image page");
        var self = this;
        self.state.isImageEditPaneOpen = true;
        self.state.editImage = image;
        self.state.uploadId = id;

        self.setState({
            isImageEditPaneOpen: self.state.isImageEditPaneOpen,
            editImage: self.state.editImage,
            uploadId: self.state.uploadId
        })
    }

    /*USED TO CLOSE THE SLIDEPANE IMAGE EDIT */
    CloseImageEdit() {
        this.state.isImageEditPaneOpen = false;
        this.setState({
            isImageEditPaneOpen: this.state.isImageEditPaneOpen,
        })
    }

    /*
    FUNCTION USED TO ADD THE IMAGES 
    OPTED FOR THE ADDING TO CART ON CLICKING THE 
    ADD TO CART ICON - IMPLEMENTED BY PRIYANKA
    */
    AddtoCart(image, id) {
      //  alert("add to cart page");

        var self = this;

        var uploadData = [];
        uploadData.push(image);

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("FranchiseCompanyId"),
                franchiseId:GetLocalStorageData("FranchiseId"),
                uploadData: uploadData,
                module: "Saved Images",
                date: this.state.date,
                time: this.state.time,
                uploadType: 'Image',
                menuId: "Saved Images",
                description: '',
                uploadId: this.state.uploadId,

            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/FranchiseUpload/ItemsUpload",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                //console.log("MENU UPLOAD DATA :", data);

                //USED TO CALL THE RENDER IMAGE FUNCTION TO DISPLAY THE EDIA DATA AFTER RESPONSE
                if (data.mediaDataList.length > 0) {
                    self.props.RenderImages(data.mediaDataList)
                }

                if (data.response == "Success") {
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        text: 'Image added to cart Successfully',
                        showConfirmButton: false,
                        timer: 2000
                    })


                    self.props.CloseSlidingPane();

                } else if (data.response == "Few Failed") {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Failed to add image to cart, kindly try after sometime',
                        showConfirmButton: false,
                        timer: 2000
                    })
                } else if (data.response == "Count Exceeded") {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Saved images can have only 10 images, kindly delete the existing image to add new image into the cart',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });

    }

    /*
  FUNCTION USED FOR DOWNLOADING THE IMAGE
  IMPLEMENTED BY PRIYANKA - 28-04-2022
  */
    DownloadImage(data) {
        FileSaver.saveAs(data);
    }

    /*
  FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
  IMPLEMENTED BY PRIYANKA - 29-04-2022
  */
    handlePageChange(pageNumber) {
        //console.log(`active page is ${pageNumber}`);

        this.state.activePage = pageNumber;

        var startCount = 0;
        var endCount = 0;

        if (pageNumber > 1) {
            startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
            endCount = this.state.itemsCountPerPage;
            //  endCount=Number(startCount)+Number(this.state.itemsCountPerPage);
        } else {
            startCount = 0;
            endCount = this.state.itemsCountPerPage;
        }

        this.state.startCount = startCount;
        this.state.endCount = endCount;

        this.setState({
            activePage: pageNumber,
            startCount: startCount,
            endCount: startCount,
        });

        this.GetData_For_ChildMenu();
    }
    render() {
        return (
            <div>
                <div className="toptitle">
                    <h3>Choose Your Image</h3>
                </div>
                <Search componentCalled={"Choose Your Image"}/>
                <div>
                        <Pagination
                            activePage={this.state.activePage}
                            itemsCountPerPage={this.state.itemsCountPerPage}
                            totalItemsCount={this.state.totalItemsCount}
                            pageRangeDisplayed={5}
                            itemClass="page-item"
                            linkClass="page-link"
                            onChange={this.handlePageChange.bind(this)}
                        />
                    </div>
                <div className="card-box">
                <h4>{this.state.menuName}</h4>
                    <div className="row">
                        {(this.state.imageArray.length > 0 ?
                            (this.state.imageArray.map((data) => (
                                data != null && data != undefined
                                    ? (
                                        <div class="col-md-3">
                                            <div className="chooseimage">
                                                <img id="image" src={data.image} />
                                                {/* <ChooseImageIcons onAddtoCart={this.AddtoCart} onEditImage={this.EditImage} 
                                                onDownloadImage={() => this.DownloadImage(data)} /> */}
                                                <div className="chooseimageicons">
                                                    <ul>
                                                        <li><FaIcons.FaCartPlus alt="add to cart" data-tip data-for="AddtoCart" onClick={() => this.AddtoCart(data.image, data.id)} /></li>
                                                        <li><FiIcons.FiEdit alt="edit image" data-tip data-for="EditImage" onClick={() => this.EditImage(data.image, data.id)} /></li>
                                                        <li><BsIcons.BsDownload alt="logo" data-tip data-for="DownloadImag" onClick={() => this.DownloadImage(data.image, data.id)} /></li>
                                                    </ul>
                                                    <ReactTooltip id="AddtoCart" place="top" effect="solid">Add to Cart</ReactTooltip>
                                                    <ReactTooltip id="EditImage" place="top" effect="solid">Edit Image</ReactTooltip>
                                                    <ReactTooltip id="DownloadImag" place="top" effect="solid">Download Image</ReactTooltip>
                                                </div>
                                            </div>
                                        </div>)

                                    : (<div class="col-md-3">
                                        <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                                    </div>)
                            ))) : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                            </div>)

                        )}
                    </div>


                    <SlidingPane
                        className="some-custom-class"
                        overlayClassName="some-custom-overlay-class"
                        isOpen={this.state.isImageEditPaneOpen}
                        title={"Choose Your Image - Edit"}
                        // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                        onRequestClose={() => {
                            // triggered on "<" on left top click or on outside click
                            // setState({ isPaneOpen: false });
                            this.CloseImageEdit()
                        }}
                    >
                      {/*  <EditImage image={this.state.editImage} 
                        uploadId={this.state.uploadId} module={"Saved Images"} 
                        CloseSlidingPane={this.CloseImageEdit}
                         pageCalledFrom={"Choose Your Image"} />
                         */}
                          <EditImage_Cropper image={this.state.editImage} 
                        uploadId={this.state.uploadId} module={"Saved Images"} 
                        CloseSlidingPane={this.CloseImageEdit}
                         pageCalledFrom={"Choose Your Image"} />
                    </SlidingPane>
                </div>
            </div>
        );
    }
}

export default ChooseYourImage;
