import React, { Component } from 'react';
import $ from 'jquery';
import ReactCrop from 'react-image-crop';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import 'react-image-crop/dist/ReactCrop.css';
import { GetLocalStorageData, TimeZoneDateTime } from '../../Common Components/CommonComponents';
import { CheckNumberFormat_WithoutDecimal } from '../../Validation Components/FormErrors';


var url;
class EditImage_Cropper extends Component {

    constructor() {
        super()


        this.state = {

            src: null,
            crop: {
                unit: '%', // Can be 'px' or '%'
                x: 25,
                y: 25,
                width: 75,
                height: 75
            },
            height: 75,
            width: 75,
            maxWidth: 0,
            maxHeight: 0,

        }

    }

    componentDidMount() {

        //  //console.log("PROPS IMAGE : ", this.props);


        //  //console.log("EditImage this.props :", this.props);

        //USED WHEN EDIT IS OPTED FROM CHOOSE YOUR IMAGE
        url = "http://15.206.129.105:8080/IceilLiveAPI/FranchiseUpload/ItemsUpload";

        if (this.props.pageCalledFrom == "Saved Images") {
            url = "http://15.206.129.105:8080/IceilLiveAPI/FranchiseUpload/ItemsUploadUpdate"

            // this.props.CloseSlidingPane();
        }

        this.state.image = this.props.image;
        this.state.src = this.props.image;
        this.state.uploadId = this.props.uploadId;

        if (this.props.module == "Saved Images") {
            this.state.module = "Saved Images";
        } else if (this.props.module == "Generate Quotation") {
            this.state.module = "Generate Quotation";
        }

        this.setState({
            image: this.state.image,
            module: this.state.module,
            uploadId: this.state.uploadId,
            src: this.state.src,
        })

        /*
        GETTING DATE & TIME FOR THE CURRENT LOGIN
        - IMPLEMENTED BY PRIYANKA - 03-05-2022
        */
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        //   //console.log("dateTimeData :", dateTimeData);

        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.setState({
            date: this.state.date,
            time: this.state.time,
        })




    }

    onCropChange = (crop, percentCrop) => {
        // You could also use percentCrop:
        // this.setState({ crop: percentCrop });
        this.state.height = Math.floor(crop.height);
        this.state.width = Math.floor(crop.width);

        this.setState({
            crop,
            height: this.state.height,
            width: this.state.width,
        });
    };



    onCropComplete = (crop) => {
        //    //console.log("ON COROP COMPLETE :", crop);

        this.makeClientCrop(crop);
    };

    onImageLoaded = (image) => {
        //  var img = document.getElementById('image');

        //  //console.log("onImageLoaded :", image.target);
        // var img=this.state.src;

        var img = document.querySelector("#srcimage");

        //console.log("onImageLoaded IMAGE HEIGHT :", img.naturalHeight, " WIDTH: ", img.naturalWidth)
        //  //console.log( `Flower pot image is of dimension ${img.width} x ${img.height}` );

        this.imageRef = image.target;

        this.state.maxHeight = parseInt(`${img.height}`);
        this.state.maxWidth = parseInt(`${img.width}`);

        this.setState({
            maxHeight: this.state.maxHeight,
            maxWidth: this.state.maxWidth
        })

        //console.log("IMAGE WIDTH :", this.state.maxWidth, " IMAGE HEIGHT :", this.state.maxHeight);

        this.makeClientCrop(this.state.crop);


    };

    async makeClientCrop(crop) {
        //  //console.log("this.imageRef :", this.imageRef);

        //console.log("makeClientCrop crop BEFORE :", crop);
        var width = Math.floor(crop.width);
        var height = Math.floor(crop.height);

        crop.width = width;
        crop.height = height;

        //console.log("makeClientCrop crop AFTER :", crop);

        if (this.imageRef && crop.width && crop.height) {
            const croppedImageUrl = await this.getCroppedImg(
                this.imageRef,
                crop,
                "newFile.jpeg"
            );
            this.setState({ croppedImageUrl });
        }
    }

    getCroppedImg(image, crop, fileName) {

        const canvas = document.createElement("canvas");
        const pixelRatio = window.devicePixelRatio;
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        const ctx = canvas.getContext("2d");

        canvas.width = crop.width * pixelRatio * scaleX;
        canvas.height = crop.height * pixelRatio * scaleY;

        ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        ctx.imageSmoothingQuality = "high";

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width * scaleX,
            crop.height * scaleY
        );

        return new Promise((resolve, reject) => {
            canvas.toBlob(
                (blob) => {
                    if (!blob) {
                        //reject(new Error('Canvas is empty'));
                        console.error("Canvas is empty");
                        return;
                    }
                    blob.name = fileName;
                    window.URL.revokeObjectURL(this.fileUrl);
                    this.fileUrl = window.URL.createObjectURL(blob);

                    //CONVERT THE BLOB DATA INTO BASE64 STRING
                    blobToURL(blob).then((url) => (this.state.imageUrl = url, this.setState({ imageUrl: url }), /* //console.log("INSIDE imageUrl :", this.state.imageUrl), */ resolve(this.state.imageUrl)));

                    // resolve(this.fileUrl); //SENDS A BLOB DATA
                },
                "image/jpeg",
                1
            );
        });
    }

    /*
FUNCTION FOR GETTING THE INFO OF KEY PRESSED 
IN FIELDS LIKE PRODUCT - RATE,DISCOUNTAMT,DISCOUNT PERCENTAGE,CGST & SGST TAX,FINAL AMOUNT
*/
    handleUser_Height_Width_KeyPress_Func = (e) => {

        //  ////console.log("handleUser_Product_Rate_Discount_Tax_KeyPress_Func EVENT:",e);
        //  ////console.log("e.charCode",e.charCode);


        this.state.productCartFieldKeys = e.charCode;

        this.setState({
            productCartFieldKeys: this.state.productCartFieldKeys,
        })


    }

    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;


        var heightWidthValidationData = CheckNumberFormat_WithoutDecimal(this.state.productCartFieldKeys, value);

        //console.log("handleUserInput NAME:", name)
        //console.log("handleUserInput VALUE:", value)


        if (heightWidthValidationData == true) {


            var x = this.state.crop.x;
            var y = this.state.crop.y;
            var width = this.state.crop.width;
            var height = this.state.crop.height;
            var unit = this.state.crop.unit;


            if (name == "width") {

                if (parseInt(value) <= this.state.maxWidth) {
                    this.state[name] = value;
                    this.setState({
                        [name]: value
                    })

                    this.state.crop = {
                        unit: this.state.crop.unit, // Can be 'px' or '%'
                        x: this.state.crop.x,
                        y: this.state.crop.y,
                        width: value,
                        height: this.state.crop.height
                    }
                } else {
                    $("#" + name + "ErrorMsg").append("Width exceeeds maximum width of image !!");
                }

            } else if (name == "height") {


                if (parseInt(value) <= this.state.maxHeight) {
                    this.state[name] = value;
                    this.setState({
                        [name]: value
                    })
                    this.state.crop = {
                        unit: this.state.crop.unit, // Can be 'px' or '%'
                        x: this.state.crop.x,
                        y: this.state.crop.y,
                        width: this.state.crop.width,
                        height: value
                    }
                } else {
                    $("#" + name + "ErrorMsg").append("Height exceeeds maximum height of image !!");
                }

                this.setState({
                    crop: this.state.crop
                })

                //    //console.log("SET CROP this.state.crop: ", this.state.crop);

                this.makeClientCrop(this.state.crop);

            }
        } else {
            $("#" + name + "ErrorMsg").append("Incorrect Number Format !!");
        }

        HideFieldErrorMsgs(name + "ErrorMsg");
    }


    /*
FUNCTION USED FOR SAVING THE CROPPED IMAGE
WHICH WILL BE AVAILABLE IN SAVED IMAGES
IMPLEMENTED BY PRIYANKA - 30-04-2022
*/
    ApplyCropping(croppedImgSrc) {

        //   //console.log("ApplyCropping croppedImgSrc :", croppedImgSrc);

        var self = this;

        // alert("module" + this.state.module);

        if (croppedImgSrc != undefined) {

            var base64data;


            if (this.state.module == "Generate Quotation") {

                this.props.SetcroppedImgSrc(croppedImgSrc, this.state.uploadId);
                this.props.CloseSlidingPane();
            } else if (this.state.module = "Saved Images") {

                var uploadData = [];
                uploadData.push(croppedImgSrc);


                /*   //console.log("APPLY CROPPING DATA :", JSON.stringify({
                       companyId: GetLocalStorageData("FranchiseCompanyId"),
                       uploadData: uploadData,
                       module: this.state.module,
                       date: this.state.date,
                       time: this.state.time,
                       uploadType: 'Image',
                       menuId: this.state.module,
                       description: '',
                       uploadId: this.state.uploadId,
   
                   }));
   */
                $.ajax({
                    type: 'POST',
                    data: JSON.stringify({
                        companyId: GetLocalStorageData("FranchiseCompanyId"),
                        franchiseId: GetLocalStorageData("FranchiseId"),
                        uploadData: uploadData,
                        module: this.state.module,
                        date: this.state.date,
                        time: this.state.time,
                        uploadType: 'Image',
                        menuId: this.state.module,
                        description: '',
                        uploadId: this.state.uploadId,

                    }),

                    url: url,

                    contentType: "application/json",
                    dataType: 'json',
                    async: false,
                    success: function (data, textStatus, jqXHR) {

                        //   //console.log("MENU UPLOAD DATA :", data);

                        //USED TO CALL THE RENDER IMAGE FUNCTION TO DISPLAY THE EDIA DATA AFTER RESPONSE
                        if (data.mediaDataList.length > 0) {
                            self.props.RenderImages(data.mediaDataList)
                        }

                        if (data.response == "Success") {
                            Swal.fire({
                                position: 'center',
                                icon: 'success',
                                text: 'Edited image saved Successfully',
                                showConfirmButton: false,
                                timer: 2000
                            })


                            self.props.CloseSlidingPane();

                        } else if (data.response == "Few Failed") {
                            Swal.fire({
                                position: 'center',
                                icon: 'warning',
                                text: 'Failed to save edited image, kindly try after sometime',
                                showConfirmButton: false,
                                timer: 2000
                            })
                        } else if (data.response == "Count Exceeded") {
                            Swal.fire({
                                position: 'center',
                                icon: 'warning',
                                text: 'Saved images can have only 10 images, kindly delete the existing image to save the new edited image',
                                showConfirmButton: false,
                                timer: 2000
                            })
                        }

                    },
                    error: function (data) {
                        Swal.fire({
                            position: 'center',
                            icon: 'error',
                            title: 'Network Connection Problem',
                            showConfirmButton: false,
                            timer: 2000
                        })


                    },
                });

            }
        } else {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Image is not cropped for applying ',
                showConfirmButton: false,
                timer: 2000
            })
        }

    }

    cancelCropping() {
        var self = this;
        this.props.CloseSlidingPane(this);
    }


    render() {

        const { crop, croppedImageUrl, src } = this.state;

        return (

            <div class="container">
                <div class="col-md-12">


                </div>



                <div class="row">
                    <div className="col-md-6">
                        <label class="control-label">Height <span class="mandatoryfields">*</span></label>
                        <input type="text" placeholder="Height" name="height" value={this.state.height}
                            onKeyPress={this.handleUser_Height_Width_KeyPress_Func}
                            onChange={this.handleUserInput} className="textfield form-control" />
                        <span id="heightErrorMsg" style={{ color: 'red' }}></span>
                    </div>
                    <div className="col-md-6">
                        <label>Width <span class="mandatoryfields">*</span></label>
                        <input type="text" className="textfield textfield_class form-control"
                            onKeyPress={this.handleUser_Height_Width_KeyPress_Func}
                            onChange={this.handleUserInput} name="width" placeholder="Description" value={this.state.width} />
                        <span id="widthErrorMsg" style={{ color: 'red' }}></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h3 style={{ fontSize: '20px', fontWeight: '600' }}>Original Image</h3>
                        <ReactCrop crop={this.state.crop}
                            onChange={this.onCropChange}
                            onComplete={this.onCropComplete}
                            maxHeight={this.state.maxHeight}
                            maxWidth={this.state.maxWidth} >
                            <img id="srcimage" src={this.state.src}
                                onLoad={this.onImageLoaded} />
                        </ReactCrop>
                    </div>

                    <div class="col-md-6">
                        <h3 style={{ fontSize: '20px', fontWeight: '600' }}>Cropped Image</h3>
                        {croppedImageUrl && (
                            <img alt="Crop" style={{ maxWidth: "100%" }}
                                src={croppedImageUrl} />
                        )}
                    </div>
                </div>

                <div class="text-center">
                    <button className="btn btn-primary btn-submit" onClick={() => this.ApplyCropping(croppedImageUrl)} >
                        Apply
                    </button>
                    <button className="btn btn-primary btn-cancel" onClick={() => this.cancelCropping(croppedImageUrl)} >
                        Cancel
                    </button>
                </div>

            </div>

        );
    }

}
export default EditImage_Cropper;

/*
  USED TO HIDE THE ERROR MESSAGES OF THE FIELDS DISPLAYED
  */
function HideFieldErrorMsgs(fieldId) {
    setTimeout(function () {
        $("#" + fieldId).empty();
    }, 4000);
}
