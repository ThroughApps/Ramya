import React from "react";
import ReactDOM from "react-dom";
import Cropper from "react-cropper";
import CryptoJS from 'crypto-js';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import $ from 'jquery';
import * as FileSaver from 'file-saver';

import "cropperjs/dist/cropper.css";
import { GetLocalStorageData, TimeZoneDateTime } from "../../Common Components/CommonComponents";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var url;
class EditImage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      imageSrc: "",
      menuId: "",
      uploadId: "",
    };
    this.fileInput = React.createRef();
    this.handleFileRead = this.handleFileRead.bind(this);
    this.fileReader = new FileReader();
    this.cropper = React.createRef();
    this.cancelCropping = this.cancelCropping.bind(this);
  }

  componentDidMount() {

    //console.log("EditImage this.props :", this.props);

    //USED WHEN EDIT IS OPTED FROM CHOOSE YOUR IMAGE
    url = "http://15.206.129.105:8080/IceilLiveAPI/FranchiseUpload/ItemsUpload";

    if (this.props.pageCalledFrom == "Saved Images") {
      url = "http://15.206.129.105:8080/IceilLiveAPI/FranchiseUpload/ItemsUploadUpdate"

     // this.props.CloseSlidingPane();
    }

    this.state.image = this.props.image;
    this.state.uploadId = this.props.uploadId;

    if (this.props.module == "Saved Images") {
      this.state.module = "Saved Images";
    } else if (this.props.module == "Generate Quotation") {
      this.state.module = "Generate Quotation";
    }

    this.setState({
      image: this.state.image,
      module: this.state.module,
      uploadId: this.state.uploadId,
    })

    /*
    GETTING DATE & TIME FOR THE CURRENT LOGIN
    - IMPLEMENTED BY PRIYANKA - 03-05-2022
    */
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    //console.log("dateTimeData :", dateTimeData);

    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.setState({
      date: this.state.date,
      time: this.state.time,
    })

  }

  handleFileRead(e) {
    //console.log("The reading is over");
    const binaryData = this.fileReader.result;
    const base64Data = window.btoa(binaryData);
    this.setState({ base64: base64Data });
  }

  handleChange(event) {
    const file = this.fileInput.current.files[0];
    const { name, size, type } = file;
    const imageSrc = URL.createObjectURL(event.target.files[0]);

    this.setState({
      name,
      size,
      type,
      imageSrc,
      croppedImgSrc: null
    });

    //console.log(file.name);
    this.fileReader.onloadend = this.handleFileRead;
    this.fileReader.readAsBinaryString(file);
  }

  handleCropChange() {
    //console.log("## cropped !");
    const croppedImgData = this.cropper.current.cropper
      .getCroppedCanvas()
      .toDataURL();

    this.state.croppedImgSrc = croppedImgData;
    this.setState({ croppedImgSrc: croppedImgData });
  }

  handleRotate() {
    this.cropper.current.cropper.rotate(90);
    this.handleCropChange();
  }

  /*
  FUNCTION USED FOR DOWNLOADING THE IMAGE
  IMPLEMENTED BY PRIYANKA - 30-04-2022
  */
  DownloadImage(data) {
    FileSaver.saveAs(data);
  }

  /*
  FUNCTION USED FOR SAVING THE CROPPED IMAGE
  WHICH WILL BE AVAILABLE IN SAVED IMAGES
  IMPLEMENTED BY PRIYANKA - 30-04-2022
  */
  ApplyCropping(croppedImgSrc) {

    //console.log("ApplyCropping croppedImgSrc :",croppedImgSrc);
   
    var self = this;

    // alert("module" + this.state.module);

    if(croppedImgSrc!=undefined){
    if (this.state.module == "Generate Quotation") {
      this.props.SetcroppedImgSrc(croppedImgSrc, this.state.uploadId);
      this.props.CloseSlidingPane();
    } else if (this.state.module = "Saved Images") {

      var uploadData = [];
      uploadData.push(croppedImgSrc);


      /*console.log("APPLY CROPPING DATA :", JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        uploadData: uploadData,
        module: this.state.module,
        date: this.state.date,
        time: this.state.time,
        uploadType: 'Image',
        menuId: this.state.module,
        description: '',
        uploadId: this.state.uploadId,

      }));
      */

      $.ajax({
        type: 'POST',
        data: JSON.stringify({
          companyId: GetLocalStorageData("FranchiseCompanyId"),
          franchiseId: GetLocalStorageData("FranchiseId"),
          uploadData: uploadData,
          module: this.state.module,
          date: this.state.date,
          time: this.state.time,
          uploadType: 'Image',
          menuId: this.state.module,
          description: '',
          uploadId: this.state.uploadId,

        }),

        url: url,

        contentType: "application/json",
        dataType: 'json',
        async: false,
        success: function (data, textStatus, jqXHR) {

          //console.log("MENU UPLOAD DATA :", data);

          //USED TO CALL THE RENDER IMAGE FUNCTION TO DISPLAY THE EDIA DATA AFTER RESPONSE
          if (data.mediaDataList.length > 0) {
            self.props.RenderImages(data.mediaDataList)
          }

          if (data.response == "Success") {
            Swal.fire({
              position: 'center',
              icon: 'success',
              text: 'Edited image saved Successfully',
              showConfirmButton: false,
              timer: 2000
            })


            self.props.CloseSlidingPane();

          } else if (data.response == "Few Failed") {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Failed to save edited image, kindly try after sometime',
              showConfirmButton: false,
              timer: 2000
            })
          } else if (data.response == "Count Exceeded") {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Saved images can have only 10 images, kindly delete the existing image to save the new edited image',
              showConfirmButton: false,
              timer: 2000
            })
          }

        },
        error: function (data) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'Network Connection Problem',
            showConfirmButton: false,
            timer: 2000
          })


        },
      });

    }
  }else{
    Swal.fire({
      position: 'center',
      icon: 'warning',
      text: 'Image is not cropped for applying ',
      showConfirmButton: false,
      timer: 2000
  })
  }

  }

  cancelCropping() {
    var self = this;
    this.props.CloseSlidingPane(this);
  }

  render() {
    const { name, type, size, imageSrc, base64, croppedImgSrc } = this.state;

    return (
      <div className="App">
        {/* <h1>Image import</h1>
        <p>Import a picture, see its properties, a preview & get a base64 </p>
        <input
          type="file"
          accept="image/*"
          ref={this.fileInput}
          onChange={e => this.handleChange(e)}
    /> */}
        <div>
          {/*    <h2>File properties</h2>
          <ul>
            <li>Name: {name}</li>
            <li>Type: {type}</li>
            <li>Size: {size}</li>
          </ul> */}
          <div className="row">
            <div className="col-md-6">
              <h2>Raw image preview</h2>
              <img src={this.state.image} style={{ maxWidth: "400px" }} />
            </div>
            {/*  <button onClick={() => this.handleRotate()}>Rotate</button> */}
            <div className="col-md-6">
              <h2>Cropped image preview</h2>
              <img src={croppedImgSrc} style={{ maxWidth: "400px" }} />
            </div>
          </div>
          <div className="row mt-40">
            <div className="text-center">
              <h2>Cropper</h2>
              <Cropper
                style={{ maxWidth: "100%", height: "500px" }}
                ref={this.cropper}
                src={this.state.image}
                aspectRatio={16 / 9}
                cropend={() => this.handleCropChange()}
              />
            </div>
          </div>
          {/*  <button download="croppedImage.png" href={croppedImgSrc} onClick={() => this.DownloadImage(croppedImgSrc)} >
            Download
          </button>
        */}
          {/*  <h2>Raw image Base64</h2>
          <textarea value={base64} style={{ width: "100%", height: "50px" }} />
        */}
          {/*  <h2>Cropped image Base64</h2>
          <textarea
            value={croppedImgSrc}
            style={{ width: "100%", height: "50px" }}
          />
          */}
          <button className="btn btn-primary btn-submit" onClick={() => this.ApplyCropping(croppedImgSrc)} >
            Apply
          </button>
          <button className="btn btn-primary btn-cancel" onClick={() => this.cancelCropping(croppedImgSrc)} >
            Cancel
          </button>
        </div>
        {/* <h2>Actions</h2>
        <a
          href="https://codebeautify.org/base64-to-image-converter"
          target="_blank"
        >
          Decode base64
        </a> */}

      </div>
    );
  }
}

export default EditImage;
// const rootElement = document.getElementById("root");
// ReactDOM.render(<App />, rootElement);
