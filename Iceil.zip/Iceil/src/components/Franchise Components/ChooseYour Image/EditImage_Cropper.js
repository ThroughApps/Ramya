import React, { Component } from 'react';
import $ from 'jquery';
import ReactCrop from 'react-image-crop';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import 'react-image-crop/dist/ReactCrop.css';
import { GetLocalStorageData, TimeZoneDateTime } from '../../Common Components/CommonComponents';
import { CheckNumberFormat_WithoutDecimal } from '../../Validation Components/FormErrors';
import { AddToCart_ChooseYourImage_To_SavedImages, GetFileName, UploadToAWS } from '../../AWS/AWSFunctionality';


var url;
class EditImage_Cropper extends Component {

    constructor() {
        super()


        this.state = {

            src: null,
            crop: {
                unit: '%', // Can be 'px' or '%'
                x: 25,
                y: 25,
                width: 75,
                height: 75
            },
            height: 75,
            width: 75,
            maxWidth: 0,
            maxHeight: 0,
            calledPage: 'ChooseYourImage',

        }

    }

    componentDidMount() {



        this.state.image = this.props.image;

        //var base64Data = getBase64(this.props.image);
        //console.log("base64Data :",base64Data);
       // this.state.src = base64Data;
        this.state.src = this.props.image;
        this.state.uploadId = this.props.uploadId;

        if (this.props.module == "Saved Images") {
            this.state.module = "Saved Images";
        } else if (this.props.module == "Choose Your Image") {
            this.state.module = "Choose Your Image";
        } else if (this.props.module == "Generate Quotation") {
            this.state.module = "Generate Quotation";
        }

        this.setState({
            image: this.state.image,
            module: this.state.module,
            uploadId: this.state.uploadId,
            src: this.state.src,
        })


    }

    onCropChange = (crop, percentCrop) => {
        // You could also use percentCrop:
        // this.setState({ crop: percentCrop });
        this.state.height = Math.floor(crop.height);
        this.state.width = Math.floor(crop.width);

        this.setState({
            crop,
            height: this.state.height,
            width: this.state.width,
        });
    };



    onCropComplete = (crop) => {
        //    //console.log("ON COROP COMPLETE :", crop);

        this.makeClientCrop(crop);
    };

    onImageLoaded = (image) => {
        //  var img = document.getElementById('image');

       console.log("onImageLoaded :", image.target);
        // var img=this.state.src;

        var img = document.querySelector("#srcimage");

        //console.log("onImageLoaded IMAGE HEIGHT :", img.naturalHeight, " WIDTH: ", img.naturalWidth)
        //  //console.log( `Flower pot image is of dimension ${img.width} x ${img.height}` );

        this.imageRef = image.target;

        this.state.maxHeight = parseInt(`${img.height}`);
        this.state.maxWidth = parseInt(`${img.width}`);

        this.setState({
            maxHeight: this.state.maxHeight,
            maxWidth: this.state.maxWidth
        })

        //console.log("IMAGE WIDTH :", this.state.maxWidth, " IMAGE HEIGHT :", this.state.maxHeight);

        this.makeClientCrop(this.state.crop);


    };

    async makeClientCrop(crop) {
        //  //console.log("this.imageRef :", this.imageRef);

        //console.log("makeClientCrop crop BEFORE :", crop);
        var width = Math.floor(crop.width);
        var height = Math.floor(crop.height);

        crop.width = width;
        crop.height = height;

        //console.log("makeClientCrop crop AFTER :", crop);

        if (this.imageRef && crop.width && crop.height) {
            const croppedImageUrl = await this.getCroppedImg(
                this.imageRef,
                crop,
                "newFile.jpeg"
            );
            this.setState({ croppedImageUrl });
        }
    }

    getCroppedImg(image, crop, fileName) {

        const canvas = document.createElement("canvas");
        const pixelRatio = window.devicePixelRatio;
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        const ctx = canvas.getContext("2d");

        canvas.width = crop.width * pixelRatio * scaleX;
        canvas.height = crop.height * pixelRatio * scaleY;

        ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        ctx.imageSmoothingQuality = "high";

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width * scaleX,
            crop.height * scaleY
        );

        return new Promise((resolve, reject) => {
            canvas.toBlob(
                (blob) => {
                    if (!blob) {
                        //reject(new Error('Canvas is empty'));
                        console.error("Canvas is empty");
                        return;
                    }
                    blob.name = fileName;
                    window.URL.revokeObjectURL(this.fileUrl);
                    this.fileUrl = window.URL.createObjectURL(blob);

                    //CONVERT THE BLOB DATA INTO BASE64 STRING
                    blobToURL(blob).then((url) => (this.state.imageUrl = url, this.setState({ imageUrl: url }), /* //console.log("INSIDE imageUrl :", this.state.imageUrl), */ resolve(this.state.imageUrl)));

                    // resolve(this.fileUrl); //SENDS A BLOB DATA
                },
                "image/jpeg",
                1
            );
        });
    }

    /*
FUNCTION FOR GETTING THE INFO OF KEY PRESSED 
IN FIELDS LIKE PRODUCT - RATE,DISCOUNTAMT,DISCOUNT PERCENTAGE,CGST & SGST TAX,FINAL AMOUNT
*/
    handleUser_Height_Width_KeyPress_Func = (e) => {

        //  ////console.log("handleUser_Product_Rate_Discount_Tax_KeyPress_Func EVENT:",e);
        //  ////console.log("e.charCode",e.charCode);


        this.state.productCartFieldKeys = e.charCode;

        this.setState({
            productCartFieldKeys: this.state.productCartFieldKeys,
        })


    }

    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;


        var heightWidthValidationData = CheckNumberFormat_WithoutDecimal(this.state.productCartFieldKeys, value);

        //console.log("handleUserInput NAME:", name)
        //console.log("handleUserInput VALUE:", value)


        if (heightWidthValidationData == true) {


            var x = this.state.crop.x;
            var y = this.state.crop.y;
            var width = this.state.crop.width;
            var height = this.state.crop.height;
            var unit = this.state.crop.unit;


            if (name == "width") {

                if (parseInt(value) <= this.state.maxWidth) {
                    this.state[name] = value;
                    this.setState({
                        [name]: value
                    })

                    this.state.crop = {
                        unit: this.state.crop.unit, // Can be 'px' or '%'
                        x: this.state.crop.x,
                        y: this.state.crop.y,
                        width: value,
                        height: this.state.crop.height
                    }
                } else if (value == "") {
                    this.state[name] = value;
                    this.setState({
                        [name]: value
                    })
                } else {
                    $("#" + name + "ErrorMsg").append("Width exceeeds maximum width of image !!");
                }

            } else if (name == "height") {


                if (parseInt(value) <= this.state.maxHeight) {
                    this.state[name] = value;
                    this.setState({
                        [name]: value
                    })
                    this.state.crop = {
                        unit: this.state.crop.unit, // Can be 'px' or '%'
                        x: this.state.crop.x,
                        y: this.state.crop.y,
                        width: this.state.crop.width,
                        height: value
                    }
                } else if (value == "") {
                    this.state[name] = value;
                    this.setState({
                        [name]: value
                    })
                } else {
                    $("#" + name + "ErrorMsg").append("Height exceeeds maximum height of image !!");
                }

                this.setState({
                    crop: this.state.crop
                })

                //    //console.log("SET CROP this.state.crop: ", this.state.crop);

                this.makeClientCrop(this.state.crop);

            }
        } else {
            $("#" + name + "ErrorMsg").append("Incorrect Number Format !!");
        }

        HideFieldErrorMsgs(name + "ErrorMsg");
    }


    /*
FUNCTION USED FOR SAVING THE CROPPED IMAGE
WHICH WILL BE AVAILABLE IN SAVED IMAGES
IMPLEMENTED BY PRIYANKA - 30-04-2022
*/
    ApplyCropping(croppedImgSrc) {

        //   //console.log("ApplyCropping croppedImgSrc :", croppedImgSrc);

        var self = this;
        var uploadData = [];
        var metaData = {

        }
        this.state.folderPath = "Saved Images" + "/" + GetLocalStorageData("FranchiseId");
        this.setState({
            folderPath: this.state.folderPath
        })

        // alert("module" + this.state.module);
        if (croppedImgSrc != undefined && this.state.height != "" && this.state.width != "") {

            if (this.state.module == "Saved Images") {
                //OVER WRITE THE EDITED IMAGE FROM SAVED IMAGE MODULE INTO SAVED IMAGES

                const url = croppedImgSrc;
                var file;
                var filePath = this.props.editImageFilePath;
                 // alert("APPLYING SRC filePath :"+filePath);
                var splitData = (filePath).split(/[\s/]+/);
                var onlyFilename = splitData[splitData.length - 1];

                //  alert("filePath :"+filePath);
                //  onlyFilename=Number(onlyFilename)+Number(1);

                fetch(url)
                    .then(res => res.blob())
                    .then(blob => {
                        file = new File([blob], "File name", { type: "image/png" })
                        console.log("ApplyCropping file :", file);

                        var fileData = {
                            originalName: file.name,
                            name: onlyFilename,
                            data: file,
                            // src:reader.result,
                            size: file.size,
                            fileType: file.type
                        }

                        uploadData.push(fileData);

                        self.UploadData(uploadData, metaData, "Saved Images");

                    })


            } else if (this.state.module == "Choose Your Image") {
                //UPLOAD THE EDITED IMAGE FROM CHOOSE YOUR IMAGE MODULE INTO SAVED IMAGES

                const url = croppedImgSrc;
                var file;
                fetch(url)
                    .then(res => res.blob())
                    .then(blob => {
                        file = new File([blob], "File name", { type: "image/png" })
                        console.log("ApplyCropping file :", file);

                        var fileData = {
                            originalName: file.name,
                            name: 1,
                            data: file,
                            // src:reader.result,
                            size: file.size,
                            fileType: file.type
                        }

                        uploadData.push(fileData);

                        GetFileName(this.state.folderPath).then(function (response) {
                            console.log("** RESPONSE :", response)
                            if (response !== "Error") {
                                // self.UpdateProfileImage(fileName);
                                console.log("** RESPONSE CONTENTS :", response.Contents)

                                var contentsLength = (response.Contents.length) - 1;
                                console.log("contentsLength :", contentsLength);

                                var fileNameArray = response.Contents.map(function (el) {
                                    var splitData = (el.Key).split(/[\s/]+/);
                                    var onlyFilename = splitData[splitData.length - 1];
                                    return onlyFilename.split(".")[0]
                                });

                                var fileNameArrayInt = fileNameArray.map(Number);


                                console.log("fileNameArrayInt :", fileNameArrayInt);

                                var keyName = Math.max(...fileNameArrayInt);

                                //  alert("keyName :" + keyName);
                                console.log(" **** uploadData :", uploadData);
                                keyName = Number(keyName) + Number(1);

                                uploadData[0].name = keyName.toString();

                                self.UploadData(uploadData, metaData, "Choose Your Image");


                            }
                        });


                    })

                console.log("ApplyCropping file outside:", file);



            } else if (this.state.module == "Generate Quotation") {

            }

        } else {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Image is not cropped for applying ',
                showConfirmButton: false,
                timer: 2000
            })
        }

        /*   if (croppedImgSrc != undefined) {
   
               var base64data;
   
   
               if (this.state.module == "Generate Quotation") {
   
                   this.props.SetcroppedImgSrc(croppedImgSrc, this.state.uploadId);
                   this.props.CloseSlidingPane();
               } else if (this.state.module = "Saved Images") {
   
                  
   
   
               }
           } else {
               Swal.fire({
                   position: 'center',
                   icon: 'warning',
                   text: 'Image is not cropped for applying ',
                   showConfirmButton: false,
                   timer: 2000
               })
           }
           */

    }

    UploadData(uploadData, metaData, module) {

        var self = this;
        console.log("***** UPLOAD DATA FUNC :",uploadData);
        UploadToAWS(self.state.folderPath, uploadData, metaData).then(function (response) {
            console.log(" ***** UploadToAWS response :", response);
            if (response == "Uploaded") {
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    text: 'Uploaded Successfully',
                    showConfirmButton: false,
                    timer: 2000
                })

            } else if (response == "Error") {
                Swal.fire({
                    position: 'center',
                    icon: 'warning',
                    text: 'Upload done partially, kindly try after sometime',
                    showConfirmButton: false,
                    timer: 2000
                })
            }
            self.props.CloseSlidingPane();
            if (module == "Saved Images") {
                self.props.ResetData();
            }
        })
    }

    cancelCropping() {
        var self = this;
        this.props.CloseSlidingPane(this);
    }


    render() {

        const { crop, croppedImageUrl, src } = this.state;

        return (

            <div class="container">
                <div class="col-md-12">


                </div>



                <div class="row">
                    <div className="col-md-6">
                        <label class="control-label">Height <span class="mandatoryfields">*</span></label>
                        <input type="text" placeholder="Height" name="height" value={this.state.height}
                            onKeyPress={this.handleUser_Height_Width_KeyPress_Func}
                            onChange={this.handleUserInput} className="textfield" />
                        <span id="heightErrorMsg" style={{ color: 'red' }}></span>
                    </div>
                    <div className="col-md-6">
                        <label>Width <span class="mandatoryfields">*</span></label>
                        <input type="text" className="textfield textfield_class"
                            onKeyPress={this.handleUser_Height_Width_KeyPress_Func}
                            onChange={this.handleUserInput} name="width" placeholder="Width" value={this.state.width} />
                        <span id="widthErrorMsg" style={{ color: 'red' }}></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h3 style={{ fontSize: '20px', fontWeight: '600' }}>Original Image</h3>
                        <ReactCrop crop={this.state.crop}
                            onChange={this.onCropChange}
                            onComplete={this.onCropComplete}
                            maxHeight={this.state.maxHeight}
                            maxWidth={this.state.maxWidth} >
                            <img id="srcimage" src={this.state.src}
                                onLoad={this.onImageLoaded} />
                        </ReactCrop>
                    </div>

                    <div class="col-md-6">
                        <h3 style={{ fontSize: '20px', fontWeight: '600' }}>Cropped Image</h3>
                        {croppedImageUrl && (
                            <img alt="Crop" style={{ maxWidth: "100%" }}
                                src={croppedImageUrl} />
                        )}
                    </div>
                </div>

                <div class="text-center">
                    <button className="btn btn-primary btn-submit" onClick={() => this.ApplyCropping(croppedImageUrl)} >
                        Apply
                    </button>
                    <button className="btn btn-primary btn-cancel" onClick={() => this.cancelCropping(croppedImageUrl)} >
                        Cancel
                    </button>
                </div>

            </div>

        );
    }

}
export default EditImage_Cropper;

/*
  USED TO HIDE THE ERROR MESSAGES OF THE FIELDS DISPLAYED
  */
function HideFieldErrorMsgs(fieldId) {
    setTimeout(function () {
        $("#" + fieldId).empty();
    }, 4000);
}

function getBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}
