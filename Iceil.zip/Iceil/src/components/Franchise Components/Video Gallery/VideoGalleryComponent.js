//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import * as FileSaver from 'file-saver';
import * as BsIcons from 'react-icons/bs';
import * as FiIcons from 'react-icons/fi';
import watermark from "watermarkjs";
import $, { timers } from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import CryptoJS from 'crypto-js';
import ReactTooltip from 'react-tooltip';
import Pagination from "react-js-pagination";

import * as FaIcons from 'react-icons/fa';
import ReactPlayer from 'react-player';
import Modal from 'react-modal';

// import statement for react class component


// import statement for react component css
import '../Saved Image/SavedImageCss.css'
import { GetLocalStorageData } from "../../Common Components/CommonComponents";
import Search from "../../Assets Components/Search Components/SearchComponent";
import { GetFileName, GetImageFileFromAWS, GetVideoFileFromAWS, GetVideoFromAWS, Initialiaze_AWS_S3 } from "../../AWS/AWSFunctionality";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    }
};

var s3;
class VideoGalleryComponent extends React.Component {
    constructor() {
        super();

        window.VideoGallery_Component = this;

        this.state = {
            videoArray: [],
            videoPlayerOpen: false,
            videoPlayerClose: true,
            videoData: "",
        }
    }
    componentDidMount() {

        //console.log("IMAGE GALLERY this.props :", this.props);
        //   this.SetImageGalleryData(this.props.menuId, this.props.menuName, this.props.folderPath);


    }


    SetVideoGalleryData(videoArray) {

        console.log(" ***************** SetVideoGalleryData videoArray: ", videoArray);
        this.state.videoArray = [];
        this.setState({
            videoArray: this.state.videoArray
        })

        this.state.videoArray = videoArray;
        this.setState({
            videoArray: this.state.videoArray
        })

        Loading_Component.ModalCloseFun()
    }


    /*
          FUNCTION USED FOR DOWNLOADING THE IMAGE
          IMPLEMENTED BY PRIYANKA - 28-04-2022
          */
    PlayVideo(filePath) {

      //  alert("filePath :" + filePath);
        var self = this;


        //  Loading_Component.ModalOpenFun()

        self.state.videoPlayerOpen = true;
        self.setState({
            videoPlayerOpen: self.state.videoPlayerOpen
        })
        var currentFilePath = filePath.split("/");
        console.log(" ************************* currentFilePath :", currentFilePath);

        currentFilePath.splice(currentFilePath.length - 2, 1);
        console.log(" ************************* currentFilePath SLICE:", currentFilePath);

        var folderPath = currentFilePath.join("/");
        console.log("####### folderPath :", folderPath);

        //  this.state.videoData = "https://d3h6ssrmm09ie.cloudfront.net/" + folderPath; 
        this.state.videoData = "https://d5g1cpur5okjb.cloudfront.net/" + folderPath;
        this.setState({
            videoData: this.state.videoData
        })

        /*  Initialiaze_AWS_S3().then(function (s3) {
  
              GetVideoFromAWS(folderPath, s3).then(function (response) {
                  console.log("####### video :",response);
  
                 self.state.videoData = response.data;
                  self.setState({
                      videoData: self.state.videoData
                  })
  
                 
              })
  
          })
  */
        // Loading_Component.ModalCloseFun()

    }
    closeModal() {
        var self = this;
        self.state.videoPlayerOpen = false;
        self.state.videoPlayerClose = true;
        self.setState({
            videoPlayerOpen: self.state.videoPlayerOpen,
            videoPlayerClose: self.state.videoPlayerClose
        })
    }


    render() {
        // console.log(" *** COMPO RENDER this.state.imagearray :", this.state.imageArray)
        return (
            <div>
                {/* <div className="card-box">
                    <div className="row imgbox">
                        {(this.state.videoArray.length > 0 ?
                            (this.state.videoArray.map((data) => (
                                data.data != null && data.data != undefined && data.data != 'data:video/mp4;base64,'
                                    ? (<div class="col-md-4  " style={{ marginTop: '-20px' }}>
                                        <div class="video-card">
                                            {/* <video className="VideoInput_video" width="100%" height={300} controls src={data} /> ***
                                            <ReactPlayer
                                                url={data.data} 
                                                className='react-player'
                                                playing={false}
                                                controls
                                                width='100%'
                                                height='180px'
                                                light={data.data}
                                            />
                                            <div class="icon_card">
                                                <FaIcons.FaDownload onClick={() => this.DownloadVideo(data.data)} />
                                            </div>
                                        </div>
                                    </div>)
                                    :
                                    (<div> </div>)
                            ))) : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data </p>
                            </div>)

                        )}

                    </div>
                            
                </div> 
                */}
                <div className="row">
                    {(this.state.videoArray.length > 0 ?
                        (this.state.videoArray.map((data) => (
                            data.data != null && data.data != undefined && data.data != 'data:image/png;base64,'
                                ? (<div className="col-md-4"><div className="videobox">
                                    <img id="image" src={data.data} alt="Red dot" />

                                    <a><FiIcons.FiYoutube alt="logo" data-tip data-for="DownloadImage" onClick={() => this.PlayVideo(data.filePath)} />
                                        <ReactTooltip id="DownloadImage" place="top" effect="solid">Play</ReactTooltip></a>

                                </div></div>)
                                :
                                (<div class="col-md-4">
                                </div>)
                        ))) : (<div class="col-md-4">
                            <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data </p>
                        </div>)

                    )}

                </div>

                <Modal
                    isOpen={this.state.videoPlayerOpen}
                    //  onAfterOpen={this.customerafterOpenModal}	
                    onRequestClose={this.state.videoPlayerClose}

                    style={customStyles}

                    contentLabel="Example Modal"
                >
                    <div className="container">
                        <ReactPlayer
                            url={this.state.videoData}
                            className='react-player'
                            playing={false}
                            controls
                            width='100%'
                        //light={data.data}
                        />
                        <div class="text-center">
                            <button type="button" onClick={() => this.closeModal()} className="btn btn-primary">close</button>
                        </div>

                    </div>
                </Modal>
            </div>
        );
    }
}

export default VideoGalleryComponent;
