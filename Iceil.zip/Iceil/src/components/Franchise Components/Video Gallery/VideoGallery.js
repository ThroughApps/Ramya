import React, { Component } from 'react';
import $ from 'jquery';
import * as FileSaver from 'file-saver';
import './VideoGalleryCSS.css';
import ReactPlayer from 'react-player';
import * as FaIcons from 'react-icons/fa';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import { Player } from 'video-react';
import 'video-react/dist/video-react.css'; // import css
import CryptoJS from 'crypto-js';

import Pagination from "react-js-pagination";

import { GetLocalStorageData } from '../../Common Components/CommonComponents';
import Search from '../../Assets Components/Search Components/SearchComponent';
import { GetFileName, GetImageFileFromAWS, GetVideoFileFromAWS } from '../../AWS/AWSFunctionality';
import VideoGalleryComponent from './VideoGalleryComponent';
import LoadingComponent from '../../Assets Components/Loading Components/LoadingComponent';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
THIS PAGE IS USED TO SET WATER MARK TO THE IMAGES DURING RENDERING
*/

var videoURL;
class VideoGallery extends Component {

    constructor() {
        super()

        window.VideoGalleryComponent = this;
        this.state = {
            videoArray: [],
            menuId: '',
            activePage: 1,
            totalItemsCount: 0,
            itemsCountPerPage: 50,
            startCount: 0,
            endCount: 50,
            fileInfoArray: [],
        }

    }

    componentDidMount() {

        console.log("VIDEO GALLERY this.props :", this.props);
        this.state.folderPathThumbNail=this.props.folderPath+"/ThumbNail";
        this.SetVideoGalleryData(this.props.menuId, this.props.menuName, this.props.folderPath,this.state.folderPathThumbNail);

    }

    /*
     FUNCTION USED FOR CALLING THE DISPLAY THE DATA
     IMPLEMENTED BY PRIYANKA - 28-04-2022
     */
    SetVideoGalleryData(menuId, menuName, folderPath,folderPathThumbNail) {

         
        var self = this;
        this.state.menuId = menuId;
        this.state.menuName = menuName;

        this.state.videoArray = [];
        this.state.activePage = 1;
        this.state.totalItemsCount = 0;
        this.state.startCount = 0;
        this.state.endCount = 50;

        this.setState({
            videoArray: [],
            activePage: 1,
            totalItemsCount: 0,
            startCount: 0,
            endCount: 50,
            menuId: this.state.menuId,
            menuName: this.state.menuName,
        })

        Loading_Component.ModalOpenFun()

    //    alert("folderPath :" + folderPath);
        GetFileName(folderPathThumbNail).then(function (response) {

            if (response !== "Error") {
                console.log("** RESPONSE CONTENTS :", response.Contents)

                self.state.fileInfoArray = response.Contents;
                self.state.fileInfoArray.shift();
                self.setState({
                    fileInfoArray: self.state.fileInfoArray,
                })

                console.log("self.state.fileInfoArray :", self.state.fileInfoArray);

                self.state.totalItemsCount = response.Contents.length;
                self.setState({
                    totalItemsCount: self.state.totalItemsCount
                });

                if (self.state.fileInfoArray.length > 0) {
                    self.GetData();
                } else {
                    var response = [];
                    VideoGallery_Component.SetVideoGalleryData(response)
                }

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        });

    }

    GetData() {

        var self = this;

        var currentFileInfoArray = this.state.fileInfoArray.slice(this.state.startCount, this.state.endCount);

        console.log(" GetData this.state.startCount :", this.state.startCount, " this.state.endCount :", this.state.endCount);

        console.log("GetData currentFileInfoArray :", currentFileInfoArray);
        console.log("GetData this.state.fileInfoArray :", this.state.fileInfoArray);

        GetImageFileFromAWS(currentFileInfoArray).then(function (response) {

            if (response !== "Error") {

                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

                VideoGallery_Component.SetVideoGalleryData(response)

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })

        /*
        GetVideoFileFromAWS(currentFileInfoArray).then(function (response) {

            if (response !== "Error") {

                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

                VideoGallery_Component.SetVideoGalleryData(response)

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })

        */
        // console.log("** self.state.imageArray OUTSIDE :", self.state.imageArray)

    }



    /*
       FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
       IMPLEMENTED BY PRIYANKA - 28-04-2022
       */
    handlePageChange(pageNumber) {
        console.log(`active page is ${pageNumber}`);

        this.state.activePage = pageNumber;

        var startCount = 0;
        var endCount = 0;

        if (pageNumber > 1) {
            startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
            // endCount = this.state.itemsCountPerPage;
            endCount = Number(startCount) + Number(this.state.itemsCountPerPage);
            //  endCount=Number(startCount)+Number(this.state.itemsCountPerPage);
        } else {
            startCount = 0;
            endCount = this.state.itemsCountPerPage;
        }

        this.state.startCount = startCount;
        this.state.endCount = endCount;

        this.setState({
            activePage: pageNumber,
            startCount: startCount,
            endCount: startCount,
        });
        this.GetData();
    }

    render() {

        return (

            <div class="">
                <div class="franchise-toptitle toptitle">
                    <div style={{display:"flex"}}>
                    <h3>Video Gallery Project</h3>
                <h4 className='underline'>{this.state.menuName}</h4></div>
                <Search componentCalled={"Video Gallery"} />
                </div>
                    <Pagination
                        activePage={this.state.activePage}
                        itemsCountPerPage={this.state.itemsCountPerPage}
                        totalItemsCount={this.state.totalItemsCount}
                        pageRangeDisplayed={5}
                        itemClass="page-item"
                        linkClass="page-link"
                        onChange={this.handlePageChange.bind(this)}
                    />
                <VideoGalleryComponent />

                <LoadingComponent />
            </div>

        );
    }

}
export default VideoGallery;


