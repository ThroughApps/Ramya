import React, { Component } from 'react';
import $ from 'jquery';
import * as FileSaver from 'file-saver';
import './VideoGalleryCSS.css';
import ReactPlayer from 'react-player';
import * as FaIcons from 'react-icons/fa';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import { Player } from 'video-react';
import 'video-react/dist/video-react.css'; // import css
import CryptoJS from 'crypto-js';

import Pagination from "react-js-pagination";

import { GetLocalStorageData } from '../../Common Components/CommonComponents';
import Search from '../../Assets Components/Search Components/SearchComponent';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
THIS PAGE IS USED TO SET WATER MARK TO THE IMAGES DURING RENDERING
*/

var videoURL;
class VideoGallery extends Component {

    constructor() {
        super()

        window.VideoGalleryComponent = this;
        this.state = {
            videoArray: [],
            menuId: '',
            activePage: 1,
            totalItemsCount: 0,
            itemsCountPerPage: 5,
            startCount: 1,
            endCount: 5,
        }

    }

    componentDidMount() {

        console.log("VIDEO GALLERY this.props :", this.props);
        this.SetVideoGalleryData(this.props.menuId, this.props.menuName);

        //   alert("VIDEO GALLERY DID MOUNT");
    }

    /*
     FUNCTION USED FOR CALLING THE DISPLAY THE DATA
     IMPLEMENTED BY PRIYANKA - 28-04-2022
     */
    SetVideoGalleryData(menuId, menuName) {

        //  alert("VIDEO GALLERY SetVideoGalleryData");

        this.state.menuId = menuId;
        this.state.menuName = menuName;

        this.state.videoArray = [];
        this.state.activePage = 1;
        this.state.totalItemsCount = 0;
        this.state.startCount = 1;
        this.state.endCount = 5;

        this.setState({
            videoArray: [],
            activePage: 1,
            totalItemsCount: 0,
            startCount: 1,
            endCount: 5,
            menuId: this.state.menuId,
            menuName: this.state.menuName,
        })

        //CALLING FUNCTION TO RENDER THE MEDIA DATA FOR DISPLAY - IMPLEMENETED BY PRIYANKA - 27-04-2022
        this.GetData_For_ChildMenu();
    }

    /*
FUNCTION USED TO RENDER THE DATA BASED ON LAST CHILD MENU SELECTED FROM SIDE BAR 
- IMPLEMENETED BY PRIYANKA - 27-04-2022
*/
    GetData_For_ChildMenu() {

        var self = this;

        self.state.videoArray = [];
        self.setState({
            videoArray: self.state.videoArray,
        })
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("FranchiseCompanyId"),
                menuId: this.state.menuId,
                startCount: this.state.startCount,
                endCount: this.state.endCount,
            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/MediaData/MediaDisplayData",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("IMAGE GALLERY MediaDisplayData DATA :", data);

                if (data.mediaDataList.length > 0) {

                    self.state.totalItemsCount = data.dataCount;
                    self.setState({
                        dataCount: self.state.totalItemsCount
                    });

                    $.each(data.mediaDataList, function (i, item) {
                        self.state.videoArray.push(item.data);
                        self.setState({
                            videoArray: self.state.videoArray,
                        })
                    })
                }

                console.log("VIDEO ARRAY :", self.state.videoArray);
            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });


    }
    /*
       FUNCTION USED FOR DOWNLOADING THE IMAGE
       IMPLEMENTED BY PRIYANKA - 28-04-2022
       */
    DownloadVideo(data) {
        FileSaver.saveAs(data);
    }

    /*
       FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
       IMPLEMENTED BY PRIYANKA - 28-04-2022
       */
    handlePageChange(pageNumber) {
        console.log(`active page is ${pageNumber}`);

        this.state.activePage = pageNumber;

        var startCount = 0;
        var endCount = 0;

        if (pageNumber > 1) {
            startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
            endCount = this.state.itemsCountPerPage;
            //  endCount=Number(startCount)+Number(this.state.itemsCountPerPage);
        } else {
            startCount = 0;
            endCount = this.state.itemsCountPerPage;
        }

        this.state.startCount = startCount;
        this.state.endCount = endCount;

        this.setState({
            activePage: pageNumber,
            startCount: startCount,
            endCount: startCount,
        });

        this.GetData_For_ChildMenu();
    }

    render() {

        return (

            <div class="">

               {/* <ReactPlayer
                    url="https://iceilmedia.s3.ap-south-1.amazonaws.com/file_example_MP4_480_1_5MG.mp4"
                    className='react-player'
                    playing={false}
                    controls
                    width='100%'
                    height='180px'
                />
                */}

                <div class="franchise-toptitle toptitle">
                <div style={{display:"flex"}}>
                    <h3>Video Gallery Project</h3>
                    <h4>{this.state.menuName}</h4>
                    </div>
                    <Search componentCalled={"Video Gallery"} />
                </div>             
                    <Pagination
                        activePage={this.state.activePage}
                        itemsCountPerPage={this.state.itemsCountPerPage}
                        totalItemsCount={this.state.totalItemsCount}
                        pageRangeDisplayed={5}
                        itemClass="page-item"
                        linkClass="page-link"
                        onChange={this.handlePageChange.bind(this)}
                    />
                <div className="card-box">
                    <div class="row ">
                        {(this.state.videoArray.length > 0 ?
                            (this.state.videoArray.map((data) => (
                                data != null && data != undefined
                                    ? (<div class="col-md-4">
                                        <div class="video-card">
                                            {/* <video className="VideoInput_video" width="100%" height={300} controls src={data} /> */}
                                            <ReactPlayer
                                                url={data}
                                                className='react-player'
                                                playing={false}
                                                controls
                                                width='100%'
                                                height='150px'
                                            /> 
                                            <div class="icon_card">
                                                <FaIcons.FaDownload onClick={() => this.DownloadVideo(data)} />
                                            </div>
                                        </div>
                                    </div>)

                                    : (<div class="col-md-3">
                                        <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                                    </div>)
                            ))) : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                            </div>)

                        )}


                    </div>
                </div>

            </div>

        );
    }

}
export default VideoGallery;

const blobToBase64 = blob => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    return new Promise(resolve => {
        reader.onloadend = () => {
            resolve(reader.result);
        };
    });
};
