import React, { Component, Suspense } from 'react';
import TextField from '@mui/material/TextField';
//import {TextField} from '@material/textfield';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import ReactDOM from 'react-dom';
import $ from 'jquery';

import Case from "case";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';

import CryptoJS from 'crypto-js';
import * as FaIcons from 'react-icons/fa';
import { GetLocalStorageData } from '../../Common Components/CommonComponents';
import { ThemeProvider, createTheme } from '@mui/material/styles';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022
const darkTheme = createTheme({
    palette: {
      mode: 'dark',
    },
  });
class AboutMe extends Component {



    constructor(props) {
        super(props);
        this.state = {

        }
    }


    componentDidMount() {


        this.state.userName = GetLocalStorageData("FranchiseUserName"); 
        this.state.email = GetLocalStorageData("FranchiseEmailId"); 
        this.state.userType = GetLocalStorageData("FranchiseUserType"); 
        this.state.companyName = GetLocalStorageData("AdminCompanyName"); 

        if (this.state.userType == 'User_Franchise') {
            this.state.userType = "Franchise";
        }

        this.setState({
            userName: this.state.userName,
            email: this.state.email,
            userType: this.state.userType
        })
    }


    render() {


        return (

            <div class="">
                    <div class="franchise-toptitle toptitle">
                        <h4>About Me</h4>
                    </div>
                    <ThemeProvider theme={darkTheme}>
                    <div class="container-fluid">
                <div class="row">
                <div class="col-md-6">
                        {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD   */}
                         <TextField fullWidth size="small" margin="normal" label='User Name' value={this.state.userName} id="userEmail" name="userName" InputProps={{readOnly: true,}} />                                            
                        </div>
                        <div class="col-md-6">
                        {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
                         <TextField fullWidth size="small" margin="normal" label='Email' value={this.state.email} id="email" name="email" InputProps={{readOnly: true,}} />
                        </div>
                    <div class="col-md-6">
                        {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
                         <TextField fullWidth size="small" margin="normal" label='User Type' value={this.state.userType} id="userType" name="userType" InputProps={{readOnly: true,}} />
                        </div>
                        <div class="col-md-6">

                        {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
                         <TextField fullWidth size="small" margin="normal" label='Admin Organization' value={this.state.companyName} id="AdminOrganization" name="AdminOrganization" InputProps={{readOnly: true,}} />
                        </div>
                        </div>
                    </div>
                    </ThemeProvider>
                </div>
        );
    }

}
export default AboutMe;
