import React, { Component } from 'react';
import { PDFViewer } from 'react-view-pdf';
//import PdfThumbnail from 'react-pdf-thumbnail';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class PDFViewerCompoenent extends Component {

    constructor() {
        super()


        this.state = {
            pdfData:"",

        }
    }

    componentDidMount(){

        //console.log("PROPS PDF DATA :",this.props);

        this.state.pdfData=this.props.pdfData;
        this.setState({
            pdfData:this.state.pdfData,
        })
    }
    render() {

        return (
            <div class="">
                <PDFViewer  url={this.state.pdfData}  />

            </div>
        )
        };

}
export default PDFViewerCompoenent;


/*
export const thumb = function (pdfData) {
	const [viewImage, setViewImage] = React.useState();
	useEffect(() => {
	const createThumb = async () => {
		const { File, error, imageUrl } = await PdfThumbnail(
			pdfData,
			{ // thumb image config
				fileName: 'mythumbimage.png', // thumb file name
				height: 200, // image height
				width: 200, // image width
				pageNo: 1  // pdf page number
			}
		);
		if (!error) {
			setViewImage(imageUrl);
		}
	};
	}, []);
	
	return (
		<>
		
			<img src={viewImage} alt='img' />
		</>
	);
};
*/
