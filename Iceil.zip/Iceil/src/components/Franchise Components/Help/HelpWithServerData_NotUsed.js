import React, { Component, useState } from 'react';
import { HeplDropdown } from '../../Assets Components/DropdownComponents/DropdownComponent';
import './Helpcss.css';
import $ from 'jquery';
//import { FileSaver, saveAs } from 'file-saver';
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import ReactPlayer from 'react-player';
import { PDFViewer } from 'react-view-pdf';
import generatePdfThumbnails from 'pdf-thumbnails-generator';
import _ from 'underscore';

import Pagination from "react-js-pagination";
import iceillogo from '../../images/image1.png';
import '../../Franchise Components/Saved Image/SavedImageCss.css';
import './Helpcss.css'

import * as MdIcons from 'react-icons/md';
import ReactTooltip from 'react-tooltip';
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import 'video-react/dist/video-react.css'; // import css
import Viewer from "react-viewer/dist/index.js";
import { GetLocalStorageData, TimeZoneDateTime } from '../../Common Components/CommonComponents';
import PDFViewerCompoenent from './PDFViewerCompoenent';
import pdflogo from '../../images/pdflogo.png';
import { HelpSearchComponent } from '../../Assets Components/Search Components/SearchComponent';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class Help extends Component {

  constructor() {
    super()


    this.state = {

      companyId: '',
      isPdfViewPaneOpen: false,
      visible: '',
      activePage: 0,
      totalItemsCount: 0,
      itemsCountPerPage: 5,
      startCount: 0,
      endCount: 5,
      helpDataList: [],
      previewImages: [],
      totalHelpDataList: [],
      selectedDocType: [],
      helpSearchDataList: [],
      searchValue: "",
      searchType: "Normal",
      imageActiveIndex: 0,

    }
    this.PDFViewFunc = this.PDFViewFunc.bind(this);
    this.PopulateData = this.PopulateData.bind(this);
    this.DocTypeSelectChange = this.DocTypeSelectChange.bind(this);
    this.SearchChange = this.SearchChange.bind(this);
    this.GetSearchData = this.GetSearchData.bind(this);

  }

  /*
THIS FUNCTION LOADS IMMEDIATLY AFTER THE PAGE IS LOADED
IMPLEMENTED BY PRIYANKA ON 21-05-2022
*/
  componentDidMount() {

    /* this.state.selectedDocType.push({ label: "All", value: "All" });
     this.setState({
       selectedDocType: this.state.selectedDocType
     })
     */
    this.GetHelpData();
  }

  /*
  FUNCTION USED FOR GETTING HELP DATA TO BE DISPLAYED
  IMPLEMENETED BY PRIYANKA ON 21-05-2022
  */
  GetHelpData() {

    var self = this;

    self.state.helpDataList = [];
    self.state.totalHelpDataList = [];
    self.state.helpSearchDataList = [];
    self.setState({
      helpDataList: self.state.helpDataList,
      totalHelpDataList: self.state.totalHelpDataList,
      helpSearchDataList: self.state.helpSearchDataList
    })

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        menuId: "Help",
        startCount: this.state.startCount,
        endCount: this.state.endCount,
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/HelpService/HelpDisplayData",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //console.log("HELP DATA :", data);

        if (data.helpDataList.length > 0) {

          self.state.totalItemsCount = data.dataCount;
          self.setState({
            totalItemsCount: self.state.totalItemsCount
          });

          self.state.totalHelpDataList = data.helpDataList;
          self.state.helpSearchDataList = data.helpSearchDataList;

          self.setState({
            totalHelpDataList: self.state.totalHelpDataList,
            helpSearchDataList: self.state.helpSearchDataList
          })

          window.HelpSearchComponent.SetSearchData(self.state.helpSearchDataList);

          //console.log("SEARCH DATA LIST  self.state.helpSearchDataList: ", self.state.helpSearchDataList)
          self.PopulateData();


        }

      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });
  }


  /* THIS FUCNTION USED FOR SLIDEPANE IMPLEMENTED BY NANDHINI - 19-05-2022*/
  PDFViewFunc(pdfData, uploadId) {
    var self = this;
    self.state.isPdfViewPaneOpen = true;
    self.state.pdfData = pdfData;
    //console.log("isPdfViewPaneOpen", self.state.isPdfViewPaneOpen);
    self.setState({
      isPdfViewPaneOpen: self.state.isPdfViewPaneOpen,
      pdfData: self.state.pdfData,
    })
    var viewInfo = _.where(this.state.helpDataList, { uploadId: uploadId });

    this.RecordVisitCount(uploadId, viewInfo);
  }
  /* THIS FUCNTION USED FOR CLOSE SLIDEPANE IMPLEMENTED BY NANDHINI - 19-05-2022*/
  Closeview() {
    this.state.isPdfViewPaneOpen = false;
    this.setState({
      isPdfViewPaneOpen: this.state.isPdfViewPaneOpen,
    })
  }

  /*
 FUNCTION USED FOR SETTING UP THE IMAGE PREVIEW
 - IMPLEMENETED BY PRIYANKA ON 21-05-2022
 */
  setVisible(flag) {
    this.state.visible = flag;
    this.setState({
      visible: flag,
    })
  }

  /*
  FUNCTION USED FOR SELECTING & DISPLAYING THE
  SELECTED TYPE OF MEDIA - 
  IMPLEMENETED BY PRIYANKA 24-05-2022
  */
  DocTypeSelectChange(selectedDocType) {

    //console.log("selectedDocType :", selectedDocType);

    this.state.selectedDocType = selectedDocType;

    this.state.helpDataList = [];
    this.setState({
      helpDataList: this.state.helpDataList,
      selectedDocType: selectedDocType,
    })

    this.PopulateData();
  }

  /*
  FUNCTION USED FOR SELECTING THE DOCTYPE TO BE 
  DISPLAYED INTO THE RENDERED PART - 
  IMPLEMENETED BY PRIYANKA 24-05-2022
  */
  PopulateData() {


    var self = this;

    var selectedDocType = _.where(this.state.selectedDocType, { value: 'All' });

    //alert("this.state.selectedDocType.length :" + this.state.selectedDocType.length);

    if (this.state.selectedDocType.length == 0) {
      //  alert("IF");
      //console.log("POPULATE DATA this.state.totalHelpDataList :", this.state.totalHelpDataList);

      this.state.helpDataList = this.state.totalHelpDataList;
      this.setState({
        helpDataList: this.state.helpDataList
      })

      //console.log("POPULATE DATA this.state.helpDataList :", this.state.helpDataList);

    } else {
      //  alert("ELSE");

      $.each(this.state.selectedDocType, function (i, item) {
        var itemData = item.value;
        if (itemData == "PDF") {
          itemData = "Application"
        }
        var currentSelectedData = _.where(self.state.totalHelpDataList, { uploadType: itemData });
        //console.log("currentSelectedData :", currentSelectedData);
        if (currentSelectedData.length > 0) {

          for (var z = 0; z < currentSelectedData.length; z++) {
            self.state.helpDataList.push(currentSelectedData[z]);
          }
          self.setState({
            helpDataList: self.state.helpDataList,
          })
        }
      })


    }
    //console.log("PopulateData this.state.helpDataList :", this.state.helpDataList);
  }


  /*
  FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
  IMPLEMENTED BY PRIYANKA - 28-04-2022
  */
  handlePageChange(pageNumber) {
    //console.log(`active page is ${pageNumber}`);

    this.state.activePage = pageNumber;

    var startCount = 0;
    var endCount = 0;

    if (pageNumber > 1) {
      startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
      endCount = this.state.itemsCountPerPage;
      //  endCount=Number(startCount)+Number(this.state.itemsCountPerPage);
    } else {
      startCount = 0;
      endCount = this.state.itemsCountPerPage;
    }

    this.state.startCount = startCount;
    this.state.endCount = endCount;

    this.setState({
      activePage: pageNumber,
      startCount: startCount,
      endCount: startCount,
    });

    if (this.state.searchType == "Normal") {
      // alert("noamrl page");
      this.GetHelpData();
    } else if (this.state.searchType == "Search") {
      //  alert("search page");
      this.GetSearchData(this.state.searchValue);
    }
  }

  /*
 FUNCTION USED FOR HANDLING THE SEARCH BASED ON 
 KEYWORD ENTERED 
 - IMPLEMENETED BY PRIYANKA ON 21-05-2022
 */
  SearchChange(searchType, searchValue) {

    //console.log("SearchChange searchValue:", searchValue);

    if (searchType == "Search") {
      this.state.searchValue = searchValue;
      this.state.searchType = "Search";
      this.setState({
        searchValue: this.state.searchValue,
        searchType: this.state.searchType
      })
      this.GetSearchData(searchValue);
    } else if (searchType == "Normal") {
      this.state.searchValue = "";
      this.state.searchType = "Normal";
      this.setState({
        searchValue: this.state.searchValue,
        searchType: this.state.searchType
      })
      this.GetHelpData();
    }

  }

  /*
 FUNCTION USED FOR GETTING THE DATA BASED ON THE SEARCH
 KEYWORD ENTERED 
 - IMPLEMENETED BY PRIYANKA ON 21-05-2022
 */
  GetSearchData(searchValue) {

    var self = this;

    this.state.startCount = 0;
    this.state.endCount = 5;
    this.state.helpDataList = [];
    this.state.totalHelpDataList = [];
    this.state.helpSearchDataList = [];

    this.setState({
      startCount: this.state.startCount,
      endCount: this.state.endCount,
      helpDataList: this.state.helpDataList,
      totalHelpDataList: this.state.totalHelpDataList,
      helpSearchDataList: this.state.helpSearchDataList
    })


    var searchDataArray = searchValue.split(" ");
    //console.log("searchDataArray :", searchDataArray);

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        menuId: "Help",
        startCount: this.state.startCount,
        endCount: this.state.endCount,
        searchData: searchDataArray.toString(),
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/HelpService/HelpSearchDataDisplay",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //console.log("HELP SEARCH DATA :", data);

        if (data.helpSearchDataList.length > 0) {

          self.state.totalItemsCount = data.dataCount;
          self.setState({
            totalItemsCount: self.state.totalItemsCount
          });

          self.state.totalHelpDataList = data.helpSearchDataList;
          self.state.helpSearchDataList = data.helpSearchDataList;

          self.setState({
            totalHelpDataList: self.state.totalHelpDataList,
            helpSearchDataList: self.state.helpSearchDataList
          })

          window.HelpSearchComponent.SetSearchData(self.state.helpSearchDataList);

          //console.log("SEARCH DATA LIST  self.state.helpSearchDataList: ", self.state.helpSearchDataList)
          self.PopulateData();


        }

      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });

  }

  /*
 FUNCTION USED FOR IMPLEMENTING THE 
 IMAGE VIEW FOR THE SELECTED IMAGE
 - IMPLEMENETED BY PRIYANKA ON 21-05-2022
 */
  ImageViewFunc(uploadId) {

    var index = _.findIndex(this.state.helpDataList, { uploadId: uploadId });
    var viewInfo = _.where(this.state.helpDataList, { uploadId: uploadId });

    // alert("imageActiveIndex :" + index);

    this.state.imageActiveIndex = index;

    this.setVisible(true);
    this.setState({
      imageActiveIndex: this.state.imageActiveIndex,
    })

    this.RecordVisitCount(uploadId, viewInfo);

  }

  /*
 FUNCTION USED FOR RECORDING THE VISITCOUNT
 WHENEVER AN VIEW IS CLICKED FOR THE IMAGE, PDF/ VIDEO IS PLAYED
 - IMPLEMENETED BY PRIYANKA ON 21-05-2022
 */
  RecordVisitCount(uploadId, viewInfo) {

    var self = this;

    //console.log("RecordVisitCount viewInfo :", viewInfo);

    /*
    GETTING DATE & TIME FOR THE CURRENT LOGIN
    - IMPLEMENTED BY PRIYANKA - 31-05-2022
    */
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    //   //console.log("dateTimeData :", dateTimeData);

    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.setState({
      date: this.state.date,
      time: this.state.time,
    })

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        franchiseId: GetLocalStorageData("FranchiseId"),
        userId: GetLocalStorageData("UserId"),
        date: this.state.date,
        time: this.state.time,
        module: "Help",
        menuId: "Help",
        title: viewInfo[0].title,
        type: viewInfo[0].uploadType,
        uploadId: uploadId,
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/HelpService/RecordVisitCount",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //console.log("RECORD VISIT COUNT DATA: ", data);




      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });
  }


  /*
FUNCTION CALLED WHEN AN VIDEO IS PLAYED WHICH IN TURN CALLS 
THE RECORD COUNT FUNCTION FOR RECORDING THE VISITCOUNT
- IMPLEMENETED BY PRIYANKA ON 26-05-2022
*/
  PlayFunc(uploadId) {
    //  alert("ON PLAY CALLED :" + uploadId);
    var viewInfo = _.where(this.state.helpDataList, { uploadId: uploadId });
    this.RecordVisitCount(uploadId, viewInfo);

  }

  render() {

    //console.log("this.state.preview images :",this.state.previewImages)

    return (
      <div >
        <div class="toptitle">
          <h3 >Technical Know-How</h3>
        </div>
        {/* DROPDOWN FOR VIDEO,IMAGE,PDF  IMPLEMENTED BY NANDHINI - 02-05-2022 */}
        <div class="dropdown_class">
          <div class="">
            <HeplDropdown DocTypeSelectChange={this.DocTypeSelectChange} />
          </div>

          <div>
            <Pagination
              activePage={this.state.activePage}
              itemsCountPerPage={this.state.itemsCountPerPage}
              totalItemsCount={this.state.totalItemsCount}
              pageRangeDisplayed={5}
              itemClass="page-item"
              linkClass="page-link"
              onChange={this.handlePageChange.bind(this)}
            />
          </div>

          {/* SEARCH BAR  IMPLEMENTED BY NANDHINI - 02-05-2022 */}
          <div class="">
            <HelpSearchComponent helpSearchDataList={this.state.helpSearchDataList}
              onSearchChange={this.SearchChange} />
          </div>

        </div>



        {/* <div class="card-box"> */}
        <div class=" container card-box ">
          <div class="row grid_column col-md-3">

            {/*RENDERING PART  IMPLEMENTED BY PRIYANKA - 24-05-2022 */}

            <div class="col-md-12 " style={{ display: 'contents' }}>
              {(this.state.helpDataList.length > 0 ?
                (this.state.previewImages = [], this.state.helpDataList.map((data) => (
                  data != null && data != undefined
                    ? ((data.uploadType == "Image" ? (<div class="text-center " >
                      <div class="imginbox">

                        <img id="image" src={data.data} />
                        <span>{data.title}</span>

                        <div style={{ display: 'none' }}>
                          {this.state.previewImages.push({
                            src: data.data,
                            alt: 'no img',
                            uploadId: data.uploadId,
                            imageActiveIndex: this.state.index,
                            title: data.title,
                            type: data.uploadType
                            // downloadUrl: data.data
                          })},
                       
                        </div>

                        <div className="overlay">
                          <ul>
                            <li><MdIcons.MdOutlineRemoveRedEye class="icon" alt="logo"
                              onClick={() => this.ImageViewFunc(data.uploadId)} data-tip data-for="Viewimage" /></li>
                            <Viewer visible={this.state.visible} onClose={() => { this.setVisible(false); }}
                              images={this.state.previewImages} activeIndex={this.state.imageActiveIndex} />
                          </ul>
                          <ReactTooltip id="Viewimage" place="top" effect="solid">View Image</ReactTooltip>

                        </div>
                      </div>
                    </div>
                    )


                      : ((data.uploadType == "Video" ? (<div class=" " style={{}}>
                        <div class="imginbox">
                          <ReactPlayer
                            url={data.data}
                            onPlay={() => this.PlayFunc(data.uploadId)}
                            className='react-player'
                            playing={false}
                            controls
                            width='250px'
                            height='180px'
                          />
                        </div>
                        <span>{data.title}</span>
                      </div>)

                        : (data.uploadType == "Application" ? (<div class="text-center">
                          <div class="imginbox">

                            {/* <iframe src={'data:application/pdf;base64,' + data.data} frameborder="0" scrolling="no" ></iframe> */}

                            <img src={pdflogo} style={{ width: '200px' }} />
                            <span>{data.title}</span>
                            <div className="overlay">
                              <ul>
                                <li><MdIcons.MdOutlineRemoveRedEye class="icon" alt="logo" data-tip data-for="Viewimage"
                                  onClick={() => this.PDFViewFunc('data:application/pdf;base64,' + data.data, data.uploadId)} /></li>
                              </ul>
                              <ReactTooltip id="Viewimage" place="top" effect="solid">View Image</ReactTooltip>

                            </div>

                          </div>
                        </div>)

                          : (<></>)

                        )))))

                    : (<div class="">
                      <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                    </div>)
                ))) : (<div class="">
                  <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                </div>)

              )}

            </div>
          </div>

        </div>
        {/* </div> */}
        {/* SLIDINGPANE FOR EDIT USER PAGE IMPLEMENTED BY NANDHINI - 19-05-2022 */}
        <SlidingPane
          className="some-custom-class"
          overlayClassName="some-custom-overlay-class"
          isOpen={this.state.isPdfViewPaneOpen}
          title={"PDF - View"}
          onRequestClose={() => {
            this.Closeview()
          }}
        >
          {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
          <PDFViewerCompoenent pdfData={this.state.pdfData} />
        </SlidingPane>
      </div>

    )

  };
}
export default Help;
