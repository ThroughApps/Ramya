import React, { Component, useState } from 'react';
import './Helpcss.css';
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import ReactPlayer from 'react-player';
import _ from 'underscore';
import * as FaIcons from 'react-icons/fa';
import * as FiIcons from 'react-icons/fi';
import '../../Franchise Components/Saved Image/SavedImageCss.css';
import './Helpcss.css'
import * as MdIcons from 'react-icons/md';
import ReactTooltip from 'react-tooltip';
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import 'video-react/dist/video-react.css'; // import css
import Viewer from "react-viewer/dist/index.js";
import pdflogo from '../../images/pdflogo.png';
import Modal from 'react-modal';
import { GetLocalStorageData, TimeZoneDateTime } from '../../Common Components/CommonComponents';
import PDFViewerCompoenent from './PDFViewerCompoenent';
import { HeplDropdown } from '../../Assets Components/DropdownComponents/DropdownComponent';
import { HelpSearchComponent } from '../../Assets Components/Search Components/SearchComponent';
import LoadingComponent from "../../Assets Components/Loading Components/LoadingComponent";

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  }
};

class HelpComponent extends Component {
  constructor() {
    super();

    window.Help_Component = this;

    this.state = {
      imageActiveIndex: 0,
      visible: '',
      previewImageArray: [],
      imageArray: [],
      videoArray: [],
      documentArray: [],
      helpDataList: [],
      companyId: '',
      isPdfViewPaneOpen: false,
      isVideoViewPaneOpen: false,
      selectedDocType: [],
      totalHelpDataList: [],
      videoData: '',
    }

    this.PDFViewFunc = this.PDFViewFunc.bind(this);
    this.PopulateData = this.PopulateData.bind(this);
    this.DocTypeSelectChange = this.DocTypeSelectChange.bind(this);
  }
  /*
  FUNCTION USED TO UPDATE THE help DATALIST WHILE LODING OR MOVING INTO NEXT PAGES
  - IMPLEMENETED BY DURGA ON 10-07-2022 */
  SetHelpData(imageArray) {

    // alert("sethelpdata");

    var self = this;
    self.state.totalHelpDataList = [];
    //console.log("after added url-imageArray", imageArray);
    //  this.state.helpDataList = imageArray;
    // this.state.totalHelpDataList = this.state.helpDataList;
    this.state.totalHelpDataList = imageArray;
    this.setState({
      //   helpDataList: this.state.helpDataList,
      totalHelpDataList: this.state.totalHelpDataList, //totalHelpDataList
    })

   
    Loading_Component.ModalCloseFun();
    self.PopulateData();
  }
  /*
  FUNCTION CALLED WHEN AN VIDEO IS PLAYED WHICH IN TURN CALLS 
  THE RECORD COUNT FUNCTION FOR RECORDING THE VISITCOUNT
  - IMPLEMENETED BY PRIYANKA ON 26-05-2022 */
  PlayFunc(fileName, filePath) {
    Loading_Component.ModalOpenFun()
    var self = this;
    //console.log("videodata", fileName, "uploadid", filePath);
    var viewInfo = _.where(this.state.helpDataList, { filePath: filePath });
    //console.log("viewInfo", viewInfo);

    self.state.videoPlayerOpen = true;
    //filePath
    var currentFilePath = filePath.split("/");
    //console.log(" ************************* currentFilePath :", currentFilePath);

    currentFilePath.splice(currentFilePath.length - 2, 1);
    //console.log(" ************************* currentFilePath SLICE:", currentFilePath);

    var folderPath = currentFilePath.join("/");
    //console.log("####### folderPath :", folderPath);

    // self.state.videoData = "https://d3h6ssrmm09ie.cloudfront.net/" + folderPath; 
    self.state.videoData = "https://d5g1cpur5okjb.cloudfront.net/" + folderPath;
    //console.log("isVideoViewPaneOpen", self.state.videoPlayerOpen);

    self.setState({
      videoPlayerOpen: self.state.videoPlayerOpen,
      videoData: self.state.videoData,
    })
    Loading_Component.ModalCloseFun();

    this.RecordVisitCount(fileName, viewInfo);
  }
  /*FUNCTION USED FOR IMPLEMENTING THE IMAGE VIEW FOR THE SELECTED IMAGE
   - IMPLEMENETED BY PRIYANKA ON 21-05-2022*/
  ImageViewFunc(fileName) {
    alert("filePath :"+fileName);
    //console.log("previewImages", this.state.previewImages);

   
    var index = _.findIndex(this.state.helpDataList, { fileName: fileName });
    var viewInfo = _.where(this.state.helpDataList, { fileName: fileName });
    //console.log("viewInfo", viewInfo);
    alert("index :"+index);
    this.state.imageActiveIndex = index;
    //console.log("previewImages", this.state.previewImages);
    this.setVisible(true);
    //alert("setVisible :");
    this.setState({
      imageActiveIndex: this.state.imageActiveIndex,
    })
    this.RecordVisitCount(fileName, viewInfo);

    //alert("RecordVisitCount :");
  }
  setVisible(flag) {
    //alert("1st visible :");
    this.state.visible = flag;

    this.setState({
      visible: flag,
    })
    //alert("visible :");
  }
  /* THIS FUCNTION USED FOR CLOSE SLIDEPANE IMPLEMENTED BY NANDHINI - 19-05-2022*/
  Closeview() {
    this.state.isPdfViewPaneOpen = false;
    this.setState({
      isPdfViewPaneOpen: this.state.isPdfViewPaneOpen,
    })
  }
  VideoCloseview() {
    this.state.isVideoViewPaneOpen = false;
    this.setState({
      isVideoViewPaneOpen: this.state.isVideoViewPaneOpen,
    })
  }
  /*
  FUNCTION USED FOR SELECTING THE DOCTYPE TO BE 
  DISPLAYED INTO THE RENDERED PART - 
  IMPLEMENETED BY PRIYANKA 24-05-2022
  */
  PopulateData() {
    var self = this;

    var selectedDocType = _.where(this.state.selectedDocType, { value: 'All' });

    if (this.state.selectedDocType.length == 0) {
      //  //alert("IF");
      //console.log("POPULATE DATA this.state.totalHelpDataList :", this.state.totalHelpDataList);

      this.state.helpDataList = this.state.totalHelpDataList;
      this.setState({
        helpDataList: this.state.helpDataList
      })

      $.each(this.state.helpDataList,function(i,item){


        var previewImageData = {
          src: item.data,
          alt: 'ImageSlideShow'
      };
      //  self.state.imageArray.push(url);
      self.state.previewImageArray.push(previewImageData);
    //  self.state.imageArray.push(imageData);
      self.setState({
          previewImageArray: self.state.previewImageArray,
      //    imageArray: self.state.imageArray,
      })
      })
      //console.log("POPULATE DATA this.state.helpDataList :", this.state.helpDataList);

    } else {
      //  alert("ELSE");
      $.each(this.state.selectedDocType, function (i, item) {
        var itemData = item.value;

        //alert("ELSEimg "+itemData);
        //console.log("ELSEimg", itemData);
        //console.log("xxxxx", self.state.totalHelpDataList);

        var currentSelectedData = _.where(self.state.totalHelpDataList, { uploadType: itemData });

        //console.log("currentSelectedData :", currentSelectedData);

        if (currentSelectedData.length > 0) {

          for (var z = 0; z < currentSelectedData.length; z++) {
            self.state.helpDataList.push(currentSelectedData[z]);
          }
          self.setState({
            helpDataList: self.state.helpDataList,
          })
        }
      })


    }
    //console.log("PopulateData this.state.helpDataList :", this.state.helpDataList);
  }
  /* THIS FUCNTION USED FOR SLIDEPANE IMPLEMENTED BY NANDHINI - 19-05-2022*/
  PDFViewFunc(pdfData, fileName) {
    //console.log("pdfdata", pdfData);
    var self = this;
    self.state.isPdfViewPaneOpen = true;
    self.state.pdfData = pdfData;
    //console.log("isPdfViewPaneOpen", self.state.isPdfViewPaneOpen);
    self.setState({
      isPdfViewPaneOpen: self.state.isPdfViewPaneOpen,
      pdfData: self.state.pdfData,
    })
    var viewInfo = _.where(this.state.helpDataList, { fileName: fileName });

    this.RecordVisitCount(fileName, viewInfo);
  }
  /*
 FUNCTION USED FOR RECORDING THE VISITCOUNT
 WHENEVER AN VIEW IS CLICKED FOR THE IMAGE, PDF/ VIDEO IS PLAYED
 - IMPLEMENETED BY PRIYANKA ON 21-05-2022
 */
  RecordVisitCount(fileName, viewInfo) {

    var self = this;
    /*  GETTING DATE & TIME FOR THE CURRENT LOGIN- IMPLEMENTED BY PRIYANKA - 31-05-2022*/
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.setState({
      date: this.state.date,
      time: this.state.time,
    })
    //console.log("RecordVisitCount viewInfo :", GetLocalStorageData("FranchiseCompanyId"), GetLocalStorageData("FranchiseId"),
    //  GetLocalStorageData("UserId"), viewInfo[0].title, viewInfo[0].uploadType, fileName);
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        franchiseId: GetLocalStorageData("FranchiseId"),
        userId: GetLocalStorageData("UserId"),
        date: this.state.date,
        time: this.state.time,
        module: "Help",
        menuId: "Help",
        title: viewInfo[0].title,
        type: viewInfo[0].uploadType,
        uploadId: viewInfo[0].uploadId,
        fileName: fileName,
      }),
      // url: "http://15.206.129.105:8080/IceilAPI/HelpService/RecordVisitCount",
      url: "http://15.206.129.105:8080/IceilLiveAPI/HelpService/RecordVisitCount",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //console.log("RECORD VISIT COUNT DATA: ", data);
      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      },
    });
  }
  /*
  FUNCTION USED FOR SELECTING & DISPLAYING THE
  SELECTED TYPE OF MEDIA - 
  IMPLEMENETED BY PRIYANKA 24-05-2022
  */
  DocTypeSelectChange(selectedDocType) {

    //console.log("selectedDocType :", selectedDocType);

    this.state.selectedDocType = selectedDocType;

    this.state.helpDataList = [];
    this.setState({
      helpDataList: this.state.helpDataList,
      selectedDocType: selectedDocType,
    })

    this.PopulateData();
  }
  closeModal() {
    var self = this;
    self.state.videoPlayerOpen = false;
    self.state.videoPlayerClose = true;
    self.setState({
      videoPlayerOpen: self.state.videoPlayerOpen,
      videoPlayerClose: self.state.videoPlayerClose
    })
  }
  render() {

    //console.log("this.state.preview images :", this.state.previewImages)
    return (
      <div >
        <HeplDropdown style={{ color: 'black' }} DocTypeSelectChange={this.DocTypeSelectChange} />
        {/* <div class="card-box"> */}
        <div class="card-box ">
          <div className='row'>
            <div class="grid_column">
              {/*RENDERING PART  IMPLEMENTED BY PRIYANKA - 24-05-2022 */}

              {(this.state.helpDataList.length > 0 ?
                (this.state.helpDataList.map((data) => (
                  data != null && data != undefined
                    ? (<div class="text-center " >
                      <div class="helpbox">
                        <img id="image" src={data.data} />
                        <span>{data.title}</span>
                        <div className="overlay">
                          <ul>
                            <li><MdIcons.MdOutlineRemoveRedEye class="icon" alt="logo"
                              onClick={() => this.ImageViewFunc(data.fileName)} data-tip data-for="Viewimage" /></li>
                            </ul>
                          <ReactTooltip id="Viewimage" place="top" effect="solid">View Image</ReactTooltip>

                        </div>
                      </div>
                    </div>
                    ) : (<div class="">
                      <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                    </div>)
                ))) : (<div></div>))}




            </div>
          </div>
        </div>
        {/* </div> */}
        {/* SLIDINGPANE FOR EDIT USER PAGE IMPLEMENTED BY NANDHINI - 19-05-2022 */}
        <SlidingPane
          className="some-custom-class"
          overlayClassName="some-custom-overlay-class"
          isOpen={this.state.isPdfViewPaneOpen}
          title={"PDF - View"}
          onRequestClose={() => {
            this.Closeview()
          }}
        >
          {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
          <PDFViewerCompoenent pdfData={this.state.pdfData} />
        </SlidingPane>
        <Modal isOpen={this.state.videoPlayerOpen}
          //  onAfterOpen={this.customerafterOpenModal}	
          onRequestClose={this.state.videoPlayerClose} style={customStyles} contentLabel="Example Modal">
          <div className="container">
            <ReactPlayer
              url={this.state.videoData}
              className='react-player'
              playing={false}
              controls
              width='100%'
              height='180px'
            //light={data.data} 
            />
            <div class="text-center">
              <button type="button" onClick={() => this.closeModal()} style={{
                borderRadius: "18px", backgroundColor: "#263eac",
                color: "white", width: "75px", marginTop: "20px"
              }}	>close</button>
            </div>
          </div>
        </Modal>
        <LoadingComponent />


        <div id="NIC_Img_Preview" className="NIC_Img_Preview row">
                        <ul id="viewimages">
                            <Viewer
                                visible={this.state.visible}
                                onClose={() => { this.setVisible(false); }}
                                images={this.state.previewImageArray}
                                activeIndex={this.state.imageActiveIndex}
                                zoomable={this.state.zoomable}
                            />
                        </ul>

                    </div>
      </div>
    )
  };

}
export default HelpComponent
