import React, { Component, useState } from 'react';
import { HeplDropdown } from '../../Assets Components/DropdownComponents/DropdownComponent';
import './Helpcss.css';
import $ from 'jquery';
//import { FileSaver, saveAs } from 'file-saver';
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import ReactPlayer from 'react-player';
import { PDFViewer } from 'react-view-pdf';
import generatePdfThumbnails from 'pdf-thumbnails-generator';
import _ from 'underscore';

import Pagination from "react-js-pagination";
import iceillogo from '../../images/image1.png';
import '../../Franchise Components/Saved Image/SavedImageCss.css';
import './Helpcss.css'

import * as MdIcons from 'react-icons/md';
import ReactTooltip from 'react-tooltip';
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import 'video-react/dist/video-react.css'; // import css
import Viewer from "react-viewer/dist/index.js";
import { GetLocalStorageData, TimeZoneDateTime } from '../../Common Components/CommonComponents';
import PDFViewerCompoenent from './PDFViewerCompoenent';
import pdflogo from '../../images/pdflogo.png';
import { HelpSearchComponent } from '../../Assets Components/Search Components/SearchComponent';
import { GetFileFrom_AWS_S3, GetHelpDataList_S3 } from '../../AWS/AWSFunctionality';
import HelpComponent from './HelpComponent';
import LoadingComponent from "../../Assets Components/Loading Components/LoadingComponent";

class Help extends Component {

  constructor() {
    super()


    this.state = {
      folderPath: 'Help/',
      thumbnailFolderPath: 'Help/ThumbNail/',
      companyId: '',
      isPdfViewPaneOpen: false,
      visible: '',
      activePage: 1,
      totalItemsCount: 0,
      itemsCountPerPage: 20,
      startCount: 0,
      endCount: 20,
      helpDataList: [],
      previewImages: [],
      totalHelpDataList: [],
      selectedDocType: [],
      helpSearchDataList: [],
      searchValue: "",
      searchType: "Normal",
      imageActiveIndex: 0,
      videoDataList: [],

      videoPlayerOpen: false,
      videoPlayerClose: true,
    }
    this.SearchChange = this.SearchChange.bind(this);
    this.GetSearchData = this.GetSearchData.bind(this);

  }

  /*
THIS FUNCTION LOADS IMMEDIATLY AFTER THE PAGE IS LOADED
IMPLEMENTED BY PRIYANKA ON 21-05-2022
*/
  /*THIS FUNCTION LOADS IMMEDIATLY AFTER THE PAGE IS LOADED
   IMPLEMENTED BY PRIYANKA ON 21-05-2022
   */
  componentDidMount() {

    this.GetHelpData();
  }
  /*
  FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
  IMPLEMENTED BY PRIYANKA - 28-04-2022
  */
  handlePageChange(pageNumber) {
    ////console.log(`active page is ${pageNumber}`);

    this.state.activePage = pageNumber;

    var startCount = 0;
    var endCount = this.state.endCount;
    //console.log("this.state.itemsCountPerPage", this.state.itemsCountPerPage);
    if (pageNumber > 1) {
      startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
      //endCount = this.state.itemsCountPerPage;
      endCount = Number(startCount) + Number(this.state.itemsCountPerPage);
    } else {
      startCount = 0;
      endCount = this.state.itemsCountPerPage;
    }

    this.state.startCount = startCount;
    this.state.endCount = endCount;

    this.setState({
      activePage: pageNumber,
      startCount: startCount,
      endCount: startCount,
    });
    // alert(this.state.endCount + "\itemsCountPerPage" + this.state.startCount);;
    //console.log("this.state.itemsCountPerPage", this.state.startCount, this.state.endCount);
    //  this.GetData();
    this.GetHelpData();
  }
  /*
   FUNCTION USED TO GET THE DATA FROM SERVER
   IMPLEMENTED BY DURGA - 10-7-2022
   */

  GetHelpData() {
    Loading_Component.ModalOpenFun();

    var self = this;
    self.state.helpDataList = [];
    self.state.totalHelpDataList = [];
    self.state.helpSearchDataList = [];
    self.setState({
      helpDataList: self.state.helpDataList,
      totalHelpDataList: self.state.totalHelpDataList,
      helpSearchDataList: self.state.helpSearchDataList
    })

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        menuId: "Help",
        startCount: this.state.startCount,
        endCount: this.state.endCount,
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/HelpService/HelpDisplayData",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //console.log("HELP DATA :", data);
        if (data.helpDataList.length > 0) {
          self.state.totalItemsCount = data.dataCount;

          self.state.helpSearchDataList = data.helpSearchDataList;
          self.state.helpDataList = data.helpDataList;
          self.setState({
            helpDataList: self.state.helpDataList,
            totalItemsCount: self.state.totalItemsCount,
            helpSearchDataList: self.state.helpSearchDataList
          })
        }
      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });

    if (self.state.helpDataList.length > 0) {


      // var temphelpDataList = self.state.helpDataList.filter(function (element) {
      //   return element.uploadType == "Image" || element.uploadType == "Application"
      // });
      // //console.log('b4 temphelpDataList',temphelpDataList);

      var helpDataList = [...self.state.helpDataList];
      self.state.helpDataList = [];
      self.setState({
        helpDataList: self.state.helpDataList,
      });

      self.state.helpDataList = helpDataList.map(v => ({ ...v, filePath: "" }))
      self.setState({
        helpDataList: self.state.helpDataList,
      });

      var imageArray = _.where(self.state.helpDataList, { uploadType: 'Image' });
      var videoArray = _.where(self.state.helpDataList, { uploadType: 'Video' });
      var pdfArray = _.where(self.state.helpDataList, { uploadType: 'Application' });

      imageArray = imageArray.map(v => ({ ...v, filePath: self.state.folderPath + v.fileName }))
      videoArray = videoArray.map(v => ({ ...v, filePath: self.state.thumbnailFolderPath + v.fileName }))
      pdfArray = pdfArray.map(v => ({ ...v, filePath: self.state.folderPath + v.fileName }))

      var newHelpDataList = [...imageArray, ...videoArray, ...pdfArray];

      //console.log("***** newHelpDataList :", newHelpDataList);

      /*  var newHelpDataList = [...self.state.helpDataList]
  
        $.each(newHelpDataList, function (i, item) {
  
          if (item.uploadType == "Video")
            newHelpDataList[i].filePath = self.state.thumbnailFolderPath + item.fileName;
          else {
            newHelpDataList[i].filePath = self.state.folderPath + item.fileName;
          }
        });
  
  
  
        //console.log('a4 temphelpDataList', newHelpDataList);
        */
        self.GetHelpDataList(imageArray);
        self.GetHelpDataList(videoArray);
        self.GetHelpDataList(pdfArray);

     // self.GetHelpDataList(newHelpDataList);

    } else {
      Loading_Component.ModalCloseFun();
    }
  }
  /*FUNCTION USED TO FETCH THE HELP DATA LIST FROM AWS 
  IMPLEMENTED BY DURGA - 10-7-2022
  */
  GetHelpDataList(temphelpDataList) {
    var self = this;

    //  alert("HELP DATA LIST")
    GetHelpDataList_S3(temphelpDataList).then(function (response) {

      if (response !== "Error") {

        //console.log("RESPONSE CONTENTS", response)

        /*  $.each(response, function (i, item) {
  
            if (item.uploadType == "Application") {
              response[i].data = 'data:application/pdf;base64,' + response[i].data;
            }
            else {
              response[i].data = 'data:image/png;base64,' + response[i].data;
            }
          });
          */

        var imageArray = _.where(response, { uploadType: 'Image' });
        var videoArray = _.where(response, { uploadType: 'Video' });
        var pdfArray = _.where(response, { uploadType: 'Application' });

        imageArray = imageArray.map(v => ({ ...v, data: 'data:image/png;base64,' + v.data }))
        videoArray = videoArray.map(v => ({ ...v, data: 'data:image/png;base64,' + v.data }))
        pdfArray = pdfArray.map(v => ({ ...v, data: 'data:application/pdf;base64,' + v.data }))

        var newHelpDataList = [...imageArray, ...videoArray, ...pdfArray];

        self.state.totalHelpDataList = [...self.state.totalHelpDataList  ,...newHelpDataList];

        self.setState({
          totalHelpDataList: self.state.totalHelpDataList,

        })
        Help_Component.SetHelpData(self.state.totalHelpDataList);


      } else {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      }
    })
  }
  /*
  FUNCTION USED FOR HANDLING THE SEARCH BASED ON 
  KEYWORD ENTERED 
  - IMPLEMENETED BY PRIYANKA ON 21-05-2022
  */
  SearchChange(searchType, searchValue) {

    //console.log("SearchChange searchValue:", searchValue);

    if (searchType == "Search") {
      this.state.searchValue = searchValue;
      this.state.searchType = "Search";
      this.setState({
        searchValue: this.state.searchValue,
        searchType: this.state.searchType
      })
      this.GetSearchData(searchValue);

    } else if (searchType == "Normal") {
      this.state.searchValue = "";
      this.state.searchType = "Normal";
      this.setState({
        searchValue: this.state.searchValue,
        searchType: this.state.searchType
      })
      this.GetHelpData();
      //this.SetHelpData();
    }

  }
  /*
 FUNCTION USED FOR GETTING THE DATA BASED ON THE SEARCH
 KEYWORD ENTERED 
 - IMPLEMENETED BY PRIYANKA ON 21-05-2022
 */
  GetSearchData(searchValue) {
    fileNameArray = [];
    var self = this;

    this.state.startCount = 0;
    this.state.endCount = 20; //5;
    this.state.helpDataList = [];
    this.state.totalHelpDataList = [];
    this.state.helpSearchDataList = [];

    this.setState({
      startCount: this.state.startCount,
      endCount: this.state.endCount,
      helpDataList: this.state.helpDataList,
      totalHelpDataList: this.state.totalHelpDataList,
      helpSearchDataList: this.state.helpSearchDataList
    })


    var searchDataArray = searchValue.split(" ");
    //console.log("searchDataArray :", searchDataArray);

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("FranchiseCompanyId"),
        menuId: "Help",
        startCount: this.state.startCount,
        endCount: this.state.endCount,
        searchData: searchDataArray.toString(),
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/HelpService/HelpSearchDataDisplay",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //console.log("HELP SEARCH DATA :", data);


        if (data.helpSearchDataList.length > 0) {

          self.state.totalItemsCount = data.dataCount;
          self.setState({
            totalItemsCount: self.state.totalItemsCount
          });
          // fileNameArray=_.pluck(data.helpSearchDataList, 'fileName');
          // //console.log("fileNameArray fileNameArray:", fileNameArray);

          var helpSearchDataList = [...data.helpSearchDataList];

          $.each(helpSearchDataList, function (i, item) {

            if (item.uploadType == "Video") {
              helpSearchDataList[i].filePath = self.state.thumbnailFolderPath + item.fileName;
            }
            else {
              helpSearchDataList[i].filePath = self.state.folderPath + item.fileName;
            }
          })
          self.GetHelpDataList(helpSearchDataList);
          // alert("get data caaling after search");
          //console.log("SEARCH DATA LIST  self.state.helpSearchDataList: ", self.state.helpSearchDataList)
        }
      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      },
    });
  } 
  render() {

    //console.log("this.state.preview images :", this.state.previewImages)

    return (
      <div >
        <div class="franchise-toptitle toptitle">
          <h4>Technical Know-How</h4>
          <HelpSearchComponent helpSearchDataList={this.state.helpSearchDataList}
              onSearchChange={this.SearchChange} />
        </div>
        {/* DROPDOWN FOR VIDEO,IMAGE,PDF  IMPLEMENTED BY NANDHINI - 02-05-2022 */}
        <div className=''>
            <Pagination
              activePage={this.state.activePage}
              itemsCountPerPage={this.state.itemsCountPerPage}
              totalItemsCount={this.state.totalItemsCount}
              pageRangeDisplayed={20}
              itemClass="page-item"
              linkClass="page-link"
              onChange={this.handlePageChange.bind(this)}
            />
            </div>
          {/* SEARCH BAR  IMPLEMENTED BY NANDHINI - 02-05-2022 */}
       
        <LoadingComponent />
             <HelpComponent />
</div>
    )

  };
}
export default Help;
