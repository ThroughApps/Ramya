//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import * as FileSaver from 'file-saver';
import * as FaIcons from 'react-icons/fa';
import watermark from "watermarkjs";
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import CryptoJS from 'crypto-js';
import ReactTooltip from 'react-tooltip';
import Pagination from "react-js-pagination";
//import { base64StringToBlob } from 'blob-util';

// import statement for react class component


// import statement for react component css
import '../Saved Image/SavedImageCss.css'
import { dataURLtoFile, GetLocalStorageData } from "../../Common Components/CommonComponents";
import Search from "../../Assets Components/Search Components/SearchComponent";
import { GetFileName, GetImageFileFromAWS, GetImageFromAWS } from "../../AWS/AWSFunctionality";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022


class ImageGalleryComponent extends React.Component {
    constructor() {
        super();

        window.ImageGallery_Component = this;

        this.state = {
            imageArray: [],
        }
    }
    componentDidMount() {

        //console.log("IMAGE GALLERY this.props :", this.props);
        //   this.SetImageGalleryData(this.props.menuId, this.props.menuName, this.props.folderPath);

    }

    SetImageGalleryData(imageArray) {

        //  alert("SetImageGalleryData");
        /* this.state.imageArray = [];
         this.setState({
             imageArray: this.state.imageArray
         })
 
         this.state.imageArray = imageArray;
         this.setState({
             imageArray: this.state.imageArray
         })
         */

        console.log(" *** IMAGE GALLERY RenderImages imageArray  :", imageArray);

        this.RenderImages(imageArray);
    }

    /*
  FUNCTION USED TO RENDER THE IMAGES AFTER THE CHNAGES LIKE EDIT, DELETE
  IMPLEMENTED BY PRIYANKA - 09-07-2022
  */
    RenderImages(mediaDataList) {

        var self = this;

        self.state.imageArray = [];
        self.setState({
            imageArray: self.state.imageArray,
        })


        if (mediaDataList.length > 0) {

            /*
                        self.state.totalItemsCount = data.dataCount;
                        self.setState({
                            totalItemsCount: self.state.totalItemsCount
                        });
            */
            $.each(mediaDataList, function (i, item) {
                //https://d5g1cpur5okjb.cloudfront.net/
                // use a data url as an image source - ADDING WATERMARK TO THE IMAGE
                console.log("****** CLOUD FRONT KEY :", item);

                var imageUrl = "https://d5g1cpur5okjb.cloudfront.net/" + item.Key;

                var imageData = {
                    // data: url,
                    // filePath: item.filePath,
                    data: "https://d5g1cpur5okjb.cloudfront.net/" + item.Key,
                    filePath: item.Key
                };

                var previewImageData = {
                    src: imageUrl,
                    alt: 'ImageSlideShow'
                };
                //  self.state.imageArray.push(url);
                //   self.state.previewImageArray.push(previewImageData);
                self.state.imageArray.push(imageData);
                self.setState({
                    //     previewImageArray: self.state.previewImageArray,
                    imageArray: self.state.imageArray,
                })

                // watermark([item.data])
                /*     watermark([imageUrl])
                          .dataUrl(watermark.text.lowerRight('Iceil', '30px serif', '#fff', 0.5))
                          .then(function (url) {
                              //document.querySelector('img').src = url;
                              console.log("IMAGE GALLERY WATER MARK URL :", url);
      
                              var imageData = {
                                  data: url,
                                  data:"https://d5g1cpur5okjb.cloudfront.net/"+item.Key,
                                  filePath: item.filePath
                              };
      
                              var previewImageData = {
                                  src: url,
                                  alt: 'ImageSlideShow'
                              };
                              //  self.state.imageArray.push(url);
                              //   self.state.previewImageArray.push(previewImageData);
                              self.state.imageArray.push(imageData);
                              self.setState({
                                  //     previewImageArray: self.state.previewImageArray,
                                  imageArray: self.state.imageArray,
                              })
                              console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray);
      
                          })
                          */

            })
        }

        Loading_Component.ModalCloseFun()
    }

    /*
    FUNCTION USED FOR DOWNLOADING THE IMAGE
    IMPLEMENTED BY PRIYANKA - 28-04-2022
    */

    DownloadImage(data) {


        var downloadFileArray = [];
        downloadFileArray.push({ Key: data.filePath })
        GetImageFileFromAWS(downloadFileArray).then(function (response) {

            if (response !== "Error") {

                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

                /* const contentType = 'image/png';
                 const blob = base64StringToBlob(response[0].data, contentType);
                 */

                /*  watermark([response[0].data])
                      .dataUrl(watermark.text.center('Iceil', '100px Josefin Slab', '#fff', 0.4))
                      .then(function (url) {
                          //document.querySelector('img').src = url;
                          console.log("IMAGE GALLERY WATER MARK URL :", url);
  
                          FileSaver.saveAs(url, "image.jpg");
  
                      })
                      */

                var file = dataURLtoFile(response[0].data, 'image.jpg');
                console.log("**** ----- DownloadImage :", file);
                FileSaver.saveAs(file, "image.jpg");

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })

    }


    render() {
        // console.log(" *** COMPO RENDER this.state.imagearray :", this.state.imageArray)
        return (
            <div className="">
                {/*  <h4>{this.state.menuName}</h4> */}
                <div className="imgbox">
                    {(this.state.imageArray.length > 0 ?
                        (this.state.imageArray.map((data) => (
                            data.data != null && data.data != undefined && data.data != 'data:image/png;base64,'
                                ? (<div class="imginbox">
                                    <img id="image" src={data.data} alt="" />

                                    <a><FaIcons.FaDownload alt="logo" data-tip data-for="DownloadImage" onClick={() => this.DownloadImage(data)} />
                                        <ReactTooltip id="DownloadImage" place="top" effect="solid">Download Image</ReactTooltip></a>

                                </div>)
                                :
                                (<div class="col-md-3">
                                    <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data </p>
                                </div>)
                        ))) : (<div class="col-md-3">
                            <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data </p>
                        </div>)

                    )}

                </div>
            </div>
        );
    }
}

export default ImageGalleryComponent;

