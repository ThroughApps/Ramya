//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import * as FileSaver from 'file-saver';
import * as BsIcons from 'react-icons/bs';
import watermark from "watermarkjs";
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import CryptoJS from 'crypto-js';
import ReactTooltip from 'react-tooltip';
import Pagination from "react-js-pagination";

// import statement for react class component


// import statement for react component css
import '../Saved Image/SavedImageCss.css'
import { GetLocalStorageData } from "../../Common Components/CommonComponents";
import Search from "../../Assets Components/Search Components/SearchComponent";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class ImageGallery extends React.Component {
    constructor() {
        super();

        window.ImageGalleryComponent = this;

        this.state = {
            imageArray: [],
            menuId: '',
            activePage: 0,
            totalItemsCount: 0,
            itemsCountPerPage: 5,
            startCount: 0,
            endCount: 5,
        }
    }
    componentDidMount() {

        //console.log("IMAGE GALLERY this.props :", this.props);
        this.SetImageGalleryData(this.props.menuId,this.props.menuName);

    }

    /*
    FUNCTION USED FOR CALLING THE DISPLAY THE DATA
    IMPLEMENTED BY PRIYANKA - 28-04-2022
    */  
    SetImageGalleryData(menuId,menuName) {

        this.state.menuId = menuId;
        this.state.menuName = menuName;

        this.state.imageArray = [];
        this.state.activePage = 0;
        this.state.totalItemsCount = 0;
        this.state.startCount = 0;
        this.state.endCount = 5;

        this.setState({
            imageArray: [],
            activePage: 0,
            totalItemsCount: 0,
            startCount: 0,
            endCount: 5,
            menuId:this.state.menuId,
            menuName:this.state.menuName,
        })

        //CALLING FUNCTION TO RENDER THE MEDIA DATA FOR DISPLAY - IMPLEMENETED BY PRIYANKA - 27-04-2022
        this.GetData_For_ChildMenu();
    }

    /*
FUNCTION USED TO RENDER THE DATA BASED ON LAST CHILD MENU SELECTED FROM SIDE BAR 
- IMPLEMENETED BY PRIYANKA - 27-04-2022
*/
    GetData_For_ChildMenu() {

        var self = this;

        self.state.imageArray = [];
        self.setState({
            imageArray: self.state.imageArray,
        })
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("FranchiseCompanyId"),
                menuId: this.state.menuId,
                startCount: this.state.startCount,
                endCount: this.state.endCount,
            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/MediaData/MediaDisplayData",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                //console.log("IMAGE GALLERY MediaDisplayData DATA :", data);

                if (data.mediaDataList.length > 0) {

                    self.state.totalItemsCount = data.dataCount;
                    self.setState({
                        totalItemsCount: self.state.totalItemsCount
                    });

                    $.each(data.mediaDataList, function (i, item) {
                        // use a data url as an image source - ADDING WATERMARK TO THE IMAGE
                        watermark([item.data])
                            .dataUrl(watermark.text.lowerRight('Iceil', '30px serif', '#fff', 0.5))
                            .then(function (url) {
                                //document.querySelector('img').src = url;
                                //console.log("IMAGE GALLERY WATER MARK URL :", url);

                                self.state.imageArray.push(url);
                                self.setState({
                                    imageArray: self.state.imageArray,
                                })
                                //console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray);

                            })

                    })
                }

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });


    }

    /*
    FUNCTION USED FOR DOWNLOADING THE IMAGE
    IMPLEMENTED BY PRIYANKA - 28-04-2022
    */

    DownloadImage(data) {
        FileSaver.saveAs(data, "image.jpg");
    }

    /*
    FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
    IMPLEMENTED BY PRIYANKA - 28-04-2022
    */
    handlePageChange(pageNumber) {
        //console.log(`active page is ${pageNumber}`);

        this.state.activePage = pageNumber;

        var startCount = 0;
        var endCount = 0;

        if (pageNumber > 1) {
            startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
            endCount = this.state.itemsCountPerPage;
            //  endCount=Number(startCount)+Number(this.state.itemsCountPerPage);
        } else {
            startCount = 0;
            endCount = this.state.itemsCountPerPage;
        }

        this.state.startCount = startCount;
        this.state.endCount = endCount;

        this.setState({
            activePage: pageNumber,
            startCount: startCount,
            endCount: startCount,
        });

        this.GetData_For_ChildMenu();
    }

    render() {
        return ( 
            <div>
                <div className="toptitle">
                    <h3>Image Gallery Projects</h3>
                </div>

                <Search componentCalled={"Image Gallery"} />
                <div>
                            <Pagination
                                activePage={this.state.activePage}
                                itemsCountPerPage={this.state.itemsCountPerPage}
                                totalItemsCount={this.state.totalItemsCount}
                                pageRangeDisplayed={5}
                                itemClass="page-item"
                                linkClass="page-link"
                                onChange={this.handlePageChange.bind(this)}
                            />
                        </div>
                <div className="card-box">
                <h4>{this.state.menuName}</h4>
                    <div className="row imgbox">
                        {(this.state.imageArray.length > 0 ?
                            (this.state.imageArray.map((data) => (
                                data != null && data != undefined
                                    ? (<div className="col-md-3">
                                        <div class="imginbox">
                                            <img id="image" src={data} />
                                            {/*   <ImageGalleryIcons data={data} 
                                                onDownloadImage={this.DownloadImage} />
                                    */}
                                            <a><BsIcons.BsDownload alt="logo" data-tip data-for="DownloadImage" onClick={() => this.DownloadImage(data)} />
                                                <ReactTooltip id="DownloadImage" place="top" effect="solid">Download Image</ReactTooltip></a>

                                        </div>
                                    </div>)
                                    // <div class="col-md-3">
                                    // <div className="image-gallery">
                                    //     <img id="image" src={data}  />
                                    //     <ImageGalleryIcons data={data} 
                                    //     onDownloadImage={this.DownloadImage} />
                                    // </div></div>

                                    : (<div class="col-md-3">
                                        <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                                    </div>)
                            ))) : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                            </div>)

                        )}
        
                    </div>
                </div>
            </div>
        );
    }
}

export default ImageGallery;
