//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import * as FileSaver from 'file-saver';
import * as BsIcons from 'react-icons/bs';
import watermark from "watermarkjs";
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import CryptoJS from 'crypto-js';
import ReactTooltip from 'react-tooltip';
import Pagination from "react-js-pagination";

// import statement for react class component


// import statement for react component css
import '../Saved Image/SavedImageCss.css'
import { GetLocalStorageData } from "../../Common Components/CommonComponents";
import Search from "../../Assets Components/Search Components/SearchComponent";
import {GetFileName, GetImageFileFromAWS } from "../../AWS/AWSFunctionality";
import ImageGalleryComponent from "./ImageGalleryComponent";
import LoadingComponent from "../../Assets Components/Loading Components/LoadingComponent";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022


class ImageGallery extends React.Component {
    constructor() {
        super();

        window.ImageGalleryComponent = this;

        this.state = {
            imageArray: [],
            menuId: '',
            activePage: 1,
            totalItemsCount: 0,
            itemsCountPerPage: 50,
            startCount: 0,
            endCount: 50,
            fileInfoArray: [],
        }
    }
    componentDidMount() {

        //console.log("IMAGE GALLERY this.props :", this.props);
        this.SetImageGalleryData(this.props.menuId, this.props.menuName, this.props.folderPath);

    }

    /*
    FUNCTION USED FOR CALLING THE DISPLAY THE DATA
    IMPLEMENTED BY PRIYANKA - 28-04-2022
    */
    SetImageGalleryData(menuId, menuName, folderPath) {

        var self = this;
        this.state.menuId = menuId;
        this.state.menuName = menuName;

        this.state.imageArray = [];
        this.state.activePage = 1;
        this.state.totalItemsCount = 0;
        this.state.startCount = 0;
        this.state.endCount = 50;

        this.setState({
            imageArray: [],
            activePage: 1,
            totalItemsCount: 0,
            startCount: 0,
            endCount: 50,
            menuId: this.state.menuId,
            menuName: this.state.menuName,
        })

        Loading_Component.ModalOpenFun()
     

        GetFileName(folderPath).then(function (response) {

            if (response !== "Error") {
                console.log("** IMAGE GALERY GetFileName RESPONSE CONTENTS :", response.Contents)

              
                self.state.fileInfoArray = response.Contents;
                self.state.fileInfoArray.shift();
                self.setState({
                    fileInfoArray: self.state.fileInfoArray,
                })

                console.log("self.state.fileInfoArray :", self.state.fileInfoArray);

                self.state.totalItemsCount = response.Contents.length;
                self.setState({
                    totalItemsCount: self.state.totalItemsCount
                });
//https://d5g1cpur5okjb.cloudfront.net/

                if(self.state.fileInfoArray.length >0){
                  //  ImageGallery_Component.SetImageGalleryData(self.state.fileInfoArray)
                self.GetData();
                }else{
                    var response=[];
                    ImageGallery_Component.SetImageGalleryData(response)
                }
              

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        });


    }

    GetData() {

        var self = this;
        
        var currentFileInfoArray = this.state.fileInfoArray.slice(this.state.startCount, this.state.endCount);

        console.log(" GetData this.state.startCount :", this.state.startCount, " this.state.endCount :", this.state.endCount);

        console.log("GetData currentFileInfoArray :", currentFileInfoArray);
        console.log("GetData this.state.fileInfoArray :", this.state.fileInfoArray);

        ImageGallery_Component.SetImageGalleryData(currentFileInfoArray)

      /*  GetImageFileFromAWS(currentFileInfoArray).then(function (response) {

            if (response !== "Error") {

                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

                ImageGallery_Component.SetImageGalleryData(response)

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })
        */

        // console.log("** self.state.imageArray OUTSIDE :", self.state.imageArray)

    }



    /*
    FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
    IMPLEMENTED BY PRIYANKA - 28-04-2022
    */
    handlePageChange(pageNumber) {
        console.log(`active page is ${pageNumber}`);

        this.state.activePage = pageNumber;

        var startCount = 0;
        var endCount = 0;

        if (pageNumber > 1) {
            startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
            // endCount = this.state.itemsCountPerPage;
            endCount = Number(startCount) + Number(this.state.itemsCountPerPage);
            //  endCount=Number(startCount)+Number(this.state.itemsCountPerPage);
        } else {
            startCount = 0;
            endCount = this.state.itemsCountPerPage;
        }

        this.state.startCount = startCount;
        this.state.endCount = endCount;

        this.setState({
            activePage: pageNumber,
            startCount: startCount,
            endCount: startCount,
        });
        this.GetData();
    }

    render() {
        console.log(" *** RENDER this.state.imagearray :", this.state.imageArray)
        return (
            <div>
                <div className="franchise-toptitle toptitle">
                <div style={{display:"flex"}}>
                    <h3>Project Gallery</h3>
                    <h4 className='underline'>{this.state.menuName}</h4>
                    </div>
                <Search componentCalled={"Project Gallery"} />
                </div>
              <Pagination
                        activePage={this.state.activePage}
                        itemsCountPerPage={this.state.itemsCountPerPage}
                        totalItemsCount={this.state.totalItemsCount}
                        pageRangeDisplayed={5}
                        itemClass="page-item"
                        linkClass="page-link"
                        onChange={this.handlePageChange.bind(this)}
                    />  
                <div className="card-box">            
                    <ImageGalleryComponent />
                    <LoadingComponent />
                    
                </div>
            </div>
        );
    }
}

export default ImageGallery;
