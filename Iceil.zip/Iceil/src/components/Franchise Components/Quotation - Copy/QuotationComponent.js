//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import Modal from 'react-modal';
import '../../StyleCss.css';
// import statement for image
import image1 from '../../images/image1.png'
// import statement for react class component
import {EditImageIcon} from '../../Assets Components/Icon Components/Iconcomponents';

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    }
};
export class QuotationImage extends React.Component{
       constructor(){
         super();      
    this.state= {
        }
        this.editImage = this.editImage.bind(this);
    }
    editImage(){
        var self= this;
        console.log("wprks fine");
        self.state.quotationEditmodalIsOpen = true;
        self.setState({
            quotationEditmodalIsOpen: self.state.quotationEditmodalIsOpen
        })
    }
    closeModalQuotationEdit(){
        var self = this;

        self.state.quotationEditmodalIsOpen = false;
        self.state.quotationEditcloseModal = true;
        self.setState({
            quotationEditmodalIsOpen: self.state.quotationEditmodalIsOpen,
            quotationEditcloseModal: self.state.quotationEditcloseModal
        })
    }
    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;
    
        this.setState({ [name]: value },
          () => { this.validateField(name, value) });
    
    
    
      }
    handleUserInputTax = (e) => {

        const name = e.target.name;
        const value = e.target.value;
    
        this.state[name] = value;
        this.setState({ [name]: value },
          () => { this.validateField(name, value) });
    
        this.Calculation(name);
      }
      validateField(fieldName, value) {
        let fieldValidationErrors = this.state.formErrors;
        let productNameValid = this.state.productNameValid;
        let saleRateValid = this.state.saleRateValid;
        let productTypeValid = this.state.productTypeValid;
        let productCategoryValid = this.state.productCategoryValid;
        let quantityLimitValid = this.state.quantityLimitValid;
        let purchaseRateValid = this.state.purchaseRateValid;
    
        switch (fieldName) {
          case 'productName':
            productNameValid = value.length >= 2;
            fieldValidationErrors.ProductName = productNameValid ? '' : ' is InCorrect';
            break;
          case 'saleRate':
            saleRateValid = value.length >= 1;
            fieldValidationErrors.SaleRate = saleRateValid ? '' : ' is InCorrect';
            break;
          case 'purchaseRate':
            purchaseRateValid = value.length >= 1;
            fieldValidationErrors.PurchaseRate = purchaseRateValid ? '' : ' is InCorrect';
            break;
          case 'productType':
            productTypeValid = value.length >= 1;
            fieldValidationErrors.ProductType = productTypeValid ? '' : ' is not selected';
            break;
          case 'productCategory':
            productCategoryValid = value.length >= 1;
            fieldValidationErrors.ProductCategory = productCategoryValid ? '' : ' is not selected';
            break;
    
    
          default:
            break;
        }
        this.setState({
          formErrors: fieldValidationErrors,
          productNameValid: productNameValid,
          saleRateValid: saleRateValid,
          productTypeValid: productTypeValid,
          purchaseRateValid: purchaseRateValid,
          productCategoryValid: productCategoryValid,
        }, this.validateForm);
      }
      validateForm() {
    
        this.setState({
          formValid:
            this.state.productNameValid
            && this.state.saleRateValid
            && this.state.productTypeValid
            && this.state.purchaseRateValid
            && this.state.productCategoryValid
        });
      }
    
    render(){
        return( 
            <div className="row mt-20 card-box Quotationimage">
            <div className="col-md-6">
                <div className="row quotation-card-box">
            <div class="col-md-8 text-center">
                <div class="card-box-img">
                    <img src={image1} />  
                    <div className="img-editicon">               
                 <EditImageIcon onEditImage={this.editImageIcon} />    
                 </div>                  
                    </div>
                    </div>
                    <div class="col-md-4 text-left mt-20">
                    <p>Image Type: <span>Nature</span><br/>Image Pixel: <span>307 * 170</span><br/>Rate: <span>400</span></p>
                    </div>
                </div>
                </div>
                <div className="col-md-6">
                <div className="quotation-card-box">
            <table className="table">
                <tbody>
                    <tr>
                        <td>Rate/Unit</td>
                        <td>150</td>
                    </tr>
                    <tr>
                        <td>Quantity</td>
                        <td>15</td>
                    </tr>
                    <tr>
                        <td>CGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>SGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>IGST(%)</td>
                        <td>14</td>
                    </tr>
                </tbody>
            </table>
            </div>
            </div>
            <div className="text-center">
                <button className="btn btn-primary btn-submit" onClick={this.editImage}>Edit Image</button>
            </div>

            {/* edit product */}
            <div className="container">
                <div className="row">
                    <div className="col-md-3">
                    <label>Product</label>    
            <div>      
            {/* FIELD USED TO edit Product */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.product} id="product" name="product"/>
            </div>
            </div>
            <div className="col-md-3">
                    <label>Product Code</label>    
            <div>      
            {/* FIELD USED TO edit Product */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.productCode} id="productCode" name="productCode"/>
            </div>
            </div>
            <div className="col-md-3">
                    <label>HSN Code</label>    
            <div>      
            {/* FIELD USED TO edit hsn */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.hsnCode} id="hsnCode" name="hsnCode"/>
            </div>
            </div>
            <div className="col-md-3">
                    <label>Rate/Unit </label>    
            <div>      
            {/* FIELD USED TO edit Rate/Unit  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rateUnit } id="rateUnit" name="rateUnit" />
            </div>
            </div>
            <div className="col-md-3">
                    <label>Rate</label>    
            <div>      
            {/* FIELD USED TO edit Rate/Unit  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rate } id="rate" name="rate" />
            </div>
            </div>
            <div className="col-md-3">
                    <label>CGST(%) </label>    
            <div>      
            {/* FIELD USED TO edit CGST(%)  */}
            <input className="textfield" type="number" min="0" onChange={this.handleUserInputTax} value={this.state.cgst } id="cgst" name="cgst" />
            </div>
            </div>
            <div className="col-md-3">
                    <label>IGST(%) </label>    
            <div>      
            {/* FIELD USED TO edit iGST(%)  */}
            <input className="textfield" type="number" min="0" onChange={this.handleUserInputTax} value={this.state.igst } id="igst" name="igst" />
            </div>
            </div>
            <div className="col-md-3">
                    <label>SGST(%) </label>    
            <div>      
            {/* FIELD USED TO edit sGST(%)  */}
            <input className="textfield" type="number" min="0" onChange={this.handleUserInputTax} value={this.state.sgst } id="sgst" name="sgst" />
            </div>
            </div>
            <div className="col-md-3">
                    <label>Quantity</label>    
            <div>      
            {/* FIELD USED TO edit quantity  */}
            <input className="textfield" type="number" min="0" onChange={this.handleUserInput} value={this.state.quantity } id="quantity" name="quantity" />
            </div>
            </div>
                </div>
            </div>
            <Modal
                    isOpen={this.state.quotationEditmodalIsOpen}
                    //  onAfterOpen={this.customerafterOpenModal}
                    onRequestClose={this.state.quotationEditcloseModal}
                    style={customStyles}
                    contentLabel="Example Modal"
                >            {/* edit image  */}
                <div className="container">
                < div class="updatedevice" id="updatedevice" onClick={() => this.closeModalProductType()} style={{ textAlign: "center" }}><span style={{ fontSize: '1em', color: 'white', float:'right',marginTop:"-30px",marginRight:"-20px" }}>
                        <i class="glyphicon glyphicon-remove" style={{
                            border: "none",
                            padding: "6px 7px 5px 7px",
                            fontSize: "1em",
                            color: "black",
                            borderRadius: "18px",
                        }}>   </i>

                    </span>


                    </div>
                    <h4>Edit-Quotation (Image)</h4>
                    <div className="row mt-20">
                        <div className="col-md-3">
                        <label>Image Type</label>    
                <div>      
                {/* FIELD USED TO edit Image Type */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.imageType} id="imageType" name="imageType" readOnly/>
                </div>
                </div>
                <div className="col-md-3">
                        <label>Image Pixel</label>    
                <div>      
                {/* FIELD USED TO edit Image Pixel  */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.imagePixel} id="imagePixel" name="imagePixel" readOnly/>
                </div>
                </div>
                <div className="col-md-3">
                        <label>Rate/Unit </label>    
                <div>      
                {/* FIELD USED TO edit Rate/Unit  */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rateUnit } id="rateUnit" name="rateUnit" />
                </div>
                </div>
                <div className="col-md-3">
                        <label>Rate</label>    
                <div>      
                {/* FIELD USED TO edit Rate/Unit  */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rate } id="rate" name="rate" />
                </div>
                </div>
                <div className="col-md-3">
                        <label>CGST(%) </label>    
                <div>      
                {/* FIELD USED TO edit CGST(%)  */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.cgst } id="cgst" name="cgst" />
                </div>
                </div>
                <div className="col-md-3">
                        <label>IGST(%) </label>    
                <div>      
                {/* FIELD USED TO edit iGST(%)  */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.igst } id="igst" name="igst" />
                </div>
                </div>
                <div className="col-md-3">
                        <label>SGST(%) </label>    
                <div>      
                {/* FIELD USED TO edit sGST(%)  */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.sgst } id="sgst" name="sgst" />
                </div>
                </div>
                <div className="col-md-3">
                        <label>Quantity</label>    
                <div>      
                {/* FIELD USED TO edit quantity  */}
                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.quantity } id="quantity" name="quantity" />
                </div>
                </div>
                    </div>
             
                                  <div class="text-center">
                    <button type="button" class="btn-default " onClick={() => this.closeModalQuotationEdit()}
                        style={{
                            borderRadius: "18px",
                            backgroundColor: "#263eac",
                            color: "white",
                            width: "75px",
                            marginTop: "20px"
                        }}

                    >
                        <span class="glyphicon glyphicon-ok" style={{ fontWeight: "800" }} ></span> Ok
                    </button>
                    </div>
                    </div>
                    </Modal>
   </div>
        );
    }
}

export class FranchiseQuotationImage extends React.Component{
    constructor(){
      super();      
 this.state= {
 }
 }
 editImageIcon(){
    alert("Edit image Icon page");
}
 render(){
     return( 
         <div className="row mt-20 card-box Quotationimage">
         <div className="col-md-6">
             <div className="row quotation-card-box">
         <div class="col-md-8 text-center">
             <div class="card-box-img">
                 <img src={image1} />
                 <div className="img-editicon">               
                 <EditImageIcon onEditImage={this.editImageIcon} />    
                 </div>
                 </div>
                 </div>
                 <div class="col-md-4 text-left mt-20">
                 <p>Image Type: <span>Nature</span><br/>Image Pixel: <span>307 * 170</span><br/>Rate: <span>400</span></p>
                 </div>
             </div>
             </div>
             <div className="col-md-6">
             <div className="quotation-card-box">
         <table className="table">
             <tbody>
                 <tr>
                     <td>Rate/Unit</td>
                     <td>150</td>
                 </tr>
                 <tr>
                     <td>Quantity</td>
                     <td>15</td>
                 </tr>
                 <tr>
                     <td>CGST(%)</td>
                     <td>14</td>
                 </tr>
                 <tr>
                     <td>SGST(%)</td>
                     <td>14</td>
                 </tr>
                 <tr>
                     <td>IGST(%)</td>
                     <td>14</td>
                 </tr>
             </tbody>
         </table>
         </div>
         </div>
         <div className="text-center">
             <button className="btn btn-primary btn-submit" onClick={this.editImage}>Delete</button>
         </div>
</div>
     );
 }
}

export class QuotationProduct extends React.Component{
    constructor(){
        super();      
   this.state= {

       }
   }
   render(){
       return( 
<div className="row mt-20 card-box Quotationproduct">
<div className="col-md-6">
    <div className="row quotation-card-box">
    <div className="col-md-6">
<label>Product</label>    
<div>      
{/* FIELD USED TO edit Product */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.product} id="product" name="product" readOnly/>
</div></div>
<div className="col-md-6">
<label>Product Code </label>    
<div>      
{/* FIELD USED TO edit Product Code */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.productCode} id="productCode" name="productCode" readOnly/>
</div></div> 
<div className="col-md-6">
<label>Rate </label>    
<div>      
{/* FIELD USED TO edit Rate  */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rate} id="rate" name="rate" readOnly/>
</div></div>   
<div className="col-md-6">
<label>HSN Code</label>    
<div>      
{/* FIELD USED TO edit HSN Code  */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.hsnCode } id="hsnCode" name="hsnCode" readOnly/>
</div></div>     
    </div>
    </div>
    <div className="col-md-6">
    <div className="quotation-card-box">
<table className="table">
    <tbody>
        <tr>
            <td>Rate/Unit</td>
            <td>150</td>
        </tr>
        <tr>
            <td>Quantity</td>
            <td>15</td>
        </tr>
        <tr>
            <td>CGST(%)</td>
            <td>14</td>
        </tr>
        <tr>
            <td>SGST(%)</td>
            <td>14</td>
        </tr>
        <tr>
            <td>IGST(%)</td>
            <td>14</td>
        </tr>
    </tbody>
</table>
</div>
</div>
<div className="text-center">
                <button className="btn btn-primary btn-submit">Edit Product</button>
            </div>
</div>
       );
   }
}

export class FranchiseQuotationProduct extends React.Component{
    constructor(){
        super();      
   this.state= {

       }
   }
   render(){
       return( 
<div className="row mt-20 card-box Quotationproduct">
<div className="col-md-6">
    <div className="row quotation-card-box">
    <div className="col-md-6">
<label>Product Name</label>    
<div>      
{/* FIELD USED TO create Product */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.product} id="product" name="product" readOnly/>
</div></div>
<div className="col-md-6">
<label>Product Code </label>    
<div>      
{/* FIELD USED TO create Product Code */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.productCode} id="productCode" name="productCode" readOnly/>
</div></div> 
<div className="col-md-6">
<label>Rate </label>    
<div>      
{/* FIELD USED TO create Rate  */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rate} id="rate" name="rate" readOnly/>
</div></div>   
<div className="col-md-6">
<label>HSN Code</label>    
<div>      
{/* FIELD USED TO create HSN Code  */}
<input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.hsnCode } id="hsnCode" name="hsnCode" readOnly/>
</div></div>     
    </div>
    </div>
    <div className="col-md-6">
    <div className="quotation-card-box">
<table className="table">
    <tbody>
        <tr>
            <td>Rate/Unit</td>
            <td>150</td>
        </tr>
        <tr>
            <td>Quantity</td>
            <td>15</td>
        </tr>
        <tr>
            <td>CGST(%)</td>
            <td>14</td>
        </tr>
        <tr>
            <td>SGST(%)</td>
            <td>14</td>
        </tr>
        <tr>
            <td>IGST(%)</td>
            <td>14</td>
        </tr>
    </tbody>
</table>
</div>
</div>
<div className="text-center">
                <button className="btn btn-primary btn-submit">Delete</button>
            </div>
</div>
       );
   }
}