//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
// import statement for image
import image1 from '../../images/image1.png'

class QuotationView extends React.Component{
       constructor(){
         super();      
    this.state= {

        }
    }
    render(){
        return( 
<div className="container-fluid">
    <div className="row">
            <div className="col-md-3">
            <label>Franchise</label>    
            <div>      
            {/* FIELD USED TO VIEW Franchise */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.franchise} id="franchise" name="franchise" readOnly />
            </div>
            </div>
            <div className="col-md-3">
            <label>Quotation No</label>    
            <div>      
            {/* FIELD USED TO VIEW Quotation No */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.quotationNo} id="quotationNo" name="quotationNo" readOnly />
            </div>
            </div>
            <div className="col-md-3"><label>Status</label>    
            <div>      
            {/* FIELD USED TO VIEW Status  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.status} id="status" name="status" readOnly />
            </div></div>
            <div className="col-md-3"><label>Submitted Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Submitted Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.submittedDate} id="submittedDate" name="submittedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Accepted Date </label>    
            <div>      
            {/* FIELD USED TO VIEW Accepted Date  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.acceptedDate } id="acceptedDate" name="acceptedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Completed Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Completed Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.completedDate} id="completedDate" name="completedDate" readOnly />
            </div></div>
            <div className="col-md-3"><label>Cancelled Date</label>    
            <div>      
            {/* FIELD USED TO VIEW Submitted Date */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.cancelledDate} id="cancelledDate" name="cancelledDate" readOnly />
            </div>
            </div>
            </div>
            <div className="row card-box">
             <div className="col-md-3">
            <label>Total Amount</label>    
            <div>      
            {/* FIELD USED TO view Total Amount */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>GST Tax</label>    
            <div>      
            {/* FIELD USED TO view GST Tax */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.gstTax} id="gstTax" name="gstTax" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Amount to be paid</label>    
            <div>      
            {/* FIELD USED TO view Amount to be paid*/}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.amountPaid} id="amountPaid" name="amountPaid" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Total Item on Cart</label>    
            <div>      
            {/* FIELD USED TO view Total Amount */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" readOnly/>
            </div></div>
  
            </div>
            <div className="row mt-20 card-box Quotationimage">
            <div className="col-md-6">
                <div className="row quotation-card-box">
            <div class="col-md-8 text-center">
                <div class="card-box-img">
                    <img src={image1} />                    
                    </div>
                    </div>
                    <div class="col-md-4 text-left mt-20">
                    <p>Image Type: <span>Nature</span><br/>Image Pixel: <span>307 * 170</span><br/>Rate: <span>400</span></p>
                    </div>
                </div>
                </div>
                <div className="col-md-6">
                <div className="quotation-card-box">
            <table className="table">
                <tbody>
                    <tr>
                        <td>Rate/Unit</td>
                        <td>150</td>
                    </tr>
                    <tr>
                        <td>Quantity</td>
                        <td>15</td>
                    </tr>
                    <tr>
                        <td>CGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>SGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>IGST(%)</td>
                        <td>14</td>
                    </tr>
                </tbody>
            </table>
            </div>
            </div>
   </div>
   <div className="row mt-20 card-box Quotationproduct">
            <div className="col-md-6">
                <div className="row quotation-card-box">
                <div className="col-md-6">
            <label>Product</label>    
            <div>      
            {/* FIELD USED TO view Product */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.product} id="product" name="product" readOnly/>
            </div></div>
            <div className="col-md-6">
            <label>Product Code </label>    
            <div>      
            {/* FIELD USED TO view Product Code */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.productCode} id="productCode" name="productCode" readOnly/>
            </div></div> 
            <div className="col-md-6">
            <label>Rate </label>    
            <div>      
            {/* FIELD USED TO view Rate  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.rate} id="rate" name="rate" readOnly/>
            </div></div>   
            <div className="col-md-6">
            <label>HSN Code</label>    
            <div>      
            {/* FIELD USED TO view HSN Code  */}
            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.hsnCode } id="hsnCode" name="hsnCode" readOnly/>
            </div></div>     
                </div>
                </div>
                <div className="col-md-6">
                <div className="quotation-card-box">
            <table className="table">
                <tbody>
                    <tr>
                        <td>Rate/Unit</td>
                        <td>150</td>
                    </tr>
                    <tr>
                        <td>Quantity</td>
                        <td>15</td>
                    </tr>
                    <tr>
                        <td>CGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>SGST(%)</td>
                        <td>14</td>
                    </tr>
                    <tr>
                        <td>IGST(%)</td>
                        <td>14</td>
                    </tr>
                </tbody>
            </table>
            </div>
            </div>
   </div>
    </div>
        );
    }
}
export default QuotationView;