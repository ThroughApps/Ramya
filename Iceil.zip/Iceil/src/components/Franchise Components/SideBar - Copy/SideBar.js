//IMPORT STATEMENTS FOR REACT COMPONENT
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import $ from 'jquery';
import ReactDOM from "react-dom";
import CryptoJS from 'crypto-js';
import _ from 'underscore';

import * as FaIcons from 'react-icons/fa';
import * as BiIcons from 'react-icons/bi';
import * as GrIcons from "react-icons/gr";
// import ScrollMenu from "react-horizontal-scrolling-menu";
import * as BsIcons from "react-icons/bs";

import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';

import VideoGallery from '../Video Gallery/VideoGallery';
//import Help from '../Help/Help'
import Tree from '@naisutech/react-tree';

//import '@grapecity/wijmo.styles/wijmo.css';
//import { getData } from './data';
import iceillogo from '../../images/iceillogo.png';
import Toggle from 'react-toggle';
import { List_To_Tree_With_KeyNameChange_For_SideBar, List_To_Tree_With_KeyNameChange_Without_RootMenu, LogOut } from '../../Common Components/CommonComponents';
import ImageGallery from '../Image Gallery/ImageGallery';
import ChooseYourImage from '../ChooseYour Image/ChooseYourImage';
import SavedImage from '../Saved Image/SavedImage';
import LoginPage from '../../LoginComponents/LoginPage';
import FAQ from '../FAQ/FAQ';
import QuotationMenus from '../Quotation/QuotationMenus';
import Help from '../Help/Help';
import AboutMe from '../About Me/AboutMe';
import './SideBarCSS.css';
import './style.css';
// import statement for react component css

var menuList = []; //USED TO HOLD THE VALUES OF THE EXISTING MENU PROVIDED AS RESPONSE FROM SERVER - DECLARED BY PRIYANKA - 27-04-2022
var treeList = []; //USED TO HOLD THE VALUES OF THE EXISTING MENU PROVIDED AS RESPONSE FROM SERVER - DECLARED BY PRIYANKA - 27-04-2022
var parentMenuList = [];
//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class SideBar extends React.Component {

  constructor() {
    super()

    this.state = {
      // data: [],
      menuIdArray: [],
      parentMenuList:[],
      subParentMenuList:[],
      childMenuList:[],
      subMenuList:[],
      customCSS: true,
      //data: getData(),

    }
  }
  // constructor(props) {
  //   super(props);
  //   this.state = {
  //       data: getData(),
  //       msg: "Ready"
  //   };

  initTreeView(ctl) {
    this._wjTreeViewControl = ctl;
}
onCustomCSSClick() {
    toggleClass(this._wjTreeViewControl.hostElement, 'accordion', !this.state.customCSS);
    this.setState({
        customCSS: !this.state.customCSS
    });
}
onItemClicked(s, e) {
  this.setState({
      msg: (<p>Navigating to <b>** {s.selectedItem.header} **</b> </p>)
  });
}
  componentDidMount() {

  var self=this;
  self.DynamicSideBar(this.props.menuList);

  $(document).ready(function () {
    $(".menubars").click(function () {
      $(".wrapper").toggleClass("collapse");
    });
  });
  $(document).ready(function () {
    $(".main_content").click(function () {
      $(".wrapper").addClass("collapse");
    }); 
  });
  /*USED TO CLOSE THE SIDEBAR MENU INTO SMALL WHEVER CLICKS THE MENU*/
  $(document).ready(function () {
    $(".sidebar-menu").click(function () {
      $(".wrapper").addClass("collapse");
    });
  });
 
 $(document).ready(function() {
  //alert("accordian");
      $("#accordian a").click(function() {
        //alert("accordian a click");
      var link = $(this);
      var closest_ul = link.closest("ul");
      console.log("closest_ul",closest_ul);

      var parallel_active_links = closest_ul.find(".active")
      console.log("parallel_active_links",parallel_active_links);

      var closest_li = link.closest("li");
      console.log("closest_li",closest_li.ul);

      //var liname = document.querySelector("#accordian ul:nth-child(2)");
      var liname = document.querySelector(".collaspsedSidemenu");
      console.log("liname", liname);

      var link_status = closest_li.hasClass("active");
      console.log("link_status",link_status);

      var count = 0;
      
      closest_ul.find("ul").slideUp(function() {

      if (++count == closest_ul.find("ul").length)
      parallel_active_links.removeClass("active");
      });
  
      if (!link_status) {
      closest_li.children("ul").slideDown();
      closest_li.addClass("active");
      }
    //  alert("end of a click");
      })
    })
  }

  /*
  FUNCTION USED TO PREPARE THE ADDED MENU ACCORDING TO THE SIDE BAR TREE FORMAT
  - IMPLEMENETED BY PRIYANKA - 27-04-2022
  */
  DynamicSideBar(menuListData) {
   // alert("menuListData");
    var self=this;

    menuList = [];
    treeList = [];

    menuList = menuListData;
    //_.where(people, {hasLong: "true"})); parentMenuId
  //  var tempMenuList= _.where(menuListData, {parentMenuId:""});
  //  alert("tempMenuList"+tempMenuList[5].parentMenuId);

   parentMenuList = menuListData.filter(
      function (element){ return element.parentMenuId =="" });

          console.log("parentMenuList",parentMenuList);
          self.setState({parentMenuList:parentMenuList})
          console.log("parentMenuList", self.state.parentMenuList);
    var subMenuList = menuListData.filter(
            function (element){ return element.parentMenuId !==""});
      
                console.log("subMenuList",subMenuList);
self.setState({subMenuList:subMenuList})
                var subParentMenuList=[];
      $.each(parentMenuList,function(i,item)
      {
        $.each(subMenuList,function(j,element)
        {
          if(item.menuId==element.parentMenuId)
          {
            subParentMenuList.push(subMenuList[j])
          }
        });
       
      });
      self.setState({subParentMenuList:subParentMenuList})
      
      console.log("subParentMenuList",subParentMenuList);

      var childMenuList=[];
      var flag=false;
      $.each(subMenuList,function(i,item)
      {
        $.each(subParentMenuList,function(j,element)
        {
          if(item.menuId==element.menuId)
          {
            flag=true;

          } });
if( flag==false)
{
  childMenuList.push(subMenuList[i]) 

}
flag=false;
});
self.setState({childMenuList:childMenuList})
 console.log("childMenuList",childMenuList);
    //CONVERTING THE FLAT ARRAY OF OBJECTS INTO TREE LIST WITH NEW ROOT MENU(PARENT - CHILD RELATIONSHIP)
    var treeListSideBar = List_To_Tree_With_KeyNameChange_For_SideBar(menuListData);
    treeList = List_To_Tree_With_KeyNameChange_Without_RootMenu(menuListData);

    this.state.data = treeListSideBar;
    this.setState({
      data: this.state.data
    })
    console.log("treeList :", treeList);
    console.log("treeListSideBar :", treeListSideBar);
  }
  renderTree(parentId) {
    var self=this;
    //console.log("inside rendertree");
    //console.log("parentId",parentId);
    //const nodes = self.state.subMenuList && self.state.subMenuList.filter(x => x.parentMenuId == parentId);
    const nodes = self.state.subMenuList.filter(x => x.parentMenuId == parentId);
    //console.log("nodes",nodes);
        return (<ul>
        { nodes && nodes.map((item) => { 
          return (
            <React.Fragment> 
               <li><a href="#" onClick={() => this.onMenuSelect(item.menuId)}><span class="menu-title">{item.menuName}</span></a>
               {this.renderTree(item.menuId)}
               </li>
            </React.Fragment>
          )
        })}
    </ul>
   )
  //   return (<ul>
  //       {nodes && nodes.map((item) => { 
  //         return (
  //           <React.Fragment> 
  //              <li>{item.name}</li>
  //              {/* {item.subNodes && this.renderTree(item.menuId)} */}
  //              {this.renderTree(item.menuId)}
  //           </React.Fragment>
  //         )
  //       })}
  //   </ul>
  //  )
}
  /*
  FUNCTION USED TO RENDER THE PAGES BASED ON MENU SELECTED FROM SIDE BAR 
  - IMPLEMENETED BY PRIYANKA - 27-04-2022
  */
  onMenuSelect =  (nodeId) => {
    console.log("nodeId :", nodeId);
    console.log("menuList :", menuList);
    if (nodeId != "") {

      // var menuId = nodeId[0];
       var menuId = nodeId;
      console.log("menuId :", menuId);
      var menuInfo = _.where(menuList, { parentMenuId: menuId }) 

      console.log("menuInfo :", menuInfo);
      if (menuInfo.length == 0) {
        //MENU DOESNOT HAVE ANY CHILDREN HENCE RENDER THE DATA FROM 
        var currentMenuInfo = _.where(menuList, { menuId: menuId });

        console.log("currentMenuInfo :", currentMenuInfo);

        var filteredArray = this.state.menuIdArray.filter(function (e) { return e == currentMenuInfo[0].module })

        console.log("filteredArray :", filteredArray);

        this.state.menuIdArray = [];
        this.setState({
          menuIdArray: [],
        })

        this.state.menuIdArray = filteredArray;
        this.setState({
          menuIdArray: filteredArray,
        })

       var folderPath = currentMenuInfo[0].menuName;
        var parentId = currentMenuInfo[0].parentMenuId;

        if (parentId != null) {

            do {
                console.log(" *** parentId :", parentId);
                var currentFolder = _.where(menuList, { menuId: parentId });

                console.log(" *** currentFolder :", currentFolder);
                if (currentFolder.length > 0) {
                    folderPath = currentFolder[0].menuName + "/" + folderPath;
                    parentId = currentFolder[0].parentMenuId;

                }else{
                    parentId=null
                }
                console.log(" *** folderPath:", folderPath);
            } while (parentId != null)
        }

        if (currentMenuInfo[0].module == "Project Gallery") {
          $(".wrapper").toggleClass("collapse");
          if (!_.contains(this.state.menuIdArray, currentMenuInfo[0].module)) {
            ReactDOM.render(
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<ImageGallery menuId={menuId} menuName={currentMenuInfo[0].menuName} folderPath={folderPath} />} />
                </Routes>
              </BrowserRouter>,
              document.getElementById("contentRender"),

            )

            this.state.menuIdArray.push(currentMenuInfo[0].module);
            this.setState({
              menuIdArray: this.state.menuIdArray
            })

          } else if (_.contains(this.state.menuIdArray, currentMenuInfo[0].module)) {

            window.ImageGalleryComponent.SetImageGalleryData(menuId, currentMenuInfo[0].menuName,folderPath)
          }

          console.log("this.state.menuIdArray :", this.state.menuIdArray);

        } else if (currentMenuInfo[0].module == "Video Gallery") {

          $(".wrapper").toggleClass("collapse");
          if (!_.contains(this.state.menuIdArray, currentMenuInfo[0].module)) {
            
            ReactDOM.render(              
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<VideoGallery menuId={menuId} menuName={currentMenuInfo[0].menuName} folderPath={folderPath}/>} />
                </Routes>
              </BrowserRouter>,
              document.getElementById("contentRender")
            )
            this.state.menuIdArray.push(currentMenuInfo[0].module);
            this.setState({
              menuIdArray: this.state.menuIdArray
            })

          } else if (_.contains(this.state.menuIdArray, currentMenuInfo[0].module)) {

            window.VideoGalleryComponent.SetVideoGalleryData(menuId, currentMenuInfo[0].menuName,folderPath,folderPath+"/ThumbNail")
          }
        } else if (currentMenuInfo[0].module == "Image Gallery") {
          $(".wrapper").toggleClass("collapse");
          if (!_.contains(this.state.menuIdArray, currentMenuInfo[0].module)) {

            ReactDOM.render(
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<ChooseYourImage menuId={menuId} menuName={currentMenuInfo[0].menuName} folderPath={folderPath} />} />
                </Routes>
              </BrowserRouter>,
              document.getElementById("contentRender")
            )
            this.state.menuIdArray.push(currentMenuInfo[0].module);
            this.setState({
              menuIdArray: this.state.menuIdArray
            })

          } else if (_.contains(this.state.menuIdArray, currentMenuInfo[0].module)) {

            window.ChooseYourImageComponent.SetChooseYourImageData(menuId, currentMenuInfo[0].menuName,folderPath)
          }
        }
      }
    }
    // alert("onMenuSelect " + nodeId);

     
  }
        ChooseYourImage(){ 
  ReactDOM.render(
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ChooseYourImage menuId={menuId} menuName={currentMenuInfo[0].menuName} folderPath={folderPath} />} />
      </Routes>
    </BrowserRouter>,
    document.getElementById("contentRender")
  )
  }
  Help(){
  ReactDOM.render(
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Help />} />
      </Routes>
    </BrowserRouter>,
    document.getElementById("contentRender")
  )
  }
  FAQ(){
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<FAQ />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    )
  }
  Aboutme(){
     ReactDOM.render(
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<AboutMe />} />
            </Routes>
          </BrowserRouter>,
          document.getElementById("contentRender")
        )
     }
     SavedImage(){
     ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SavedImage />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    )
     }
  render() {
    return (
      <div>
        <div class="wrapper" style={{ paddingBottom: '76px', overflowY: 'auto!important' }}>
          <div class="topnavbar franchise">
            <div class="menus">
              <div class="menubars">
                <FaIcons.FaBars size={30} />
              </div>
              <div class="comp_title">Iceil</div>
            </div>
          </div>
          <div className="sidebar franchise">
          <div style={{ width: '100%', display: 'flex', flexDirection: 'column', maxHeight: '630px',backgroundColor:'#233044' }}>
                  <div class="logocolumn">
                      <h3 class="logo">ICEIL</h3>
                      <h4 class="logo_sub">Franchise Management System</h4>
                  </div>
                  <div>
                  <div id="container-fluid">
                 
                <div className="collapsed_group">
                <div id="accordian">
                <ul class="collaspsedSidemenu ">
                  
                  {(
                    this.state.parentMenuList.map((data) => 
                    // this.onMenuSelect(nodeIds)
                  <div> <li class="listItem commonItem"><a href="#" onClick={() => this.onMenuSelect(data.menuId)}><span class="menu-icon fa fa-file-image-o"></span><span class="menu-title">{data.menuName}</span></a>
                 
                  {this.renderTree(data.menuId)}

                  </li>
                  </div>
                  )
                  )}
                 
                  <li class="listItem commonItem">
                                <a href="#" onClick={() => this.SavedImage()}>
                                    <span class="menu-icon fa fa-floppy-o"></span>
                                    <span class="menu-title">Saved Image</span>
                                </a>
                  </li>
                  <li>
                                <a href="#">
                                    <span class="menu-icon fa fa-file-text-o "></span>
                                    <span class="menu-title">Quotation</span>
                                </a>
                  </li>
                  <li>
                                <a href="#" onClick={() => this.Help()}>
                                    <span class="menu-icon fa fa-info-circle "></span>
                                    <span class="menu-title">Technical Know-How</span>
                                </a>
                  </li>
                  <li>
                                <a href="#" onClick={() => this.FAQ()}>
                                    <span class="menu-icon fa fa-question-circle "></span>
                                    <span class="menu-title">FAQ</span>
                                </a>
                  </li>
                  <li>
                                <a href="#" onClick={() => this.Aboutme()}>
                                    <span class="menu-icon fa fa-user"></span>
                                    <span class="menu-title">About Me</span>
                                </a>
                  </li>
                  <li>
                                <a href="#" >
                                    <span class="menu-icon fa fa-power-off "></span>
                                    <span class="menu-title">Logout</span>
                                </a>
                  </li>

                  </ul>
                  </div>
                  </div></div></div>
            </div>
          </div>
          <div class="main_content" id="contentRender"></div>
        </div>
      </div>
    );
  };

}
export default SideBar;
