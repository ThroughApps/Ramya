//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { useState } from "react";
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";
import $ from 'jquery';
import _ from 'underscore';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import SlidingPane from "react-sliding-pane";
import Viewer from 'react-viewer';
//import Lightbox from "react-images-zoom";
import CryptoJS from 'crypto-js';

import * as BsIcons from 'react-icons/bs';
import * as FaIcons from 'react-icons/fa';
import * as FiIcons from 'react-icons/fi';
import * as AiIcons from 'react-icons/ai';
import * as MdIcons from 'react-icons/md';
import ReactTooltip from 'react-tooltip';
import { initDB, IndexedDB, AccessDB, useIndexedDB } from 'react-indexed-db';
import { PDFViewer } from 'react-view-pdf';

import "react-sliding-pane/dist/react-sliding-pane.css";
// import statement for react class component
//import { SavedImageIcons } from '../../Assets Components/Icon Components/Icons';
//import EditImage from '../../Franchise Components/Choose Your Image/EditImage';
//import PreviewImage from '../../Franchise Components/Saved Image/PreviewImage';
// import statement for react component css
import '../../Franchise Components/Saved Image/SavedImageCss.css';
import EditImage from "../ChooseYour Image/EditImage";
import { AddDataToTable, CheckDataInTable, ClearTable, GetLocalStorageData } from "../../Common Components/CommonComponents";
import { DBConfig } from "../../Common Components/CommonComponents";
import EditImage_Cropper from "../ChooseYour Image/EditImage_Cropper";
import { GetFileName, GetImageFileFromAWS } from "../../AWS/AWSFunctionality";
import SavedImageComponent from "./SavedImageComponent";
import LoadingComponent from "../../Assets Components/Loading Components/LoadingComponent";


//const { add } = useIndexedDB('AddToCart');

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var tableName = "AddToCart";


class SavedImage extends React.Component {
    constructor() {
        super();
        this.state = {
            uploadedLogoImage: "",
            uploadedQrCodeImage: "",
            isImageEditPaneOpen: false,
            isImagePreviewPaneOpen: false,
            OpenLightbox: false,
            visible: false,
            // setVisible: false,
            closeLightbox: '',
            imageUrl: "",
            imageArray: [],
            previewImageArray: [],
            imageActiveIndex: 0,
            uploadId: "",
            pdf: "",
            zoomable: true,
            fileInfoArray: [],
            folderPath: '',
        }
        this.GetFile_Name = this.GetFile_Name.bind(this);
        this.GetData = this.GetData.bind(this);

    }
    componentDidMount() {

        var self = this;

        this.state.folderPath = "Saved Images" + "/" + GetLocalStorageData("FranchiseId");
        this.setState({
            folderPath: this.state.folderPath
        })

        Loading_Component.ModalOpenFun()

        this.GetFile_Name();


    }

    GetFile_Name() {

        //   alert("GET FILE NAME :"+ this.state.folderPath );

        var self = this;
        self.state.fileInfoArray =[];
        self.setState({
            fileInfoArray:self.state.fileInfoArray,
        })
        GetFileName(self.state.folderPath).then(function (response) {

            if (response !== "Error") {
                console.log("** RESPONSE CONTENTS :", response.Contents)

                self.state.fileInfoArray = response.Contents;
                self.state.fileInfoArray.shift();
                self.setState({
                    fileInfoArray: self.state.fileInfoArray,
                })

                console.log("self.state.fileInfoArray :", self.state.fileInfoArray);

                self.state.totalItemsCount = response.Contents.length;
                self.setState({
                    totalItemsCount: self.state.totalItemsCount
                });
                  self.GetData();
              
              //  SavedImage_Component.SetSavedImageData(self.state.fileInfoArray)

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        });
    }

    GetData() {

        var self = this;

        //  alert("GET DATA");

        GetImageFileFromAWS(self.state.fileInfoArray).then(function (response) {

            if (response !== "Error") {

                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

                SavedImage_Component.SetSavedImageData(response)

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })

        // console.log("** self.state.imageArray OUTSIDE :", self.state.imageArray)

    }


    render() {

        return (
            <div>
                <SavedImageComponent ResetData={this.GetFile_Name} />
                <LoadingComponent />
            </div>
        );
    }
}

export default SavedImage;
