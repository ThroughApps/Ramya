import React from "react";
import Lightbox from "react-images-zoom";
import CryptoJS from 'crypto-js';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class PreviewImage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      imageSrc: ""
    };

  }


  render() {
    const { name, type, size, imageSrc, base64, croppedImgSrc } = this.state;

    return (
<div>
<Lightbox
        images={[
          {
            src:
              "https://i.picsum.photos/id/611/300/200.jpg?hmac=uiyH7IkXAN478vYqMR-h9nPMKXaKDiEOKyk5JRS35sI"
          }
        ]}
        isOpen={true}
        // onClickPrev={this.gotoPrevious}
        // onClickNext={this.gotoNext}
        onClose={this.closeLightbox}
        // rotatable={true}
        zoomable={true}
      />
</div>
    );
  }
}

export default PreviewImage;
