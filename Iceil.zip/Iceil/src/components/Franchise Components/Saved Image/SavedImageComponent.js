//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { useState } from "react";
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";
import $ from 'jquery';
import _ from 'underscore';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import SlidingPane from "react-sliding-pane";
import Viewer from 'react-viewer';
//import Lightbox from "react-images-zoom";
import CryptoJS from 'crypto-js';

import * as BsIcons from 'react-icons/bs';
import * as FaIcons from 'react-icons/fa';
import * as FiIcons from 'react-icons/fi';
import * as AiIcons from 'react-icons/ai';
import * as MdIcons from 'react-icons/md';
import ReactTooltip from 'react-tooltip';
import { initDB, IndexedDB, AccessDB, useIndexedDB } from 'react-indexed-db';
import { PDFViewer } from 'react-view-pdf';

import "react-sliding-pane/dist/react-sliding-pane.css";
// import statement for react class component
//import { SavedImageIcons } from '../../Assets Components/Icon Components/Icons';
//import EditImage from '../../Franchise Components/Choose Your Image/EditImage';
//import PreviewImage from '../../Franchise Components/Saved Image/PreviewImage';
// import statement for react component css
import '../../Franchise Components/Saved Image/SavedImageCss.css';
import EditImage from "../ChooseYour Image/EditImage";
import { AddDataToTable, CheckDataInTable, ClearTable, GetLocalStorageData } from "../../Common Components/CommonComponents";
import { DBConfig } from "../../Common Components/CommonComponents";
import EditImage_Cropper from "../ChooseYour Image/EditImage_Cropper";
import { DeleteFile, GetImageFileFromAWS } from "../../AWS/AWSFunctionality";


//const { add } = useIndexedDB('AddToCart');

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var tableName = "AddToCart";

class SavedImageComponent extends React.Component {
    constructor() {
        super();

        window.SavedImage_Component = this;

        this.state = {
            isImageEditPaneOpen: false,
            isImagePreviewPaneOpen: false,
            OpenLightbox: false,
            visible: false,
            // setVisible: false,
            closeLightbox: '',
            imageUrl: "",
            imageArray: [],
            previewImageArray: [],
            imageActiveIndex: 0,
            uploadId: "",
            pdf: "",
            zoomable: true,
        }

        this.EditImage = this.EditImage.bind(this);
        this.PreviewImage = this.PreviewImage.bind(this);
        this.CloseImageEdit = this.CloseImageEdit.bind(this);
        this.RenderImages = this.RenderImages.bind(this);
        this.ResetData = this.ResetData.bind(this);
    }
    componentDidMount() {



    }


    SetSavedImageData(imageArray) {

      //  alert("SetSavedImageData");
        /*  this.state.imageArray = [];
          this.setState({
              imageArray: this.state.imageArray
          })
  
          this.state.imageArray = imageArray;
          this.setState({
              imageArray: this.state.imageArray
          })
          */

        this.RenderImages(imageArray);
    }




    /*
    FUNCTION USED TO RENDER THE IMAGES AFTER THE CHNAGES LIKE EDIT, DELETE
    IMPLEMENTED BY PRIYANKA - 03-05-2022
    */
    RenderImages(mediaDataList) {

        var self = this;

        self.state.imageArray = [];
        self.setState({
            imageArray: self.state.imageArray,
        })

        if (mediaDataList.length > 0) {

            /*
                        self.state.totalItemsCount = data.dataCount;
                        self.setState({
                            totalItemsCount: self.state.totalItemsCount
                        });
            */
            $.each(mediaDataList, function (i, item) {
                // use a data url as an image source - ADDING WATERMARK TO THE IMAGE

                var imageData = {
                      data: item.data,
                      filePath: item.filePath,
                  //  data: "https://d5g1cpur5okjb.cloudfront.net/" + item.Key,
                  //  filePath: item.Key
                };

                var previewImageData = {
                    src: item.data,
                  // src:"https://d5g1cpur5okjb.cloudfront.net/" + item.Key,
                    alt: 'ImageSlideShow'
                };

                self.state.previewImageArray.push(previewImageData);
                self.state.imageArray.push(imageData);
                self.setState({
                    previewImageArray: self.state.previewImageArray,
                    imageArray: self.state.imageArray,
                })

                console.log("*** INSIDE  self.state.imageArray :", self.state.imageArray);

                /*  watermark([item.data])
                      .dataUrl(watermark.text.lowerRight('Iceil', '30px serif', '#fff', 0.5))
                      .then(function (url) {
                          //document.querySelector('img').src = url;
                          console.log("IMAGE GALLERY WATER MARK URL :", url);
  
                          var imageData = {
                              data: url,
                              filePath: item.filePath
                          };
  
                          var previewImageData = {
                              src: url,
                              alt: 'ImageSlideShow'
                          };
                          //  self.state.imageArray.push(url);
                          self.state.previewImageArray.push(previewImageData);
                          self.state.imageArray.push(imageData);
                          self.setState({
                              previewImageArray: self.state.previewImageArray,
                              imageArray: self.state.imageArray,
                          })
                          console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray);
  
                      })
                      */

            })
            console.log("*** OUTSIDE  self.state.imageArray :", self.state.imageArray);


        }

        Loading_Component.ModalCloseFun()

    }

    /*USED TO OPEN THE SLIDEPANE IMAGE EDIT */
    EditImage(image, filePath) {
        // alert("dit image page");
     //   alert("filePath :"+filePath);
        var self = this;
        /*  self.state.isImageEditPaneOpen = true;
          self.state.editImage = image;
          //  self.state.uploadId = id;
          self.state.editImageFilePath = filePath;
  
          self.setState({
              isImageEditPaneOpen: self.state.isImageEditPaneOpen,
              editImage: self.state.editImage,
              editImageFilePath: self.state.editImageFilePath,
              //   uploadId: self.state.uploadId,
          })
          */

        var downloadFileArray = [];
        downloadFileArray.push({ Key: filePath })
        GetImageFileFromAWS(downloadFileArray).then(function (response) {

            if (response !== "Error") {

                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)


                self.state.isImageEditPaneOpen = true;
                self.state.editImage = response[0].data;
                self.state.editImageFilePath = filePath;
                // self.state.uploadId = id;

                self.setState({
                    isImageEditPaneOpen: self.state.isImageEditPaneOpen,
                    editImage: self.state.editImage,
                    editImageFilePath: self.state.editImageFilePath,
           
                    //   uploadId: self.state.uploadId
                })



            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })
    }
    /*USED TO CLOSE THE SLIDEPANE IMAGE EDIT */
    CloseImageEdit() {
        this.state.isImageEditPaneOpen = false;
        this.setState({
            isImageEditPaneOpen: this.state.isImageEditPaneOpen,
        })
    }

    /*
    FUNCTION USED TO ADD IMAGE TO 
    CART WHEN ADD TO CART ICON IS CLICKED
    - IMPLEMENTED BY PRIYANKA
    */
    AddtoCart(image, id) {

        var dbData = CheckDataInTable(tableName, id, image);

        dbData.then(function (response) {

            console.log("AddtoCart response :", response);

            if (response == undefined) {
                AddDataToTable(tableName, id, image);

                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    text: 'Image added to cart',
                    showConfirmButton: false,
                    timer: 2000
                })

            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'warning',
                    text: 'Image is already available in cart',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })


    }

    /*
    FUNCTION USED TO DOWNLOAD IMAGE TO 
    WHEN DOWNLOAD ICON IS CLICKED
    - IMPLEMENTED BY PRIYANKA
    */
    DownloadImage(image, filePath) {
        // FileSaver.saveAs(image);

        var downloadFileArray = [];
        downloadFileArray.push({ Key: filePath })
        GetImageFileFromAWS(downloadFileArray).then(function (response) {

            if (response !== "Error") {

                console.log("** GetData GetImageFileFromAWS RESPONSE CONTENTS :", response)

                /* const contentType = 'image/png';
                 const blob = base64StringToBlob(response[0].data, contentType);
                 */

                /*  watermark([response[0].data])
                      .dataUrl(watermark.text.center('Iceil', '100px Josefin Slab', '#fff', 0.4))
                      .then(function (url) {
                          //document.querySelector('img').src = url;
                          console.log("IMAGE GALLERY WATER MARK URL :", url);
  
                          FileSaver.saveAs(url, "image.jpg");
  
                      })
                      */

                var file = dataURLtoFile(response[0].data, 'image.jpg');
                console.log("**** ----- DownloadImage :", file);
                FileSaver.saveAs(file, "image.jpg");
            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }
        })
    }
    // PreviewImage(image, id) {
    //     //  alert("previewImage page");
    // }
    /*USED TO OPEN THE SLIDEPANE IMAGE PREVIEW */
    PreviewImage(image, filePath) {
       // console.log("preview page is this");
        var self = this;
        var index = _.findIndex(this.state.imageArray, { filePath: filePath });

        self.state.imageActiveIndex = index;

        self.state.visible = true;
        self.state.isImagePreviewPaneOpen = true;
        self.setState({
            isImagePreviewPaneOpen: self.state.isImagePreviewPaneOpen,
            visible: self.state.visible,
            imageActiveIndex: self.state.imageActiveIndex
        })
    }
    /*USED TO CLOSE THE SLIDEPANE IMAGE VIEW */
    CloseImagePreview() {
        var self = this;
        this.state.isImagePreviewPaneOpen = false;
        this.setState({
            isImagePreviewPaneOpen: this.state.isImagePreviewPaneOpen,
        })
    }
    closeLightbox() {
        var self = this;
        self.state.OpenLightbox = false;
        self.setState({
            OpenLightbox: self.state.OpenLightbox,
        })
    }
    setVisible(flag) {
        this.state.visible = flag;
        this.setState({
            visible: flag,
        })
    }

    /*
FUNCTION USED TO GETTING CONFIRMATION FOR DELETING THE SAVED IMAGES DATA 
- IMPLEMENETED BY PRIYANKA - 30-04-2022
*/
    DeleteImage(image, filePath) {

        var self = this;

        //    alert("filePath :" + filePath);

        Swal.fire({
            title: 'Do you want to delete the image ?',
            showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: 'Yes Delete It !',
            denyButtonText: `No Don't Delete It !`,
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                self.DeleteConfirm(image, filePath);
            } else if (result.isDenied) {
                Swal.fire('Image not deleted', '', 'info')
            }
        })

    }

    /*
  FUNCTION USED FOR DELETING THE SAVED IMAGES DATA AFTER GETTING THE CONFIRMATION
  - IMPLEMENETED BY PRIYANKA - 03-05-2022
  */
    DeleteConfirm(image, filePath) {

        var self = this;


        DeleteFile(filePath).then(function (response) {

            if (response !== "Error") {
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    text: 'Deleted the image successfully',
                    showConfirmButton: false,
                    timer: 2000
                })

                self.props.ResetData();
            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        });


    }

    /*
    FUNCTION USED FOR ADDING ALL THE SAVED IMAGES INTO THE CART
    IMPLEMENTED BY PRIYANKA - 04-05-2022
    */
    Add_All_To_Cart() {

        ClearTable(tableName);

        if (this.state.imageArray.length > 0) {
            $.each(this.state.imageArray, function (i, item) {
                AddDataToTable(tableName, item.id, item.image);
            })
            Swal.fire({
                position: 'center',
                icon: 'success',
                text: 'All Images added to cart',
                showConfirmButton: false,
                timer: 2000
            })
        } else {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'No items available',
                showConfirmButton: false,
                timer: 2000
            })
        }
    }

    /*
SAMPLE FOR GETTING DATA FROM INDEXED DB
WILL BE USED IN QUOTATION MODULE
IMPLEMENTED BY PRIYANKA - 04-05-2022
    */
    GetCartDBData() {
        const { getAll } = useIndexedDB('AddToCart');
        getAll().then(DBData => {
            console.log("GET INDEX DB DATA :", JSON.stringify(DBData));
        });

    }

    ClosepaneImageEdit = (currentState) => {
        var self = this;
        this.state.isImageEditPaneOpen = false;
        this.setState({
            isImageEditPaneOpen: this.state.isImageEditPaneOpen,
        })
    }

    ResetData() {
       // alert("RESET DATA");
        this.props.ResetData();
    }

    render() {

        return (
            <div>
                <div className="franchise-toptitle toptitle">
                    <h4>Saved Image</h4>
                    {/* <button onClick={() => this.GetCartDBData()}> Get Db Data</button> */}
                    <div className="text-right">
                    <button className="btn btn-primary" onClick={() => this.Add_All_To_Cart()}><i class="fa fa-cart-plus" aria-hidden="true"></i> Add all to cart</button>
                    </div>
                </div>
                <div className="card-box">
                    {/* <h4>Image name</h4> */}
                    <div className="chooseimage">
                        {(this.state.imageArray.length > 0 ?
                            (this.state.imageArray.map((data) => (
                                data.data != null && data.data != undefined && data.data != 'data:image/png;base64,'
                                    ? (<div className="chooseimage1">
                                        <img id="image" src={data.data} />
                                        <div className="chooseimageicons">
                                            <ul>
                                                <li><FaIcons.FaCartPlus alt="add to cart" data-tip data-for="AddtoCart" onClick={() => this.AddtoCart(data.data, data.filePath)} /></li>
                                                <li><FaIcons.FaEdit alt="edit image" data-tip data-for="EditImage" onClick={() => this.EditImage(data.data, data.filePath)} /></li>
                                                <li><FaIcons.FaEye alt="logo" data-tip data-for="PreviewImage" onClick={() => this.PreviewImage(data.data, data.filePath)} /></li>
                                                {/* <li><MdIcons.MdPreview alt="logo" data-tip data-for="DownloadImag" onClick={() => this.DownloadImage(data.image, data.id)} /></li> */}
                                                <li><AiIcons.AiFillDelete alt="delete image" data-tip data-for="DeleteImage" onClick={() => this.DeleteImage(data.data, data.filePath)} /></li>
                                            </ul>
                                            <ReactTooltip id="AddtoCart" place="top" effect="solid">Add to Cart</ReactTooltip>
                                            <ReactTooltip id="EditImage" place="top" effect="solid">Edit Image</ReactTooltip>
                                            <ReactTooltip id="PreviewImage" place="top" effect="solid">View Image</ReactTooltip>

                                            <ReactTooltip id="DeleteImage" place="top" effect="solid">Delete Image</ReactTooltip>
                                        </div>
                                    </div>)

                                    : (<div class="col-md-3"> </div>)
                            ))) : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                            </div>)

                        )}
                    </div>
                    <SlidingPane
                        className="some-custom-class"
                        overlayClassName="some-custom-overlay-class"
                        isOpen={this.state.isImageEditPaneOpen}
                        title={"Saved Image - Edit"}
                        // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                        onRequestClose={() => {
                            // triggered on "<" on left top click or on outside click
                            // setState({ isPaneOpen: false });
                            this.CloseImageEdit()
                        }}
                    >
                        <EditImage_Cropper image={this.state.editImage} uploadId={this.state.uploadId}
                            module={"Saved Images"} CloseSlidingPane={this.CloseImageEdit}
                            pageCalledFrom={"Saved Images"} RenderImages={this.RenderImages}
                            editImageFilePath={this.state.editImageFilePath} ResetData={this.ResetData} />
                    </SlidingPane>
                    <div id="NIC_Img_Preview" className="NIC_Img_Preview row">
                        <ul id="viewimages">
                            <Viewer
                                visible={this.state.visible}
                                onClose={() => { this.setVisible(false); }}
                                images={this.state.previewImageArray}
                                activeIndex={this.state.imageActiveIndex}
                                zoomable={this.state.zoomable}
                            />
                        </ul>

                    </div>
                </div>

            </div>
        );
    }
}

export default SavedImageComponent;
