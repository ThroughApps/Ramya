//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { useState } from "react";
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import SlidingPane from "react-sliding-pane";
import Viewer from 'react-viewer';
//import Lightbox from "react-images-zoom";
import CryptoJS from 'crypto-js';

import * as BsIcons from 'react-icons/bs';
import * as FaIcons from 'react-icons/fa';
import * as FiIcons from 'react-icons/fi';
import * as AiIcons from 'react-icons/ai';
import * as MdIcons from 'react-icons/md';
import ReactTooltip from 'react-tooltip';
import { initDB, IndexedDB, AccessDB, useIndexedDB } from 'react-indexed-db';
import { PDFViewer } from 'react-view-pdf';

import "react-sliding-pane/dist/react-sliding-pane.css";
// import statement for react class component
//import { SavedImageIcons } from '../../Assets Components/Icon Components/Icons';
//import EditImage from '../../Franchise Components/Choose Your Image/EditImage';
//import PreviewImage from '../../Franchise Components/Saved Image/PreviewImage';
// import statement for react component css
import '../../Franchise Components/Saved Image/SavedImageCss.css';
import EditImage from "../ChooseYour Image/EditImage";
import { AddDataToTable, CheckDataInTable, ClearTable, GetLocalStorageData } from "../../Common Components/CommonComponents";
import { DBConfig } from "../../Common Components/CommonComponents";


//const { add } = useIndexedDB('AddToCart');

var tableName = "AddToCart";

class SavedImage extends React.Component {
    constructor() {
        super();
        this.state = {
            uploadedLogoImage: "",
            uploadedQrCodeImage: "",
            isImageEditPaneOpen: false,
            isImagePreviewPaneOpen: false,
            OpenLightbox: false,
            visible: false,
            // setVisible: false,
            closeLightbox: '',
            imageUrl: "",
            imageArray: [],
            uploadId: "",
            pdf: 'amoeba.pdf',
        }
        this.EditImage = this.EditImage.bind(this);
        this.PreviewImage = this.PreviewImage.bind(this);
        this.CloseImageEdit = this.CloseImageEdit.bind(this);
        this.RenderImages = this.RenderImages.bind(this);
    }
    componentDidMount() {

        this.GetSavedImageData();



    }

    GetSavedImageData() {

        var self = this;


        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("CompanyId"),
                menuId: "Saved Images",
            }),

            url: "http://15.206.129.105:8080/IceilAPI/MediaData/SavedImageMediaDisplayData",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("CHOOSE YOUR IMAGE MediaDisplayData DATA :", data);

                self.RenderImages(data.mediaDataList);

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });


    }

    /*
    FUNCTION USED TO RENDER THE IMAGES AFTER THE CHNAGES LIKE EDIT, DELETE
    IMPLEMENTED BY PRIYANKA - 03-05-2022
    */
    RenderImages(mediaDataList) {

        var self = this;

        self.state.imageArray = [];
        self.setState({
            imageArray: self.state.imageArray,
        })

        if (mediaDataList.length > 0) {

            /*
                        self.state.totalItemsCount = data.dataCount;
                        self.setState({
                            totalItemsCount: self.state.totalItemsCount
                        });
            */
            $.each(mediaDataList, function (i, item) {
                // use a data url as an image source - ADDING WATERMARK TO THE IMAGE
                watermark([item.data])
                    .dataUrl(watermark.text.lowerRight('Iceil', '30px serif', '#fff', 0.5))
                    .then(function (url) {
                        //document.querySelector('img').src = url;
                        console.log("IMAGE GALLERY WATER MARK URL :", url);

                        var imageData = {
                            image: url,
                            id: item.uploadId
                        };

                        //  self.state.imageArray.push(url);
                        self.state.imageArray.push(imageData);
                        
                        self.setState({
                            imageArray: self.state.imageArray,
                        })
                        console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray);

                    })

            })
        }

    }

    /*USED TO OPEN THE SLIDEPANE IMAGE EDIT */
    EditImage(image, id) {
        // alert("dit image page");
        var self = this;
        self.state.isImageEditPaneOpen = true;
        self.state.editImage = image;
        self.state.uploadId = id;

        self.setState({
            isImageEditPaneOpen: self.state.isImageEditPaneOpen,
            editImage: self.state.editImage,
            uploadId: self.state.uploadId,
        })
    }
    /*USED TO CLOSE THE SLIDEPANE IMAGE EDIT */
    CloseImageEdit() {
        this.state.isImageEditPaneOpen = false;
        this.setState({
            isImageEditPaneOpen: this.state.isImageEditPaneOpen,
        })
    }

    AddtoCart(image, id) {

        var dbData = CheckDataInTable(tableName, id, image);

        dbData.then(function (response) {

            console.log("AddtoCart response :", response);

            if (response == undefined) {
                AddDataToTable(tableName, id, image);
            } else {
                Swal.fire({
                    position: 'center',
                    icon: 'warning',
                    text: 'Image is already available in cart',
                    showConfirmButton: false,
                    timer: 2000
                })
            }

        })


    }

    DownloadImage(image, id) {
        FileSaver.saveAs(image);
    }
    PreviewImage(image, id) {
        //  alert("previewImage page");
    }
    /*USED TO OPEN THE SLIDEPANE IMAGE PREVIEW */
    PreviewImage() {
        console.log("preview page is this");
        var self = this;
        self.state.visible = true;
        self.state.isImagePreviewPaneOpen = true;
        self.setState({
            isImagePreviewPaneOpen: self.state.isImagePreviewPaneOpen,
            visible: self.state.visible,
        })
    }
    /*USED TO CLOSE THE SLIDEPANE IMAGE VIEW */
    CloseImagePreview() {
        var self = this;
        this.state.isImagePreviewPaneOpen = false;
        this.setState({
            isImagePreviewPaneOpen: this.state.isImagePreviewPaneOpen,
        })
    }
    closeLightbox() {
        var self = this;
        self.state.OpenLightbox = false;
        self.setState({
            OpenLightbox: self.state.OpenLightbox,
        })
    }
    setVisible(flag) {
        this.state.visible = flag;
        this.setState({
            visible: flag,
        })
    }

    /*
FUNCTION USED TO GETTING CONFIRMATION FOR DELETING THE SAVED IMAGES DATA 
- IMPLEMENETED BY PRIYANKA - 30-04-2022
*/
    DeleteImage(image, id) {

        var self = this;

        Swal.fire({
            title: 'Do you want to delete the image ?',
            showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: 'Yes Delete It !',
            denyButtonText: `No Don't Delete It !`,
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                self.DeleteConfirm(image, id);
            } else if (result.isDenied) {
                Swal.fire('Image not deleted', '', 'info')
            }
        })

    }

    /*
  FUNCTION USED FOR DELETING THE SAVED IMAGES DATA AFTER GETTING THE CONFIRMATION
  - IMPLEMENETED BY PRIYANKA - 03-05-2022
  */
    DeleteConfirm(image, id) {

        var self = this;

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("CompanyId"),
                menuId: 'Saved Images',
                uploadId: id,
            }),

            url: "http://15.206.129.105:8080/IceilAPI/MediaData/DeleteMediaDisplayData",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("CHOOSE YOUR IMAGE MediaDisplayData DATA :", data);

                if (data.response == "Success") {
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        text: 'Deleted the image successfully',
                        showConfirmButton: false,
                        timer: 2000
                    })
                } else if (data.response == "Fail") {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Failed to delete the image, kindly try after sometime',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }

                self.RenderImages(data.mediaDataList);


            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });

    }

    /*
    FUNCTION USED FOR ADDING ALL THE SAVED IMAGES INTO THE CART
    IMPLEMENTED BY PRIYANKA - 04-05-2022
    */
    Add_All_To_Cart() {

        ClearTable(tableName);

        if (this.state.imageArray.length > 0) {
            $.each(this.state.imageArray, function (i, item) {
                AddDataToTable(tableName, item.id, item.image);
            })
        } else {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'No items available',
                showConfirmButton: false,
                timer: 2000
            })
        }
    }

    /*
SAMPLE FOR GETTING DATA FROM INDEXED DB
WILL BE USED IN QUOTATION MODULE
IMPLEMENTED BY PRIYANKA - 04-05-2022
    */
    GetCartDBData() {
        const { getAll } = useIndexedDB('AddToCart');
        getAll().then(DBData => {
            console.log("GET INDEX DB DATA :", JSON.stringify(DBData));
        });

    }

    render() {
        // const [visible, setVisible] =  useState(0);
        return (
            <div>
                <div className="toptitle">
                    <h3>Saved Image</h3>
                   {/* <button onClick={() => this.GetCartDBData()}> Get Db Data</button> */}
                </div>
                <div className="text-right">
                    <button className="btn btn-primary btn-submit" onClick={() => this.Add_All_To_Cart()}><i class="fa fa-cart-plus" aria-hidden="true"></i> Add all to cart</button>
                </div>
                <div className="card-box mt-20">
                    {/* <h4>Image name</h4> */}
                    <div className="row">
                        {(this.state.imageArray.length > 0 ?
                            (this.state.imageArray.map((data) => (
                                data != null && data != undefined
                                    ? (
                                        <div class="col-md-3">
                                            <div className="chooseimage">
                                                <img id="image" src={data.image} />
                                                {/* <SavedImageIcons onAddtoCart={this.AddtoCart} onEditImage={this.EditImage} 
                               onPreviewImage={this.PreviewImage}
                            onDownloadImage={() => this.DownloadImage(data)} /> */}
                                                <div className="chooseimageicons">
                                                    <ul>
                                                        <li><FaIcons.FaCartPlus alt="add to cart" data-tip data-for="AddtoCart" onClick={() => this.AddtoCart(data.image, data.id)} /></li>
                                                        <li><FiIcons.FiEdit alt="edit image" data-tip data-for="EditImage" onClick={() => this.EditImage(data.image, data.id)} /></li>
                                                        <li><MdIcons.MdPreview alt="logo" data-tip data-for="DownloadImag" onClick={() => this.PreviewImage(data.image, data.id)} /></li>
                                                        {/* <li><MdIcons.MdPreview alt="logo" data-tip data-for="DownloadImag" onClick={() => this.DownloadImage(data.image, data.id)} /></li> */}
                                                        <li><AiIcons.AiFillDelete alt="delete image" data-tip data-for="DeleteImage" onClick={() => this.DeleteImage(data.image, data.id)} /></li>
                                                    </ul>
                                                    <ReactTooltip id="AddtoCart" place="top" effect="solid">Add to Cart</ReactTooltip>
                                                    <ReactTooltip id="EditImage" place="top" effect="solid">Edit Image</ReactTooltip>
                                                    <ReactTooltip id="PreviewImag" place="top" effect="solid">Preview Image</ReactTooltip>

                                                    <ReactTooltip id="DeleteImage" place="top" effect="solid">Delete Image</ReactTooltip>
                                                </div>
                                            </div>
                                        </div>)

                                    : (<div class="col-md-3">
                                        <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                                    </div>)
                            ))) : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                            </div>)

                        )}
                    </div>
                    <SlidingPane
                        className="some-custom-class"
                        overlayClassName="some-custom-overlay-class"
                        isOpen={this.state.isImageEditPaneOpen}
                        title={"Saved Image - Edit"}
                        // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                        onRequestClose={() => {
                            // triggered on "<" on left top click or on outside click
                            // setState({ isPaneOpen: false });
                            this.CloseImageEdit()
                        }}
                    >
                        <EditImage image={this.state.editImage} uploadId={this.state.uploadId}
                            module={"Saved Images"} CloseSlidingPane={this.CloseImageEdit}
                            pageCalledFrom={"Saved Images"} RenderImages={this.RenderImages} />
                    </SlidingPane>
                    <SlidingPane
                    className="some-custom-class"
                    overlayClassName="some-custom-overlay-class"
                    isOpen={this.state.isImagePreviewPaneOpen}
                    title={"Saved Image - Edit"}
                    // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                    onRequestClose={() => {
                        // triggered on "<" on left top click or on outside click
                        // setState({ isPaneOpen: false });
                        this.CloseImagePreview()
                    }}
                >
                                <div id="NIC_Img_Preview" className="NIC_Img_Preview row">
                                    
                      <ul id="viewimages">
                        <Viewer
                          visible={this.state.visible}
                          onClose={() => { this.setVisible(false); }}
                          images={this.state.imageArray}
                        /> 
                      </ul>

                    </div>
                </SlidingPane>
                </div>

                {/*  <embed src="amoeba.pdf" width="500" height="375" 
 type="application/pdf" />

<embed src="amoeba.pdf"></embed>

<PDFViewer url={this.state.pdf} />
*/}
            </div>
        );
    }
}

export default SavedImage;