import React, { Component, Suspense } from 'react';
import './Loginpagecss.css';

import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import ReactDOM from 'react-dom';
import $ from 'jquery';

import Case from "case";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';

import CryptoJS from 'crypto-js';
import * as FaIcons from 'react-icons/fa';

import AdminSideBar from '../Admin Components/SideBar/SideBar';
import FranchiseSideBar from '../Franchise Components/SideBar/SideBar';
//import FranchiseSideBar from '../Test Components/SideBar';


import { FormErrors, ErrorClass } from '../Validation Components/Loginvalidation';
import iceillogo from '../images/iceillogo.png';
import { GetLocalStorageData, LogOut, SetLocalStorageData } from '../Common Components/CommonComponents';
import loginimg from '../images/loginimg2.jpg'


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
AWS URL: 15.206.129.105
*/

/*
ICEIL AWS URL: 15.206.129.105
*/

var menuList = [];
class LoginPage extends Component {



  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      formErrors: { email: '', password: '' },
      emailValid: false,
      passwordValid: false,
      userType: "",
    }

    this.CheckLogin = this.CheckLogin.bind(this);

  }


  /*USED TO STORE USERNAME  */

  handleUserInput(e) {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({ [name]: value },
      () => { this.validateField(name, value) });
  }

  componentDidMount() {

    // this.state.interval_refresh = setInterval(() => this.CheckLogin(), 50000);

    this.state.interval_refresh = setInterval(() => this.CheckLogin(), 200000);

    
if (window.location.pathname.toLowerCase() === "/login") {
  // alert("IF");
   var url=window.location.href;

     
   var uri = window.location.toString();
   //	alert("URI - "+uri);
       if (uri.indexOf("/") > 0) {
           var clean_uri = uri.substring(0, uri.indexOf("/"));
           //alert("CLEANED SUB URL - "+clean_uri);
           //alert("DOC-TITLE :"+ document.title);
           //window.history.replaceState({}, document.title, clean_uri);
           window.history.replaceState({}, document.title, "/");
       }
  
 }


  }

  /*FUNCTION FOR VALIDATION FOR USERNAME AND PASSWORD BY NANDHINI - 02-05-2022*/
  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let emailValid = this.state.emailValid;
    let passwordValid = this.state.passwordValid;

    switch (fieldName) {

      case 'email':
        if (value.length == 0) {
          fieldValidationErrors.email = '';
          emailValid = false;
        }
        else {
          emailValid = value.match('^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})|(^[0-9]{10})+$');
          fieldValidationErrors.email = emailValid ? '' : 'Please enter valid email address or phone number';
        }
        break;
      case 'password':
        if (value.length == 0) {
          fieldValidationErrors.password = '';
          passwordValid = false;
        }
        else {
          // passwordValid = value.match('^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})|(^[0-9]{10})+$');
          passwordValid = value.match(/^((?=.*[0-9])(?=.*[A-Z])(?=.*?[#?!@$%^&*-])(?=.{8,}))/);

          fieldValidationErrors.password = passwordValid ? '' : 'Password should be a alpha numeric of minumum 6 character with atleast one uppercase & special charachter';
        }
        break;
    }

    this.setState({
      formErrors: fieldValidationErrors,
      emailValid: emailValid,
      passwordValid: passwordValid
    }, this.validateForm);
  }

  validateForm() {
    this.setState({
      formValid:
        this.state.emailValid
        && this.state.passwordValid


    });
  }

  errorClass(error) {
    return (error.length === 0 ? '' : 'has-error');
  }

  /* FUNCTION USED TO CHECK LOGIN CREDENTIALS
  - IMPLEMENTED BY PRIYANKA 27-04-2022  */
  LoginPage() {

    var self = this;
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        emailId: this.state.email,
        password: this.state.password
      }),

     // url: "http://-15.206.129.105:8080/IceilLiveAPI/ServiceLaunch/Login",
      url: "http://15.206.129.105:8080/IceilLiveAPI/ServiceLaunch/Login",
     

      
      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        console.log("LOGIN GET EXISTING MENU DATA :", data);


        if (data.response == "Login_Success") {

          /*  Swal.fire({
              position: 'center',
              icon: 'success',
              text: 'Successfull login',
              showConfirmButton: false,
              timer: 2000
            })
            */


          //SETTING UP NECESSARY DATA IN THE LOCAL STORAGE
          /*
             localStorage.setItem('CompanyId', CryptoJS.AES.encrypt(data.companyId, key));
             localStorage.setItem('UserName', CryptoJS.AES.encrypt(data.userName, key));
             localStorage.setItem('UserType', CryptoJS.AES.encrypt(data.userType, key));
             localStorage.setItem('MenuList', CryptoJS.AES.encrypt((JSON.stringify(data.menuList)), key));
   */

          //   SetLocalStorageData("isAdminLoggedIn", "false");
          //    SetLocalStorageData("isFranchiseLoggedIn", "true");

          self.state.userLoginStatus = true;

          self.setState({
            userLoginStatus: self.state.userLoginStatus
          })

          if (data.userType == "Admin") {
          //  alert("ADMIN")
            //LOGIN USER TYPE IS ADMIN HENCE DISPLAY THE ADMIN PAGES & ADMIN MENU
            ReactDOM.render(
              <BrowserRouter>
                <Routes>
                  <Route path="/*" element={<AdminSideBar />} />
                </Routes>
              </BrowserRouter>,
              document.getElementById("root")
            );

            //    SetLocalStorageData("isAdminLoggedIn", "true");


            SetLocalStorageData("EmailId", self.state.email);
            SetLocalStorageData("Password", self.state.password);
            SetLocalStorageData("CompanyId", data.companyId);
            SetLocalStorageData("UserName", data.userName);
            SetLocalStorageData("UserType", data.userType);
            SetLocalStorageData("UserId", data.userId);
            SetLocalStorageData("CompanyName", data.companyName);



          } else if (data.userType == "User_Franchise") {
            //LOGIN USER TYPE IS FRANCHISE HENCE DISPLAY THE FRANCHISE PAGES & FRANCHISE MENU
          //  alert("FRANCHISE")
            menuList = [];
            menuList = data.menuList;

            ReactDOM.render(
              <BrowserRouter>
                <Routes>
                  <Route path="/*" element={<FranchiseSideBar menuList={menuList} />} />
                </Routes>
              </BrowserRouter>,
              document.getElementById("root")
            );

            //   SetLocalStorageData("isFranchiseLoggedIn", "true");

            SetLocalStorageData("FranchiseEmailId", self.state.email);
            SetLocalStorageData("FranchisePassword", self.state.password);

            SetLocalStorageData("FranchiseCompanyId", data.companyId);
            SetLocalStorageData("FranchiseUserName", data.userName);
            SetLocalStorageData("FranchiseUserType", data.userType);
            SetLocalStorageData("MenuList", JSON.stringify(data.menuList));
            SetLocalStorageData("FranchiseId", data.franchiseId);
            SetLocalStorageData("FranchiseUserId", data.userId);
            SetLocalStorageData("AdminCompanyName", data.companyName);

            /// self.state.interval_refresh = setInterval(() => self.CheckLogin(), 5000);

          }


        } else if (data.response == "Password_Mismatch") {

          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Incorrect Password',
            showConfirmButton: false,
            timer: 2000
          })

          self.state.userLoginStatus = false;

          //  LogOut("", "Admin");

        } else if (data.response == "Not_Registered") {

          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Not Registered',
            showConfirmButton: false,
            timer: 2000
          })

          self.state.userLoginStatus = false;


        } else if (data.status == "1") {



          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Your account has been deactivated',
            showConfirmButton: false,
            timer: 2000
          })

          self.state.userLoginStatus = false;


        }


        self.state.userType = data.userType;

        self.setState({
          userType: self.state.userType,
          userLoginStatus: self.state.userLoginStatus
        })

      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });

  }

  show_Password() {
    var passwordInput = document.getElementById('password');
    var passStatus = document.getElementById('togglePassword');

    if (passwordInput.type == 'password') {
      passwordInput.type = 'text';
      passStatus.className = 'fa fa-eye eyeIcon';

    }
    else {
      passwordInput.type = 'password';
      passStatus.className = 'fa fa-eye-slash eyeIcon';
    }
  }


  CheckLogin() {

    /*  alert("CHECK LOGIN CALLED");
  
      alert("this.state.email :" + this.state.email);
      alert("this.state.password :" + this.state.password);
      alert("this.state.userLoginStatus :"+this.state.userLoginStatus);
      alert("this.state.userType :"+this.state.userType );
  */
    if (this.state.userLoginStatus == true) {
      //  alert("ADMIN CHECK");
      this.LoginPage();
    } else if (this.state.userType == "User_Franchise" && this.state.userLoginStatus == false) {
      //  alert("FRANCHISE CHECK false");
      LogOut("AddToCart", "Franchise");
    } else if (this.state.userType == "Admin" && this.state.userLoginStatus == false) {
      //  alert("ADMIN CHECK false");
      LogOut("", "Admin");
    }




  }


  render() {


    return (

      <div class=" col-md-12 bg_login">
        <div class="">
          <div class="card_header text-center">
          {/* <h3 class="header_text">Login Into Your Account</h3> */}
          </div>
{/* <div class="box"></div> */}
<div class="log_form">
<div class="row">

  <div class="col-md-6">
    <img src={loginimg} class="login_div_img"/>
  </div>
  <div class="col-md-6">
      
    
     

     <div class=" log_form_div2">
            <img class="logo_login" src={iceillogo} />
            <p class="header_text">Login Into Your Account</p>
            {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD   */}
          
            <h4 style={{ textAlign: 'left', fontSize: '16px' }}>User Name</h4>
            <input type="text" class="form-control form-group login_text" id="userEmail" name="email" placeholder='Enter Email'
              value={this.state.email} onChange={(eventuser) => this.handleUserInput(event)} ></input>
            <ErrorClass errorContent={this.state.formErrors.email} />
            <br />
            {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
            <h4 style={{ textAlign: 'left', fontSize: '16px' }}>Password</h4>
            <input  type="Password" class=" login_text form-control form-group " id="password" value={this.state.password}
              onChange={(event) => this.handleUserInput(event)} name="password" placeholder="Enter Password" />
            <i class="fa fa-eye-slash eyeIcon"  onClick={this.show_Password} aria-hidden="true" id="togglePassword"></i>
            <ErrorClass errorContent={this.state.formErrors.password} />
            <br />

            <button class="btn btn-primary login_btn" disabled={!this.state.formValid} onClick={() => this.LoginPage()} >Login</button>
            
            </div>
           
          
          </div>
          </div>
          </div>
          {/* <div class="box2"></div> */}
          {/* <div class="box1"></div> */}
        </div>
      </div>

    );
  
  }

}
export default LoginPage;


