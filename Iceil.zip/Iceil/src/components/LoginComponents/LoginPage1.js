import React, { Component, Suspense } from 'react';
import './Loginpagecss.css';

import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import ReactDOM from 'react-dom';
import $ from 'jquery';

import Case from "case";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';

import CryptoJS from 'crypto-js';
import * as FaIcons from 'react-icons/fa';

import AdminSideBar from '../Admin Components/SideBar/SideBar';
import FranchiseSideBar from '../Franchise Components/SideBar/SideBar';

import { FormErrors, ErrorClass } from '../Validation Components/Loginvalidation';
import iceillogo from '../images/iceillogo.png';
import { GetLocalStorageData, LogOut, SetLocalStorageData } from '../Common Components/CommonComponents';
import loginimg from '../images/loginimg2.jpg'

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
AWS URL: 15.206.129.105
*/
var menuList = [];
class LoginPage extends Component {



  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      formErrors: { email: '', password: '' },
      emailValid: false,
      passwordValid: false,
      userType: "",
    }


  }
  render() {


    return (

<div className='container-fluid'>
  <div className='top-menus'>
    <ul className='menus'>
      <li>image gallery projects</li>
      <li>video gallery projects</li>
      <li>Choose Your Image</li>
      <li>saved image</li>
      <li>Help</li>
      <li>FAQ</li>
      <li>About Me</li>
      <li>LogOut</li>
    </ul>
  </div>
</div>

    );
  
  }

}
export default LoginPage;


