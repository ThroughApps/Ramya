
//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { lazy, Component, Suspense } from 'react';
import $ from 'jquery';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, NavLink } from 'react-router-dom';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
import watermark from "watermarkjs";



/*
THIS PAGE IS USED TO ADD WATERMARK TO THE IMAGES DURING UPLOAD ITSELF
*/
var convertedFileSize = 0;
class ImageWaterMarkUpload extends Component {

    constructor() {
        super()


        this.state = {
            companyId: '129',
            uploadedImage: "",
            oldImage: "",

            url: "",
            oldUrl: "",

            convertedFileSize: 0,
        };
        this.fileChangedHandler = this.fileChangedHandler.bind(this);


    }


    componentDidMount() {
        window.scrollTo(0, 0);

        var self = this;

        this.GetExistingLogo();

    }

    BackbtnFunc() {
        ReactDOM.render(
            <Router>
                <Suspense fallback={<LoadingComponent />} >

                    <div>

                        <Route path="/" component={DashboardOverall} />


                    </div>
                </Suspense>
            </Router>,
            document.getElementById('contentRender'));
        registerServiceWorker();
    }

    GetExistingLogo() {

        var self = this;
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: this.state.companyId,
                requestModule: "Logo",
            }),

            //   url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/GetLogo_QRCode",
            url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/GetLogo_QRCode",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("GET EXISTING LOGO DATA :", data);

                if (data.image != undefined)
                    self.state.uploadedImage = data.image;
                self.state.oldImage = data.image;

                //  self.state.url= data.image;
                self.state.oldUrl = data.image;

                self.setState({
                    uploadedImage: self.state.uploadedImage,
                    oldImage: self.state.oldImage,

                    //   url:self.state.url,
                    oldUrl: self.state.oldUrl,
                })

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });
    }

    fileChangedHandler(event) {

        var self = this;

        var fileInput = false;
        if (event.target.files[0]) {
            fileInput = true;
        }
        if (fileInput) {

            /* try {
               Resizer.imageFileResizer(
                 event.target.files[0],
                 100,
                 100,
                 "JPEG",
                 100,
                 0,
                 (uri) => {
                   console.log("uri :",uri);
                   this.setState({ uploadedImage: uri });
                 },
                 "base64",
                 100,
                 100
               );
             } catch (err) {
               console.log(err);
             }
             */

            //  var imageWithWaterMark = watermarkImageWithText(event.target.files[0], "Priyanka");

            blobToURL(event.target.files[0]).then((url) => (self.state.uploadedFileUrl = url, self.setState({ uploadedFileUrl: url })));

            self.handleBlob(event.target.files[0]);



        }
    }

    handleBlob = (blobFile) => {

        var self = this;

        // quality value for webp and jpeg formats.
        const quality = 80;
        // output width. 0 will keep its original width and 'auto' will calculate its scale from height.
        const width = 200;
        // output height. 0 will keep its original height and 'auto' will calculate its scale from width.
        const height = "auto";
        // file format: png, jpeg, bmp, gif, webp. If null, original format will be used.
        const format = 'png';

        var reducedFileSize = 0;
        self.state.convertedFileSize = 0;

        console.log("HANDLE BLOB ************ blobFile :", blobFile);
        // note only the blobFile argument is required
        var originalImage;
        var finalImage;

        fromBlob(blobFile, quality, width, height, format).then((blob) => {
            // will output the converted blob file
            console.log("*** handleBlob blob :", blob);

            // will generate a url to the converted file
            blobToURL(blob).then((url) => (
                self.state.url = url,
                self.setState({ url: self.state.url }),

                /* getBase64(blob).then(
                 data => (console.log("BASE 64 DATA :",data),
                 self.state.url=data, 
                 self.setState({ url:self.state.url })
                  ) ), */
                console.log(" uploaded blobFile.size :", blobFile.size, " converted blob.size :", blob.size),
                reducedFileSize = getSize((Number(blobFile.size) - Number(blob.size))),
                self.state.convertedFileSize = getSize(blob.size),
                self.setState({
                    convertedFileSize: self.state.convertedFileSize
                }),
                console.log("convertedFileSize :", self.state.convertedFileSize),
                // console.log("*** handleBlob url :",url.size)

           

                // use a data url as an image source  - ADDING WATERMARK TO THE IMAGE
                watermark([self.state.url])
                    .dataUrl(watermark.text.lowerRight('ThroughApps', '30px serif', '#fff', 0.5))
                    .then(function (url) {
                        //document.querySelector('img').src = url;
                        self.state.url = url
                        self.setState({
                            url:self.state.url
                        })
                        console.log("INSIDE WATER MARK :", self.state.url)
                    })


               
            ))

        });



    };

    UploadLogo() {

        console.log("NEW IMAGE :", this.state.url);

        var self = this;

        var standardFileSize = 5120.000;

        /*
        console.log("this.state.url !=  :",this.state.url != "");
        console.log("this.state.oldUrl != this.state.url :", this.state.oldUrl != this.state.url  );
        console.log("this.state.convertedFileSize <= standardFileSize :", Number(this.state.convertedFileSize) <= Number(standardFileSize) );
     
        console.log("less greate :",this.state.url != "" && (this.state.oldUrl != this.state.url) && ( Number(this.state.convertedFileSize) <= Number(standardFileSize) ) );
     */
        if (this.state.url != "" && (this.state.oldUrl != this.state.url) && (Number(this.state.convertedFileSize) <= Number(standardFileSize))) {

            //   alert("IF");
            $.ajax({
                type: 'POST',
                data: JSON.stringify({
                    companyId: this.state.companyId,
                    image: this.state.url,
                    requestModule: "Logo",
                }),

                url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/UploadLogo_QRCode",
                //url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/UploadLogo_QRCode",

                contentType: "application/json",
                dataType: 'json',
                async: false,
                success: function (data, textStatus, jqXHR) {

                    if (data.response == "Success") {
                       /* Swal.fire({
                            position: 'center',
                            icon: 'success',
                            //  title: 'Network Connection Problem',
                            text: 'Successfully uploaded Logo',
                            showConfirmButton: false,
                            timer: 2000
                        })
                        */

                        self.state.uploadedImage = self.state.url;
                        self.state.oldUrl = self.state.url;
                        self.state.url = "";
                        self.state.convertedFileSize = 0;

                        self.setState({
                            uploadedImage: self.state.uploadedImage,
                            url: self.state.url,
                            convertedFileSize: self.state.convertedFileSize,
                            oldUrl: self.state.oldUrl,
                        })

                    } else {
                        Swal.fire({
                            position: 'center',
                            icon: 'warning',
                            //  title: 'Network Connection Problem',
                            text: 'Failed to uploaded Logo, kindly try after sometime',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }

                },
                error: function (data) {
                    Swal.fire({
                        position: 'center',
                        icon: 'error',
                        title: 'Network Connection Problem',
                        showConfirmButton: false,
                        timer: 2000
                    })


                },
            });
        } else {

            //  alert("ELSE");

            /*   console.log("this.state.url :",this.state.url);
               console.log("this.state.oldUrl != this.state.url :",this.state.oldUrl != this.state.url);
               console.log("this.state.convertedFileSize :",this.state.convertedFileSize);
               console.log("standardFileSize :",standardFileSize);
         */
            //    alert("this.state.convertedFileSize <= standardFileSize :"+this.state.convertedFileSize <= standardFileSize);

            if (this.state.uploadedImage == "") {
                Swal.fire({
                    position: 'center',
                    icon: 'warning',
                    text: 'Kindly upload image to proceed',
                    showConfirmButton: false,
                    timer: 2000
                })
            } else if (this.state.oldImage == this.state.uploadedImage) {
                Swal.fire({
                    position: 'center',
                    icon: 'warning',
                    text: 'No Changes',
                    showConfirmButton: false,
                    timer: 2000
                })
            } else if (this.state.convertedFileSize >= standardFileSize) {
                Swal.fire({
                    position: 'center',
                    icon: 'warning',
                    text: 'Kindly upload file of size within 5MB',
                    showConfirmButton: false,
                    timer: 2000
                })
            }
        }
    }

    render() {




        return (
            <div className="container">
                <div class="row text-center">
                  
                    <h4 className="header_text">Image WaterMark - UPLOAD</h4>
                    <div class="col-md-12 form_card" >
                        <div class="text-center" style={{ marginBottom: "20px" }}>
                            <div className="form-group">
                                <img id="photo" />
                                {/* <input type="file" onChange={this.fileChangedHandler} /> */}
                                <input type="file" onChange={this.fileChangedHandler} class="form-control" id="customFile" style={{ background: "#f9f9fd" }} />
                            </div>
                            <button class="btn btn-primary" type="Submit" onClick={() => this.UploadLogo()}>
                                Upload Logo
                            </button>
                        </div>



                    </div>
              
                    <div class="col-md-2 col-xs-12" ></div>
                    <div class="col-md-4 col-xs-12" >
                        <div class="card cardlogo" style={{ background: "#fff" }}>
                            <h4 style={{ textAlign: "center" }}>Uploaded Logo</h4>
                            <div class="text-center">
                                <img src={this.state.uploadedImage} alt="" style={{ padding: "20px" }} />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12" >
                        <div class="card cardlogo" style={{ background: "#fff" }}>
                            <h4 style={{ textAlign: "center" }}>Logo Preview</h4>
                            <h5 style={{ textAlign: "center" }}>{this.state.convertedFileSize + "KB"}</h5>
                            <div class="text-center">
                                <img id="logopreview" src={this.state.url} alt="" style={{ padding: "20x" }}></img>
                            </div>
                        </div>

                    </div>

                 
                </div>


            

            </div>
        );
    }
}

export default ImageWaterMarkUpload;


function getBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}


const getSize = (size) => (console.log("GET SIZE :", size), (size / 1024).toFixed(3));

function fileToDataUri(field) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.addEventListener("load", () => {
            resolve(reader.result);
        });

        reader.readAsDataURL(field);
    });
}

function dataURItoBlob(dataURI) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    var binaryVal;

    console.log("DATA URL TO BLOB :", dataURI);
    // mime extension extraction
    var inputMIME = dataURI.split(',')[0].split(':')[1].split(';')[0];

    // Extract remaining part of URL and convert it to binary value
    if (dataURI.split(',')[0].indexOf('base64') >= 0)
        binaryVal = atob(dataURI.split(',')[1]);

    // Decoding of base64 encoded string
    else
        binaryVal = unescape(dataURI.split(',')[1]);

    // Computation of new string in which hexadecimal
    // escape sequences are replaced by the character 
    // it represents

    // Store the bytes of the string to a typed array
    var blobArray = [];
    for (var index = 0; index < binaryVal.length; index++) {
        blobArray.push(binaryVal.charCodeAt(index));
    }

    return new Blob([blobArray], {
        type: inputMIME
    });
}






