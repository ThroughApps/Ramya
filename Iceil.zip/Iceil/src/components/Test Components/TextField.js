//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';

import TextField from '@mui/material/TextField';

import InputLabel from '@mui/material/InputLabel';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { theme } from '../Common Components/CommonComponents';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022



class TextFieldComponent extends Component {
    constructor() {
        super();

        this.state = {

        }


    }
    componentDidMount() {
        // Swal.fire('Any one can use a computer') 
    }



    render() {

        const defaultColor = "#ff0000";
        const hoverColor = "#0000ff";
        const focusColor = "#00ff00";

        const theme1 = createTheme({
            overrides: {
                MuiOutlinedInput: {
                    root: {
                        "&:hover $notchedOutline": {
                            borderColor: 'white'
                        },
                        "&$focused $notchedOutline": {
                            borderColor: 'white'
                        }
                    },
                    notchedOutline: {
                        borderColor: 'white'
                    },
                    input: {
                        color: "white"
                    }
                },
                MuiFormLabel: {
                    root: {
                       
                        MuiInputLabel: {
                            root: {
                                color: "#rgb(255,255,255,1) !important" 
                            }
                        }
                    },
                    asterisk: {
                        color: "#ff0000",
                        "&$error": {
                            color: "#db3131"
                        }
                    },

                },
               

            }
        });

        /*root-MuiInputLabel-root*/
        return (
            <div class="container-fluid">
                <ThemeProvider theme={theme1}>



                     <TextField fullWidth required size="small" margin="normal" variant="outlined"
                        label="Enter State" id="state" value={this.state.state} onChange={this.handleUserInputState} name="state" />

                </ThemeProvider>





            </div>


        );
    }
}
export default TextFieldComponent;
