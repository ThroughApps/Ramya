import React, { Component } from 'react';
import $ from 'jquery';
import logo from '../images/bgimage3.jpg';
import './ImageCropperCSS.css';
import ReactCrop from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

class ImageCropper extends Component {

    constructor() {
        super()


        this.state = {

            src: null,
            crop: {
                unit: '%', // Can be 'px' or '%'
                x: 25,
                y: 25,
                width: 50,
                height: 50
            },
            height: 50,
            width: 50,

        }

    }

    componentDidMount() {

        console.log("PROPS IMAGE : ", this.props);

        // this.imageRef = this.props;
        this.state.src = this.props.image;
        this.setState({
            src: this.state.src
        })

        // this.makeClientCrop(this.state.crop);
    }

    onSelectFile = (e) => {
        if (e.target.files && e.target.files.length > 0) {
            const reader = new FileReader();
            reader.addEventListener("load", () =>
                this.setState({ src: reader.result })
            );
            reader.readAsDataURL(e.target.files[0]);
        }
    };

    setCrop(c) {

        console.log("SET CROP :", c);
        /*{x: 93, y: 48, width: 51, height: 44.03125, unit: 'px'} */

        var x = c.x;
        var y = c.y;
        var width = c.width;
        var height = c.height;
        var unit = c.unit;

        this.state.height = height;
        this.state.width = width;

        this.state.crop = {
            unit: unit, // Can be 'px' or '%'
            x: x,
            y: y,
            width: width,
            height: height
        }

        this.setState({
            crop: this.state.crop,
            height: this.state.height,
            width: this.state.width,
        })
        console.log("SET CROP this.state.crop: ", this.state.crop);

    }

    onCropChange = (crop, percentCrop) => {
        // You could also use percentCrop:
        // this.setState({ crop: percentCrop });
        this.state.height = crop.height;
        this.state.width = crop.width;

        this.setState({
            crop,
            height: this.state.height,
            width: this.state.width,
        });
    };

    setCompletedCrop(c) {

        console.log("SET COMPLETED CROP :", c);

    }

    onCropComplete = (crop) => {
        console.log("ON COROP COMPLETE :", crop);

        this.makeClientCrop(crop);
    };

    onImageLoaded = (image) => {
        console.log("onImageLoaded :", image.target);
        this.imageRef = image.target;

        this.makeClientCrop(this.state.crop);
    };

    async makeClientCrop(crop) {
        console.log("this.imageRef :", this.imageRef);
        if (this.imageRef && crop.width && crop.height) {
            const croppedImageUrl = await this.getCroppedImg(
                this.imageRef,
                crop,
                "newFile.jpeg"
            );
            this.setState({ croppedImageUrl });
        }
    }

    getCroppedImg(image, crop, fileName) {
        const canvas = document.createElement("canvas");
        const pixelRatio = window.devicePixelRatio;
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        const ctx = canvas.getContext("2d");

        canvas.width = crop.width * pixelRatio * scaleX;
        canvas.height = crop.height * pixelRatio * scaleY;

        ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        ctx.imageSmoothingQuality = "high";

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width * scaleX,
            crop.height * scaleY
        );

        return new Promise((resolve, reject) => {
            canvas.toBlob(
                (blob) => {
                    if (!blob) {
                        //reject(new Error('Canvas is empty'));
                        console.error("Canvas is empty");
                        return;
                    }
                    blob.name = fileName;
                    window.URL.revokeObjectURL(this.fileUrl);
                    this.fileUrl = window.URL.createObjectURL(blob);
                    resolve(this.fileUrl);
                },
                "image/jpeg",
                1
            );
        });
    }
    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        console.log("handleUserInput NAME:", name)
        console.log("handleUserInput VALUE:", value)
        this.state[name] = value;
        this.setState({
            [name]: value
        })

        var x = this.state.crop.x;
        var y = this.state.crop.y;
        var width = this.state.crop.width;
        var height = this.state.crop.height;
        var unit = this.state.crop.unit;


        if (name == "width") {
            this.state.crop = {
                unit: this.state.crop.unit, // Can be 'px' or '%'
                x: this.state.crop.x,
                y: this.state.crop.y,
                width: value,
                height: this.state.crop.height
            }
        } else if (name == "height") {
            this.state.crop = {
                unit: this.state.crop.unit, // Can be 'px' or '%'
                x: this.state.crop.x,
                y: this.state.crop.y,
                width: this.state.crop.width,
                height: value
            }
        }

        this.setState({
            crop: this.state.crop
        })

        console.log("SET CROP this.state.crop: ", this.state.crop);

        this.makeClientCrop(this.state.crop);

    }


    render() {

        const { crop, croppedImageUrl, src } = this.state;

        return (

            <div class="container">
                <div class="col-md-12">

                    <div class="log_form">
                        <div class="card">
                            <h2 style={{ color: "red" }}>Image CROPPER</h2>
                        </div>
                    </div>
                </div>



                <div class="row">
                    <div className="col-md-6">
                        <label class="control-label">Height <span class="mandatoryfields">*</span></label>
                        <input type="text" placeholder="Height" name="height" value={this.state.height} onChange={this.handleUserInput} className="textfield" />
                    </div>
                    <div className="col-md-6">
                        <label>Width <span class="mandatoryfields">*</span></label>
                        <input type="text" className="textfield textfield_class " onChange={this.handleUserInput} name="width" placeholder="Description" value={this.state.width} />
                    </div>
                </div>

                {/*   <ReactCrop crop={this.state.crop} onChange={c => this.setCrop(c)} onComplete={(c) => this.setCompletedCrop(c)}>
                    <img id="image" src="logo192.png" />
                </ReactCrop>
*/}

                <div>
                    <input type="file" accept="image/*" onChange={this.onSelectFile} />
                </div>

                <ReactCrop crop={this.state.crop}
                    onChange={this.onCropChange}
                    onComplete={this.onCropComplete}
                //</div> onImageLoaded={this.onImageLoaded}
                >
                    <img id="image" src={this.state.src}
                        onLoad={this.onImageLoaded} />
                </ReactCrop>


                {croppedImageUrl && (
                    <img alt="Crop" style={{ maxWidth: "100%" }}
                        src={croppedImageUrl} />
                )}

            </div>

        );
    }

}
export default ImageCropper;

