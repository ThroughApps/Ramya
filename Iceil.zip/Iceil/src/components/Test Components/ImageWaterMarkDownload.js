import React, { Component } from 'react';
import $ from 'jquery';
//import { FileSaver, saveAs } from 'file-saver';
import * as FileSaver from 'file-saver';
import watermark from "watermarkjs";


/*
THIS PAGE IS USED TO SET WATER MARK TO THE IMAGES DURING RENDERING
*/

class ImageWaterMarkDownload extends Component {

    constructor() {
        super()


        this.state = {

            uploadedLogoImage: "",
            uploadedQrCodeImage: "",
            imageUrl: "",
            imageArray: [],
        }

    }

    componentDidMount() {



        this.GetLogo();
        this.GetQRCode();


        console.log("this.state.imagearray :", this.state.imageArray);
    }


    GetLogo() {

        var self = this;
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: '129',
                requestModule: "Logo",
            }),

            //   url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/GetLogo_QRCode",
            url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/GetLogo_QRCode",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("GET EXISTING LOGO DATA :", data);

                if (data.image != undefined)

                    self.state.uploadedLogoImage = data.image;

                self.setState({
                    uploadedLogoImage: self.state.uploadedLogoImage,
                })


                // use a data url as an image source - ADDING WATERMARK TO THE IMAGE
                watermark([self.state.uploadedLogoImage])
                    .dataUrl(watermark.text.lowerRight('ThroughApps', '30px serif', '#fff', 0.5))
                    .then(function (url) {
                        //document.querySelector('img').src = url;
                        self.state.uploadedLogoImage = url
                        self.setState({
                            uploadedLogoImage: self.state.uploadedLogoImage
                        })
                        self.state.imageArray.push(self.state.uploadedLogoImage);
                        self.setState({
                            imageArray: self.state.imageArray,
                        })
                        console.log("INSIDE WATER MARK LOGO IMAGE :", self.state.uploadedLogoImage);
                        console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray)
                    })




            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });
    }

    GetQRCode() {

        var self = this;
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: '129',
                requestModule: "QrCode",
            }),

            //  url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/GetLogo_QRCode",
            url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/GetLogo_QRCode",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("GET EXISTING LOGO DATA :", data);

                if (data.image != undefined)
                    self.state.uploadedQrCodeImage = data.image;

                self.setState({
                    uploadedQrCodeImage: self.state.uploadedQrCodeImage,
                })

               // use a data url as an image source - ADDING WATERMARK TO THE IMAGE
                watermark([self.state.uploadedQrCodeImage])
                    .dataUrl(watermark.text.lowerRight('ThroughApps', '30px serif', '#fff', 0.5))
                    .then(function (url) {
                        //document.querySelector('img').src = url;
                        self.state.uploadedQrCodeImage = url
                        self.setState({
                            uploadedQrCodeImage: self.state.uploadedQrCodeImage
                        })
                        self.state.imageArray.push(self.state.uploadedQrCodeImage);
                        self.setState({
                            imageArray: self.state.imageArray,
                        })
                        console.log("INSIDE WATER MARK QR CODE:", self.state.uploadedQrCodeImage);
                        console.log("INSIDE WATER MARK LOGO IMAGE - IMAGE ARRAY :", self.state.imageArray)
                    })
            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });
    }


    DownloadImage(data) {
        FileSaver.saveAs(data, "image.jpg");
    }



    render() {

        return (

            <div class="container">
                <div class="col-md-12">

                    <div class="log_form">
                        <div class="card">
                            <h2>Image Water Mark - DOWNLOAD</h2>
                        </div>
                    </div>
                </div>


                {(this.state.imageArray.length > 0 ?
                    (this.state.imageArray.map((data) => (
                        data != null && data != undefined
                            ? (<div class="col-md-3">
                                <img id="image" src={data} />
                                <button onClick={() => this.DownloadImage(data)} >Download </button>
                            </div>)

                            : (<div class="col-md-3">
                                <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                            </div>)
                    ))) : (<div class="col-md-3">
                        <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                    </div>)

                )}

            </div>

        );
    }

}
export default ImageWaterMarkDownload;

