import React, { Component } from 'react';
import $ from 'jquery';
import * as FileSaver from 'file-saver';
import './VideoUploaderViewerCSS.css';
import ReactPlayer from 'react-player';


import { Player } from 'video-react';
import 'video-react/dist/video-react.css'; // import css


/*
THIS PAGE IS USED TO SET WATER MARK TO THE IMAGES DURING RENDERING
*/

var videoURL;
class VideoUploaderViewer extends Component {

    constructor() {
        super()


        this.state = {

            companyId: '129',
            videoURL_State: [],
            videoArray: [],
        }

    }

    componentDidMount() {

    }

    handleFileChange = (event) => {
        var file = event.target.files[0];

        console.log("FILE :",file);
        // Encode the file using the FileReader API
        const reader = new FileReader();

        const url = URL.createObjectURL(file);

        this.state.videoURL = url;
        this.setState({
            videoURL: this.state.videoURL
        })

        console.log("this.state.videoURL :", this.state.videoURL);


        reader.onloadend = () => {
            // Use a regex to remove data url part
            const base64String = reader.result;
            //  .replace('data:', '')
            //   .replace(/^.+,/, '');

            //  console.log("base64String :",base64String);
            videoURL = base64String;

            /*  self.state.videoURL_State = base64String;
              self.setState({
                  videoURL_State: self.state.videoURL
              })
              */
            // Logs wL2dvYWwgbW9yZ...
            console.log("videoURL :", videoURL);
        };
        reader.readAsDataURL(file);




    };




    UploadVideo() {


        console.log("NEW IMAGE :", videoURL);

        var self = this;

        var standardFileSize = 5120.000;

        console.log("AJAX DATA :", JSON.stringify({
            companyId: this.state.companyId,
             image: videoURL,
            //image: this.state.videoURL,
            requestModule: "Logo",
            // requestModule: "QrCode",
        }));

       var sizeInBytes = (videoURL.length * (3/4)) - 2 ;
console.log("sizeInBytes :",sizeInBytes);

var sizeInMB = (sizeInBytes / (1024*1024)).toFixed(2);
console.log("sizeInMB :",sizeInMB + 'MB');

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: this.state.companyId,
                 image: videoURL,
               // image: this.state.videoURL,
                requestModule: "Logo",
                // requestModule: "QrCode",
            }),

            url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/UploadLogo_QRCode",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                if (data.response == "Success") {


                } else {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        //  title: 'Network Connection Problem',
                        text: 'Failed to uploaded Logo, kindly try after sometime',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });


    }

    FetchDownloadImage() {

        var self = this;
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: '129',
                requestModule: "Logo",
            }),

            url: "https://wildfly.garageapp.in:443/GarageAppIN_API/ImportExport/GetLogo_QRCode",
        
            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("GET EXISTING LOGO DATA :", data);


                  self.state.videoArray.push(data.image);
                  self.setState({
                      videoArray: self.state.videoArray
                  })
                  
              
                console.log("this.state.videoArray :", self.state.videoArray);

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });

    }

    render() {

        return (

            <div class="container">
                <button onClick={() => this.FetchDownloadImage()} >Fetch Download Video</button>
                <div class="col-md-12">

                    <div class="log_form">
                        <div class="card">
                            <h2>VIDEO - UPLOAD</h2>
                        </div>
                    </div>
                </div>

                <input className="VideoInput_input" type="file" onChange={this.handleFileChange} accept=".mov,.mp4" />

                <button class="btn btn-primary" type="Submit" onClick={() => this.UploadVideo()}>
                    Upload Video
                </button>




                <p>VIDEO - PREVIEW  </p>
                <ReactPlayer url={this.state.videoURL} className='react-player' playing={false}
                    controls width='320px' height='180px' />



                <div class="col-md-12">

                    <div class="log_form">
                        <div class="card">
                            <h2>VIDEO - DOWNLOAD</h2>
                        </div>
                    </div>
                </div>


                {/*   <Player>
                    <source src="https://media.w3.org/2010/05/sintel/trailer_hd.mp4" />
                </Player>
                */}

                {/*  <p>HTML - 5</p>


                <div class="row">
                    {(this.state.videoArray.length > 0 ?
                        (this.state.videoArray.map((data) => (
                            data != null && data != undefined
                                ? (<div class="col-md-4">
                                    <video controls>
                                        <source type="video/webm" src={data} />
                                    </video>
                                </div>)

                                : (<div class="col-md-3">
                                    <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                                </div>)
                        ))) : (<div class="col-md-3">
                            <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                        </div>)

                    )}


                </div>





                <div class="row">
                    {(this.state.videoArray.length > 0 ?
                        (this.state.videoArray.map((data) => (
                            data != null && data != undefined
                                ? (<div class="col-md-4">
                                    <Player>
                                        <source src={data} />
                                    </Player>
                                </div>)

                                : (<div class="col-md-3">
                                    <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                                </div>)
                        ))) : (<div class="col-md-3">
                            <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                        </div>)

                    )}


                </div>



                <h2>REACT-PLAYER</h2> */}

                <div class="row">
                    {(this.state.videoArray.length > 0 ?
                        (this.state.videoArray.map((data) => (
                            data != null && data != undefined
                                ? (<div class="col-md-4" style={{ marginTop: '20px' }}>
                                    {/* <video className="VideoInput_video" width="100%" height={300} controls src={data} /> */}
                                    <ReactPlayer
                                        url={data}
                                        className='react-player'
                                        playing={false}
                                        controls
                                        width='320px'
                                        height='180px'
                                    />
                                </div>)

                                : (<div class="col-md-3">
                                    <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                                </div>)
                        ))) : (<div class="col-md-3">
                            <p style={{ textAlign: "center", marginTop: "16px", fontWeight: "900" }} >No Data</p>
                        </div>)

                    )}


                </div>








            </div>

        );
    }

}
export default VideoUploaderViewer;

const blobToBase64 = blob => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    return new Promise(resolve => {
        reader.onloadend = () => {
            resolve(reader.result);
        };
    });
};