import React from 'react';

// CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022 


export const ErrorClass =({errorContent}) =>
  {  
   //console.log(errorContent.length);
    
    if(errorContent.length>0){ 
        return ( <p style={{color:"red",fontSize: '13px',fontWeight: "400",textAlign:'left'} } >{errorContent}</p>);

      } 
      else if(errorContent.length==0){
        return '';
  }
}

export const FormErrors = ({formErrors}) =>
  <div className='formErrors'>
    {Object.keys(formErrors).map((fieldName, i) => {
      if(formErrors[fieldName].length > 0){
        return (
          <p style={{color:"red",fontSize: '13px',fontWeight: "400"} } key={i}>{fieldName} {formErrors[fieldName]}</p>
        )        
      } else {
        return '';
      }
    })}
  </div>
