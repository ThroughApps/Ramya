 // CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022 

 
 /* eslint-disable */ 
import React from 'react';

 /*FORMERROR FOR LOGIN VALIDATION  IMPLEMENTED BY NANDHINI */
 export const FormErrors = ({formErrors}) =>
 <div className='formErrors'>
   {Object.keys(formErrors).map((fieldName, i) => {
     if(formErrors[fieldName].length > 0){
       return (
         <p style={{color:"#000",fontSize: '13px',fontWeight: "400",marginTop:'-12px'} } key={i}>{} {formErrors[fieldName]}</p>
       )        
     } else {
       return '';
     }
   })}
 </div>

export const LengthCheckFunc =function (textValue,targetLengthValue)
{
  var lengthValidationStatus=false;

  if(textValue<=targetLengthValue)
  {
    console.log("inside LengthCheckFunc");
    lengthValidationStatus=true; 
  }

return lengthValidationStatus;
}

export const NumericPatternCheckFunc =function (textValue) //specly for rate,amount with decimal points
{
  var patternValidationStatus=false; 
  ///^\d+(\.\d{1,2})?$/
  //(/^[0-9]+$/)  @"([/^.\d]+|[\d+\.]{2,}/)"
   //^[0-9]\d{0,9}(\.\d{1,3})?%?$
 //^[1-9]\d*(\.\d+)?$
 //^[-+]?[0-9]+\.[0-9]+$/
  if(textValue.match(/[0-9]\d*(\.\d+)?$/) )
  {
    console.log("inside NumericPatternCheckFunc ");
    patternValidationStatus=true; 
  }

return patternValidationStatus;
}

export const PatternCheckFunc=function (textValue) //name related
{
  var patternValidationStatus=false;
//^[A-Za-z_-][A-Za-z0-9_-]*$
//
  if(textValue.match(/^[a-zA-Z]([a-zA-Z0-9]|[- @\.#&!])*$/) ) 
  {
    console.log("inside PatternCheckFunc");
    patternValidationStatus=true; 
  }

return patternValidationStatus;
}

export const AlphaNumericPatternCheckFunc=function (textValue) // hsn code,product code
{
  var patternValidationStatus=false;
  ///^[a-z\d\-_\s]+$/i
  ///^[a-zA-Z0-9]+$/ 
  if(textValue.match(/^[a-z\d\-_\s]+$/i) )
  {
    console.log("inside AlphaNumericPatternCheckFunc");
    patternValidationStatus=true; 
  }

return patternValidationStatus;
}

export const PercentageRangeCheckFunc =function (textValue) //percentage -number with two decimal values
{
  var ValidationStatus=false;
 
  if(textValue.match(/^[0-9]\d{0,9}(\.\d{1,2})?%?$/) )
  {
    console.log("inside PercentageRangeCheckFunc");
    ValidationStatus=true; 
  }

return ValidationStatus;
}


export const Truncate_2DecimalPlaces = function(number) //rnd up with 2 digits after decimal
{
  //console.log("numberrate",number);
  var truncatedNumber=(parseInt( number * 100 ) / 100 ).toFixed(2) ;
  //console.log("truncatedNumber",truncatedNumber);
  return truncatedNumber;
  }

  export const Truncate_1DecimalPlaces = function(number) //rnd up with 2 digits after decimal
{
 // console.log("numberrate",number);
  var truncatedNumber=(parseInt( number * 100 ) / 100 ).toFixed(1) ;
  //console.log("truncatedNumber",truncatedNumber);
  return truncatedNumber;
  }

  export const InfoList=function(list) {
    console.log(list);
    var str = '',j=1;
              for(var i = 0; i < data.alreadyExistProductCode.length; i++,j++) {

                str += '('+j+')'+ data.alreadyExistProductCode[i] + ", ";
                console.log(str);
               
              }
            Swal.fire({
              position: 'center',
              icon: 'info',
              title: 'Few Products are Already Exist',
              text:str,
              showConfirmButton: true,
              timer: 2000
            })
    // <Popup trigger={<button> Trigger</button>} position="right center">
    //    <div>Popup content here !!</div>
    // </Popup>
  }


  export const CheckNumberFormat_WithoutDecimal = function(charCode,number) {

    var validationData=false;
    
    /*
    var numberFormatValidation=/^[0-9]+$/;
    var specialCharValidation="!@#$%^&*()+=-[]\\\';,./{}|\":<>?";

    //console.log("number.match(specialCharValidation) :",number.match(specialCharValidation));
    //console.log("!number.match(specialCharValidation) :",!number.match(specialCharValidation));

    if(number!=""){
        if(number.match(numberFormatValidation)  && !number.match(specialCharValidation) ){
            validationData=true;
        }
    }else{
        validationData=true;
    }
    */

 //   alert("charCode :"+charCode);

        if(number!=""){
           // alert("NOT EMPTY");
        
           if(!( ((charCode >= 65) && (charCode<= 90)) || 
           ((charCode >= 97) && (charCode <= 122)) || ((charCode >= 48) && (charCode <= 57)) )){
           // alert("inside if");
            validationData=false;
           }else{
          //  alert("inside if else");
            validationData=true;
           }
                   

        }else{
            
           
            if(charCode == 46 || charCode == 8  || charCode == 45){
               // alert("NUMBER EMPTY :"+false);
                 validationData=false;
             }else{
                // alert("NUMBER EMPTY :"+true);
                 validationData=true;
             }
             
            
            
        }
        
    return validationData;
}
