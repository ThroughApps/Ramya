//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { lazy, Component, Suspense } from 'react';
import $ from 'jquery';
import SelectSearch from 'react-select';
import _ from 'underscore';
import DropdownTreeSelect from 'react-dropdown-tree-select';
import isEqual from 'lodash/isEqual';
import './DropdownComponentCss.css'
import CryptoJS from 'crypto-js';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*CLASS NAME,STRUCTURES,UI FUNCTIONS AND DID MOUNT DONE BY
 UI TEAM*-FUNCTIONLITIES IMPLEMENTED BY DURGA 25-05-2022 */

const site_dropstyle = {
    width: " 250px",
    padding: "10px 0px"
}

const customStyles_Dropdown = {
    control: (base, state) => ({
      ...base,
      background: "transparent",
     // color:'black',
      
    //   borderRadius: state.isFocused ? "3px 3px 0 0" : 3,
    //   borderColor: state.isFocused ? "yellow" : "green",
      boxShadow: state.isFocused ? null : null,
    //   "&:hover": {
    //     borderColor: state.isFocused ? "red" : "blue"
    //   }
    }),
    menu: (base) => ({
      ...base,
      borderRadius: 0,
      marginTop: 0
    }),
    menuList: (base) => ({
      ...base,
      padding: 0
    })
  };

export class FranchiseQuotationStatusDropDown extends React.Component {

    constructor(props) {
        super()

        this.state = {
            Cancel: '',
            statusOptions: [],

        }

    }
    componentDidMount() {
        //console.log("testtt", this.props.quotationList);
        var self = this;
        var statusOptions = [];
        statusOptions.push({ label: "Submitted", value: 0 })
        statusOptions.push({ label: "Cancelled", value: 1 })
        statusOptions.push({ label: "Inprogress", value: 2 })
        statusOptions.push({ label: "Completed", value: 3 })
        statusOptions.push({ label: "Edited", value: 5 })
        self.state.statusOptions = statusOptions;
        self.setState({
            statusOptions: statusOptions,
        })

    }

    /*QUOTATION STATUS BASED FILTER SEARCH USED IN  QUOTATIONLIST.JS PAGE-IMPLEMENTED BY DURGA 05-05-2022 */
    handleStatus = (e) => {
        var self = this;
        var self = this;
        this.state.selectedStatus = e;

        this.setState({ selectedStatus: this.state.selectedStatus })
        var statusData = [];

        var dataList = this.props.quotationList;
        var statusData = [];
        var currentData;

        if (e !== null && e.length > 0) {

            $.each(e, function (i, item) {

                //console.log("item.value", item.value, dataList[i].status);
                currentData = _.where(dataList, { status: (item.value).toString() });
                //console.log(" **** currentData **** :", currentData);
                statusData = [...statusData, ...currentData];
            })
            //console.log(" **** HANDLE STATUS :", statusData);

            // if (statusData.length > 0) {
            self.props.PopulateQuotationData(statusData);
            //}
        }
        else {

            self.props.PopulateQuotationData(self.props.quotationList);
        }


    }

    render() {
        return (
            <div className="site_dropstyle">
                <label htmlFor="username">Status</label>

                <SelectSearch style={customStyles_Dropdown} options={this.state.statusOptions} value={this.state.selectedStatus}
                    isMulti={true}
                    onChange={(e) => this.handleStatus(e)} name="status" placeholder="Select Status" />


            </div>
        );
    }
}

export class FranchiseDropDown extends React.Component {

    constructor(props) {
        super()
        window.FranchiseDropDownComponent = this;
        this.state = {
            options: [],


        }
        this.ResetStatus = this.ResetStatus.bind(this);
        this.SetFranchiseList = this.SetFranchiseList.bind(this);
    }
    componentDidMount() {
        //console.log("franchiseList", this.props.franchiseList);
    }
    SetFranchiseList(tempFranchiseList) {
        var self = this;
        var franchiseList = [];
        $.each(tempFranchiseList, function (i, item) {
            franchiseList.push({ label: item.franchiseName, value: item.franchiseId });
        });

        self.state.options = franchiseList;
        self.setState({ options: self.state.options })
        //console.log("franchiseList", this.props.franchiseList);
    }
    /*RESET FRABCHISE-IMPLEMENTED BY DURGA 24-05-2022 */
    ResetStatus() {
        var self = this;
        self.state.selectedFranchise = "";
        self.setState({ selectedFranchise: self.state.selectedFranchise })
    }
    /*FRANCHISE NAME BASED FILTER SEARCH USED IN QUOTATION.JS -IMPLEMENTED BY DURGA 08-05-2022 */
    franchiseList(e) {
        var self = this;
        //console.log("e", e, e.length, self.state.Status);

        this.state.selectedFranchise = e;
        self.props.FranchiseOnChange(e);

        this.setState({ selectedFranchise: this.state.selectedFranchise })

        var dataList = this.props.quotationList;
        var statusData = [];
        var tempstatusData = [];
        var currentData;

        if (e !== null && e.length > 0) {

            //FRANCHISE NAME BASED FILTER SEARCH//

            $.each(e, function (i, item) {


                // currentData = _.where(dataList, { franchiseId: (item.value).toString() });
                //  //console.log("item.value", item.value, dataList[i].franchiseName);
                currentData = _.where(dataList, { franchiseId: (item.value).toString() });

                //console.log(" **** currentData **** :", currentData);
                statusData = [...statusData, ...currentData];
            })
            //console.log(" **** statusData **** :", statusData);

            //IF STATUS IS NOT EMPTY DO FILTER ON THE RESULT OF [FRANCHISE NAME BASED FILTER SEARCH]//
            if (self.props.Status !== "" && self.props.Status.length !== 0) {

                $.each(self.props.Status, function (i, item) {

                    ////console.log("item.value", item.value, statusData[i].status);

                    var tempcurrentData = _.where(statusData, { status: (item.value).toString() });

                    tempstatusData = [...tempstatusData, ...tempcurrentData]
                });
                statusData = tempstatusData;

            }
            //console.log(" **** HANDLE STATUS :", statusData);
            //  if (statusData.length > 0) {
            self.props.PopulateQuotationData(statusData);
            //}
        }
        else {
            if (self.props.Status !== "" && self.props.Status.length !== 0) {
                $.each(self.props.Status, function (i, item) {

                    ////console.log("item.value", item.value, statusData[i].status);

                    var tempcurrentData = _.where(dataList, { status: (item.value).toString() });

                    tempstatusData = [...tempstatusData, ...tempcurrentData]
                });
                statusData = tempstatusData;

                self.props.PopulateQuotationData(statusData);
            }
            else {
                self.props.PopulateQuotationData(self.props.quotationList);
            }


        }
    }

    render() {
        return (
            <div className="site_dropstyle">
                <label htmlFor="username">Franchise</label>

                <SelectSearch style={customStyles_Dropdown} options={this.state.options} value={this.state.selectedFranchise}
                    isMulti={true}
                    onChange={(e) => this.franchiseList(e)} name="franchise" placeholder="Select Franchise" />

            </div>
        );
    }
}

export class StatusDropDown extends React.Component {

    constructor(props) {
        super()
        window.StatusDropDownComponent = this;
        this.state = {
            Cancel: '',
            statusOptions: [],

        }
        this.ResetStatus = this.ResetStatus.bind(this);
    }
    componentDidMount() {
        //console.log("testtt", this.props.quotationList);
        var self = this;
        var statusOptions = [];
        statusOptions.push({ label: "Submitted", value: 0 })
        statusOptions.push({ label: "Inprogress", value: 2 })
        statusOptions.push({ label: "Cancelled", value: 1 })
        statusOptions.push({ label: "Completed", value: 3 })
        statusOptions.push({ label: "Edited", value: 5 })
        self.state.statusOptions = statusOptions;
        self.setState({
            statusOptions: statusOptions,
        })

    }

    /*QUOTATION STATUS BASED FILTER SEARCH USED IN QUOTATION.JS  PAGE-IMPLEMENTED BY DURGA 05-05-2022 */
    handleStatus = (e) => {
        var self = this;

        //console.log("e", e, "self.props.FranchiseStatus", self.props.FranchiseStatus.length);


        this.state.selectedStatus = e;

        self.props.StatusOnChange(e)

        this.setState({ selectedStatus: this.state.selectedStatus })

        var dataList = this.props.quotationList;
        var statusData = [];
        var tempstatusData = [];
        var currentData;

        if (e !== null && e.length > 0) {
            //STATUS  BASED FILTER SEARCH//
            $.each(e, function (i, item) {

                // //console.log("item.value", item.value, dataList[i].status);
                currentData = _.where(dataList, { status: (item.value).toString() });
                //console.log(" **** currentData **** :", currentData);
                statusData = [...statusData, ...currentData];
            })
            //console.log(" **** statusData **** :", statusData);

            //IF FranchiseStatus IS NOT EMPTY DO FILTER ON THE RESULT OF [STATUS BASED FILTER SEARCH]//
            if (self.props.FranchiseStatus !== "" && self.props.FranchiseStatus.length != 0) {
                $.each(self.props.FranchiseStatus, function (i, item) {

                    // //console.log("item.value", item.value, statusData[i].franchiseId);

                    var tempcurrentData = _.where(statusData, { franchiseId: (item.value).toString() });

                    tempstatusData = [...tempstatusData, ...tempcurrentData]
                });
                //console.log(" ****  tempstatusData **** :", tempstatusData);
                statusData = tempstatusData;
            }

            //console.log(" **** Final statusData **** :", statusData);
            // if (statusData.length > 0) {
            self.props.PopulateQuotationData(statusData);
            //}
        }
        else {

            //IF FranchiseStatus IS NOT EMPTY DO FILTER ON THE RESULT OF [STATUS BASED FILTER SEARCH]//
            if (self.props.FranchiseStatus !== "" && self.props.FranchiseStatus.length != 0) {
                $.each(self.props.FranchiseStatus, function (i, item) {

                    // //console.log("item.value", item.value, statusData[i].franchiseId);

                    var tempcurrentData = _.where(dataList, { franchiseId: (item.value).toString() });

                    tempstatusData = [...tempstatusData, ...tempcurrentData]
                });
                //console.log(" ****  tempstatusData **** :", tempstatusData);
                statusData = tempstatusData;
                self.props.PopulateQuotationData(statusData);
            }
            else {
                self.props.PopulateQuotationData(self.props.quotationList);
            }
        }

    }
    /*RESET STATUS-IMPLEMENTED BY DURGA 24-05-2022 */
    ResetStatus() {
        var self = this;
        self.state.selectedStatus = ""; //setEmpty
        self.setState({ selectedStatus: self.state.selectedStatus })
    }
    render() {
        return (
            <div className="site_dropstyle">
                <label htmlFor="username">Status</label>

                <SelectSearch style={customStyles_Dropdown} options={this.state.statusOptions} value={this.state.selectedStatus}
                    isMulti={true}
                    onChange={(e) => this.handleStatus(e)} name="status" placeholder="Select Status" />


            </div>
        );
    }
}



export class MembershipDropdown extends React.Component {

    constructor(props) {
        super()
        window.MembershipDropdownComponent = this;

        this.state = {
            All: '',
            Cancel: '',
            options: [],

        }

    }
    componentDidMount() {

        //console.log(this.props.userData);
        var self = this;
        var options = [];
        options.push({ label: "Normal", value: "Normal" })
        options.push({ label: "Bronze", value: "Bronze" })
        options.push({ label: "Silver", value: "Silver" })
        options.push({ label: "Gold", value: "Gold" })
        options.push({ label: "Platinum", value: "Platinum" })
        self.state.options = options;
        self.setState({
            options: options,
        })

    }
    /*MEMBER SHIP STATUS BASED FILTER SEARCH USED IN USERLIST.JS PAGE-IMPLEMENTED BY DURGA 05-05-2022 */
    statusList = (e) => {
        var self = this;
        var dataList = self.props.userData;
        var statusData = [];
        var tempstatusData = [];
        self.props.MembershipStatusOnChange(e);//to set the selected status in main component[userlist.js]-used for status search filter communication
        self.state.selectedMemberShip = e;
        self.setState({ selectedMemberShip: e })
        // //console.log(" ** handleStatus e:", e);

        if (e !== null && e.length > 0) {
            //MEMBERSHIP STATUS BASED FILTER SEARCH//
            $.each(e, function (i, item) {

                ////console.log("membershipStatus", item.value, dataList[i].membershipStatus);

                var currentData = _.where(dataList, { membershipStatus: (item.value).toString() });

                // //console.log(" **** currentData **** :",i,currentData);

                statusData = [...statusData, ...currentData];

            })

            // //console.log(" ** statusData :", statusData);
            //IF Status IS NOT EMPTY DO FILTER ON THE RESULT OF [MEMBERSHIP STATUS BASED FILTER SEARCH]//
            if (self.props.Status != "") {
                $.each(self.props.Status, function (i, item) {

                    ////console.log("item.value", item.value, statusData[i].status);

                    var tempcurrentData = _.where(statusData, { status: (item.value).toString() });
                    //console.log(" **** tempcurrentData **** :", tempcurrentData);
                    tempstatusData = [...tempstatusData, ...tempcurrentData];

                });
                ////console.log(" **** tempcurrentData **** :", tempstatusData);

                statusData = tempstatusData;
            }

            // if (statusData.length > 0) {
            self.props.PopulateUserData(statusData);
            //}
        }
        else {

            //IF Status IS NOT EMPTY DO FILTER ON THE RESULT OF [MEMBERSHIP STATUS BASED FILTER SEARCH]//
            if (self.props.Status != "") {
                $.each(self.props.Status, function (i, item) {
                    var tempcurrentData = _.where(dataList, { status: (item.value).toString() });
                    //console.log(" **** tempcurrentData **** :", tempcurrentData);
                    tempstatusData = [...tempstatusData, ...tempcurrentData];
                });

                statusData = tempstatusData;
                self.props.PopulateUserData(statusData);
            }
            else {
                self.props.PopulateUserData(dataList);
            }
        }

        //}


    }

    /*RESET Status-IMPLEMENTED BY DURGA 24-05-2022 */
    ResetStatus() {
        var self = this;
        self.state.selectedMemberShip = "";
        self.setState({ selectedMemberShip: self.state.selectedMemberShip })
    }

    render() {
        return (
            <div className="site_dropstyle">
                <label htmlFor="username">Membership</label>

                <SelectSearch styles={customStyles_Dropdown} options={this.state.options} 
                value={this.state.selectedMemberShip}
                    isMulti={true} class="select_class"
                    onChange={(e) => this.statusList(e)} name="status" placeholder="Select Membership" >
                </SelectSearch>

            </div>
        );
    }
}

export class ActiveStatusDropDown extends Component {

    constructor(props) {
        super()
        window.ActiveStatusDropDownComponent = this;

        this.state = {
            All: '',
            Cancel: '',
            options: [],


        }

    }
    componentDidMount() {

        //console.log("************active*****");
        var self = this;
        var options = [];
        options.push({ label: "Active", value: 0 })
        options.push({ label: "Deactivate", value: 1 })

        self.state.options = options;
        self.setState({
            options: options,
        })
        //console.log("now addedd", this.props.userData);

    }
    /*ACTIVE / DEACTIVATED STATUS BASED FILTER SEARCH USED IN USERLIST.JS PAGE-IMPLEMENTED BY DURGA 05-05-2022 */
    statusList = (e) => {

        //console.log("e", e, e.length);

        var self = this;
        self.props.StatusOnChange(e);//to set the selected status in main component[userlist.js]-used for membership search filter communication

        this.state.selectedStatus = e;
        this.setState({ selectedStatus: this.state.selectedStatus })

        var dataList = this.props.userData;
        var statusData = [];
        var tempstatusData = [];
        var currentData;

        if (e !== null && e.length > 0) {

            $.each(e, function (i, item) {

                ////console.log("item.value", item.value, dataList[i].status);
                currentData = _.where(dataList, { status: (item.value).toString() });

                ////console.log(" **** currentData **** :", currentData);

                statusData = [...statusData, ...currentData];
            })
            //IF MembershipStatus IS NOT EMPTY DO FILTER ON THE RESULT OF [STATUS BASED FILTER SEARCH]//

            if (self.props.MembershipStatus != "") {
                $.each(self.props.MembershipStatus, function (i, item) {
                    ////console.log("item.value", item.value, statusData[i].membershipStatus);
                    var tempcurrentData = _.where(statusData, { membershipStatus: (item.value).toString() });

                    tempstatusData = [...tempstatusData, ...tempcurrentData]
                });
                statusData = tempstatusData;
            }
            self.props.PopulateUserData(statusData);
        }
        else {

            //IF MembershipStatus IS NOT EMPTY DO FILTER ON THE RESULT OF [STATUS BASED FILTER SEARCH]//
            if (self.props.MembershipStatus != "") {
                $.each(self.props.MembershipStatus, function (i, item) {
                    ////console.log("item.value", item.value, statusData[i].membershipStatus);
                    var tempcurrentData = _.where(dataList, { membershipStatus: (item.value).toString() });
                    tempstatusData = [...tempstatusData, ...tempcurrentData]
                });
                statusData = tempstatusData;
                self.props.PopulateUserData(statusData);
            }
            else {
                self.props.PopulateUserData(self.props.userData);
            }

        }

    }

    /*RESET Status-IMPLEMENTED BY DURGA 24-05-2022 */
    ResetStatus() {
        var self = this;
        self.state.selectedStatus = "";
        self.setState({ selectedStatus: self.state.selectedStatus })
    }

    render() {
       
        return (
            <div className="site_dropstyle">
                <label htmlFor="username">Status</label>

                <SelectSearch  styles={customStyles_Dropdown} options={this.state.options} value={this.state.selectedStatus}
                    isMulti={true} 
                    onChange={(e) => this.statusList(e)} name="status" placeholder="Select Status" >
                </SelectSearch>

            </div>
        );
    }
}


/*
USED FOR RENDERING THE TREE MENU -
USED IN - AddMenu.js
IMPLMENTED BY PRIYANKA - 19-04-2022
NOT USED NOW -- BECAUSE CHANGES ARE REQUIRED FOR THE CLEAR OPERATION
BUT THIS CODE IS A BASIC RENDERING FORMAT

export default class TreeDropdownContainer extends Component {
    constructor(props) {
        super(props)

        window.TreeDropdownContainerComponent = this;

        this.state = { data: props.data }
    }

    componentWillReceiveProps = (nextProps) => {

        //  alert("TREE");
        //console.log(" componentWillReceiveProps PROPD :", nextProps, " this.state.data :", this.state.data);
        if (!isEqual(nextProps.data, this.state.data)) {
            this.setState({ data: nextProps.data })
        }

    }

    shouldComponentUpdate = (nextProps) => {
        //console.log("shouldComponentUpdate PROPD :", nextProps, " this.state.data :", this.state.data);
        return !isEqual(nextProps.data, this.state.data)
    }


    render() {
        const { data, ...rest } = this.props

        //console.log(" RENDER uncheckAll data :", this.state.data);
        return (
            <DropdownTreeSelect data={this.state.data} {...rest} mode="radioSelect" />
        )
    }
}
*/


/*
USED FOR RENDERING THE TREE MENU -
USED IN - AddMenu.js, MenuUpload.js
IMPLMENTED BY PRIYANKA - 19-05-2022
*/
export class TreeDropdownContainer extends Component {
    constructor(props) {
        super(props)

        window.TreeDropdownContainerComponent = this;

        this.state = { data: props.data }

    }

    componentWillReceiveProps = (nextProps) => {

        //   alert("TREE");
        //console.log(" componentWillReceiveProps PROPD :", nextProps, " this.state.data :", this.state.data);
        if (!isEqual(nextProps.data, this.state.data)) {
            // //console.log("IF");
            this.setState({ data: nextProps.data })
        } else if (nextProps.operation == "refresh") {
            // //console.log("ELSE");
            this.setState({ data: nextProps.data })
        }


    }

    shouldComponentUpdate = (nextProps) => {
        //console.log("shouldComponentUpdate PROPD :", nextProps, " this.state.data :", this.state.data);
        if (nextProps.operation == "refresh") {
            //console.log("!isEqual(nextProps.data, this.state.data) :", !isEqual(nextProps.data, this.state.data));
            // return !isEqual(nextProps.data, this.state.data)
            return true
        }
    }

    render() {
        const { data, ...rest } = this.props

        console.log(" ******************** RENDER uncheckAll data :", this.state.data);
        return (
            <DropdownTreeSelect data={this.state.data} {...rest} mode="radioSelect" />
        )
    }
}

// HELP DROPDOWN -
// USED IN - help.js, 
// IMPLMENTED BY NANDHINI - 19-05-2022
export class HeplDropdown extends React.Component {

    constructor(props) {
        super()

        this.state = {
            All: '',
            Cancel: '',
            options: [],

        }

    }
    componentDidMount() {
        var self = this;
        var options = [];
        options.push({ label: "Image", value: "Image" })
        options.push({ label: "Video", value: "Video" })
        options.push({ label: "PDF", value: "PDF" })
        //   options.push({ label: "All", value: "All" })

        self.state.options = options;
        self.setState({
            options: options,
        })

    }

    DocTypeSelect = (e) => {
        const name = e.name;
        const value = e.value;

        this.state.selectedDocType = e;

        var self = this;
        this.props.DocTypeSelectChange(this.state.selectedDocType);

    }

    render() {
        return (
            <div className="site_dropstyle" style={{ marginTop: '6px', color: 'black' }}>
                <label htmlFor="username">Files</label>

                <SelectSearch style={customStyles_Dropdown} options={this.state.options} value={this.state.selectedDocType} styles={{ width: '300px' }}
                    isMulti={true}
                    onChange={(e) => this.DocTypeSelect(e)} name="status" placeholder="Select Type" >
                </SelectSearch>

            </div>
        );
    }
}

/*
DROPDOWN FOR VISITCOUNT REPORT VIDEO IMAGE PDF in Visitcount.js
*/
export class VistCountFranchiseDropDown extends React.Component {

    constructor(props) {
        super()

        window.VistCountFranchiseDropDown = this;

        this.state = {
            franchiseListOptions: [],
            selectedFranchise: [{ label: 'All', value: 'All' }],
        }

    }

    componentDidMount() {

        //  alert("dropdown");
        //console.log(" VistCountFranchiseDropDown FRANCHISE LIST: ", this.props);

        this.PopulateDropdown(this.props.franchiseList);



    }

    PopulateDropdown(franchiseList) {
        this.state.franchiseListOptions = [];

        var franchiseListOptions = [];
        $.each(franchiseList, function (i, item) {
            franchiseListOptions.push({ label: item.franchiseName, value: item.franchiseId })
        })
        franchiseListOptions.push({ label: 'All', value: 'All' })


        this.state.franchiseListOptions = franchiseListOptions;
        this.setState({
            franchiseListOptions: this.state.franchiseListOptions,
        })
    }

    handleFranchise = (e) => {
        var sites = "";

        //console.log(" e :", e);
        this.state.selectedFranchise = e;
        this.setState({
            selectedFranchise: e,
        });

        //console.log("this.state.selectedFranchise :", this.state.selectedFranchise);
        this.props.onFranchiseChnage(e.value);

    }

    render() {
        return (
            <div className="site_dropstyle">
                <label htmlFor="username">Franchise</label>
                <SelectSearch styles={customStyles_Dropdown}  options={this.state.franchiseListOptions} value={this.state.selectedFranchise}
                    isMulti={false}
                    onChange={(e) => this.handleFranchise(e)} name="WorkingSite" placeholder="Select Franchise" />

            </div>
        );
    }
}
