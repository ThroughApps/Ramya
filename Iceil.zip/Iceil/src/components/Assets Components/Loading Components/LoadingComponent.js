//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import * as FileSaver from 'file-saver';
import * as BsIcons from 'react-icons/bs';
import watermark from "watermarkjs";
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import CryptoJS from 'crypto-js';
import ReactTooltip from 'react-tooltip';
import Pagination from "react-js-pagination";
import Modal from 'react-modal';

import './LoadingComponentCSS.css';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        width: "491px",
        background: 'rgba(0,0,0,.075);',
        backgroundColor: '#26232366',
        overflow: 'none',
        width: '100%',
        height: '100%',
    }
};

class LoadingComponent extends React.Component {
    constructor() {
        super();

        window.Loading_Component = this;

        this.state = {
            active: false,
        }
        this.ModalOpenFun = this.ModalOpenFun.bind(this);
        this.ModalCloseFun = this.ModalCloseFun.bind(this);
    }

    componentDidMount() {


    }

    ModalOpenFun() {
        var self = this;

      //  alert("open");
        this.state.active = true;
        this.setState({
            active: this.state.active
        })
    }

    ModalCloseFun() {
        var self = this;

      //  alert("close");
        this.state.active = false;
        self.setState({
            active: this.state.active
        })
    }

    render() {
      //  console.log(" *** RENDER this.state.imagearray :", this.state.imageArray)
        return (
            <div>
                <Modal
                    isOpen={this.state.active}
                    //  onAfterOpen={this.customerafterOpenModal}
                    // onRequestClose={this.state.productTypecloseModal}
                    style={customStyles}
                    contentLabel="Example Modal">
                    {/* <PropagateLoader color='#36D7B7' css={override} loading={true} size={15} /> */}
                    <div class="loader"></div>
                </Modal>
            </div>
        );
    }
}

export default LoadingComponent;
