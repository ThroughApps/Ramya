//IMPORT STATEMENTS FOR REACT CLASS COMPONENT
import React, { Component } from 'react';
import Swal from 'sweetalert2/dist/sweetalert2.js';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

 /*
FUNCTION USED TO DISPLAY THE ALERT AFTER UPDATE THE STATUS- IN ADMIN QUOTATIONLIST
IMPLEMENTED BY DURGA - 21-05-2022
   */
export const StatusChangeAlert=(statusValue, quotationId) => {

    //Accepted QOT-1 successfully "// Status=2 - Accepeted //Status=1 - Cancelled  //Status=3 - Completed
    var tempStatus;
    if(statusValue=='1')
    {
        tempStatus="Cancelled";
    }
    else if(statusValue=='2')
    {
        tempStatus="Accepeted";
    }
    else if(statusValue=='3')
    {
        tempStatus="Completed";
    }
    Swal.fire({
        icon:'success',
        position: 'center',
        text: quotationId+" - "+ tempStatus+" " + "Successfully!",
        showConfirmButton: false,
        timer: 2000
      })
}
