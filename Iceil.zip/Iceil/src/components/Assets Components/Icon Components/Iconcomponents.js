import React from 'react';
import ReactTooltip from 'react-tooltip';
import "./Iconcomponentcss.css";
import active from './Images/active_icon.svg';
import deactive from './Images/deactive_icon.svg';
import viewicon from './Images/eye_icon.svg';
import editicon from './Images/edit_icon.svg';
//IMPORT REACT ICONS

import * as BsIcons from 'react-icons/bs';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as FiIcons from 'react-icons/fi';
import * as MdIcons from 'react-icons/md';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
FUNCTION USED FOR GETTING THE LIST OF ICONS
USED IN - Quotation.js - IMPLEMENTED BY RAMYA - 20-04-2022
*/
export  const  QuotationListIcons  = function (props) {
    
  return <div className="reactIcon_Btn"> 
          <ul>
          <li>
    <MdIcons.MdEditNote alt="logo"data-tip data-for="EditQuotation" onClick={props.onQuotationEdit} /> 
    </li>
          <li>
          <FaIcons.FaEye alt="logo" data-tip data-for="ViewQuotation" onClick={props.onQuotationView} /> 
          </li>
          <li>
          <MdIcons.MdCheckCircle alt="logo" data-tip data-for="AcceptQuotation" onClick={props.onQuotationAccept} />
          </li>
          <li>
            <MdIcons.MdCancel alt="logo" data-tip data-for="CancelQuotation" onClick={props.onQuotationCancel} /> 
          </li> 
          <li>
            <MdIcons.MdOutlineFactCheck alt="logo" data-tip data-for="CompleteQuotation" onClick={props.onQuotationComplete} /> 
          </li> 
          </ul>
          <ReactTooltip id="EditQuotation" place="top" effect="solid">Edit Quotation</ReactTooltip>
          <ReactTooltip id="ViewQuotation" place="top" effect="solid">View Quotation</ReactTooltip>
          <ReactTooltip id="AcceptQuotation" place="top" effect="solid">Accept Quotation</ReactTooltip>
          <ReactTooltip id="CancelQuotation" place="top" effect="solid">Cancel Quotation</ReactTooltip>
          <ReactTooltip id="CompleteQuotation" place="top" effect="solid">Complete Quotation</ReactTooltip>
          </div>
}

/*
FUNCTION USED FOR GETTING THE LIST OF ICONS
USED IN - Quotation.js - IMPLEMENTED BY RAMYA - 20-04-2022
*/
export  const  QuotationViewIcons  = function (props) {
  
  return <div className="reactIcon_Btn"> 
          <ul>
          <li>
          <FaIcons.FaEye alt="logo" data-tip data-for="QuotationView" onClick={props.onQuotationView} /> 
          </li>
          </ul>
          <ReactTooltip id="QuotationView" place="top" effect="solid">View Quotation</ReactTooltip>
          </div>
  
  }
/*
FUNCTION USED FOR GETTING THE IMAGE EDIT ICON
USED IN - QuotationComponent.js - IMPLEMENTED BY RAMYA - 20-04-2022
*/
export  const  EditImageIcon  = function (props) {
  return <a className='editimage'>
  <FiIcons.FiEdit  alt="edit image" data-tip data-for="EditImageIcon" onClick={props.onEditImage}/>
  <ReactTooltip id="EditImageIcon" place="top" effect="solid">Edit Image</ReactTooltip>
  </a>
  }
  export  const  ListIcons  = function (props) {
    
    return <div className="reactIcon_Btn">  

      <ul>
      <li>
      <FaIcons.FaUserCheck alt="logo" data-tip data-for="activetip" onClick={props.onActivate} style={{color:"green"}} /> 
      
      </li>
      <li>
      <FaIcons.FaUserTimes alt="logo" data-tip data-for="deactiveTip" onClick={props.onDeactivate} style={{color:"red"}} /> 
      </li>
    
      <li>
      <FaIcons.FaUserEdit alt="logo" data-tip data-for="editTip" onClick={props.onEditUser}  /> 
      </li>
      <li>
      <FaIcons.FaEye alt="logo" data-tip data-for="viewTip" onClick={props.onViewUser} /> 
     
      </li>
      {/* <li>
      <GrIcons.GrDocumentDownload data-tip data-for="downloadVehicleTip" onClick={props.onDownloadVehicle} /> 
      </li> */}
      

      </ul>


      {/*  LIST ICON TOOLTIP */}
        <ReactTooltip id="activetip" place="top" effect="solid">
        Active 
      </ReactTooltip>

        <ReactTooltip id="deactiveTip" place="top" effect="solid">
       Deactivate
      </ReactTooltip>

    <ReactTooltip id="viewTip" place="top" effect="solid">
   View User List
      </ReactTooltip>

    
      <ReactTooltip id="editTip" place="top" effect="solid">
      Edit User List
      </ReactTooltip>

     

          </div>

}


/*
FUNCTION USED FOR GETTING THE LIST OF ICONS
USED IN - ProductList.js - IMPLEMENTED BY RAMYA - 20-04-2022
*/
export  const  ProductListIcons  = function (props) {
  
  return <div className="reactIcon_Btn_product" style={{display:'inline-flex'}}> 
          <ul>
          <li>
          <AiIcons.AiFillEye alt="logo" data-tip data-for="viewProduct" onClick={props.onViewProduct} /> 
          </li>
           <li>
            <FaIcons.FaCloudDownloadAlt alt="logo" data-tip data-for="downloadProduct" onClick={props.onDownloadProduct} /> 
          </li>              
          </ul>           
          <ReactTooltip id="viewProduct" place="top" effect="solid">View Product</ReactTooltip>
           <ReactTooltip id="downloadProduct" place="top" effect="solid">Download Product List</ReactTooltip> 
          </div>

}

/*
FUNCTION USED FOR GETTING THE IMAGE EDIT ICON
USED IN - ProductList.js - IMPLEMENTED BY DURGA - 20-04-2022
*/
export const Product_xlDownldBtn = function ()
{
  return <div className="reactIcon_downloadbtn"> 
        <FaIcons.FaCloudDownloadAlt alt="logo" data-tip data-for="downloadProduct" /> 
        <ReactTooltip id="downloadProduct" place="top" effect="solid">Download ProductList</ReactTooltip>
      </div>
}


/*

IMPLEMENTED BY RAMYA BUT NOT USED DUE TO CODE CHNAGES DONE BY PRIYANKA

export  const  VehicleIcons  = function (props) {
    
    return <div>  

      <ul className="reactIcon_Btn" style={{marginRight:'37px',listStyle:'none',display:'flex'}}>
      <li>
      <img src={active}alt="logo" data-tip data-for="activetip" onClick={props.onViewVehicle} style={{width:'24px',color:'white',marginRight:'10px'}} /> 
      
      </li>
      <li>
      <img src={deactive}alt="logo" data-tip data-for="viewVehicleTip" onClick={props.onViewVehicle} style={{width:'24px',color:'white',marginRight:'10px'}} /> 
      </li>
      <li>
      <img src={viewicon}alt="logo" data-tip data-for="editVehicleTip" onClick={props.onViewVehicle} style={{width:'24px',color:'white',marginRight:'10px'}}/> 
     
      </li>
      <li>
      <img src={editicon}alt="logo" data-tip data-for="deleteVehicleTip" onClick={props.DeleteVehicle} style={{width:'24px',color:'white'}} /> 
      </li>
      {/* <li>
      <GrIcons.GrDocumentDownload data-tip data-for="downloadVehicleTip" onClick={props.onDownloadVehicle} /> 
      </li> ***}
      

      </ul>
   
        <ReactTooltip id="activetip" place="top" effect="solid">
        Active 
      </ReactTooltip>

        <ReactTooltip id="viewVehicleTip" place="top" effect="solid">
       Deactivate
      </ReactTooltip>

    <ReactTooltip id="editVehicleTip" place="top" effect="solid">
   View List
      </ReactTooltip>

    
      <ReactTooltip id="deleteVehicleTip" place="top" effect="solid">
        Delete Vehicle
      </ReactTooltip>

      <ReactTooltip id="downloadVehicleTip" place="top" effect="solid">
        Download Vehicle List
      </ReactTooltip>

          </div>

}

export  const  ImageGalleryIcons  = function (props) {
  
  console.log("ImageGalleryIcons PROPS :",props);

  return <a>
          <BsIcons.BsDownload alt="logo" data-tip data-for="DownloadImage" onClick={props.onDownloadImage} />          
          <ReactTooltip id="DownloadImage" place="top" effect="solid">Download Image</ReactTooltip>
            </a>
  
  }

export  const  ChooseImageIcons  = function (props) {
  return <div className="chooseimageicons"> 
  <ul>
  <li><FaIcons.FaCartPlus alt="add to cart" data-tip data-for="AddtoCart" onClick={props.onAddtoCart}  /></li>
  <li><FiIcons.FiEdit  alt="edit image" data-tip data-for="EditImage" onClick={props.onEditImage}/></li>
  <li><BsIcons.BsDownload alt="logo" data-tip data-for="DownloadImag" onClick={props.onDownloadImage} /></li>
  </ul>
  <ReactTooltip id="AddtoCart" place="top" effect="solid">Add to Cart</ReactTooltip>
  <ReactTooltip id="EditImage" place="top" effect="solid">Edit Image</ReactTooltip>
  <ReactTooltip id="DownloadImag" place="top" effect="solid">Download Image</ReactTooltip>
  </div>
  }

  export  const  SavedImageIcons  = function (props) {
    return <div className="chooseimageicons"> 
    <ul>
    <li><FaIcons.FaCartPlus alt="add to cart" data-tip data-for="saveimageAddtoCart" onClick={props.onAddtoCart}  /></li>
    <li><FiIcons.FiEdit  alt="edit image" data-tip data-for="saveimageEdit" onClick={props.onEditImage}/></li>
    <li><MdIcons.MdPreview alt="logo" data-tip data-for="saveimagePreview" onClick={props.onPreviewImage} /></li>
    <li><AiIcons.AiFillDelete alt="logo" data-tip data-for="DeleteImage" onClick={props.onDeleteImage} /></li>
    </ul>
    <ReactTooltip id="saveimageAddtoCart" place="top" effect="solid">Add to Cart</ReactTooltip>
    <ReactTooltip id="saveimageEdit" place="top" effect="solid">Edit Image</ReactTooltip>
    <ReactTooltip id="saveimagePreview" place="top" effect="solid">Preview Image</ReactTooltip>
    <ReactTooltip id="DeleteImage" place="top" effect="solid">Delete Image</ReactTooltip>
    </div>
    }
*/

