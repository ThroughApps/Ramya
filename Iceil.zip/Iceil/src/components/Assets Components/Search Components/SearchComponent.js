//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { lazy, Component, Suspense } from 'react';
import _ from 'underscore';
import $ from 'jquery';
import FilterResults from 'react-filter-search';

import { GetLocalStorageData, List_To_Tree_With_KeyNameChange_For_SearchBar } from '../../Common Components/CommonComponents';
import './SearchComponentCss.css';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*THIS PAGE WAS IMPLEMENTED BY PRIYANKA WHERE AS THE CSS ADJUSTMENTS 
WHERE MADE BY RAMYA
ON 11-05-2022
USED IN - IMAGE GALLERY, VIDEO GALLERY, CHOOSE YOUR IMAGE OF FRANCHISE MODULE
*/
export default class Search extends React.Component {
    constructor() {
        super();
        this.state = {
            data: [],
            value: '',
        }
    }


    /*
    FUNCTION THAT LOAD IMMEDIATLY AFTER THE PAGE IS LOADED
    IMPLEMENTED BY PRIYANKA - 11-05-2022
    */
    componentDidMount() {

        //  alert("SEARCH COMPONENT");
        //console.log("SEARCH COMPOENENT THIS. PROPS :", this.props);

        $("#renderData").hide();
        //CALLING THE SetSearchData FUNC TO SET THE MENU INTO THE SEARCH BOX
        this.SetSearchData(this.props.componentCalled);

    }

    /*
    FUNCTION USED TO SET DATA TO THE SERACH BOX 
    BASED ON THE PAGE OPTED FROM THE LOCAL STORAGE
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */
    SetSearchData(componentName) {

        //   alert("componentName :" + componentName);
        var self = this;
        var searchDataArray = [];
        this.state.data = [];
        this.setState({
            data: this.state.data,
        })

        var menuList = GetLocalStorageData("MenuList");
        // console.log("SEARCH COMPONENT MENU LIST :", menuList);
        var parsedMenuArray = JSON.parse(`[ ${menuList}]`);
        //console.log("SEARCH COMPONENT PARSED MENU LIST :", parsedMenuArray[0]);
        var filteredMenuList = _.where(parsedMenuArray[0], { module: componentName });
        //console.log("SEARCH COMPONENT FILTERED MENU LIST :", filteredMenuList);

        if (filteredMenuList.length > 0) {

            $.each(filteredMenuList, function (i, item) {
                var currentMenu;
                currentMenu = _.where(filteredMenuList, { parentMenuId: item.menuId });
                //DISPLAYING ONLY THE CILD NODES IN THE SEARCH BAR
                //console.log("MENU ID :", item.menuId, " currentMenu :", currentMenu)
                if (currentMenu.length == 0) {
                    searchDataArray.push(item);
                }
            })

            var menuListData = List_To_Tree_With_KeyNameChange_For_SearchBar(searchDataArray);
            menuListData = menuListData.map(v => ({ ...v, folderPath: "" }))

            this.state.data = menuListData;
            this.setState({
                data: this.state.data,
            })


            $.each(this.state.data, function (i, item) {

                var currentData = _.where(filteredMenuList, { menuId: item.key });
                var currentDataIndex = _.findLastIndex(self.state.data, { key: item.key });

               // alert("item.key :"+item.key+" currentDataIndex :" + currentDataIndex);
                var folderPath = currentData[0].menuName;
                var parentId = currentData[0].parentMenuId;

                if (parentId != null) {

                    do {

                        console.log(" *** parentId :", parentId);

                        var currentFolder = _.where(parsedMenuArray[0], { menuId: parentId });

                        console.log(" *** currentFolder :", currentFolder);

                        if (currentFolder.length > 0) {
                            folderPath = currentFolder[0].menuName + "/" + folderPath;
                            parentId = currentFolder[0].parentMenuId;
                        } else {
                            parentId = null
                        }
                        console.log(" *** folderPath:", folderPath);
                    } while (parentId != null)


                    console.log("*** SEARCH COMPONENT FOLDER PATH :", folderPath);

                    if (currentDataIndex >= 0) {
                        self.state.data[currentDataIndex].folderPath = folderPath;
                        self.setState({
                            data: self.state.data
                        })
                    }
                }


            })


            console.log("************************** serach set data :", self.state.data);
        }
    }

    /*
   FUNCTION USED TO HANDLE DATA TYPED IN THE SEARCH BAR
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */

    handleChange = event => {
        const { value } = event.target;

        this.state.value = value;
        this.setState({ value });

        if (value != "") {
            $("#renderData").show();
        } else {
            $("#renderData").hide();
        }

    };


    /*
   FUNCTION USED TO RENDER THE PAGE BASED ON THE
    DATA SELECTED (ONCLICKED) IN THE SEARCH BAR
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */
    ModuleOnClickFunc(menuId, menuName, folderPath) {

    
        if (this.props.componentCalled == "Image Gallery") {
            window.ImageGalleryComponent.SetImageGalleryData(menuId, menuName, folderPath)
        } else if (this.props.componentCalled == "Video Gallery") {
            window.VideoGalleryComponent.SetVideoGalleryData(menuId, menuName, folderPath)
        } else if (this.props.componentCalled == "Choose Your Image") {
            window.ChooseYourImageComponent.SetChooseYourImageData(menuId, menuName, folderPath)
        }

    }


    /*
   FUNCTION USED FETCH THE MENUID & MENUNAME FOR THE DATA 
   SELECTED (ONCLICKED) IN THE SEARCH BAR
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */
    SpanClick(menuId, menuName, folderPath) {
        // alert("SPAN CLICK :", menuId + " - " + menuName);

        this.ModuleOnClickFunc(menuId, menuName, folderPath);

        this.state.value = '';
        this.setState({
            value: this.state.value
        })
        $(".renderData").hide();

    }

    /*
    FUNCTION USED EMPTY THE SEARCH BAR
    IMPLEMENTED BY PRIYANKA - 11-05-2022
    */
    EmptyGlobalSearch() {
        this.state.value = "";
        this.setState({
            value: "",
        })
        $(".renderData").hide();
    }

    render() {
        const { data, value } = this.state;
        //   //console.log("DATA :",data);
        return (<div className="search_btn_div">
            {/*  <div className="search_div_cls" style={{ marginTop: "12px", background: "white" }}> */}
            {/* <span id="accessDeniedSpan" className="search_a_denied">Access Denied !!</span> */}
            <input className="search_btn" placeholder="Search Here" type="text" value={value} onChange={this.handleChange}  >

            </input>
            <FilterResults
                value={value}
                data={data}
                renderResults={
                    results => (

                        <div id="renderData" className="searchresult_cls renderData">
                            {results.map(el => (
                                // //console.log("renderResults :",results),
                                <div>
                                    <span class="mainSpan" id={el.key + " - " + el.value + " - "+ el.folderPath}
                                        /*  onClick={(e) => this.SpanClick(el.key + " - " + el.value)}> */
                                        onClick={(e) => this.SpanClick(el.key, el.value, el.folderPath)}>
                                        <span>
                                            {/* {el.key}</span> - <span>{el.value}</span> */}
                                            {el.folderPath}</span>
                                    </span>
                                </div>
                            ))}

                        </div>
                    )

                }
            />
            {/* </div> */}
        </div>
        )
    }
}


/*THIS PAGE WAS IMPLEMENTED BY PRIYANKA 
ON 27-05-2022
USED IN - HELP OF FRANCHISE MODULE
*/
export class HelpSearchComponent extends React.Component {
    constructor() { 
        super();
        window.HelpSearchComponent = this;
        this.state = {
            data: [],
            value: '',
            serachValue: "",
        }
    }


    /*
    FUNCTION THAT LOAD IMMEDIATLY AFTER THE PAGE IS LOADED
    IMPLEMENTED BY PRIYANKA - 11-05-2022
    */
    componentDidMount() {

        //  alert("HELP SEARCH COMPONENT");
        //console.log("SEARCH COMPOENENT THIS. PROPS :", this.props);

        $("#renderData").hide();
        //CALLING THE SetSearchData FUNC TO SET THE MENU INTO THE SEARCH BOX
        this.SetSearchData(this.props.helpSearchDataList);

    }

    /*
    FUNCTION USED TO SET DATA TO THE SERACH BOX 
    BASED ON THE PAGE OPTED FROM THE LOCAL STORAGE
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */
    SetSearchData(searchDataList) {

        // alert("SetSearchData ");
        var searchDataArray = [];
        this.state.data = [];
        this.setState({
            data: this.state.data,
        })

        var newArrayOfObj = searchDataList.map(({ description: key, title: value, ...rest }) => ({ key, value }));

        var menuArrayOfObj = newArrayOfObj.map(obj => obj.key == '' ? { ...obj, key: null } : obj);
        //console.log("SetSearchData menuArrayOfObj :", menuArrayOfObj);

        //  var sideBarMenuData = arrayData.map(({children,comapnyId,date, ...rest}) => ({...rest}));

        var searchData = menuArrayOfObj.map(({ key, value }) => ({ key, value }));

        this.state.data = searchData;
        this.setState({
            data: this.state.data,
        })

        console.log("**** SEARCH COMPONENT SetSearchData searchData :", searchData);

    }

    /*
   FUNCTION USED TO HANDLE DATA TYPED IN THE SEARCH BAR
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */

    handleChange = event => {
        const { value } = event.target;

        this.state.value = value;
        this.setState({ value });

        if (value != "") {
            $("#renderData").show();
        } else {
            $("#renderData").hide();
        }

    };


    /*
   FUNCTION USED TO RENDER THE PAGE BASED ON THE
    DATA SELECTED (ONCLICKED) IN THE SEARCH BAR
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */
    ModuleOnClickFunc(menuId, menuName) {

        this.props.onSearchChange(menuId, menuName);
    }


    /*
   FUNCTION USED FETCH THE MENUID & MENUNAME FOR THE DATA 
   SELECTED (ONCLICKED) IN THE SEARCH BAR
   IMPLEMENTED BY PRIYANKA - 11-05-2022
   */
    SpanClick(menuId, menuName) {
        //console.log("SPAN CLICK :", menuId + " - " + menuName);

        this.ModuleOnClickFunc(menuId, menuName);

        this.state.value = '';
        this.setState({
            value: this.state.value
        })
        $(".renderData").hide();

    }

    /*
    FUNCTION USED EMPTY THE SEARCH BAR
    IMPLEMENTED BY PRIYANKA - 11-05-2022
    */
    EmptyGlobalSearch() {
        this.state.value = "";
        this.setState({
            value: "",
        })
        $(".renderData").hide();
    }

    handleChange = (e) => {
        //console.log(" handleChange :", e);

        const name = e.target.name;
        const value = e.target.value;
        // alert("value"+e.target.value)

        this.state[name] = value;

        this.setState({ [name]: value });

        if (value == "") {

            this.props.onSearchChange("Normal", "");
        }
    }

    SearchFunc() {
        //  alert("SERACH FUNC CALLED");

        if (this.state.serachValue !== "") {
            var searchValue = this.state.serachValue.replace(/[^a-zA-Z0-9 ]/g, "");
            //console.log("***** this.state.serachValue :", searchValue);
            this.props.onSearchChange("Search", searchValue);
        } else {
            this.props.onSearchChange("Normal", searchValue);
        }

    }
    render() {
        const { data, value } = this.state;
        //   //console.log("DATA :",data);
        return (<div className="search_btn_tech">
            {/*  <div className="search_div_cls" style={{ marginTop: "12px", background: "white" }}> */}
            {/* <span id="accessDeniedSpan" className="search_a_denied">Access Denied !!</span> */}
            <input className="search_btn" placeholder="Search Here" type="text" name="serachValue"
                value={this.state.serachValue} onChange={this.handleChange}  >
                    
            </input>
            {/* <FilterResults
                value={value}
                data={data}
                renderResults={
                    results => (

                        <div id="renderData" className="searchresult_cls renderData">
                            {results.map(el => (
                                // //console.log("renderResults :",results),
                                <div>
                                    <span class="mainSpan" id={el.key + " - " + el.value}
                                        /*  onClick={(e) => this.SpanClick(el.key + " - " search_btn_div+ el.value)}> ****
                                        onClick={(e) => this.SpanClick(el.key, el.value)}>
                                        <span style={{ color: '#037bde', fontWeight: '600' }}>
                                            {/* {el.key}</span> - <span>{el.value}</span> ***
                                            {el.value}  </span>  
                                    </span>
                                </div>
                            ))}

                        </div>
                    )

                }
            /> */}
            {/* </div> */}
        </div>
        )
    }
}
