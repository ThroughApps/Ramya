import _ from 'underscore';

import watermark from "watermarkjs";
import Compressor from 'compressorjs';

/*
const S3_BUCKET = 'iceilmedia';
const REGION = 'ap-south-1';  //Asia Pacific (Mumbai) ap-south-1 //website.
const ACCESS_KEY = 'AKIA36WI4RQ3ZMCAZUVF';
const SECRET_ACCESS_KEY = '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';
*/

const S3_BUCKET = 'iceilstretchceilingsmedia';
const REGION = 'ap-south-1';  //Asia Pacific (Mumbai) ap-south-1 //website. 
const ACCESS_KEY = 'AKIAZSAN4STWXTI7GFUW';
const SECRET_ACCESS_KEY = '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';


/*
THIS FUNCTION USED TO INITIALIZE THE CONNECTION TO AWS S3 BUCKET 
IMPLEMENTED BY DURGA ON -20-06-22 [REFF FROM TICTOKS]
*/
export const Initialiaze_AWS_S3 = async () => {
    var region = REGION;
    var accessKeyId = ACCESS_KEY;
    var secretAccessKey = SECRET_ACCESS_KEY;

    return new Promise((resolve, reject) => {
        var AWS = require('aws-sdk');
        AWS.config.update(
            {
                accessKeyId: accessKeyId,
                secretAccessKey: secretAccessKey,
                region: region
            }
        );
        AWS.config.apiVersions = {
            s3: '2006-03-01',
            // other service API versions
            //s3_headers =>  { "Content-Type" => "video/mp4" }
        };

        var s3 = new AWS.S3({ apiVersion: '2006-03-01' });
        console.log("s3 :", s3);
        resolve(s3);

    });
}
/*
THIS FUNCTION USED TO UPLOAD THE FILES TO AWS S3 BUCKET 
IMPLEMENTED BY DURGA ON 20-06-22 
*/
export const UploadFileToAWS = (videoURLArray, videofilenamearray) => {
    console.log("arryas", videoURLArray, videofilenamearray);
    console.log("length-videofilenamearray", videofilenamearray.length);

    var bucketName = S3_BUCKET;
    var errcount = 0, successcount = 0;

    return new Promise((resolve, reject) => {


        Initialiaze_AWS_S3().then(function (s3) {

            for (var i = 0; i < videofilenamearray.length; i++) {
                console.log("i value", i);
                console.log("videoURLArray", videoURLArray[i]);
                console.log("videofilenamearray", videofilenamearray[i]);
                var params = {
                    Key: videofilenamearray[i],
                    ContentType: "video/mp4",  // awsfiletype,//file.type,   JSON.stringify(doc).
                    Body: videoURLArray[i], //file,  //JSON.stringify(file),
                    Bucket: bucketName,
                };

                s3.putObject(params, function (err, data) {
                    if (err) {

                        console.log("File uploaded error ", err);
                        errcount++;
                    } else {
                        console.log("File uploaded successfully ", data);
                        // resolve("Uploaded")
                        successcount++;
                    }
                });
                console.log("after single upload", i);

            }

            if (errcount > 0) {
                console.log("File uploaded error ", errcount);
                resolve("Error")
            } else {
                console.log("File uploaded successfully ", successcount);
                resolve("Uploaded")
            }
        });

    });


}
/*
THIS FUNCTION USED TO GET THE FILES FROM AWS S3 BUCKET 
IMPLEMENTED BY DURGA ON 20-06-22 
*/
export const GetFileFrom_AWS_S3 = async (videofilenamearray, s3) => {

    console.log("videofilenamearray ", videofilenamearray);
    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            let fileData = [];

            console.log("videofilenamearray.length ", videofilenamearray.length);
            for (var i = 0; i < videofilenamearray.length; i++) {
                console.log("i iteration count", i);
                s3.getObject(
                    { Bucket: S3_BUCKET, Key: videofilenamearray[i] },

                    function (error, data) {

                        if (error != null) {
                            console.log("Failed to retrieve an object: ", error);
                            resolve([]);
                            //use some count
                        } else {
                            //var data=encode(data.Body);
                            console.log("b4-data.body", data.Body);
                            fileData.push(encode(data.Body));
                            // fileData[i]=encode(data.Body);
                            console.log("fileData-i", fileData);

                            if (videofilenamearray.length == fileData.length) {
                                console.log("File download successfully ");
                                resolve(fileData);
                            }
                        }
                    }
                );
            }

            console.log("result", fileData, "fileData.length", fileData.length);
        });

    });
}
/*
THIS FUNCTION USED TO ENCODE THE STRING URL WHICH IS PRODUCE FROM AWS S3 BUCKET 
IMPLEMENTED BY DURGA ON 20-06-22 [REFF FROM TICTOKS]
*/
export function encode(data) {
    var str = data.reduce(function (a, b) { return a + String.fromCharCode(b) }, '');
    return btoa(str).replace(/.{76}(?=.)/g, '$&\n');
}


function dataURLtoFile(dataurl, filename) {

    console.log("dataurltofile", dataurl, filename);

    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);

    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }

    return new File([u8arr], filename, { type: mime });
}



export const FolderExistCheck = async (parentFolder, folderName) => {

    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            //  let fileData=[];

            console.log("CREATE FOLDER FOLDERNAME ", folderName);
            var params = {
                Prefix: parentFolder + "/" + folderName + "/", // This should create an empty object in which we can store files 
                Delimiter: '/',
                Bucket: S3_BUCKET,
            };


            /*
              s3.listObjects(params, function(err, data) {
                if (err) console.log("** err :",err, err.stack); // an error occurred
                else     console.log("*** data :",data);           // successful response
              });
              */

            /*  s3.listObjectsV2 (params, (err, data) => {
                if (err) {
                  reject (err);
                }
                resolve (data);
              });
              */

        });

    });

}


/*
THIS FUNCTION IS USED TO CREATE A FOLDER INSIDE THE DESIRED PATH
IMPLEMENTED BY PRIYANKA ON 06-07-2022
*/
export const CreateFolder = async (parentFolder, folderName) => {

    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            //  let fileData=[];

            console.log("CREATE FOLDER FOLDERNAME ", parentFolder + "/" + folderName);
            var params = {
                Key: parentFolder + "/" + folderName + "/", // This should create an empty object in which we can store files 
                Bucket: S3_BUCKET,
            };


            s3.putObject(params, function (error, data) {

                if (error) {
                    console.log("Error in posting Content [" + error + "]");
                    return false;
                } /* end if error */
                else {
                    console.log("Successfully posted Content", data);
                } /* end else error */
            })
                .on('httpUploadProgress', function (progress) {
                    // Log Progress Information
                    console.log("httpUploadProgress :", Math.round(progress.loaded / progress.total * 100) + '% done');
                });

            //  console.log("result",fileData,"fileData.length",fileData.length);   
        });

    });
}


/*
GET FILE NAME OF FILE IN THE PROVIDED PATH
IMPLEMENTED BY PRIYANKA ON 06-07-2022
*/
export const GetFileName = async (folderPath) => {

    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            //  let fileData=[];

            console.log("FOLDER PATH", folderPath);
            var params = {
                Prefix: folderPath + "/", // This should create an empty object in which we can store files 
                Delimiter: '/',
                Bucket: S3_BUCKET,
            };

            s3.listObjects(params, function (err, data) {
                if (err) resolve("Error"), console.log("** GetFileName err :", err, err.stack); // an error occurred
                else resolve(data), console.log("*** GetFileName data :", data);           // successful response
            });

        });

    });

}
/*
THIS FUNCTION IS USED TO UPOAD THE IMAGE/VIDEO/PDF INTO THE ASW S3
IMPLEMENTED BY PRIYANKA ON 06-07-2022
*/
export const UploadToAWS = (folderPath, uploadArray, metaData) => {

    console.log("folderPath :", folderPath);
    console.log("UploadToAWS uploadArray :", uploadArray);

    var bucketName = S3_BUCKET;
    var errcount = 0, successcount = 0;

    return new Promise((resolve, reject) => {


        Initialiaze_AWS_S3().then(function (s3) {

            for (var i = 0; i < uploadArray.length; i++) {
                //console.log("i value", i);
                console.log("uploadArray data", uploadArray[i].data);
                // console.log("uploadArray name", uploadArray[i].name);
                var params = {
                    Key: folderPath + "/" + parseInt(uploadArray[i].name),
                    //Key: folderPath + "/" + parseInt(uploadArray[i].name)+".jpg",
                    ContentType: uploadArray[i].fileType,  // awsfiletype,//file.type,   JSON.stringify(doc).
                    //  ContentType: "jpg",  // awsfiletype,//file.type,   JSON.stringify(doc).

                    Body: uploadArray[i].data, //file,  //JSON.stringify(file),
                    Bucket: bucketName,
                    Metadata: metaData,

                };

                s3.putObject(params, function (err, data) {
                    if (err) {

                        console.log("File uploaded error ", err);
                        errcount++;
                    } else {
                        console.log("File uploaded successfully ", data);
                        // resolve("Uploaded")
                        successcount++;
                    }
                });
                console.log("after single upload", i);

            }

            if (errcount > 0) {
                console.log("File uploaded error ", errcount);
                resolve("Error")
            } else {
                console.log("File uploaded successfully ", successcount);
                resolve("Uploaded")
            }
        });

    });


}

/*
THIS FUNCTION IS USED TO GET THE UPLOADED IMAGE/VIDEO/PDF INTO THE ASW S3
IMPLEMENTED BY PRIYANKA ON 07-07-2022
*/
export const GetImageFileFromAWS = async (fileNameArray) => {

    console.log("*** AWS S3fileNameArray ", fileNameArray);
    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            let fileData = [];

            console.log("fileNameArray.length ", fileNameArray.length);
            if (fileNameArray.length > 0) {
                for (var i = 0; i < fileNameArray.length; i++) {
                    console.log("i iteration count", i);
                    console.log("fileNameArray[i].Key :", fileNameArray[i].Key)
                    var filePath = fileNameArray[i].Key;

                    var params = { Bucket: S3_BUCKET, Key: fileNameArray[i].Key }

                    GetImageFromAWS(filePath, s3).then(function (imageData) {
                        fileData.push(imageData);
                        // fileData[i]=encode(data.Body);
                        console.log("fileData-i", fileData);
                        // resolve(imageData);
                        if (fileNameArray.length == fileData.length) {
                            console.log("File download successfully ");
                            resolve(fileData);
                        }
                        /*else {
                            resolve("");
                        }
*/
                    })

                }
            } else {
                resolve("");
            }

            console.log("result", fileData, "fileData.length", fileData.length);
        });

    });
}

export const GetImageFromAWS = async (filePath, s3) => {

    var params = { Bucket: S3_BUCKET, Key: filePath }

    return new Promise((resolve, reject) => {
        s3.getObject(params, function (error, data) {

            //  alert("fileNameArray[i].Key outside else; " + filePath);

            console.log("GetImageFileFromAWS data :", data);
            if (error != null) {
                console.log("Failed to retrieve an object: ", error);
                resolve([]);
                //use some count
            } else {
                //var data=encode(data.Body);
                // alert("fileNameArray[i].Key in else; " + filePath);
                console.log("b4-data.body", data.Body);
                var bodyData = encode(data.Body);
                var imageData = {
                    data: 'data:image/png;base64,' + bodyData,
                    filePath: filePath,
                }
                // fileData.push(imageData);
                // fileData[i]=encode(data.Body);
                //  console.log("fileData-i", fileData);
                resolve(imageData);
                /* if (fileNameArray.length == fileData.length) {
                     console.log("File download successfully ");
                     resolve(fileData);
                 }
                 */
            }
        }
        );

    })
}


/*
THIS FUNCTION IS USED TO GET THE UPLOADED VIDEO INTO THE ASW S3
IMPLEMENTED BY PRIYANKA ON 07-07-2022
*/
export const GetVideoFileFromAWS = async (fileNameArray) => {

    console.log("*** AWS S3fileNameArray ", fileNameArray);
    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            let fileData = [];

            console.log("fileNameArray.length ", fileNameArray.length);
            if (fileNameArray.length > 0) {
                for (var i = 0; i < fileNameArray.length; i++) {
                    console.log("i iteration count", i);
                    console.log("fileNameArray[i].Key :", fileNameArray[i].Key)

                    var filePath = fileNameArray[i].Key;

                    GetVideoFromAWS(filePath, s3).then(function (videoData) {
                        fileData.push(videoData);
                        // fileData[i]=encode(data.Body);
                        console.log("fileData-i", fileData);
                        // resolve(imageData);
                        if (fileNameArray.length == fileData.length) {
                            console.log("File download successfully ");
                            resolve(fileData);
                        }

                    })


                }

            } else {
                resolve("");
            }
            console.log("result", fileData, "fileData.length", fileData.length);
        });

    });
}

export const GetVideoFromAWS = async (filePath, s3) => {

    var params = { Bucket: S3_BUCKET, Key: filePath }

    //  alert("filePath :" + filePath);

    return new Promise((resolve, reject) => {
        s3.getObject(
            { Bucket: S3_BUCKET, Key: filePath },

            function (error, data) {

                console.log("GetVideoFileFromAWS data :", data);
                if (error != null) {
                    console.log("Failed to retrieve an object: ", error);
                    resolve([]);
                    //use some count
                } else {
                    //var data=encode(data.Body);
                    console.log("b4-data.body", data.Body);
                    var bodyData = encode(data.Body);
                    var videoData = {
                        data: 'data:video/mp4;base64,' + bodyData
                    }

                    resolve(videoData);
                    /* fileData.push(videoData);
                     // fileData[i]=encode(data.Body);
                     console.log("fileData-i", fileData);
 
                     if (fileNameArray.length == fileData.length) {
                         console.log("File download successfully ");
                         resolve(fileData);
                     }
                     */


                }
            }
        );

    })
}

/*
DELETE FILE IN THE PROVIDED PATH
IMPLEMENTED BY PRIYANKA ON 09-07-2022
*/
export const DeleteFile = async (folderPath) => {

    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            //  let fileData=[];

            console.log("FOLDER PATH", folderPath);
            var params = {
                Key: folderPath, // This should create an empty object in which we can store files 
                //   Delimiter: '/',
                Bucket: S3_BUCKET,
            };

            s3.deleteObject(params, function (err, data) {
                if (err) resolve("Error"), console.log("** GetFileName err :", err, err.stack); // an error occurred
                else resolve("Success"), console.log("deleted !!");           // successful response
            });

        });

    });

}


/*
COPY FILE FROM ONE FOLDER TO ANOTHER IN THE PROVIDED PATH
IMPLEMENTED BY PRIYANKA ON 09-07-2022
*/
export const AddToCart_ChooseYourImage_To_SavedImages = async (srcFolderPath, destinationFolderPath) => {

    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            //  let fileData=[];

            console.log("copyFolderPath ", srcFolderPath);
            console.log("destinationFolderPath ", destinationFolderPath);

            var params = {
                Key: destinationFolderPath, // This should create an empty object in which we can store files 
                CopySource: S3_BUCKET + "/" + srcFolderPath,
                //   Delimiter: '/',
                Bucket: S3_BUCKET,
            };

            s3.copyObject(params, function (err, data) {
                if (err) resolve("Error"), console.log("** GetFileName err :", err, err.stack); // an error occurred
                else resolve("Success"), console.log("deleted !!");           // successful response
            });

        });

    });

}


export const GetMetaDataFromAWS = async (folderPath) => {

    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            let fileData = [];


            var params = { Bucket: S3_BUCKET, Key: folderPath }

            s3.headObject(params, function (error, data) {

                console.log("GetImageFileFromAWS data :", data);
                if (error != null) {
                    console.log("Failed to retrieve an object: ", error);
                    resolve([]);
                    //use some count
                } else {
                    //var data=encode(data.Body);
                    console.log("META DATA BODY :", data);
                    /* var bodyData = encode(data.Body);
                     var videoData = {
                         data: 'data:video/mp4;base64,' + bodyData
                     }
                     fileData.push(videoData);
                     // fileData[i]=encode(data.Body);
                     console.log("fileData-i", fileData);

                     if (fileNameArray.length == fileData.length) {
                         console.log("File download successfully ");
                         resolve(fileData);
                     }
                     */
                }
            }
            );



            console.log("result", fileData, "fileData.length", fileData.length);
        });

    });
}

/*
THIS FUNCTION USED TO GET THE FILE LIST BASED ON FILENAME FROM AWS S3 BUCKET[used in Help.js]
-IMPLEMENTED BY DURGA ON 20-06-22 
*/
export const GetHelpDataList_S3 = async (filenamearray) => {

    console.log("filenamearray ", filenamearray, filenamearray.length);
    // alert("help AWS");
    return new Promise((resolve, reject) => {

        Initialiaze_AWS_S3().then(function (s3) {
            let fileData = [];

            if (filenamearray.length > 0) {
                for (var i = 0; i < filenamearray.length; i++) {
                    var filePath = filenamearray[i].filePath;
                    var params = { Bucket: S3_BUCKET, Key: filePath }
                    GetHelpData(filenamearray[i], filePath, s3).then(function (imageData) {
                       // console.log("temp-imageData", imageData);
                        fileData.push(imageData);
                        if (filenamearray.length == fileData.length) {
                            console.log("File download successfully ");
                            resolve(fileData);
                        }
                    })
                }
            } else {
                //  alert("no name");
                resolve("");
            }
        });
    });
}

export const GetHelpData = async (filenamearrayone, filePath, s3) => {
    var temp = filenamearrayone;
    console.log("temptemptemp", temp);
    var params = { Bucket: S3_BUCKET, Key: filePath }
    return new Promise((resolve, reject) => {
        s3.getObject(params, function (error, data) {
            console.log("**** HELP DATA PARAMS :",params);
            if (error != null) {
                console.log("Failed to retrieve an object: ", error);
                resolve([]);
            } else {
                var bodyData = encode(data.Body);
                temp.data = bodyData;
                console.log("final -end");
                resolve(temp);

            }
        }
        );
    })
}        
