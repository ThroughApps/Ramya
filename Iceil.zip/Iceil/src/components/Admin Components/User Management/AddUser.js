//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Toggle from 'react-toggle';
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import CreatableSelect from 'react-select/creatable';
import _ from 'underscore';
import Switch from "react-switch";

import Modal from 'react-modal';
import * as FaIcons from 'react-icons/fa';
//IMPORT REACT COMPONENT CSS
import "./UserManagementcss.css";
import "react-toggle/style.css";
import TextField from '@mui/material/TextField';

import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
//IMPORT STATEMENTS FOR REACT CLASS COMPONENT
import { ErrorClass } from '../../Validation Components/Loginvalidation';
import { FormErrors } from '../../Validation Components/Loginvalidation';
import Listpage from './UserList';
import UserList from './UserList';
import { GetLocalStorageData, TimeZoneDateTime, CapitalCaseFunc, Get_TextField_MUI_Styling, theme } from '../../Common Components/CommonComponents';
import { CreateFolder } from '../../AWS/AWSFunctionality';
import { ThemeProvider, createTheme } from '@mui/material/styles';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  }
};


const darkTheme = createTheme({
  palette: {
    mode: 'dark',
  },
});





const customStyles_Dropdown = {
  control: (base, state) => ({
    ...base,
    background: "transparent",

    //   borderRadius: state.isFocused ? "3px 3px 0 0" : 3,
    //   borderColor: state.isFocused ? "yellow" : "green",
    boxShadow: state.isFocused ? null : null,
    //   "&:hover": {
    //     borderColor: state.isFocused ? "red" : "blue"
    //   }
  }),
  menu: (base) => ({
    ...base,
    borderRadius: 0,
    marginTop: 0
  }),
  menuList: (base) => ({
    ...base,
    padding: 0
  })
};

var franchiseList = [];
class AddUser extends Component {
  constructor() {
    super();

    this.state = {
      emailId: '',
      userName: '',
      gstIn: '',
      contactNo: '',
      address: '',
      city: '',
      state: '',
      membershipStatus: 'Normal',
      date: "",
      time: "",
      isOpen: false,
      franchiseCreateStatus: 'No',
      userType: '0',   //0-franchies[default] ,1-admin//
      franchiseList: [],
      franchiseName: '',
      franchiseId: '',

      toggleEnable: false,

      formErrors: {
        userName: '',
        emailId: '',
        contactNo: '',
        gstIn: '',
        address: '',
        city: '',
        state: '',

      },
      // userType:true,
      formValid: false,
      userNameValid: false,
      emailValid: false,
      contactNoValid: false,
      gstInValid: false,
      addressValid: false,
      cityValid: false,
      stateValid: false,
      selectedFranchiseValid: false,
    }
    this.handleToggle = this.handleToggle.bind(this);
    this.setState({

      date: "",
      time: "",
      membershipStatus: this.state.membershipStatus,
    })

  }
  componentDidMount() {
    // Swal.fire('Any one can use a computer') 

    /*
       GETTING DATE & TIME FOR THE CURRENT LOGIN
       - IMPLEMENTED BY PRIYANKA - 20-05-2022
       */
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    //   //console.log("dateTimeData :", dateTimeData);

    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.setState({
      date: this.state.date,
      time: this.state.time,
    })

    this.getfranchiseList();
  }
  /*USEDTO GET THE franchiseList TO SET IN DROP DOWN WHILE TIME OF PAGE LOAD- IMPLEMENTED BY DURGA 20-04-2022*/
  getfranchiseList() {
    var self = this;
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("CompanyId"),

      }),
      url: "http://15.206.129.105:8080/IceilLiveAPI/UserManagementWebService/SelectFranchiseDetails",
      contentType: "application/json",
      dataType: 'json',
      success: function (data, textStatus, jqXHR) {
        //console.log("datat", data);
        //console.log("datat", data.franchiseList);
        if (data.franchiseList.length != null || data.franchiseList.length != undefined) {

          $.each(data.franchiseList, function (i, item) {
            // self.state.franchiseList.push({value:item.franchiseId,label:item.franchiseId+" - "+item.franchiseName});
            self.state.franchiseList.push({ value: item.franchiseId, label: item.franchiseName });
          });

          self.setState({ franchiseList: self.state.franchiseList })
        }

      },
      error: function (data, textStatus, jqXHR) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },

    });
  }

  handleUserInput = (e) => {

    //console.log(e);

    const name = e.target.name;
    const value = e.target.value;
    this.setState({ [name]: value });
  }


  handleUserInputName = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    //console.log("b4 fieldName", value);
    value = CapitalCaseFunc(value);
    //console.log("after fieldName", value);
    this.setState({ [name]: value },
      () => { this.validateField(name, value) });
  }


  /* THIS FUCNTION USED FOR SETTING EMAILID IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserEmail = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    // alert("value"+e.target.value)

    this.state[name] = value;

    this.setState({ [name]: value },
      () => { this.validateField(name, value) });

  }




  /* THIS FUCNTION USED FOR SETTING CONTACTNO IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserInputContactNo = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    // alert("value"+e.target.value)

    this.state[name] = value;

    this.setState({ [name]: value },
      () => { this.validateField(name, value) });

  }


  /* THIS FUCNTION USED FOR SETTING GSTIN NO IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserInputGstin = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    // alert("value"+e.target.value)

    this.state[name] = value;

    this.setState({ [name]: value },
      () => { this.validateField(name, value) });

  }


  /* THIS FUCNTION USED FOR SETTING ADDRESS IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserInputAddress = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    // alert("value"+e.target.value)
    value = CapitalCaseFunc(value);
    this.state[name] = value;
    this.setState({ [name]: value },
      () => { this.validateField(name, value) });
  }


  /* THIS FUCNTION USED FOR SETTING CITY IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserInputCity = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    // alert("value"+e.target.value)
    value = CapitalCaseFunc(value);
    this.state[name] = value;
    this.setState({ [name]: value },
      () => { this.validateField(name, value) });
  }


  /* THIS FUCNTION USED FOR SETTING STATE IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserInputState = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    // alert("value"+e.target.value)
    value = CapitalCaseFunc(value);
    this.state[name] = value;
    this.setState({ [name]: value },
      () => { this.validateField(name, value) });
  }


  /*FUNCTION FOR VALIDATING A INPUT FIELD IMPLEMENTED BY NANDHINI - 02-05-2022*/
  validateField(fieldName, value) {

    let fieldValidationErrors = this.state.formErrors;
    let userNameValid = this.state.userNameValid;
    let emailValid = this.state.emailValid;
    let contactNoValid = this.state.contactNoValid;
    let gstInValid = this.state.gstInValid;
    let addressValid = this.state.addressValid;
    let cityValid = this.state.cityValid;
    let stateValid = this.state.stateValid;

    //console.log("value", value, "fieldName", fieldName);

    switch (fieldName) {
      case 'userName':
        userNameValid = value.length > 0;
        fieldValidationErrors.userName = userNameValid ? '' : ' is InCorrect';
        break;
      case 'contactNo':
        contactNoValid = value.match(/^[0-9]{10}$/);
        fieldValidationErrors.contactNo = contactNoValid ? '' : ' is InCorrect';
        break;

      case 'emailId':
        emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
        fieldValidationErrors.emailId = emailValid ? '' : ' is InCorrect';
        break;
      case 'gstIn':
        // gstInValid = value.match(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9]{1}Z[0-9a-zA-Z]{1}$/);
        gstInValid = value.match(/^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$/);
        fieldValidationErrors.gstIn = gstInValid ? '' : ' Format is InCorrect';
        break;
      //EX:33AABCU9603R1ZU

      case 'address':
        if (value.length == 0) {
          fieldValidationErrors.address = '';
          addressValid = true;
        }
        //   else if(value.length<3)
        // {
        //     fieldValidationErrors.address = 'Should Contain Atleast 3 Characters';
        //     addressValid=false;
        // }
        else if (value.length > 150) {
          fieldValidationErrors.address = 'Sorry! You are Exceeding the Limit';
          addressValid = false;
        }
        else {
          addressValid = value.match();
          fieldValidationErrors.address = addressValid ? '' : ' is InCorrect';
        }
        break;

      case 'city':
        if (value.length == 0) {
          fieldValidationErrors.city = '';
          cityValid = true;
        }
        else if (value.length < 3) {
          fieldValidationErrors.city = 'Should Contain Atleast 3 Characters';
          cityValid = false;
        }
        else if (value.length > 32) {
          fieldValidationErrors.city = 'Sorry! You are Exceeding the Limit';
          cityValid = false;
        }
        else {
          cityValid = value.match();
          fieldValidationErrors.city = cityValid ? '' : ' is InCorrect';
        }
        break;

      case 'state':
        if (value.length == 0) {
          fieldValidationErrors.state = '';
          stateValid = true;
        }
        else if (value.length < 3) {
          fieldValidationErrors.state = 'Should Contain Atleast 3 Characters';
          stateValid = false;
        }
        else if (value.length > 32) {
          fieldValidationErrors.state = 'Sorry! You are Exceeding the Limit';
          stateValid = false;
        }
        else {
          stateValid = value.match();
          fieldValidationErrors.state = stateValid ? '' : ' is InCorrect';
        }
        break;
    }

    this.setState({
      userNameValid: userNameValid,
      contactNoValid: contactNoValid,
      emailValid: emailValid,
      // gstInValid: gstInValid,
      // addressValid: addressValid,
      // cityValid: cityValid,
      // stateValid: stateValid,
    }, this.validateForm);

  }

  validateForm() {
    ////console.log("this.state.selectedFranchiseValid",this.state.selectedFranchiseValid)
    this.setState({
      formValid:
        this.state.userNameValid &&
        this.state.contactNoValid
        && this.state.emailValid
        && this.state.selectedFranchiseValid
    });
  }


  errorClass(error) {
    return (error.length === 0 ? '' : 'has-error');
  }

  /* THIS FUCNTION USED FOR LEAD TO LISTPAGE IMPLEMENTED BY NANDHINI - 02-05-2022*/
  listpage() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<UserList />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    );
  }


  /*IMPLEMENTED BY NANDHINI - 10-06-2022*/
  insertGstin() {
    var self = this;
    self.state.insertGstinmodalIsOpen = true;
    self.setState({
      insertGstinmodalIsOpen: self.state.insertGstinmodalIsOpen
    })
  }
  /*IMPLEMENTED BY NANDHINI - 10-06-2022*/
  closeModalGstinNo() {
    var self = this;
    self.state.insertGstinmodalIsOpen = false;
    self.state.closeModalGstin = true;
    self.setState({
      insertGstinmodalIsOpen: self.state.insertGstinmodalIsOpen,
      closeModalGstin: self.state.closeModalGstin
    })
  }

  handleUserInputMembershipStatus = (e) => //IMPLEMENTED BY DURGA 23-04-2022
  {
    var self = this;

    self.state.membershipStatus = e.target.value;

    self.setState({
      membershipStatus: self.state.membershipStatus
    })

  }

  /*USER REGISTRATION FUNCTION-IMPLEMENTED BY DURGA 23-04-2022*/
  UserRegistrationFunc() {
    var self = this;
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        franchiseCreateStatus: this.state.franchiseCreateStatus,
        companyId: GetLocalStorageData("CompanyId"),
        emailId: this.state.emailId,
        userName: this.state.userName,
        gstIn: this.state.gstIn,
        contactNo: this.state.contactNo,
        address: this.state.address,
        city: this.state.city,
        state: this.state.state,
        membershipStatus: this.state.membershipStatus,
        userType: this.state.userType,
        date: this.state.date,
        time: this.state.time,
        recentDate: this.state.date,
        recentTime: this.state.time,
        password: "Iceil@1234",
        franchiseId: this.state.franchiseId,
        franchiseName: this.state.franchiseName,
      }),
      url: "http://15.206.129.105:8080/IceilLiveAPI/UserManagementWebService/AddUserDetails",
      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data) {

        //console.log(data.response);

        if (data.response === "Insert Success") {
          //console.log("inside");
          Swal.fire({
            position: 'center',
            icon: 'success',
            text: 'Add successfully',
            showConfirmButton: false,
            timer: 2000
          })

          if (self.state.userType == '0' && self.state.franchiseCreateStatus == 'Yes') {
            //CREATE A FOLDER OF THE GENERATED FRANCHISE IN SAVED IMAGES FOLDER OF AWS
            self.CreateFranchiseFolder(data.franchiseId);
          }
        }
        else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: data.response,
            showConfirmButton: false,
            timer: 2000
          })
        }
        self.Clear();
      },
      error: function () {

        Swal.fire({
          position: 'center',
          icon: 'error',
          text: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      },
    });
  }


  /*
  FUNCTION USED FOR CRATING AN FOLDER INSIDE SABED IMAGES
  WHENVER AN FRANCHISE IS ADDED INTO THE SYSTEM SUCCESSFULLY
  - IMPLEMENTED BY PRIYANA - 12-07-2022
  */
  CreateFranchiseFolder(franchiseId) {

    CreateFolder("Saved Images", franchiseId);

    CreateFolder("Quotation/"+ GetLocalStorageData("CompanyId"), franchiseId);

  }

  /*CLEAR FUNCTION -IMPLEMENTED BY DURGA 23-04-2022*/
  Clear() {
    var self = this;
    // $('#membershipStatus')
    //   .find('option')
    //   .remove()
    //   .end()
    //   .append('<option value="Normal">Normal</option><option value="Bronze">Bronze</option><option value="Silver">Silver</option><option value="Gold">Gold</option><option value="Platinum">Platinum</option>')
    //   .val('whatever');

    self.state.isOpen = "";
    self.state.emailId = "";
    self.state.userName = "";
    self.state.gstIn = "";
    self.state.contactNo = "";
    self.state.address = "";
    self.state.city = "";
    self.state.state = "";
    self.state.membershipStatus = 'Normal';

    self.state.date = "";
    self.state.time = "";
    self.state.userType = '0';
    self.state.formErrors.userName = "";
    self.state.selectedFranchise = [];

    self.state.formErrors.emailId = '';
    self.state.formErrors.contactNo = '';
    self.state.formErrors.gstIn = '';
    self.state.formErrors.address = '';
    self.state.formErrors.city = '';
    self.state.formErrors.state = '';
    self.state.franchiseCreateStatus = 'No';
    self.state.franchiseList = [];


    self.setState({

      franchiseList: self.state.franchiseList,
      formValid: false,
      userNameValid: false,
      emailValid: false,
      contactNoValid: false,
      gstInValid: false,
      addressValid: false,
      cityValid: false,
      stateValid: false,
      toggleEnable: false,
      toggleEnable: false,
      selectedFranchiseValid: false,
      franchiseCreateStatus: self.state.franchiseCreateStatus,
      isOpen: false,
      selectedFranchise: self.state.selectedFranchise,
      emailId: self.state.emailId,
      userName: self.state.userName,
      gstIn: self.state.gstIn,
      contactNo: self.state.contactNo,
      address: self.state.address,
      city: self.state.city,
      state: self.state.state,
      membershipStatus: self.state.membershipStatus,
      date: self.state.date,
      time: self.state.time,
      userType: self.state.userType,
    })

    self.getfranchiseList();

  }



  /*HANDLE TOGGLE/SWITCH -IMPLEMENTED BY DURGA-04-05-2022 */
  handleToggle(isOpen) {
    var self = this;
    let tempusertype = '0';
    var temptoggleEnable = false;
    self.state.selectedFranchiseValid = false;
    if (self.state.franchiseName.length > 0) {
      self.state.selectedFranchiseValid = true;
    }
    if (isOpen) {
      tempusertype = '1';
      temptoggleEnable = true;
      self.state.selectedFranchiseValid = true;
    }

    self.state.userType = tempusertype;
    self.state.isOpen = isOpen;
    self.setState({
      toggleEnable: temptoggleEnable,
      userType: self.state.userType,
      isOpen: self.state.isOpen,
      selectedFranchiseValid: self.state.selectedFranchiseValid
    });
    //console.log("tempselectedFranchiseValid", self.state.selectedFranchiseValid);

    this.validateForm();
  }

  /*HANDLE CHANGE FOR FRANCHISE LIST SELECT -IMPLEMENTED BY DURGA-04-05-2022 */
  handleChangeSelectFranchise = (newValue, actionMeta) => {
    //console.log("SELECT CUSTOMER MOBILE NO:", newValue);
    this.state.selectedFranchise = '';
    this.state.franchiseName = '';

    this.setState({
      selectedFranchise: this.state.selectedFranchise, franchiseName: this.state.franchiseName, selectedFranchiseValid: false,
    }, this.validateForm);
    if (newValue != null) {

      this.state.franchiseId = newValue.value;
      this.state.franchiseName = newValue.label
      this.state.selectedFranchise = { value: newValue.value, label: newValue.label };
      this.setState({
        franchiseId: this.state.franchiseId,
        franchiseName: this.state.franchiseName,
        selectedFranchise: this.state.selectedFranchise,
        selectedFranchiseValid: true
      }, this.validateForm);
    }
  };
  /*HANDLE CHANGE FOR FRANCHISE LIST CREATE SELECT -IMPLEMENTED BY DURGA-04-05-2022 */
  handleInputCreateFranchise = (inputValue, actionMeta) => {

    var self = this;

    //console.log("CREATE CUSTOMER :", inputValue);
    inputValue = CapitalCaseFunc(inputValue);
    //console.log("CREATE CUSTOMER :", inputValue);

    self.state.selectedFranchise = { value: inputValue, label: inputValue };
    self.state.franchiseCreateStatus = 'Yes';

    self.state.franchiseId = '';
    self.state.franchiseName = inputValue;

    self.setState({
      franchiseId: self.state.franchiseId,
      franchiseName: self.state.franchiseName,
      selectedFranchise: self.state.selectedFranchise,
      franchiseCreateStatus: self.state.franchiseCreateStatus,
      selectedFranchiseValid: true
    }, this.validateForm);

  }

  render() {
    // let {userType} = this.state;
    return (
      <div class="container-fluid">
         <ThemeProvider theme={darkTheme}>
        {/* TOGGLE BUTTON  */}
        {/* <div class=" ">
          <label style={{ marginRight: '20px', fontWeight: '700' }}>Admin</label>
          <Switch onChange={this.handleToggle} checked={this.state.isOpen} /> 

        </div> */}
        <div class="admin-toggle">
            <label style={{ marginRight: '20px', fontWeight: '700' }}>Admin</label>
            <Switch onChange={this.handleToggle} checked={this.state.isOpen} /> {/*added by durga*/}

          </div>
        <div class="row mt-20">

          {/* FIELD USED TO GET Franchise Name - IT'S MANDATORY FIELD   */}

          <div class="col-md-4" id="creatableSelect" style={{color: 'black',marginTop:'-10px'}}>
             <label class="  control_label_text selectpicker" for="customerName">Franchise List<span style={{ color: "red" }}>*</span></label>
            <CreatableSelect id="creatableSelect"
              //style={{ width: "302px" }}
              isClearable
              isDisabled={this.state.toggleEnable}
              onChange={this.handleChangeSelectFranchise}
              onCreateOption={this.handleInputCreateFranchise}
              options={this.state.franchiseList}
              value={this.state.selectedFranchise}
              styles={customStyles_Dropdown}
            />

          </div>




          {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD   */}

          <div class="col-md-4 ">

            {/* <label class=" control_label_text" for="UserName"> Email Id<span style={{ color: 'red' }}>*</span></label> */}
            {/* <input type="text" class="form-control" id="emailId" name="emailId" placeholder='Enter Email Id'
              value={this.state.emailId} onChange={this.handleUserEmail} /> */}
             <TextField fullWidth size="small" margin="normal"  required variant="outlined" label="Enter Email "
             id="emailId" name="emailId"
              value={this.state.emailId} onChange={this.handleUserEmail} 
              />
            {/* <ErrorClass errorContent={this.state.formErrors.emailId} /> */}
          </div>


          {/* FIELD USED TO GET Franchise Name - IT'S MANDATORY FIELD   */}

          <div class="col-md-4 ">

            {/* <label class=" control_label_text" for="userName"> User Name<span style={{ color: 'red' }}>*</span></label> */}
            {/* <input type="text" name="userName" id="userName" maxLength="31" class="form-control" value={this.state.userName} onChange={this.handleUserInputName} placeholder="Enter Name" /> */}
             <TextField fullWidth size="small" margin="normal"  variant="outlined" label="Enter UserName *" name="userName" id="userName" maxLength="31" value={this.state.userName} onChange={this.handleUserInputName} />
            <ErrorClass errorContent={this.state.formErrors.userName} />
          </div>



          {/* FIELD USED TO GET GSTIN   */}

          <div class="col-md-4 ">
            <div class="">
              {/* <input type="text" class="form-control form-group" id="gstIn" value={this.state.gstIn} onChange={this.handleUserInputGstin} name="gstIn" placeholder="Enter GSTIN No" /> */}
               <TextField fullWidth size="small" margin="normal"  variant="outlined" label="Enter GSTIN" id="gstIn" value={this.state.gstIn} onChange={this.handleUserInputGstin} name="gstIn" />
              {/* <ErrorClass errorContent={this.state.formErrors.gstIn} /> */}
            </div>
          </div>
          {/* FIELD USED TO GET CONTACT   */}

          <div class="col-md-4 ">
            <div class="">
              {/* <input type="text" class="form-control form-group" id="contactNo" name="contactNo" onChange={this.handleUserInputContactNo} value={this.state.contactNo} placeholder="Enter Contact No" /> */}
               <TextField fullWidth size="small" margin="normal"  variant="outlined" label="Enter ContactNo *" id="contactNo" name="contactNo" onChange={this.handleUserInputContactNo} value={this.state.contactNo} />

              {/* <ErrorClass errorContent={this.state.formErrors.contactNo} /> */}
            </div>
          </div>

          {/* FIELD USED TO GET ADDRESS   */}

          <div class="col-md-4 ">

            <div class="">
              {/* <input type="text" class="form-control form-group" id="address" maxLength={151} name="address" onChange={this.handleUserInputAddress} value={this.state.address} placeholder="Enter Address" /> */}
               <TextField fullWidth size="small" margin="normal"  variant="outlined" label="Enter Address" id="address" maxLength={151} name="address" onChange={this.handleUserInputAddress} value={this.state.address} />
              <ErrorClass errorContent={this.state.formErrors.address} />
            </div>
          </div>
          {/* FIELD USED TO GET CITY   */}
          <div class="col-md-4 ">

            <div class="">
              {/* <input type="text" class="form-control form-group" id="city" value={this.state.city} onChange={this.handleUserInputCity} name="city" placeholder="Enter City" /> */}
               <TextField fullWidth size="small" margin="normal"  variant="outlined" label="Enter City" id="city" value={this.state.city} onChange={this.handleUserInputCity} name="city" />

              <ErrorClass errorContent={this.state.formErrors.city} />
            </div>
          </div>


          {/* FIELD USED TO GET state   */}


          <div class="col-md-4">

            <div class="">
              {/* <input type="text" class="form-control form-group" id="state" value={this.state.state} onChange={this.handleUserInputState} name="state" placeholder="Enter state" /> */}
               <TextField fullWidth size="small" margin="normal"  variant="outlined" label="Enter State" id="state" value={this.state.state} onChange={this.handleUserInputState} name="state" />
              <ErrorClass errorContent={this.state.formErrors.state} />
            </div>
          </div>

          {/* FIELD USED TO GET MEMEBERSHIP   */}
          <div class="col-md-4">
              <div class="">
                {/* <select name="membershipStatus" id="membershipStatus" value={this.state.membershipStatus} onChange={this.handleUserInputMembershipStatus} class="form-control">
                  <option value="Normal">Normal</option>
                  <option value="Bronze">Bronze</option>
                  <option value="Silver">Silver</option>
                  <option value="Gold">Gold</option>
                  <option value="Platinum">Platinum</option>
                </select> */}
                <FormControl fullWidth margin="normal" size="small">
                  <InputLabel id="">Membership</InputLabel>
                  <Select
                    labelId="demo-simple-select-label" id="demo-simple-select membershipStatus"
                    name="membershipStatus" value={this.state.membershipStatus} onChange={this.handleUserInputMembershipStatus}>
                    <MenuItem value="Normal">Normal</MenuItem>
                    <MenuItem value="Bronze">Bronze</MenuItem>
                    <MenuItem value="Silver">Silver</MenuItem>
                    <MenuItem value="Gold">Gold</MenuItem>
                    <MenuItem value="Platinum">Platinum</MenuItem>
                  </Select>
                </FormControl>
            </div>
          </div>

        </div>
        </ThemeProvider>
        <br />
        <div class="text-center">
          {/* disabled={!this.state.formValid} */}
          <button class="btn btn-primary btn_form" disabled={!this.state.formValid} onClick={() => this.UserRegistrationFunc()}>Submit</button>
          <button class="btn btn-primary btn_form" style={{ marginLeft: '4px' }} onClick={() => this.Clear()}>Cancel</button>
        </div>


        <Modal
          isOpen={this.state.insertGstinmodalIsOpen}
          //  onAfterOpen={this.customerafterOpenModal}	
          onRequestClose={this.state.closeModalGstin}
          style={customStyles}
          contentLabel="Example Modal"
        >
          <div className="container">
            <h3>GSTIN Number</h3>
            <p>1. GST is a 15 Digit Unique Identification Number[Ex:07AABCU9603R1ZP/18AABCU9603R1ZM]</p>
            <p>2. First Two Digit Shows The State Code As Per Census 2011 [01-35]</p>
            <p>3. Next 10 Digits Are The Pan Number Of The Gst Registered Entity.</p>
            <p>4. 13th Digit Is The Entity Code Viz. The Multiple Registration Made By The Same Entity, Within The Same State.</p>
            <p>5. 14th Digit Is By-Default "Z" For Every Gst Registration.</p>
            <p>6. 15th Digit Is The Check Code (Number/Alphabet) That Has Been Radomly Assigned.</p>
            <p></p>
            <div class="text-center">
              <button type="button" class="btn-default " onClick={() => this.closeModalGstinNo()}
                style={{
                  borderRadius: "18px",
                  backgroundColor: "#263eac",
                  color: "white",
                  width: "75px",
                  marginTop: "20px"
                }}
              >
                <span class="glyphicon glyphicon-ok" style={{ fontWeight: "800" }} ></span> Ok
              </button>
            </div>
          </div>
        </Modal>

      </div>


    );
  }
}
export default AddUser;
