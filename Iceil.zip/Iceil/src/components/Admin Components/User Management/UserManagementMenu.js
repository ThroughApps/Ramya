//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import $ from "jquery";
// import statement for react class component
import AddUser from "./AddUser";
import UserList from "./UserList";

import "./UserManagementcss.css";

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class UserManagementMenu extends React.Component {
  constructor() {
    super();
    this.state = {
      UserData: 'List',
    }
  }

  /* THIS FUCNTION USED FOR LEAD TO ADDUSER PAGE IMPLEMENTED BY NANDHINI - 02-05-2022*/
  AddUser() {
    $(".tabs").removeClass("active");
    $(".List").addClass("active");
    this.state.UserData = 'List';
    this.setState({
      UserData: this.state.UserData
    })
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<UserManagementMenu />} />
          <Route path="/" element={<AddUser />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    );
  }

  /* THIS FUCNTION USED FOR LEAD TO USERLIST PAGE IMPLEMENTED BY NANDHINI - 02-05-2022*/
  UserList() {
    $(".tabs").removeClass("active");
    $(".UserList").addClass("active");
    this.state.UserData = 'UserList';
    this.setState({
      UserData: this.state.UserData
    })
    ReactDOM.render(
      <BrowserRouter>
        <Routes>

          <Route path="/" element={<UserManagementMenu />} />
          <Route path="/" element={<UserList />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    );
  }
  RenderComponenets(UserData) {

    var self = this;

    switch (UserData) {
      case 'List':
        return <AddUser />
      case 'UserList':
        return <UserList />
      default:
        return <div></div>;
    }

  }
  render() {

    return (
      <div className="">
        <div class="toptitle">
        
          <h3>User Management</h3>
          <ul class="nav nav-tabs">
            <li class="List tabs active"><a onClick={() => this.AddUser()}><span style={{ display: "inline-grid" }}>User</span></a></li>
            <li className="UserList tabs"><a onClick={() => this.UserList()}><span style={{ display: "inline-grid" }}>User List</span></a></li>
          </ul>
        </div>
         {/* <hr/>  */}
        <div className="">


          {/* <ul class="nav nav-tabs">
            <li class="List tabs active"><a onClick={() => this.AddUser()}><span style={{ display: "inline-grid" }}>User</span></a></li>
            <li className="UserList tabs"><a onClick={() => this.UserList()}><span style={{ display: "inline-grid" }}>User List</span></a></li>
          </ul> */}


        </div>
        {this.RenderComponenets(this.state.UserData)}
      </div>

    );
  };
}
export default UserManagementMenu;

  