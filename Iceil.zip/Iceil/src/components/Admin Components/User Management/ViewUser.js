import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter,Routes,Route, NavLink } from 'react-router-dom';
import "./UserManagementcss.css";
import Toggle from 'react-toggle';
import "react-toggle/style.css";
import Switch from "react-switch";
import TextField from '@mui/material/TextField';
import { ThemeProvider, createTheme } from '@mui/material/styles';


const darkTheme = createTheme({
  palette: {
    mode: 'dark',
  },
});

//import { ErrorClass , FormErrors} from '../../ValidationComponents/Loginvalidation';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class ViewUser extends Component {
  constructor() {
    super();
    this.state = {
     // isOpen : false,
      userType : "Franchise",
    }
  }
componentDidMount()
{
  //console.log("stateData",this.props.stateData);
  //console.log("stateData",this.props.stateData.userData);
  //console.log("stateData",this.props.stateData.userType);

  //added by durga-toggle btn set based on usertype//
  if(this.props.stateData.userType=='1')
  {
    this.state.userType="Admin";
  }

  
this.setState({
  userType:this.state.userType})
}

 /*USED TO LEAD TO LISTPAGE  */ 

 
 render() {
 
   return (
    <div class="">
         
      
        <div class="container-fluid" >
        <ThemeProvider theme={darkTheme}>
             {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD   */}
              <div class="row">
                <div class="col-md-4 ">

                  {/* <label class="control_label_text" for="emailid"> Email Id<span style={{color:'red'}}>*</span></label> */}
                   {/* <input type="text" class="form-control" id="userEmail" name="email" placeholder='Enter Email Id'
                  value={this.props.stateData.emailId}  readOnly ></input> */}
                   <TextField fullWidth margin="normal"  size="small"  id="userEmail" name="email" label=' Email Id' value={this.props.stateData.emailId} InputProps={{readOnly: true,}} /> 
               
                </div>   
              
        
           {/* FIELD USED TO GET Franchise Name - IT'S MANDATORY FIELD   */}
              
           <div class="col-md-4">
                        {/* FIELD USED TO GET Franchise Name - IT'S MANDATORY FIELD   */}
                         <TextField fullWidth margin="normal" size="small"  label=' FranchiseName' id="name"  name="name" value={this.props.stateData.userName} InputProps={{readOnly: true,}}  />
                        {/* <input type="text" class="form-control form-group" id="name"  name="name" value={this.props.stateData.userName} placeholder="Enter Franchise Name" readOnly/> */}
                        {/* <ErrorClass errorContent={this.state.formErrors.name}></ErrorClass>  */}
                    </div>     
               
             
             
               <div class="col-md-4">
                            {/* FIELD USED TO GET GSTIN   */}
                             <TextField fullWidth margin="normal"  size="small" label=' GSTIN' id="gstin_no"  name="gstin_no" value={this.props.stateData.gstIn} InputProps={{readOnly: true,}}  />
                            {/* <input type="text" class="form-control form-group" id="gstin_no"  name="gstin_no" value={this.props.stateData.gstIn} placeholder="Enter GSTIN No" readOnly/> */}
                    </div>   
               
                    <div class="col-md-4">
                          {/* FIELD USED TO GET CONTACT   */}
                           <TextField fullWidth margin="normal"  size="small" label=' Contact No' id="contact_no"  name="contact_no" value={this.props.stateData.contactNo} InputProps={{readOnly: true,}}  />
                          {/* <input type="text" class="form-control form-group" id="contact_no"  name="contact_no" value={this.props.stateData.contactNo}  placeholder="Enter Contact No" readOnly/> */}
                    </div>   
                
                
                 <div class="col-md-4">
                          {/* FIELD USED TO GET ADDRESS   */}
                           <TextField fullWidth margin="normal"  size="small" label=' Address' id="Address"  name="Address" value={this.props.stateData.address} InputProps={{readOnly: true,}}  />
                          {/* <input type="text" class="form-control form-group" id="Address"  name="Address" value={this.props.stateData.address}  placeholder="Enter Address" readOnly/> */}
                    </div>    
                 


         
                
                    <div class="col-md-4">
                          {/* FIELD USED TO GET CITY   */}
                           <TextField fullWidth margin="normal"  size="small" label=' City' id="city"  name="city" value={this.props.stateData.city} InputProps={{readOnly: true,}}  />
                          {/* <input type="text" class="form-control form-group" id="city"  name="city" value={this.props.stateData.city}  placeholder="Enter City" readOnly/> */}
                      
                    </div>
                 
               <div class="col-md-4">
                          {/* FIELD USED TO GET state   */}
                           <TextField fullWidth margin="normal" size="small"  label=' State' id="state"  name="state" value={this.props.stateData.state}  InputProps={{readOnly: true,}}  />
                          {/* <input type="text" class="form-control form-group" id="state"  name="state" value={this.props.stateData.state}  placeholder="state" readOnly/> */}
                    </div>

                    <div class="col-md-4">
                          {/* FIELD USED TO GET MEMEBERSHIP   */}
                           <TextField fullWidth margin="normal" size="small"  label=' Membership'  name="membershipStatus" id="membershipStatus" value={this.props.stateData.membershipStatus}  InputProps={{readOnly: true,}}  />
                          {/* <input name="membershipStatus" id="membershipStatus" value={this.props.stateData.membershipStatus} class="form-control" readOnly/> */}
                  </div>
                 
                       <div class="col-md-4">
                         <TextField fullWidth margin="normal"  size="small" label=' Login Type'  name="loginType" id="loginType" value={this.state.userType} InputProps={{readOnly: true,}}  />
                        {/* <input name="loginType" id="loginType" value={this.state.userType} class="form-control" readOnly/> */}
                  </div>
            
              
             
                
               
          

           {/*added by durga*/}
           {/* <div className=" col-md-2">
        <label   style={{marginRight:'20px',fontWeight:'700'}}>Admin</label>
      </div>
      <div className="col-md-2">
           <Switch onChange={this.handleToggle} checked={this.state.isOpen} /> 
           </div> */}
           
            {/* FIELD USED TO GET ADMIN   */}
            {/* <div class="col-md-4">
                <div className="r_Pay_tog_cls">
                  <div className="r_Pay_Labl ">
                    <label class="control-label" style={{marginRight:'20px',fontWeight:'700'}}>Admin</label>
                  </div>
                  <div className="r_Pay_Inp">
                    <Toggle
                      name="admin"
                    
                      icons={true}
                      aria-label='No label tag'
                      />
                  </div>
                </div> 
                  </div>
              <br/>  */}

           </div> 
           </ThemeProvider>
           <br/> 
           {/* <div class="text-center">
           <button class="btn btn-primary btn_form"  disabled={!this.state.formValid}>Submit</button>
           </div>   */}

        </div>

      

  
 
  
    </div>
    
   );
   }
}
export default ViewUser ;
