//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import $ from 'jquery';
import ReactDOM from 'react-dom';
import { BrowserRouter,Routes,Route } from 'react-router-dom';

//IMPORT STATEMENTS FOR REACT CLASS COMPONENT
import ReactTable from "react-table-v6";
import SlidingPane from "react-sliding-pane";
import Swal from 'sweetalert2/dist/sweetalert2.js';

//IMPORT REACT COMPONENT CSS
import "react-toggle/style.css";
import "react-table-v6/react-table.css" 
import "./UserManagementcss.css";


//IMPORT STATEMENTS FOR REACT CLASS COMPONENT
import AddUser from './AddUser';
import {ListIcons } from '../../Assets Components/Icon Components/Iconcomponents';


var userList;

class Listpage extends Component {

  constructor() {
    super();
    
    this.state={
      totlaItemCount: 0,
      itemsPerPage: 10,
      activePage: 1,
      
      isListPagePaneOpen: false,
      userData:[],
      listColumns:[{
          Header:"SNO",
      },
      {
         Header:"Franchise Name",
      },
      {
         Header:"GSTIN",
      },
      {
         Header:"Contact No",
      },
      {
         Header:"Membership",
      },
      {
          Header:"Status",
       },
    
      ],    
  }     
  }

 /*USED TO LEAD TO LISTPAGE  */ 
 Franchisepage(){
    ReactDOM.render(
        <BrowserRouter>
        <Routes>
                    <Route path="/" element={<AddUser />} />
            </Routes>
        </BrowserRouter>,
        document.getElementById("root")
    );
}
componentDidMount()
  {
    $("#tableOverflow1").hide();
    this.getData();

  }


ViewListPage(){
  this.state.isListPagePaneOpen = true;

  this.setState({
    isListPagePaneOpen: this.state.isListPagePaneOpen,
  })
}

getData()
{
  var self=this;
  $.ajax({
    type: 'POST',
      //type: 'GET',
    
      url: "http://localhost:8080/IceilAPI/IceilWebService/SelectUserDetails",
      contentType: "application/json",
      dataType: 'json',
      async: false,

      success: function (data, textStatus, jqXHR) {

          console.log("data",data);
          userList = data.userList;
          
          self.setState({
              userData: userList,
            });
          console.log(userList);
          console.log( self.state.userData);

           self.PopulateUserData(userList);
  },
  error: function (data) {
    Swal.fire({
      position: 'center',
      icon: 'error',
      title: 'Network Connection Problem',
      showConfirmButton: false,
      timer: 2000
    })
  },
});
} 
PopulateUserData(userList)
{
    var self=this;
    var count=0;   
     $("#tableHeadings").empty();
    // SNO
    // FranchiseName
    // GSTIN
    // contactNo
    // Membership
    // Status
console.log("userlist",userList);

     var tab = '<thead><tr class="headcolor"><th>SNO</th><th>FranchiseName</th><th>GSTIN</th><th>ContactNo</th><th>Membership</th><th>Status</th></tr></thead>';

    $.each(userList, function (i, item) {
      console.log(item.userName);
      console.log(item.gstIn);
      console.log(item.contactNo);

      count=Number(count)+1;
 
      tab += '<tbody id= "myTable" ><tr  id="tabletextcol" ><td>' + count + '</td>'
      +'<td>' +  item.userName + '</td>'
      +'<td>' + item.gstIn + '</td>'
      +'<td>' + item.contactNo + '</td>'  
      +'<td>' + item.membershipStatus + '</td>'  
      +'<td>' + item.status + '</td>'  
      
            self.state.userData[i]={ 
                "SNO":count,
                "FranchiseName":item.userName,
                "GSTIN":item.gstIn,
                "ContactNo":item.contactNo,
                "Membership":item.membershipStatus,
                "Status":item.status,
                // "EmailId":item.emailId,
              }
        });

        $("#tableHeadings").append(tab);

        self.state.listColumns=this.GetColumns();

        self.setState({

           TableColumns:self.state.listColumns,
            userData:self.state.userData,
        });
            

}

GetColumns() {

  return Object.keys(this.state.userData[0]).map(key => {

      return {
          Header: key,
          accessor: key,

      };

  });
}


 render() {
 
   return (
    <div class="container">
          <div class="card_head">
                    <h2 class="card_header_text">User Management</h2>
                </div>
        <div> 
        <ul class="nav nav-tabs">
          <li class="active"><a className="active" onClick={() => this.Franchisepage()}><span style={{ display: "inline-grid" }}>Franchise</span></a></li>
          <li><a onClick={() => this.listpage()}><span style={{ display: "inline-grid" }}> List</span></a></li>
        </ul>
        </div>
        <br/>
        <div class="Franchise_card">
      <div class="row">
          <div class="col-md-4">
          <div class="labellist">
                         <label class="control-label" for="member">Status</label>
                   </div>
                     <div class="">
                     <select name="paymentStatus" id="paymentStatus" onChange={this.handleUserInputPaymentStatus} class="form-control">
                {/* <option disabled selected hidden value="">Select Payment Status</option> */}
                <option value="Paid">Active</option>
                <option value="UnPaid">Deactivate</option>
                <option value="PartiallyPaid">All</option>
              
              </select>
                     </div>
          </div>
          <div class="col-md-4">
          <div class="labellist">
                         <label class="control-label" for="member">Membership</label>
                   </div>
                     <div class="">
                     <select name="membershipStatus" id="membershipStatus" onChange={this.handleUserInputMembershipStatus} class="form-control">
                {/* <option disabled selected hidden value="">Select Payment Status</option> */}
                <option value="Paid">Normal</option>
                <option value="UnPaid">Bronze</option>
                <option value="PartiallyPaid">Silver</option>
                <option value="UnPaid">Gold</option>
                <option value="PartiallyPaid">Platinum</option>
              
              </select>
                     </div>
         
        </div>

        <div class="col-md-4">
        <div className="reactIcon_Dcls">
          <ListIcons onViewProduct={this.ViewListPage}  />
        </div>
        </div>
      </div>
          <div>
          <br/>
          <br/>
          {/* <ReactTable style={{ overflow: "auto" }}
                        data={this.state.userData}
                        columns={this.state.listColumns}
                        noDataText="No Data Available"
                        filterable
                        defaultPageSize={10}
                        className="-highlight"
                        defaultFilterMethod={(filter, row, column) => {
                        const id = filter.pivotId || filter.id;
                        return row[id] !== undefined
                            ? String(row[id])
                            .toLowerCase()
                            .indexOf(filter.value.toLowerCase()) !== -1
                            : true;
                        }}
                        showPaginationTop={true}
                        showPaginationBottom={false}
                       // getTdProps={this.onTrRowClick}
                    /> */}

          {/* <div>
            <ReactHTMLTableToExcel 
            id="test-table-xls-button"
            className="download-table-xls-button "
            table="tableHeadings"
            filename="Resume_List"
            sheet="tablexls"
            buttonText={downloadButtonData}/>
            </div> */}
        
      <div id="tableOverflow1">
            <table style={{ margin: "auto" }} class="table table-bordered" id="tableHeadings">
            </table>
        </div>
        
    
            <div style={{marginTop:'50px'}}>
        <ReactTable style={{ overflow: "auto" }}
                        data={this.state.userData}
                        columns={this.state.listColumns}
                        noDataText="No Data Available"
                        filterable
                        defaultPageSize={10}
                        className="-striped -highlight"
                        defaultFilterMethod={(filter, row, column) => {
                        const id = filter.pivotId || filter.id;
                        return row[id] !== undefined
                            ? String(row[id])
                            .toLowerCase()
                            .indexOf(filter.value.toLowerCase()) !== -1
                            : true;
                        }}
                        showPaginationTop={true}
                        showPaginationBottom={false}
                       // getTdProps={this.onTrRowClick}
                    />
                    
                </div>
      

            {/*    <div style={{ marginBottom: "3%" }} className="pull-right" id="paginationdiv">
            <Pagination
              activePage={this.state.activePage}
              itemsCountPerPage={this.state.itemsPerPage}
              totalItemsCount={this.state.totlaItemCount}
              pageRangeDisplayed={5}
              onChange={this.handlePageChange.bind(this)}
            /></div>
            */}

          </div>

        </div>
    </div>  
        // <SlidingPane
        //             className="some-custom-class"
        //             overlayClassName="some-custom-overlay-class"
        //             isOpen={this.state.isListPagePaneOpen}
        //             title={"Payment Receivables Config Info"}

        //             subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
        //             onRequestClose={() => {
        //                 // triggered on "<" on left top click or on outside click
        //                 // setState({ isPaneOpen: false });
        //                 this.ClosePaymentReceivables()
        //             }}
        //         >
        //             {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
                  
        //         </SlidingPane>
  
 

    
    
   );
   }
}
export default Listpage ;