//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import $ from 'jquery';
import _ from 'underscore';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactTable from "react-table-v6";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import Pagination from "react-js-pagination";
import 'status-indicator/styles.css';
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";

//IMPORT REACT COMPONENT CSS
import "react-toggle/style.css";
//import "react-table-v6/react-table.css" 
//import "react-table/react-table.css";
//import 'sweetalert2/src/sweetalert2.scss';

//IMPORT CLASS COMPONENT CSS
import "./UserManagementcss.css";

//IMPORT STATEMENTS FOR REACT CLASS COMPONENT
import AddUser from './AddUser';
import ViewUser from './ViewUser';
import EditUser from './EditUser';
import { ListIcons } from '../../Assets Components/Icon Components/Iconcomponents';
import { MembershipDropdown, ActiveStatusDropDown } from '../../Assets Components/DropdownComponents/DropdownComponent';
import { GetLocalStorageData } from '../../Common Components/CommonComponents';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var userList;

var dataCount = 0;
var dataCountArray = [];
var itemData = 1;
var pageArray = [];
var pageData_Status;

class UserList extends Component {

  constructor() {
    super();

    this.state = {
      totlaItemCount: 0,
      itemsPerPage: 10,
      activePage: 1,
      isUserViewPaneOpen: false,
      isUserEditPaneOpen: false,
      propsSelectedStatus: '',
      propsSelectedMembershipStatus: '',
      userData: [],
      listColumns: [
        { Header: "SNO",
         accessor: 'SNO'
      },
        {
          Header: "FranchiseName",
          accessor: 'FranchiseName'
        },
        {
          Header: "UserName",
          accessor: 'UserName'
        },
        {
          Header: "ContactNo",
          accessor: 'ContactNo'
        },
        {
          Header: "EmailId",
          accessor: 'EmailId'
        },
        {
          Header: "Type",
          accessor: 'Type'
        },
        {
          Header: "Status",
          accessor: 'Status'
        },
        {
          Header: "Membership",
          accessor: 'Membership'
        },
        {
          Header: "City",
          accessor: 'City'
        },
        {
          Header: "State",
          accessor: 'State'
        },
       
        ],
  
    }

    this.ActivateFunc = this.ActivateFunc.bind(this);
    this.DeactivateFunc = this.DeactivateFunc.bind(this);
    this.ActivateandDeactivateFunc = this.ActivateandDeactivateFunc.bind(this);
    this.EditListPage = this.EditListPage.bind(this);
    this.ViewListPage = this.ViewListPage.bind(this);
    this.PopulateUserData = this.PopulateUserData.bind(this);
    this.StatusOnChange = this.StatusOnChange.bind(this);
    this.MembershipStatusOnChange = this.MembershipStatusOnChange.bind(this);
    this.CloseProductEdit = this.CloseProductEdit.bind(this);
    this.GetData = this.GetData.bind(this);

  }


  /*USED TO LEAD TO LISTPAGE  */
  Franchisepage() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AddUser />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    );
  }
  componentDidMount() {
    dataCount = 0;
    dataCountArray = [];
    itemData = 1;
    pageArray = [];

    dataCountArray.push(0);
    pageArray.push(1);

    $("#tableOverflow1").hide();

    this.GetData();

  }


  // ViewListPage() {
  //   this.state.isListPagePaneOpen = true;

  //   this.setState({
  //     isListPagePaneOpen: this.state.isListPagePaneOpen,
  //   })
  // }
  /* THIS FUCNTION USED FOR SLIDEPANE FOR VIEWPAGE IMPLEMENTED BY NANDHINI - 02-05-2022*/


  /*USED TO GET THE USER LIST DETAILS FROM DATABASE- -IMPLEMENTED BY DURGA 19-04-2022*/
  GetData() {
    //alert("get data");
    this.SearchBarClearFunc();

    var self = this;
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("CompanyId"),
        dataCount: dataCount,
        totlaItemCount: self.state.totalItemCount,
      }),
      url: "http://15.206.129.105:8080/IceilLiveAPI/UserManagementWebService/SelectUserDetails",
      contentType: "application/json",
      dataType: 'json',
      async: false,

      success: function (data, textStatus, jqXHR) {

        //console.log("data", data);

        userList = data.userList;
        if (data.userList !== null && data.userList.length != 0) {
          var no = 0;
          // self.state.downloadData = "yes";
          if (itemData == "1") {
            self.state.totlaItemCount = data.totlaItemCount;

            itemData = Number(itemData) + 1;
          }

        } else {
          itemData = "1";
          self.state.totlaItemCount = 0;
          //self.state.downloadData = "no";


        }


        self.PopulateUserData(userList);
      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      },
    });
  }

  SearchBarClearFunc() {
    window.ActiveStatusDropDownComponent.ResetStatus();
    window.MembershipDropdownComponent.ResetStatus();
  }

  tempPopulateUserData(list) {
    var self = this;
    //console.log("list", list);
    self.PopulateUserData(list);
  }
  /*USED TO RENDER THE USER LIST IN REACT TABLE  -IMPLEMENTED BY DURGA 19-04-2022*/
  PopulateUserData(userList) {

    var self = this;
    self.state.userData = [];
    var count = dataCount;
    var tempStatus;
    var tempusertype;

    $("#tableHeadings").empty();

    //console.log("userlist", userList);

    var tab = '<thead><tr class="headcolor"><th>SNO</th><th>UserId</th><th>FranchiseName</th><th>GSTIN</th><th>ContactNo</th><th>Membership</th><th>Status</th></tr></thead>';

    $.each(userList, function (i, item) {

      count = Number(count) + 1;

      //BASED ON STATUS VALUE RENDERING THE Active/Deactivated STATUS WITH  COLOR//-IMPLEMENTED BY DURGA 19-04-2022*/
      if (item.status == "1") {

        tempStatus = <span class="deactivate">Deactivated</span>
      }
      else {
        tempStatus = <span class="activate">Active</span>
      }


      if (item.userType == 1) {
        tempusertype = "Admin";
      }
      else {
        tempusertype = "Franchise";
      }

      /*  tab += '<tbody id= "myTable" ><tr  id="tabletextcol" ><td>' + count + '</td>'
          + '<td>' + item.userId + '</td>' +
          +'<td>' + item.userName + '</td>'
          + '<td>' + item.gstIn + '</td>'
          + '<td>' + item.contactNo + '</td>'
          + '<td>' + item.membershipStatus + '</td>'
          + '<td>' + tempStatus + '</td>' */
      ////console.log( item.userType);
      self.state.userData[i] = {
        "SNO": count,
        "UserName": item.userName,
        "FranchiseName": item.franchiseName,
        "GSTIN": item.gstIn,
        "ContactNo": item.contactNo,
        "Membership": item.membershipStatus,
        "Status": tempStatus,
        "UserId": item.userId,
        "EmailId": item.emailId,
        "Address": item.address,
        "City": item.city,
        "State": item.state,
        "UserType": item.userType,
        "Type": tempusertype,
      }
    });

    //  $("#tableHeadings").append(tab);

   /* if (self.state.userData.length > 0) {
      self.state.listColumns = this.GetColumns();
    }
    */
    this.state.selected = -1;
    self.setState({
      selected: this.state.selected,
    //  TableColumns: self.state.listColumns,
      userData: self.state.userData,
    });


  }
  // CHANHE THE STATUS AS DEACTIVATE WHILE PERFORMING THE DEACTIVATE ICON CLICK //-IMPLEMENTED BY DURGA 19-04-2022*/
  DeactivateFunc() {
    var self = this;

    if (self.state.userId === undefined || self.state.userId == "") {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Kindly, Select the User! ',

      })
    }
    else {
      //console.log("self.state.status", self.state.status);
      //console.log("self.state.status", self.state.status.props);
      //  alert("self.state.status"+self.state.status);

      if (self.state.status == "1" || self.state.status == "Deactivated") {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          text: 'Already Deactivated',
          showConfirmButton: false,
          timer: 2000
        })
      }
      else {
        self.state.status = "1";
        self.setState({ status: self.state.status })
        self.ActivateandDeactivateFunc();
      }

    }

  }
  // CHANHE THE STATUS AS ACTIVE WHILE PERFORMING THE ACTIVE ICON CLICK //-IMPLEMENTED BY DURGA 19-04-2022*/
  ActivateFunc() {
    var self = this;

    if (self.state.userId === undefined || self.state.userId == "") {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Kindly, Select the User! ',

      })
    }
    else {
      if (self.state.status == "0" || self.state.status == "Active") {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          text: 'Already in active State',
          showConfirmButton: false,
          timer: 2000
        })
      }
      else {
        self.state.status = "0";
        self.setState({ status: self.state.status })
        self.ActivateandDeactivateFunc();
      }
    }

  }
  //METHOD FOR UPDATING BOTH ACTIVATE AND DEACTIVATE ONCLICK IS PERFORMED //-IMPLEMENTED BY DURGA 19-04-2022*/
  ActivateandDeactivateFunc() {
    var self = this;

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        status: self.state.status,
        userId: self.state.userId,
        companyId: GetLocalStorageData("CompanyId"),
      }),
      url: "http://15.206.129.105:8080/IceilLiveAPI/UserManagementWebService/UpdateUserStatus",
      contentType: "application/json",
      dataType: 'json',
      async: false,

      success: function (data, textStatus, jqXHR) {

        //console.log("update", data);
        self.setState({userId:''})
        self.GetData();
      },
      error: function (data) {
        //console.log("update error");


      },

    });
  }

 
  /* USED TO HANDLE THE PAGINATION- IMPLEMENTED BY DURGA 18-04-2022 */
  handlePageChange(pageNumber) {

    this.state.activePage = pageNumber;
    this.setState({ activePage: pageNumber });

    var self = this;


    pageData_Status = false;
    pageData_Status = _.contains(pageArray, this.state.activePage);

    dataCount = 0;
    self.state.oldPageAcces = "false";
    self.setState({
      oldPageAcces: self.state.oldPageAcces
    });

    if (pageData_Status == false) {

      pageArray.push(pageNumber);
      dataCount = Math.round((Number(dataCount)) + ((Number(pageNumber) - 1) * 10));
      dataCountArray.push(dataCount);

    } else if (pageData_Status == true) {

      var currentPageIndex = _.indexOf(pageArray, this.state.activePage);
      dataCount = dataCountArray[currentPageIndex];

    }
    this.GetData();
  }

  /* HANDLE ROW SELECTION-USED TO STORE THE SELECTED ROW DATAS - IMPLEMENTED BY DURGA 18-04-2022 */
  onTrRowClick = (state, rowInfo, column, instance) => {

    var self = this;
    // //console.log("ROW INFO :",rowInfo);

    if (typeof rowInfo !== "undefined") {
      return {
        onClick: (e, handleOriginal) => {
          this.setState({
            selected: rowInfo.index
          });
          if (handleOriginal) {
            handleOriginal()
          }
          //console.log("self.state.status =", rowInfo.original["Status"]);
          //console.log("self.state.status =", rowInfo.original["Status"].props.children);
          //console.log("self.state.status =", rowInfo.original["Status"].props.item);
          self.state.userId = rowInfo.original["UserId"];
          self.state.userName = rowInfo.original["FranchiseName"];
          self.state.emailId = rowInfo.original["EmailId"];
          self.state.gstIn = rowInfo.original["GSTIN"];
          self.state.contactNo = rowInfo.original["ContactNo"];
          self.state.membershipStatus = rowInfo.original["Membership"];
          self.state.status = rowInfo.original["Status"].props.children; //after added a html element row select return the object,so to get the value we using props.children [<span style={{ color: "red", fontWeight: "700" }}>Deactivated</span>]-added by durga
          self.state.address = rowInfo.original["Address"];
          self.state.city = rowInfo.original["City"];
          self.state.state = rowInfo.original["State"];
          self.state.userType = rowInfo.original["UserType"];

          self.setState({
            userId: self.state.userId,
            gstIn: self.state.gstIn,
            contactNo: self.state.contactNo,
            membershipStatus: self.state.membershipStatus,
            status: self.state.status,
            userName: self.state.userName,
            emailId: self.state.emailId,
            address: self.state.address,
            city: self.state.city,
            state: self.state.state,
            userType: self.state.userType,
          })

          //console.log("list after set", self.state.userName, self.state.userId);


          this.state.rowIndexValue = rowInfo.index;
        },
        style: {
          background: rowInfo.index === this.state.selected ? '#407ad67a' : '',

        },
      }
    }
    else {
      return {
        onClick: (e, handleOriginal) => {
          if (handleOriginal) {
            handleOriginal()
          }
        },
      }
    }
  };

  /*MOVE TO VIEW PAGE WHILE VIEW ICON CLICK IS PERFORMED- IMPLEMENTED BY DURGA 18-04-2022 */
  ViewListPage() {
    var self = this;
    if (self.state.userId === undefined || self.state.userId == "") {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Kindly, Select the User! ',

      })
    }
    else {

      self.state.selected = -1; //used to de-select the row ,while view icon clicked	

      var self = this;
      self.state.isUserViewPaneOpen = true;
      //console.log("isUserViewPaneOpen", self.state.isUserViewPaneOpen);
      self.setState({
        selected: self.state.selected, //used to de-select the row ,while view icon clicked	
        isUserViewPaneOpen: self.state.isUserViewPaneOpen,
      })

    }
  }
  CloseProductView() {
    this.state.isUserViewPaneOpen = false;
    this.state.userId='';
    this.setState({
      userId:self.state.userId,
      isUserViewPaneOpen: this.state.isUserViewPaneOpen,
    })
  }
  /*MOVE TO EDIT PAGE WHILE EDIT ICON CLICK IS PERFORMED- IMPLEMENTED BY DURGA 18-04-2022 */

  EditListPage() {
    var self = this;
    //console.log("self.state", self.state);
    if (self.state.userId === undefined || self.state.userId == "") {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Kindly, Select the User! ',
        timer: 2000
      })
    }
    else {
      var self = this;
      self.state.selected = -1; //used to de-select the row ,while edit icon clicked
      self.state.isUserEditPaneOpen = true;
      //console.log("isUserEditPaneOpen", self.state.isUserEditPaneOpen);
      self.setState({
        selected: self.state.selected,
        isUserEditPaneOpen: self.state.isUserEditPaneOpen,
      })
      // ReactDOM.render(
      //   <BrowserRouter>
      //     <Routes>
      //       <Route path="/" element={<EditUser stateData={self.state} />} />
      //     </Routes>
      //   </BrowserRouter>,
      //   document.getElementById("contentRender")
      // );
    }
  }
  CloseProductEdit() {

    this.state.isUserEditPaneOpen = false;
    this.setState({
      userId:'',
      isUserEditPaneOpen: this.state.isUserEditPaneOpen,
    })
  }

 

  /*HANDLE THE STAUS BASED FILTER USED IN DROPDOWNCOMPONENTS.JS- IMPLEMENTED BY DURGA 06-04-2022 */
  StatusOnChange(e) {
    var self = this;
    //console.log(e);
    self.state.propsSelectedStatus = e;
    self.setState({ propsSelectedStatus: self.state.propsSelectedStatus })
    //console.log("propsSelectedStatus", self.state.propsSelectedStatus);
  }
  /*HANDLE THE MEMBERSHIP STAUS  BASED FILTER  USED IN DROPDOWNCOMPONENTS.JS- IMPLEMENTED BY DURGA 06-04-2022 */
  MembershipStatusOnChange(e) {
    var self = this;
    //console.log(e);
    self.state.propsSelectedMembershipStatus = e;
    self.setState({ propsSelectedMembershipStatus: self.state.propsSelectedMembershipStatus })
    //console.log("propsSelectedMembershipStatus", self.state.propsSelectedMembershipStatus);
    //console.log("propsSelectedStatus", self.state.propsSelectedStatus);
  }



  render() {


    return (
      <div class="">

        <div class="top-menus" style={{marginBottom:'3px',zIndex:'100',color:'black'}} >

          <ActiveStatusDropDown style={{color:'black'}} stateData={this.state} StatusOnChange={this.StatusOnChange} MembershipStatus={this.state.propsSelectedMembershipStatus} PopulateUserData={this.PopulateUserData} userData={userList} />

          {/* THIS DROPDOWN FOR MEMBERSHIP IMPLEMENTED BY NANDHINI - 02-05-2022 */}
          <MembershipDropdown style={{color:'black'}} stateData={this.state} MembershipStatusOnChange={this.MembershipStatusOnChange} Status={this.state.propsSelectedStatus} PopulateUserData={this.PopulateUserData} userData={userList} />



          {/* ICONS FOR ACTIVE,DEACTIVE,EDIT,VIEW IMPLEMENTED BY NANDHINI - 02-05-2022 */}

          <div class="col-md-4">
            <div className="reactIcon_Dcls">

              <ListIcons onViewUser={this.ViewListPage} onEditUser={this.EditListPage} onActivate={this.ActivateFunc} onDeactivate={this.DeactivateFunc} />
            </div>
          </div>
        </div>
        <div>
         
          {/* REACT TABLE FOR FRANCHISE DETAILS IMPLEMENTED BY NANDHINI - 02-05-2022 */}
          <div id="tableOverflow1">
            <table style={{ margin: "auto" }} class="table table-bordered" id="tableHeadings">
            </table>
          </div>

           {/* PAGINATION FOR REACT TABLE  IMPLEMENTED BY DURGA  */}
           <div >
            <Pagination
              activePage={this.state.activePage}
              itemsCountPerPage={this.state.itemsPerPage}
              totalItemsCount={this.state.totlaItemCount}
              pageRangeDisplayed={5}
              itemClass="page-item"
              linkClass="page-link"
              onChange={this.handlePageChange.bind(this)}
            /></div>


          <div style={{ marginTop: '0px' }}>
            <ReactTable style={{ overflow: "auto" }}
              data={this.state.userData}
              columns={this.state.listColumns}
              noDataText="No Data Available"
              filterable
              defaultPageSize={5}
              className="-striped -highlight react-table"
              defaultFilterMethod={(filter, row, column) => {
                const id = filter.pivotId || filter.id;
                return row[id] !== undefined
                  ? String(row[id])
                    .toLowerCase()
                    .indexOf(filter.value.toLowerCase()) !== -1
                  : true;
              }}
              showPaginationTop={true}
              showPaginationBottom={false}
              getTdProps={this.onTrRowClick}
            />

          </div>
          

         

        </div>


        {/* SLIDINGPANE FOR VIEW USER PAGE IMPLEMENTED BY NANDHINI - 02-05-2022 */}

        <SlidingPane
          className="some-custom-class"
          overlayClassName="some-custom-overlay-class"
          isOpen={this.state.isUserViewPaneOpen}
          title={"User List - View"}
          onRequestClose={() => {
            this.CloseProductView()
          }}
        >
          {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
          <ViewUser stateData={this.state} />
        </SlidingPane>

        {/* SLIDINGPANE FOR EDIT USER PAGE IMPLEMENTED BY NANDHINI - 02-05-2022 */}
        <SlidingPane
          className="some-custom-class"
          overlayClassName="some-custom-overlay-class"
          isOpen={this.state.isUserEditPaneOpen}
          title={"User List - Edit"}
          onRequestClose={() => {
            this.CloseProductEdit()
          }}
        >
          {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
          <EditUser stateData={this.state} CloseProductEdit={this.CloseProductEdit} UserListGetData={this.GetData} />
        </SlidingPane>

      </div>

    );
  }
}
export default UserList;
