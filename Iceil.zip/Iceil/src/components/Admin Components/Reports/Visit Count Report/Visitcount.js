import React, { Component, useState } from 'react';

import { Multiselect } from 'react-widgets';
import "./Visitcountcss.css";
import ReactTable from "react-table-v6";
import "react-table-v6/react-table.css"
import $, { data } from 'jquery';
import _ from 'underscore';
import moment from 'moment';
import Pagination from "react-js-pagination";

import Swal from 'sweetalert2/dist/sweetalert2.js';
import MonthYearPicker from 'react-month-year-picker';

import DatePicker from "react-datepicker";
import { GetLocalStorageData, TimeZoneDateTime } from '../../../Common Components/CommonComponents';
import { VistCountFranchiseDropDown } from '../../../Assets Components/DropdownComponents/DropdownComponent';

import "react-datepicker/dist/react-datepicker.css";

import '../../Quotation/QuotationCss.css';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class Visitcount extends Component {

  constructor() {

    super();

    this.state = {
      visitCountData: [],
      franchiseList: [],
      activePage: 1,
      totalItemsCount: 0,
      itemsCountPerPage: 5,
      startCount: 0,
      endCount: 5,
      franchiseId: "All",
      visitcountColumns: [{
        Header: "SNO",
        accessor: "SNO",
      },
      {
        Header: "Franchise",
        accessor: "Franchise",
      },
      {
        Header: "Title",
        accessor: "Title",
      },
      {
        Header: "Date",
        accessor: "Date",
      },
      {
        Header: "Visit Count",
        accessor: "Visit Count",
      },],
    }

    this.FranchiseChange = this.FranchiseChange.bind(this);
    this.PopulateTableData = this.PopulateTableData.bind(this);

  }

  componentDidMount() {

    /*
GETTING DATE & TIME FOR THE CURRENT LOGIN
- IMPLEMENTED BY PRIYANKA - 01-06-2022
*/
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    //   //console.log("dateTimeData :", dateTimeData);

    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;

    //console.log("this.state.date.split(" - ") :", this.state.date.split("-"));
    this.state.month = this.state.date.split("-")[1];
    this.state.year = this.state.date.split("-")[0];

    this.setState({
      date: this.state.date,
      time: this.state.time,
      month: this.state.month,
      year: this.state.year,
    })

    $(document).ready(function () {
      $("#monthselect").click(function () {
        $(".month-year-picker").toggleClass("active");
      });

    });

    $(document).ready(function () {
      $(".month-year-picker .month-picker > div > div").click(function () {
        $(".month-year-picker").removeClass("active");

      });

    });
    this.GetData();

  }

  /*
  FUNCTION USED FOR GETTING THE VISIT COUNT DATA
  - IMPLEMENETED BY PRIYANKA - 01-06-2022
  */
  GetData() {

    var self = this;
    self.state.franchiseList = [];
    self.state.visitCountData = [];
    self.setState({
      franchiseList: self.state.franchiseList,
      visitCountData: self.state.visitCountData,
    })

    /*console.log("GET DATA JSON DATA :", JSON.stringify({
      companyId: GetLocalStorageData("CompanyId"),
      month: this.state.month,
      year: this.state.year,
      menuId: 'Help',
      startCount: this.state.startCount,
      endCount: this.state.endCount,
    }));
    */

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("CompanyId"),
        month: this.state.month,
        year: this.state.year,
        menuId: 'Help',
        startCount: this.state.startCount,
        endCount: this.state.endCount,
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/ReportService/VisitCountReport",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //console.log("VISIT COUNT REPORT DATA : ", data);

        self.state.franchiseList = data.franchiseList;
        self.state.totalVisitCountData = data.reportDataList;
        self.state.totalItemsCount = data.dataCount;

        self.setState({
          franchiseList: self.state.franchiseList,
          totalVisitCountData: self.state.totalVisitCountData,
          totalItemsCount: self.state.totalItemsCount
        })

        window.VistCountFranchiseDropDown.PopulateDropdown(self.state.franchiseList);


        self.SetVisitCountData();

      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });

  }

  /*
    FUNCTION USED FOR SETTING THE VISIT COUNT DATA
    - IMPLEMENETED BY PRIYANKA - 01-06-2022
    */
  SetVisitCountData() {

    if (this.state.franchiseId == "All") {
      this.PopulateTableData(this.state.totalVisitCountData);
    } else {
      var visitCountData = _.where(this.state.totalVisitCountData, { franchiseId: this.state.franchiseId });
      this.PopulateTableData(visitCountData);
    }

  }

  /*
  FUNCTION USED FOR IMPLEMENTING THE CHANGES WHEN 
  A FRANCHISE IS CHANGED
  - IMPLEMENETED BY PRIYANKA - 01-06-2022
  */
  FranchiseChange(franchiseId) {

    //console.log("franchiseId :", franchiseId);

    this.state.franchiseId = franchiseId;
    this.state.visitCountData = [];
    this.setState({
      franchiseId: this.state.franchiseId,
      visitCountData: this.state.visitCountData,
    })

    this.SetVisitCountData();

  }


  /*
 FUNCTION USED FOR DISPLAYING DATA BASED ON PAGE OPTED
 IMPLEMENTED BY PRIYANKA - 01-06-2022
 */
  handlePageChange(pageNumber) {
    //console.log(`active page is ${pageNumber}`);

    this.state.activePage = pageNumber;

    var startCount = 0;
    var endCount = 0;

    if (pageNumber > 1) {
      startCount = Number(Number(pageNumber) - Number(1)) * Number(this.state.itemsCountPerPage);
      endCount = this.state.itemsCountPerPage;
      //  endCount=Number(startCount)+Number(this.state.itemsCountPerPage);
    } else {
      startCount = 0;
      endCount = this.state.itemsCountPerPage;
    }

    this.state.startCount = startCount;
    this.state.endCount = endCount;

    this.setState({
      activePage: pageNumber,
      startCount: startCount,
      endCount: startCount,
    });

      this.GetData();
    
  }

  /*
 FUNCTION USED FOR POPULATING THE TABLE DATA 
 BASED ON PAGE OPTED/FRANCHISE SELECTED/MONTH OR YEAR PICKER CHANGED
 IMPLEMENTED BY PRIYANKA - 01-06-2022
 */
  PopulateTableData(currentVisitCountData) {

    var self = this;
    var count = this.state.startCount;
    //console.log("Start Count",this.state.startCount);
    $.each(currentVisitCountData, function (i, item) {

      count = Number(count) + Number(1);
      self.state.visitCountData[i] = {
        "SNO": count,
        "Franchise": item.franchiseName,
        "Title": item.title,
        "Date": item.date,
        "Visit Count": item.visitCount
      }
    })

    self.setState({
      visitCountData: self.state.visitCountData,
    })

  }

  /*FUNCTION USED HANDLE YEAR CHANGE IN MONTH & YEAR PICKER 
  - IMPLEMENTED BY PRIYANKA 01-06-2022 */
  onChangeYear(year) {
    this.state.year = year;
    this.setState({ year: this.state.year })
    this.GetMonthData();

  }

  /*FUNCTION USED HANDLE MONTH CHANGE IN MONTH & YEAR PICKER-IMPLEMENTED BY PRIYANKA 01-06-2022 */

  onChangeMonth(month) {
    this.state.month = month;
    //console.log("onChangeMonth", month, "this.state.month", this.state.month);
    this.setState({
      month: this.state.month,
    })
    this.GetMonthData();
  }


  /* USED TO GET DATA FOR MONTH SELECTED - IMPLEMENTED BY PRIYANKA -  01-06-2022 */
  GetMonthData() {

    this.state.startCount = 0;
    this.state.endCount = 5;
    this.state.totalVisitCountData = [];

    this.GetData();
  }

  render() {
    const { data } = this.state;

    return (
      <div class="">
        <div class="toptitle">
          <h4>Visit Count</h4>
          </div>
          <div class="head_text">
          <h4>{moment(this.state.month, 'M').format('MMMM')} - {this.state.year}</h4>
        </div>
      
        <div class="top-menus">

              {/* <label for="member"> Modules</label>
              <select name="module" id="module" onChange={this.handleUserInputPaymentStatus} class="form-control">
                <option value="Technical">Technical Know-How</option>
              

              </select> */}
  <div className="site_dropstyle">
              <label class=" selectpicker" for="customerName">Month<span style={{ color: "red", fontWeight: "700" }}>*</span></label>
              {/* <input onChange={this.handleChange} class="form-control"
                  id="appointmentdate" name="appointmentDate" placeholder="Date Of Visit" value={this.state.appointmentDate}   selected={ this.state.startDate }    required /> */}
              <div>
                <input className="form-control textcolor_form" value={moment(this.state.month, 'M').format('MMMM') + " " + this.state.year} type="text" id="monthselect" />

                <MonthYearPicker
                  selectedMonth={this.state.month}
                  selectedYear={this.state.year}
                  minYear={2022}
                  maxYear={this.state.year}
                  onChangeYear={this.onChangeYear.bind(this)}
                  onChangeMonth={this.onChangeMonth.bind(this)}
                />   </div>
            </div>
                <VistCountFranchiseDropDown franchiseList={this.state.franchiseList}
              onFranchiseChnage={this.FranchiseChange} />
              <div className="" style={{marginTop: "20px"}}>
          <Pagination
            activePage={this.state.activePage}
            itemsCountPerPage={this.state.itemsCountPerPage}
            totalItemsCount={this.state.totalItemsCount}
            pageRangeDisplayed={5}
            itemClass="page-item"
            linkClass="page-link"
            onChange={this.handlePageChange.bind(this)}
          />           
          </div>
          </div>
        <div>
         
          <ReactTable style={{ overflow: "auto" }}
            data={this.state.visitCountData}
            columns={this.state.visitcountColumns}
            noDataText="No Data Available"
            filterable
            defaultPageSize={5}
            className="-highlight react-table"
            defaultFilterMethod={(filter, row, column) => {
              const id = filter.pivotId || filter.id;
              return row[id] !== undefined
                ? String(row[id])
                  .toLowerCase()
                  .indexOf(filter.value.toLowerCase()) !== -1
                : true;
            }}
            showPaginationTop={true}
            showPaginationBottom={false}
          // getTdProps={this.onTrRowClick}
          />
        </div>



      </div>
    );
  }
}
export default Visitcount;
