import React from "react";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var visibility;
class ViewProduct extends React.Component {
        constructor() {
                super();
                this.state = {
                        productCode: '',
                        productName: '',
                        priceUnit: '',
                        productType: '',
                        cgst: '',
                        igst: '',
                        sgst: '',
                        hsnCode: '',
                        description: '',
                        normal: '',
                        silver: '',
                        bronze: '',
                        gold: '',
                        platinum: '',
                        visibility: "",
                }
        }
        componentDidMount() {
             //   console.log("this.props.stateData", this.props.stateData);

            //    console.log("VISIBILITY STATUS :", this.props.stateData.visibilityStatus.props.children.props);

                if (this.props.stateData.visibilityStatus.props.children.props.negative != undefined) {
                      //  alert("NOT VISIBLE");
                        this.state.visibility = <status-indicator style={{ width: "30px", height: "30px" }} negative pulse></status-indicator>;
                } else {
                     //   alert("VISIBLE");
                        this.state.visibility = <status-indicator style={{ width: "30px", height: "30px" }} positive pulse></status-indicator>;

                }

                this.setState({
                        visibility: this.state.visibility,
                })

        }
        /*USED TO STORE INPUTFIELDS TO VIEW ONLY*/
        handleUserInput = (e) => {
                const name = e.target.name;
                const value = e.target.value;
                this.setState({ [name]: value },);
        }
        render() {
                return (
                        <div>
                                <div className="container-fluid">
                                        <div> {this.state.visibility}</div>
                                        <div className="row mt-20">
                                                <div class="col-md-3">
                                                        <label>Product Code</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Product Code */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.productCode} id="productCode" name="productCode" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Product Name</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Product Name */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.productName} id="productName" name="productName" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Price/Unit</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Price/Unit */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.rate} id="priceUnit" name="priceUnit" readOnly />
                                                        </div>
                                                </div>
                                                {/*cmd by durga-reason inside product all type will be product so*/}
                                              {/*  <div class="col-md-3">
                                                        <label>Product Type</label>
                                                        <div>
                                                                { FIELD USED TO VIEW Product Type }
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.productType}
                                                                        id="productName" name="productName" readOnly />
                                                        </div>
                                                </div>*/}
                                                <div class="col-md-3">
                                                        <label>CGST</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW CGST*/}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.cgst} id="cgst" name="cgst" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>SGST</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW SGST */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.sgst} id="sgst" name="sgst" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>IGST</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW IGST */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.igst} id="igst" name="igst" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>HSN Code</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW HSN Code */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.hsnCode} id="hsnCode" name="hsnCode" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Description</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Description */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.description} id="description" name="description" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Normal</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Normal */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.normal} id="normal" name="normal" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Silver</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Silver */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.silver} id="silver" name="silver" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Bronze</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Bronze */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.bronze} id="bronze" name="bronze" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Gold</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Gold*/}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.gold} id="gold" name="gold" readOnly />
                                                        </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <label>Platinum</label>
                                                        <div>
                                                                {/* FIELD USED TO VIEW Platinum */}
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.platinum} id="platinum" name="platinum" readOnly />
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                        </div>
                );
        };
}
export default ViewProduct;
