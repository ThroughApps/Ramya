import React from "react";
import TextField from '@mui/material/TextField';
import { ThemeProvider, createTheme } from '@mui/material/styles';


const darkTheme = createTheme({
        palette: {
          mode: 'dark',
        },
      });

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var visibility;
class ViewProduct extends React.Component {
        constructor() {
                super();
                this.state = {
                        productCode: '',
                        productName: '',
                        priceUnit: '',
                        productType: '',
                        cgst: '',
                        igst: '',
                        sgst: '',
                        hsnCode: '',
                        description: '',
                        normal: '',
                        silver: '',
                        bronze: '',
                        gold: '',
                        platinum: '',
                        visibility: "",
                }
        }
        componentDidMount() {
             //   console.log("this.props.stateData", this.props.stateData);

            //    console.log("VISIBILITY STATUS :", this.props.stateData.visibilityStatus.props.children.props);

                if (this.props.stateData.visibilityStatus.props.children.props.negative != undefined) {
                      //  alert("NOT VISIBLE");
                        this.state.visibility = <status-indicator style={{ width: "30px", height: "30px" }} negative pulse></status-indicator>;
                } else {
                     //   alert("VISIBLE");
                        this.state.visibility = <status-indicator style={{ width: "30px", height: "30px" }} positive pulse></status-indicator>;

                }

                this.setState({
                        visibility: this.state.visibility,
                })

        }
        /*USED TO STORE INPUTFIELDS TO VIEW ONLY*/
        handleUserInput = (e) => {
                const name = e.target.name;
                const value = e.target.value;
                this.setState({ [name]: value },);
        }
        render() {
                return (
                        <div>
                                <div className="container-fluid">
                                <ThemeProvider theme={darkTheme}>
                                        <div> {this.state.visibility}</div>
                                        <div className="row mt-20">
                                                <div class="col-md-4">
                                                        {/* <label>Product Code</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Product Code */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.productCode} id="productCode" name="productCode" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Product Code' onChange={this.handleUserInput} value={this.props.stateData.productCode} id="productCode" name="productCode" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Product Name</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Product Name */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.productName} id="productName" name="productName" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Product Name' onChange={this.handleUserInput} value={this.props.stateData.productName} id="productName" name="productName"  InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Price/Unit</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Price/Unit */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.rate} id="priceUnit" name="priceUnit" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Price/Unit' onChange={this.handleUserInput} value={this.props.stateData.rate} id="priceUnit" name="priceUnit" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                {/*cmd by durga-reason inside product all type will be product so*/}
                                              {/*  <div class="col-md-4">
                                                        <label>Product Type</label>
                                                        <div>
                                                                { FIELD USED TO VIEW Product Type }
                                                                <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.productType}
                                                                        id="productName" name="productName" readOnly />
                                                        </div>
                                                </div>*/}
                                                <div class="col-md-4">
                                                        {/* <label>CGST</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW CGST*/}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.cgst} id="cgst" name="cgst" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='CGST' onChange={this.handleUserInput} value={this.props.stateData.cgst} id="cgst" name="cgst" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>SGST</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW SGST */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.sgst} id="sgst" name="sgst" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='SGST' onChange={this.handleUserInput} value={this.props.stateData.sgst} id="sgst" name="sgst" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>IGST</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW IGST */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.igst} id="igst" name="igst" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='IGST'  onChange={this.handleUserInput} value={this.props.stateData.igst} id="igst" name="igst" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>HSN Code</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW HSN Code */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.hsnCode} id="hsnCode" name="hsnCode" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='HsnCode' onChange={this.handleUserInput} value={this.props.stateData.hsnCode} id="hsnCode" name="hsnCode"  InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Description</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Description */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.description} id="description" name="description" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Description'  onChange={this.handleUserInput} value={this.props.stateData.description} id="description" name="description" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Normal</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Normal */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.normal} id="normal" name="normal" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Normal'  onChange={this.handleUserInput} value={this.props.stateData.normal} id="normal" name="normal" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Silver</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Silver */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.silver} id="silver" name="silver" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Silver'  onChange={this.handleUserInput} value={this.props.stateData.silver} id="silver" name="silver" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Bronze</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Bronze */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.bronze} id="bronze" name="bronze" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Bronze'  onChange={this.handleUserInput} value={this.props.stateData.bronze} id="bronze" name="bronze" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Gold</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Gold*/}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.gold} id="gold" name="gold" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Description'   onChange={this.handleUserInput} value={this.props.stateData.gold} id="gold" name="gold" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                                <div class="col-md-4">
                                                        {/* <label>Platinum</label> */}
                                                        <div>
                                                                {/* FIELD USED TO VIEW Platinum */}
                                                                {/* <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.stateData.platinum} id="platinum" name="platinum" readOnly /> */}
                                                                 <TextField fullWidth margin="normal" size="small" label='Platinum'  onChange={this.handleUserInput} value={this.props.stateData.platinum} id="platinum" name="platinum" InputProps={{readOnly: true,}} />

                                                        </div>
                                                </div>
                                        </div>
                                        </ThemeProvider>
                                </div>
                        </div>
                );
        };
}
export default ViewProduct;
