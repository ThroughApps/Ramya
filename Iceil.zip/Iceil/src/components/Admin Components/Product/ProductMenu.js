//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import $ from "jquery";
// import statement for react class component
import ProductUpload from "./ProductUpload";
import ProductList from "./ProductList";

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022


class ProductMenu extends React.Component {
  constructor() {
    super();
    this.state = {
      productData: 'ProductList',
    }
  }

  componentDidMount() {
  //  console.log("inside did menu");

    if (this.props.pageCalledFrom != undefined) {
    //  alert("OTHER PAGE");
      if (this.props.pageCalledFrom == "ProductImportExcelResponse" || this.props.pageCalledFrom == "ProductExcelUploadResponse") {

        $(".tabs").removeClass("active");
        $(".productupload").addClass("active");
        this.state.productData = "ProductUpload";
        this.setState({
          productData: this.state.productData
        })
      }
    } else {
  //    alert("MAIN PAGE");
      $(".tabs").addClass("active");
      $(".productupload").removeClass("active");
    }
  }

  /*USED TO SHOW THE DATAS INSIDE THE PRODUCTLIST PAGE IMPLEMENTED BY RAMYA - 25-04-2022 */
  ProductList() {
    $(".tabs").removeClass("active");
    $(".productlist").addClass("active");
    this.state.productData = 'ProductList';
    this.setState({
      productData: this.state.productData
    })
   // console.log("b4 reactdom");
   
   /* ReactDOM.render(

      <BrowserRouter>
        <Routes>
          <Route path="/" element={<ProductMenu />} />
          <Route path="/" element={<ProductList />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    );
    */
  }
  /*USED TO SHOW THE DATAS INSIDE THE EXCELUPLOAD PAGE IMPLEMENTED BY RAMYA - 25-04-2022 */
  ProductUpload() {
    $(".tabs").removeClass("active");
    $(".productupload").addClass("active");
    this.state.productData = 'ProductUpload';
    this.setState({
      productData: this.state.productData
    })
   
   /* ReactDOM.render(
      <BrowserRouter>
        <Routes>

          <Route path="/" element={<ProductMenu />} />
          <Route path="/" element={<ProductUpload />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    );
    */
  }


  /*USED TO SHOW THE RENDER DATAS CONTENT  IMPLEMENTED BY RAMYA - 25-04-2022 */
  RenderComponenets(productData) {

    var self = this;

    switch (productData) {
      case 'ProductList':
      //  console.log("switch");
        return <ProductList />
      case 'ProductUpload':
        return <ProductUpload />
      default:
        return <div></div>;
    }

  }
  render() {

    return (
      <div className="">
        <div className="toptitle">
          <h3>Product</h3>
          <ul class="nav nav-tabs">
            <li class="productlist tabs"><a onClick={() => this.ProductList()}><span style={{ display: "inline-grid" }}>List</span></a></li>
            <li className="productupload tabs"><a onClick={() => this.ProductUpload()}><span style={{ display: "inline-grid" }}>Excel</span></a></li>
          </ul>
        </div>
        <div className="">
          {/* <ul class="nav nav-tabs">
            <li class="productlist tabs"><a onClick={() => this.ProductList()}><span style={{ display: "inline-grid" }}>List</span></a></li>
            <li className="productupload tabs"><a onClick={() => this.ProductUpload()}><span style={{ display: "inline-grid" }}>Excel</span></a></li>
          </ul> */}
        </div>
        {/* USED TO SHOW THE RENDERED CONTENT  IMPLEMENTED BY RAMYA - 25-04-2022  */}
        {this.RenderComponenets(this.state.productData)}
      </div>

    );
  };
}
export default ProductMenu;
