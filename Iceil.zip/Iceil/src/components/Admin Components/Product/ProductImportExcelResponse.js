//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { lazy, Component, Suspense } from 'react';
import $ from 'jquery';
import CryptoJS from 'crypto-js';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import ReactHTMLTableToExcel from 'react-html-table-to-excel';

//IMPORT CLASS COMPONENT
import ProductUpload from './ProductUpload';
import ProductMenu from './ProductMenu';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class ProductImportExcelResponse extends Component {

    constructor(errorData) {
        super(errorData)

        this.state = {

            data: [],

        }
    }

    componentDidMount() {

    //    alert("IMPORT EXCEL RESPONSE PAGE");

        /*DISPLAYING ERROR LIST AND ITS ROW NUMBER- IMPLEMENTED BY DURGA 23-04-2022 */
        var errorData = this.props.errorData;
        $("#validationmessagetable").empty();
        var tab = ' <thead><tr class="headcolor"><th class="headcolor">S.No</th><th>Errors</th></tr></thead>';
        var sno = 0;
        for (var i = 0; i < errorData.length; i++) {
            sno++;

            tab += '<tbody id= "myTable" ><tr class="" style=" background-color: white;">'
                + '<td>' + sno + '</td>'
                + '<td>' + errorData[i] + '</td></tr></tbody>';

        }

        $("#validationmessagetable").append(tab);




    }

    /*REDIRECTING TO PRODUCTUPLOAD PAGE- IMPLEMENTED BY DURGA 23-04-2022 */
    BackbtnFunc() {
        ReactDOM.render(

            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<ProductUpload />} />
                </Routes>
            </BrowserRouter>, document.getElementById('contentRender'));
    }

    /*REDIRECTING TO PRODUCTUPLOAD PAGE- IMPLEMENTED BY DURGA 23-04-2022 */
    OkFunc() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<ProductMenu pageCalledFrom={"ProductImportExcelResponse"} />} />
                    <Route path="/" element={<ProductUpload />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender"));

    }

    render() {


        return (

            <div>
                    {/* <div className="col-lg-3 col-md-3 col-sm-4 col-xs-4">
                        <ul class="previous disabled" id="backbutton"
                            style={{
                                backgroundColor: "#263eac", color: "white",
                                float: "none",
                                display: "inline-block",
                                marginLeft: "5px",
                                borderRadius: "5px",
                                padding: "3px 7px 3px 7px",
                                marginTop: "13px",
                                display: "inline-block"
                            }}>
                            <a href="#" onClick={() => this.BackbtnFunc()}><i class="arrow left"></i>Back</a></ul>

                    </div> */}
                        <div class="toptitle">
                            <h3>Validation Error Message</h3>
                    </div>
                    <div className="container-fluid">
                <div className="row">
                <p>kindly Rectify The Below Mentioned Errors For Successful File Upload</p>

                <div id="tableOverflow">
                    <table style={{ margin: "auto" }} class="table table-bordered" id="validationmessagetable">

                    </table>
<div className='text-center mt-20'>
                    <button type="button" id="okbutton" onClick={() => this.OkFunc()} className="btn btn-primary">Ok</button>
                    </div>
                </div>

            </div>
            </div>
</div>


        );
    }
}


export default ProductImportExcelResponse;
