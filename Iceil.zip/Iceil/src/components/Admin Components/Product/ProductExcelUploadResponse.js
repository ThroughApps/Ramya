//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { lazy, Component, Suspense } from 'react';
import $ from 'jquery';
import CryptoJS from 'crypto-js';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
import ProductUpload from './ProductUpload';
import ProductMenu from './ProductMenu';

//IMPORT CLASS COMPONENT

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class ProductExcelUploadResponse extends Component {

  constructor(data) {
    super()
    this.state = {

    };
  }

  componentDidMount() {

  //  alert("IMPORT EXCEL RESPONSE PAGE");

  //  console.log("alreadyExistProductCode", this.props.alreadyExistProductCode);
   // console.log("alreadyExistProductCode", this.props.excelData);

    /* BASED ON PRODUCT CODE DISPLAYING THE DATASET IN TABLE- IMPLEMENTED BY DURGA 23-04-2022 */
    var productCodes = this.props.alreadyExistProductCode;
    var count = 0;
    var data = this.props.excelData;
    //<th>Normal</th><th>Gold</th><th>Silver</th><th>Bronze</th><th>Platinum</th>
    var tab = '<thead><tr class="headcolor"><th>SNO</th><th>ProductCode</th><th>ProductName</th><th>Price/Unit</th><th>HSNCode</th><th>Description</th><th>CGST</th><th>SGST</th><th>IGST</th><th>Status</th></tr></thead>';

    $.each(productCodes, function (i, item) {
      count = Number(count) + 1;
    //  console.log('item', item, 'i', i);
      // var temp=item;
     // console.log("find", data);
      //const product =
      data.find(element => {
        // console.log("element.productCode",element.ProductCode);

        if (item === element.ProductCode.toString()) {
        //  console.log("element.ProductName", element.ProductName, "element", element);

          tab += '<tbody id= "myTable" ><tr  id="tabletextcol" ><td>' + count + '</td>'
            + '<td>' + element.ProductCode + '</td>'
            + '<td>' + element.ProductName + '</td>'
            + '<td>' + element.Rate + '</td>'
            + '<td>' + element.HSNCode + '</td>'
            + '<td>' + element.Description + '</td>'
            + '<td>' + element.CGST + '</td>' + '<td>' + element.SGST + '</td>' + '<td>' + element.IGST + '</td>'
            + '</td><td>Already Exist</td>';
          // +'<td>' + element.Normal + '</td>'+'<td>' + element.Gold + '</td>' +'<td>' + element.Silver + '</td>'
          // +'<td>' + element.Bronze + '</td>'+'<td>' + element.Platinum + '</td>' 


        }
      });


    });
    $("#excelResponse").append(tab);


  }

  /*REDIRECTING TO PRODUCTLIST PAGE- IMPLEMENTED BY DURGA 23-04-2022 */
  OkFunc() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<ProductMenu pageCalledFrom={"ProductExcelUploadResponse"} />} />
          <Route path="/" element={<ProductUpload />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender"));
  }

  render() {

    return (

      <div className="container">


        <h3 className="centerAlign" style={{ textAlign: "center" }}>Uploaded Data Response</h3>
        <p style={{ color: "red" }}>**Kindly Download The Data Report Displayed, For Your Future Reference
          using <b><q>Download</q> </b>Button</p>

        <ReactHTMLTableToExcel
          id="test-table-xls-button"
          className="download-table-xls-button"
          table="excelResponse"
          filename="ProductTable"
          sheet="tablexls"
          buttonText="Download as XLS" />

        <div id="tableOverflow">
          <table class="table" id="excelResponse">

          </table>
          <button type="button" id="okbutton" onClick={() => this.OkFunc()} className="btn btn-primary" style={{ marginLeft: "20px", marginLeft: "auto", marginRight: "auto", marginBottom: "45px", marginTop: "20px", display: "block" }}>Ok</button>


        </div>
      </div>
    );
  }

}

export default ProductExcelUploadResponse;
