//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import $ from 'jquery';
import _ from 'underscore';
import ReactDOM from 'react-dom';
import Modal from 'react-modal';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Swal from 'sweetalert2/dist/sweetalert2.js'
//import 'sweetalert2/src/sweetalert2.scss';
import * as SiIcons from 'react-icons/si';
import * as XLSX from 'xlsx';

import uploadimg from '../../images/upload_img2.png'

//IMPORT STATEMENTS FOR REACT CLASS COMPONENT
import ProductList from "./ProductList";
import {
  LengthCheckFunc, PatternCheckFunc, Truncate_2DecimalPlaces, Truncate_1DecimalPlaces
  , NumericPatternCheckFunc, AlphaNumericPatternCheckFunc
} from "../../Validation Components/FormErrors";
import ProductExcelUploadResponse from "./ProductExcelUploadResponse";
import ProductImportExcelResponse from "./ProductImportExcelResponse";
import ProductMenu from "./ProductMenu";
import { GetLocalStorageData } from "../../Common Components/CommonComponents";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  }
};

//VARAIBLES USED FOR PRODUCT- IMPLEMENTED BY DURGA 23-04-2022
var result;
var errorMessageArray = [];
var errorStatus = 0;
var url;
class ProductUpload extends React.Component {

  constructor() {
    super();

    //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 23-04-2022
    var today = new Date();
    var tempDate = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var tempTime = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
    this.state = {
      companyId: GetLocalStorageData("CompanyId"),
      date: tempDate,
      time: tempTime,
      insertvalue: false,
      updateValue: false,
      // insertProductmodalIsOpen:false,
      // closeModalinsertProduct:false,
      updateProductmodalIsOpen: false,
    }

    this.ExcelUploadInsert = this.ExcelUploadInsert.bind(this);
    this.ExcelUploadUpdate = this.ExcelUploadUpdate.bind(this);
    this.insertProduct = this.insertProduct.bind(this);
    this.updateProduct = this.updateProduct.bind(this);
    this.updatefiles=this.updatefiles.bind(this);
    this.uploadfiles=this.uploadfiles.bind(this);
    
    //  this.closeModalinsertProduct = this.closeModalinsertProduct.bind(this);

  }

  componentDidMount() {
    this.Clear();

    // $(document).ready(function () {
    //   $('#productfilesinsert').change(handleProductFile);
    //   $('#productfilesupdate').change(handleProductFileUpdate);

    // });
  }
  Clear()
  {
    errorMessageArray=[];
    errorStatus=0;
  }

  /*HANDLE THE UPLOADED EXCEL FILE-IMPLEMENTED BY DURGA 23-04-2022*/
  handleFile(e) {
    var self = this;
   // console.log("e,inside hadleproduct", e);
   // console.log("e,target id", e.target.id);
    var uploadid = e.target.id;
  //  console.log("filetype", e.target.files[0].type);

    var file = e.target.files[0];
    var fileType = e.target.files[0].type;
    errorMessageArray = [];

    var reader = new FileReader();
    //FILE TYPE RESTRICTION [CHECK THE FILE TYPE IS EXCEL OR NOT]-IMPLEMENTED BY DURGA 23-04-2022//
    if (fileType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || fileType == "application/vnd.ms-excel") {
      // $("#insertSubmit").prop("disabled", false); 


      //added by ramya-start
      let filename = document.getElementById('uploadfilename');
      let updatefilename = document.getElementById('updatefilename');
      var submitcheck = e.target.id;
      if (e.target.id == "productfilesinsert") {
        updatefilename.textContent = 'upload';
     //   console.log("insertSubmit", submitcheck);
        // $("#insertSubmit").prop("disabled", false);
        // $("#updatesubmit").prop("disabled", true);
        self.setState({ insertvalue: true, updateValue: false }) //durga-changed

      }
      else if (e.target.id == "productfilesupdate") {
        filename.textContent = 'upload';
        // $("#insertSubmit").prop("disabled", true);
        // $("#updatesubmit").prop("disabled", false);
        self.setState({ insertvalue: false, updateValue: true }) //durga-changed
      }
      else {
        // $("#insertSubmit").prop("disabled", false);
        // $("#updatesubmit").prop("disabled", false);
        self.setState({ insertvalue: true, updateValue: true })//durga-changed
      }
      //added by ramya-end



      //FILE SIZE RESTRICTION -IMPLEMENTED BY DURGA 23-04-2022//

      /*var bytes = file.size;
        console.log("size",bytes);
        if (!(bytes <= 1000000)) {
        
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: "File Size should be less than 1MB ", 
            showConfirmButton: false,
            timer: 2000
          })
        } 
    else{ */
      reader.onload = function (e) {
        var data = e.target.result;
     //   console.log("DATA : ", data);
        var binary = "";
        var bytes = new Uint8Array(e.target.result);
        var length = bytes.byteLength;
        for (var i = 0; i < length; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        /* if binary string, read with type 'binary' */

        var workbook = XLSX.read(binary, { type: 'binary' });
        // console.log("WORK BOOK : " +workbook);

        /* DO SOMETHING WITH workbook HERE */
        //   workbook.SheetNames.forEach(function (sheetName) {
        var sheetName = workbook.SheetNames[0];

        //   var workbook = XLSX.readFile('./assets/yourfile.xlsx');// ./assets is where your relative path directory where excel file is, if your excuting js file and excel file in same directory just igore that part
        var sheet_name_list = workbook.SheetNames; // SheetNames is an ordered list of the sheets in the workbook
        var data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]); //if you have multiple sheets
      //  console.log("datas", data);
        // read from a XLS file

        // get first sheet
        let first_sheet_name = workbook.SheetNames[0];
        let worksheet = workbook.Sheets[first_sheet_name];

        errorStatus = 0;

        if (data.length > 0) {
          result = data;
        //  console.log("result", result);

          for (var key in data) {

            var keyValue = key;
            keyValue = Number(keyValue) + 1; //row no  //productcode,productname,rate,unit,category
            var targetLength;
            var Length;
            //PRODUCT NAME VALIDATON //IMPLEMENTED BY DURGA 23-04-2022

            var productName = data[key]['ProductName'];
         //   console.log("productName", productName);
            // console.log("productNamelength",productName.length);

            if (productName != undefined) {
              productName = productName.toString();
              targetLength = 50;
              var lengthValidationStatus = LengthCheckFunc(productName.length, targetLength);

              if (lengthValidationStatus == true) { //removed by durga 10-05-202 to allow all type of patterns for productname

                // var patternValidationStatus = PatternCheckFunc(productName)
                // if (patternValidationStatus != true) {
                //   errorStatus++;
                //   errorMessageArray.push("Check for productName Format( Only Alphanumeric ) At Row " + keyValue);
                // }
              }
              else {
                errorStatus++;
                errorMessageArray.push("productName Exceeding the limit At Row " + keyValue);
              }
            }
            else {

              errorStatus++;
              errorMessageArray.push("productName Empty At Row " + keyValue);
            }

            //PRODUCTCODE NO VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
            var productCode = data[key]['ProductCode'];
            if (productCode != undefined) {
              productCode = productCode.toString();
              targetLength = 50;
              var lengthValidationStatus = LengthCheckFunc(productCode.length, targetLength);

              if (lengthValidationStatus == true) {
                var patternValidationStatus = AlphaNumericPatternCheckFunc(productCode)
                if (patternValidationStatus != true) {
                  errorStatus++;
                  errorMessageArray.push("Check for productCode Format( Only Alphanumeric ) At Row " + keyValue);
                }
              }
              else {
                errorStatus++;
                errorMessageArray.push("productCode Exceeding the limit At Row " + keyValue);
              }

            } else {

              errorStatus++;
              errorMessageArray.push("ProductCode Empty At Row " + keyValue);
            }


            //CATEGORY VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
            var Category = data[key]['Category'];
        //    console.log("Category", Category);

            if (Category != undefined) {
              Category = Category.toString();
              targetLength = 30;
              var lengthValidationStatus = LengthCheckFunc(Category.length, targetLength);
              if (lengthValidationStatus != true) {
                errorStatus++;
                errorMessageArray.push("Category Exceeding the limit At Row " + keyValue);
              }
            } else {

              data[key]['Category'] = "";
            }


            //DESCRIPTION VALIDATION//IMPLEMENTED BY DURGA 23-04-2022
            var Description = data[key]['Description'];
       //     console.log("Description", Description);

            if (Description != undefined) {
              Description = Description.toString()
              targetLength = 50;
              var lengthValidationStatus = LengthCheckFunc(Description.length, targetLength);
              if (lengthValidationStatus != true) {
                errorStatus++;
                errorMessageArray.push("Description  Exceeding the limit At Row " + keyValue);
              }
            }
            else{
              data[key]['Description'] = "";
            }

            //UNIT VALIDATION// IMPLEMENTED BY DURGA 23-04-2022
            var Unit = data[key]['Unit'];
          //  console.log("Unit", Unit);

            if (Unit != undefined) {
              Unit = Unit.toString();
              targetLength = 30;
              var lengthValidationStatus = LengthCheckFunc(Unit.length, targetLength);
              if (lengthValidationStatus != true) {
                errorStatus++;
                errorMessageArray.push("Unit Exceeding the limit At Row " + keyValue);
              }
            } else {
              errorStatus++;
              errorMessageArray.push("Unit Empty At Row " + keyValue);
            }

            //RATE VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
            var Rate = data[key]['Rate'];
        //    console.log("Rate", Rate);

            if (Rate != undefined) {
              Rate = Rate.toString()
              targetLength = 15;

              var lengthValidationStatus = LengthCheckFunc(Rate.length, targetLength);

              if (lengthValidationStatus == true) {
                //^[0-9]\d{0,9}(\.\d{1,3})?%?$
                //^[1-9]\d*(\.\d+)?$
                var patternValidationStatus = NumericPatternCheckFunc(Rate);
                // var patternValidationStatus=PercentageRangeCheckFunc(Rate);
                if (patternValidationStatus == true) {
                  data[key]['Rate'] = Truncate_2DecimalPlaces(Rate);
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("Check for Rate Format( Only Numeric ) At Row  " + keyValue);
                }

              }
              else {
                errorStatus++;
                errorMessageArray.push("Rate Exceeding the limit " + keyValue);
              }
            } else {

              errorStatus++;
              errorMessageArray.push("Rate Empty At Row " + keyValue);
            }

            //HSNCode VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
            var HSNCode = data[key]['HSNCode'];

            if (HSNCode != undefined) {
              HSNCode = HSNCode.toString();
              targetLength = 30;
              var lengthValidationStatus = LengthCheckFunc(HSNCode.length, targetLength);

              if (lengthValidationStatus == true) {
                var patternValidationStatus = AlphaNumericPatternCheckFunc(HSNCode)
                if (patternValidationStatus != true) {
                  errorStatus++;
                  errorMessageArray.push("Check for HSNCode Format( Only Alphanumeric ) At Row " + keyValue);
                }
              }
              else {
                errorStatus++;
                errorMessageArray.push("HSNCode Exceeding the limit " + keyValue);
              }
            } else {

              errorStatus++;
              errorMessageArray.push("HSNCode Empty At Row " + keyValue);
            }

            //CGST ID VALIDATION //IMPLEMENTED BY DURGA 23-04-2022          
            var CGST = data[key]['CGST'];

            if (CGST != undefined) {
         //     console.log("(CGST.length", CGST);
              targetLength = 6;
              //CGST=CGST.toString();//
              // Length=CGST.toString().length;
              var lengthValidationStatus = LengthCheckFunc(CGST.toString().length, targetLength);

              if (lengthValidationStatus == true) {
                if (CGST < 100) {
                  //var patternValidationStatus= PercentageRangeCheckFunc(CGST.toString());
                  var patternValidationStatus = NumericPatternCheckFunc(CGST.toString());

                  if (patternValidationStatus == true) {
                    data[key]['CGST'] = Truncate_2DecimalPlaces(CGST);
             //       console.log("data[key]['CGST']", data[key]['CGST']);
                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("CGST-Should be in the Range of 100 [Numbers & Decimals Only!] At Row" + keyValue);
                }

              }
              else {
                errorStatus++;
                errorMessageArray.push("CGST Exceeding the limit " + keyValue);
              }
            }
            else {

              data[key]['CGST'] = "0";
          //    console.log("data[key]['CGST']", data[key]['CGST']);
            }
            //SGST VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
            var SGST = data[key]['SGST'];


            if (SGST != undefined) {
              targetLength = 6;
              SGST = SGST.toString();
              var lengthValidationStatus = LengthCheckFunc(SGST.length, targetLength);

              if (lengthValidationStatus == true) {
                if (SGST < 100) {
                  var patternValidationStatus = NumericPatternCheckFunc(SGST);
                  if (patternValidationStatus == true) {
                    data[key]['SGST'] = Truncate_2DecimalPlaces(SGST);

                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("SGST-Should be in the Range of 100  Only![Numbers & Decimals] At Row" + keyValue);
                }
              }
              else {
                errorStatus++;
                errorMessageArray.push("SGST Exceeding the limit " + keyValue);
              }
            } else {

              data[key]['SGST'] = "0";
         //     console.log("data[key]['SGST']", data[key]['SGST']);

            }
            //IGST VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
            var IGST = data[key]['IGST'];


            if (IGST != undefined) {
              IGST = IGST.toString();
              targetLength = 6;
              var lengthValidationStatus = LengthCheckFunc(IGST.length, targetLength);

              if (lengthValidationStatus == true) {
                if (IGST < 100) {
                  var patternValidationStatus = NumericPatternCheckFunc(IGST);
                  if (patternValidationStatus == true) {
                    data[key]['IGST'] = Truncate_2DecimalPlaces(IGST);

                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("IGST-Should be in the Range of 100 [Numbers & Decimals Only!] At Row" + keyValue);
                }
              }
              else {
                errorStatus++;
                errorMessageArray.push("IGST Exceeding the limit " + keyValue);
              }
            } else {

              data[key]['IGST'] = "0";
            //  console.log("data[key]['IGST']", data[key]['IGST']);

            }
            //**UPDATE-EXCELUPLOAD-added columns for updateproduct excel ***//IMPLEMENTED BY DURGA 23-04-2022
            // 
            if (uploadid == "productfilesupdate") {
           //   console.log("update true");
              //VISIBILITY STATUS VALIDATION //
              var VisibilityStatus = data[key]['VisibilityStatus'];
           //   console.log("VisibilityStatus", VisibilityStatus);

              if (VisibilityStatus != undefined) {
                VisibilityStatus = (VisibilityStatus.toString()).toLowerCase();
           //     console.log("VisibilityStatus", VisibilityStatus);

              //   if (VisibilityStatus !== '0' && VisibilityStatus !== '1') {
              //     errorStatus++;
              //     errorMessageArray.push("VisibilityStatus Value NotValid At Row " + keyValue);
              //   }
              // } else {

              //   errorStatus++;
              //   errorMessageArray.push("VisibilityStatus Empty At Row " + keyValue);
              // }
              if (VisibilityStatus !== 'yes' && VisibilityStatus !== 'no')
              {
               errorStatus++;
               errorMessageArray.push("VisibilityStatus Value NotValid At Row [Only Yes/No]" + keyValue);
             }
             else
             {
               data[key]['VisibilityStatus']=0;
               
               if (VisibilityStatus == 'yes')
               {
                 data[key]['VisibilityStatus']=1;
               }
             }
           } else {

             errorStatus++;
             errorMessageArray.push("VisibilityStatus Empty At Row " + keyValue);
           }
              //NORMAL VALIDATION //
              var Normal = data[key]['Normal'];
              if (Normal != undefined) {
                Normal = Normal.toString();
                targetLength = 6;
                var lengthValidationStatus = LengthCheckFunc(Normal.length, targetLength);

                if (lengthValidationStatus == true) {
                  if (Normal < 100) {
                    var patternValidationStatus = NumericPatternCheckFunc(Normal);
                    if (patternValidationStatus == true) {
                      data[key]['Normal'] = Truncate_1DecimalPlaces(Normal);
                    }
                  }
                  else {
                    errorStatus++;
                    errorMessageArray.push("Normal-Should be in the Range of 100 [Numbers & Decimals Only!] At Row" + keyValue);
                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("Normal Exceeding the limit " + keyValue);
                }
              } else {

                data[key]['Normal'] = "0";
            //    console.log("data[key]['Normal']", data[key]['Normal']);

              }
              //Silver VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
              var Silver = data[key]['Silver'];


              if (Silver != undefined) {

                Silver = Silver.toString();
                targetLength = 6;
                var lengthValidationStatus = LengthCheckFunc(Silver.length, targetLength);

                if (lengthValidationStatus == true) {
                  if (Silver < 100) {
                    var patternValidationStatus = NumericPatternCheckFunc(Silver);
                    if (patternValidationStatus == true) {
                      data[key]['Silver'] = Truncate_1DecimalPlaces(Silver);
                   //   console.log("data[key]['Silver']", data[key]['Silver']);
                    }
                  }
                  else {
                    errorStatus++;
                    errorMessageArray.push("Silver-Should be in the Range of 100 [Numbers & Decimals Only!] At Row" + keyValue);
                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("Silver Exceeding the limit " + keyValue);
                }
              } else {

                data[key]['Silver'] = "0";
              //  console.log("data[key]['Silver']", data[key]['Silver']);

              }
              //BRONZE VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
              var Bronze = data[key]['Bronze'];
              if (Bronze != undefined) {
                targetLength = 6;
                Bronze = Bronze.toString();
                var lengthValidationStatus = LengthCheckFunc(Bronze.length, targetLength);

                if (lengthValidationStatus == true) {
                  if (Bronze < 100) {
                    var patternValidationStatus = NumericPatternCheckFunc(Bronze);
                    if (patternValidationStatus == true) {
                      data[key]['Bronze'] = Truncate_1DecimalPlaces(Bronze);
                  //    console.log("data[key]['Bronze']", data[key]['Bronze']);
                    }
                  }
                  else {
                    errorStatus++;
                    errorMessageArray.push("Bronze-Should be in the Range of 100 [Numbers & Decimals Only!] At Row" + keyValue);
                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("Bronze Exceeding the limit " + keyValue);
                }
              } else {

                data[key]['Bronze'] = "0";
             //   console.log("data[key]['Bronze']", data[key]['Bronze']);

              }
              //Gold VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
              var Gold = data[key]['Gold'];

              if (Gold != undefined) {
                targetLength = 6;
                Gold = Gold.toString();
                var lengthValidationStatus = LengthCheckFunc(Gold.length, targetLength);

                if (lengthValidationStatus == true) {
                  if (Gold < 100) {
                    var patternValidationStatus = NumericPatternCheckFunc(Gold);
                    if (patternValidationStatus == true) {
                      data[key]['Gold'] = Truncate_1DecimalPlaces(Gold);
                  //    console.log("data[key]['Gold']", data[key]['Gold']);
                    }
                  }
                  else {
                    errorStatus++;
                    errorMessageArray.push("Gold-Should be in the Range of 100 [Numbers & Decimals Only!] At Row" + keyValue);
                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("Gold Exceeding the limit " + keyValue);
                }
              } else {

                data[key]['Gold'] = "0";
             //   console.log("data[key]['Gold']", data[key]['Gold']);

              }
              //Platinum VALIDATION //IMPLEMENTED BY DURGA 23-04-2022
              var Platinum = data[key]['Platinum'];

            //  console.log("platinum", Platinum);
              if (Platinum != undefined) {
                targetLength = 6;
                Platinum = Platinum.toString();
             //   console.log("platinum", Platinum.length);
                var lengthValidationStatus = LengthCheckFunc(Platinum.length, targetLength);

                if (lengthValidationStatus == true) {
                  if (Platinum < 100) {
                    var patternValidationStatus = NumericPatternCheckFunc(Platinum);
                    if (patternValidationStatus == true) {
                      data[key]['Platinum'] = Truncate_1DecimalPlaces(Platinum);
                //      console.log("data[key]['Platinum']", data[key]['Platinum']);
                    }
                  }
                  else {
                    errorStatus++;
                    errorMessageArray.push("Platinum-Should be in the Range of 100 [Numbers & Decimals Only!] At Row" + keyValue);
                  }
                }
                else {
                  errorStatus++;
                  errorMessageArray.push("Platinum Exceeding the limit " + keyValue);
                }
              } else {

                data[key]['Platinum'] = "0";
           //     console.log("data[key]['Platinum']", data[key]['Platinum']);

              }

            }
            else {
           //   console.log("update false");
            }

          //  console.log("end of loop");

          }
     //     console.log("error status", errorStatus);
          // if (errorStatus == 0) {
          //   //PROCEED WITH UPLOAD ENABLE THE SUBMIT BUTTON
          // }
          if (errorStatus !== 0) {
           // console.log("inside");
            //SHOW THE VALIDATION ERROR MESSAGES IN SEPARATE PAGE-IMPLEMENTED BY DURGA 23-04-2022
            ReactDOM.render(
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<ProductImportExcelResponse errorData={errorMessageArray} />} />
                </Routes>
              </BrowserRouter>, document.getElementById('contentRender'));
          }

        }
        else {
       //   console.log("target id", submitcheck);

          if (submitcheck == "productfilesinsert") {
            self.setState({ insertvalue: false })
          }
          else if (submitcheck == "productfilesupdate") {

            self.setState({ updateValue: false })
          }
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'An Empty File cannot be Uploaded',
            showConfirmButton: false,
            timer: 2000
          })

        }
      };
      reader.readAsArrayBuffer(file);
    }
    else {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: "You Have Uploaded An Invalid File Type,Please Upload A Valid FileType ",
        showConfirmButton: false,
        timer: 2000
      })
    }

  }
  //**UPDATE-EXCELUPLOAD-DYNAMICALLY SETTING THE URL WHILE EXCELUPLOAD FUNC IS PERFORMED**//IMPLEMENTED BY DURGA 23-04-2022                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       **//
  ExcelUploadUpdate(e) {
    url = "http://15.206.129.105:8080/IceilLiveAPI/ProductWebService/UpdateProductDetails";
    this.ExcelUpload();
  }
  //**INSERT-EXCELUPLOAD-DYNAMICALLY SETTING THE URL WHILE EXCELUPLOAD FUNC IS PERFORMED **//IMPLEMENTED BY DURGA 23-04-2022
  ExcelUploadInsert(e) {

    url = "http://15.206.129.105:8080/IceilLiveAPI/ProductWebService/AddProductDetails";
    this.ExcelUpload();
  }


  /*USED TO INSERT OR UPDATE PRODUCT LIST - THE PRODUCT EXCEL IS CONVERTED AS DATA */ //IMPLEMENTED BY DURGA 23-04-2022 
  ExcelUpload() {

    var self = this;
  //  console.log("productNameList", result);
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: self.state.companyId,
        productNameList: JSON.stringify(result),
        date: self.state.date,
        time: self.state.time,
        recentDate: self.state.date,
        recentTime: self.state.time
      }),
      // url: "http://15.206.129.105:8080/IceilLiveAPI/ProductWebService/AddProductDetails",
      url: url,
      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {
    //    console.log(data);
        if(data.response=="insert or update success")
        {
          let uploadfilename = document.getElementById('uploadfilename');
          uploadfilename.textContent = "upload";
          let updatefilename = document.getElementById('updatefilename');
          updatefilename.textContent = "upload";
          self.setState({ insertvalue: false, updateValue: false })
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Your File Has Been Uploaded Successfully',
            showConfirmButton: false,
            timer: 2000
          })

          ReactDOM.render(
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<ProductMenu />} />
                <Route path="/" element={<ProductList />} />
              </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender"));

          //*THE SERVER SIDE RESPONSE PAGE CALLING CODE TO DISPLAY LIST OF ALREADY EXIST PRODUCT */cmd by durga-11-05-2022
         /* if (data.alreadyExistProductCode.length != 0) {

            console.log("data after update", data.alreadyExistProductCode);
  
            ReactDOM.render(
              //SHOW THE LIST OF ALREADY EXIST PRODUCT DETAILS IN SEPARATE PAGE-IMPLEMENTED BY DURGA 23-04-2022//
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<ProductExcelUploadResponse alreadyExistProductCode={data.alreadyExistProductCode} excelData={result} />} />
                </Routes>
              </BrowserRouter>,
              document.getElementById("contentRender"));
  
  
          } */
        }  

      },
      error: function (data) {

        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })



      },
    });


  }
  /*
 FUNCTION USED TO GET THE EXCELFILE NAME FOR INSERT FILE
 - IMPLEMENTED BY RAMYA - 20-04-2022
 */
  Insert(e) {
    let filename = document.getElementById('uploadfilename');
    let uploadfilename = e.target.files[0].name;
    filename.textContent = uploadfilename;
    this.handleFile(e);
    //this.ClearFunc();
  }
  /*
  FUNCTION USED TO GET THE EXCELFILE NAME FOR UPDATE FILE
  - IMPLEMENTED BY RAMYA - 20-04-2022
  */
  Update(e) {
    let updatefilename = document.getElementById('updatefilename');
    let updatefile = e.target.files[0].name;
    updatefilename.textContent = updatefile;
    this.handleFile(e);
    //this.ClearFunc();
  }
  /*
  FUNCTION USED TO GET THE CHOOSE FILE OPTION IN INSERT
  - IMPLEMENTED BY RAMYA - 20-04-2022
  */
  uploadfiles() {
    var self=this;
    document.getElementById("productfilesinsert").click();
    let updatefilename = document.getElementById('updatefilename');
    updatefilename.textContent = "upload";
    self.setState({ insertvalue: false, updateValue: true })
  }
  /*
  FUNCTION USED TO GET THE CHOOSE FILE OPTION FOR UPDATE
  - IMPLEMENTED BY RAMYA - 20-04-2022
  */
  updatefiles() {
    var self=this;
    document.getElementById("productfilesupdate").click();
    let uploadfilename = document.getElementById('uploadfilename');
    uploadfilename.textContent = "upload";
    self.setState({ insertvalue: true, updateValue: false })
  }
  /*
FUNCTION USED TO OPEN THE POPUP FOR INSERTPRODUCT INFORMATION TO BE NOTED
- IMPLEMENTED BY RAMYA - 07-05-2022
*/
  insertProduct() {
    var self = this;
    self.state.insertProductmodalIsOpen = true;
    self.setState({
      insertProductmodalIsOpen: self.state.insertProductmodalIsOpen
    })
  }
  updateProduct() {
    var self = this;
    self.state.updateProductmodalIsOpen = true;
    self.setState({
      updateProductmodalIsOpen: self.state.updateProductmodalIsOpen
    })
  }
  /*
FUNCTION USED TO CLOSE THE POPUP FOR INSERTPRODUCT INFORMATION TO BE NOTED
- IMPLEMENTED BY RAMYA - 07-05-2022
*/
  // closeModalinsertProduct(){
  //         var self = this;
  //         self.state.insertProductmodalIsOpen = false;
  //         self.setState({
  //             insertProductmodalIsOpen: self.state.insertProductmodalIsOpen,
  //         })
  //     }
  closeModalinsert() {
    var self = this;

    self.state.insertProductmodalIsOpen = false;
    self.state.closeModalinsertProduct = true;
    self.setState({
      insertProductmodalIsOpen: self.state.insertProductmodalIsOpen,
      closeModalinsertProduct: self.state.closeModalinsertProduct
    })
  }
  closeModalupdate() {
    var self = this;

    self.state.updateProductmodalIsOpen = false;
    self.state.closeModalupdateProduct = true;
    self.setState({
      updateProductmodalIsOpen: self.state.updateProductmodalIsOpen,
      closeModalupdateProduct: self.state.closeModalupdateProduct
    })
  }
  render() {

    return (
      <div className="">
        <div className="container-fluid">
          <div className="container">
            <div className="row">
              <div className="col-md-6">
                <div className="text-center">
                  <h5 onClick={() => this.insertProduct()}>Insert Product <i class="fa fa-info-circle" aria-hidden="true"></i></h5>
                </div>
                <div class="image-wrapper">
                  {/* Field used to insert product - it's mandatory field  onChange={this.ExcelUpload}  accept="image/png, image/jpeg"  */}
                  <div class="text-center upload__image-wrapper"><div class="">
                    <a class="uploadicon" onClick={() => this.uploadfiles()} style={{color:'white'}}>
                      {/* <SiIcons.SiMicrosoftexcel /> */} <img src={uploadimg} style={{width:'100px'}} />
                      {/* <input type="file" id="productfiles" style={{display: "none"}}  /> <p className="uploadtext">Upload</p></a></div> */}
                      <input type="file" id="productfilesinsert" style={{ display: "none" }} onChange={(e) => this.Insert(e)} /><p id="uploadfilename">Upload</p></a></div>
                    {/* <input type="file" id="customerfiles" name="files" /> */}
                    <button id="insertSubmit" class="btn btn-primary btn-submit " disabled={!this.state.insertvalue} onClick={this.ExcelUploadInsert}>Submit</button>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="text-center">
                  <h5 onClick={() => this.updateProduct()} style={{color:'white'}}>Update Product  <i class="fa fa-info-circle" aria-hidden="true"></i></h5>
                </div>
                <div class="image-wrapper">
                  {/* Field used to insert product - it's mandatory field */}
                  <div class="text-center upload__image-wrapper"><div class="">
                    <a class="uploadicon" onClick={this.updatefiles}style={{color:'white'}}>
                      {/* <SiIcons.SiMicrosoftexcel /> */} <img src={uploadimg} style={{width:'100px'}} />
                      <input type="file" id="productfilesupdate" style={{ display: "none" }} onChange={(e) => this.Update(e)} /><p id="updatefilename">Upload</p>
                    </a></div>
                    <button class="btn btn-primary btn-submit " disabled={!this.state.updateValue} onClick={this.ExcelUploadUpdate}>Submit</button></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Modal
          isOpen={this.state.insertProductmodalIsOpen}
          //  onAfterOpen={this.customerafterOpenModal}
          onRequestClose={this.state.closeModalinsertProduct}
          style={customStyles}
          contentLabel="Example Modal"
        >
          <div className="container" style={{background:'#233044',color:'white'}}>
            <h3>Insert Product</h3>
            <p>1. New products will be added into the system</p>
            <p>2. Existing products information like ProductName, Price/Unit, Type, CGST (%), SGST (%), IGST (%), Category, HSN Code, Description will be updated automaticall</p>
            <p>3. The unique parameter check is done for theproduct code</p>
            <p><span className="mandatoryfields">Mandatory Fields :</span> Product Code , ProductName, Price/Unit, HSN Code</p>
            <div class="text-center">
              <button type="button" class="btn-default " onClick={() => this.closeModalinsert()}
                style={{
                  borderRadius: "4px",
                  backgroundColor: "#4782da",
                  color: "white",
                  width: "75px",
                  marginTop: "20px"
                }}

              >
                <span class="glyphicon glyphicon-ok" style={{ fontWeight: "800" }} ></span> Ok
              </button>
            </div>
          </div>
        </Modal>
        <Modal
          isOpen={this.state.updateProductmodalIsOpen}
          //  onAfterOpen={this.customerafterOpenModal}
          onRequestClose={this.state.closeModalupdateProduct}
          style={customStyles}
          contentLabel="Example Modal"
        >
          <div className="container" style={{background:'#233044',color:'white'}}>
            <h3>update product</h3>
            <p>1. Download the product information as Excel from the system (use the download option available in product list)</p>
            <p>2. Products information like ProductName, Price/Unit, Type, CGST (%), SGST (%), IGST (%), Category, HSN Code, Description, Visibility (toggle button), Membership (at last add as a separate section with five text boxes like Normal (%), Bronze (%), Silver (%), Gold (%), Platinum (%) will be updated</p>
            <p>3. The unique parameter check is done for the product code</p>
            <p><span className="mandatoryfields">Mandatory Fields :</span> Product Code , ProductName, Price/Unit, HSN Code</p>
            <div class="text-center">
              <button type="button" class="btn-default " onClick={() => this.closeModalupdate()}
                style={{
                  borderRadius: "4px",
                  backgroundColor: "#4782da",
                  color: "white",
                  width: "75px",
                  marginTop: "20px"
                }}

              >
                <span class="glyphicon glyphicon-ok" style={{ fontWeight: "800" }} ></span> Ok
              </button>
            </div>
          </div>
        </Modal>

      </div>
    );
  };

}
export default ProductUpload;
