//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import $ from 'jquery';
import ReactTable from "react-table-v6";
import SlidingPane from "react-sliding-pane";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
import "../../Assets Components/Icon Components/Pagination.css"
// import statement for react class component
//import {ProductListIcons} from '../../Assets Components/Icon Components/iconcomponents';
import { ProductListIcons, Product_xlDownldBtn } from '../../Assets Components/Icon Components/Iconcomponents';
//import 'sweetalert2/src/sweetalert2.scss';
import ViewProduct from './ViewProduct';
// import statement for react component css
import "react-sliding-pane/dist/react-sliding-pane.css";
import "react-table-v6/react-table.css"
import Pagination from "react-js-pagination";
import _ from 'underscore';
import * as XLSX from 'xlsx';
import { GetLocalStorageData } from "../../Common Components/CommonComponents";
import './ProductListCSS.css';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var productList;
var tableProductListDta;
var dataCount = 0;
var dataCountArray = [];
var itemData = 1;
var pageArray = [];
var pageData_Status;
var xlsRows = [];

class ProductList extends React.Component {
  constructor() {
    super();
    this.state = {
      isProductViewPaneOpen: false,
      totlaItemCount: 0,
      itemsPerPage: 10,
      activePage: 1,
      selected: -1,
      productData: [],
      columns: [
        {
          Header: 'SNO',
          accessor: 'SNO'
        },
        {
          Header: 'Visibility',
          accessor: 'Visibility'
        },
        {
          Header: 'ProductCode',
          accessor: 'ProductCode'
        },
        {
          Header: 'ProductName',
          accessor: 'ProductName'
        },
        {
          Header: 'Rate',
          accessor: 'Rate'
        },
        // {
        //   Header: 'Type',
        //   accessor: 'Type'
        // }, //by durga-reason inside product all type will be product so
        {
          Header: 'CGST',
          accessor: 'CGST'
        },
        {
          Header: 'SGST',
          accessor: 'SGST'
        },
        {
          Header: 'IGST',
          accessor: 'IGST'
        },
        {
          Header: 'HSNCode',
          accessor: 'HSNCode'
        }
        ,
        {
          Header: 'Description',
          accessor: 'Description'
        },
        {
          Header: 'Normal',
          accessor: 'Normal'
        },
        {
          Header: 'Silver',
          accessor: 'Silver'
        }
        ,
        {
          Header: 'Bronze',
          accessor: 'Bronze'
        },
        {
          Header: 'Gold',
          accessor: 'Gold'
        }
        ,
        {
          Header: 'Platinum',
          accessor: 'Platinum'
        }
      ],
    }
    this.viewProduct = this.viewProduct.bind(this);
    this.DownloadProduct = this.DownloadProduct.bind(this);
    this.GenerateExcel = this.GenerateExcel.bind(this);
  }
  /* USED TO HANDLE THE PAGINATION- IMPLEMENTED BY DURGA 22-04-2022 */
  handlePageChange(pageNumber) {

    this.state.activePage = pageNumber;
    this.setState({ activePage: pageNumber });

    var self = this;


    pageData_Status = false;
    pageData_Status = _.contains(pageArray, this.state.activePage);

    dataCount = 0;
    self.state.oldPageAcces = "false";
    self.setState({
      oldPageAcces: self.state.oldPageAcces
    });

    if (pageData_Status == false) {

      pageArray.push(pageNumber);
      dataCount = Math.round((Number(dataCount)) + ((Number(pageNumber) - 1) * 10));
      dataCountArray.push(dataCount);

    } else if (pageData_Status == true) {

      var currentPageIndex = _.indexOf(pageArray, this.state.activePage);
      dataCount = dataCountArray[currentPageIndex];

    }
    this.getData();
  }

  /* USED TO GET THE PRODUCT LIST DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 22-04-2022 */
  getData() {

    var self = this;
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("CompanyId"),
        dataCount: dataCount,
        totlaItemCount: this.state.totalItemCount,
      }),
      url: "http://15.206.129.105:8080/IceilLiveAPI/ProductWebService/SelectProductDetails",
      contentType: "application/json",
      dataType: 'json',
      async: false,

      success: function (data, textStatus, jqXHR) {

     //   console.log("data", data);

        productList = data.productList;
     //   console.log(productList);
        if (data.productList !== null && data.productList.length != 0) {
          var no = 0;
          if (itemData == "1") {
            self.state.totlaItemCount = data.totlaItemCount;

            itemData = Number(itemData) + 1;
          }

        } else {
          itemData = "1";
          self.state.totlaItemCount = 0;
        }


        self.PopulateProductData(productList);
      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      },
    });
  }
  GetColumns() {

    return Object.keys(this.state.productData[0]).map(key => {

      return {
        Header: key,
        accessor: key,

      };

    });
  }

  /* USED TO POPULATE PRODUCT LIST INTO TABLE- IMPLEMENTED BY DURGA 22-04-2022 */
  PopulateProductData(productList) {
    var self = this;
    var count = dataCount;
 //   console.log("populate data");
    self.state.productData = [];

  
    $.each(productList, function (i, item) {

      count = Number(count) + 1;

      var visibility = <center><status-indicator positive pulse></status-indicator></center>;

      if (item.visibilityStatus == '0') {
        visibility = <center><status-indicator negative pulse></status-indicator></center>;
      }

      self.state.productData[i] = {
        "SNO": count,
        "Visibility": visibility,
        "ProductCode": item.productCode,
        "ProductName": item.productName,
        "Rate": item.rate,
        "HsnCode": item.hsnCode,
        "Description": item.description,
        "Date": item.date,
        "Time": item.time,
        "CGST": item.cgst,
        "IGST": item.igst,
        "SGST": item.sgst,
        "HSNCode": item.hsnCode,
        "Normal": item.normal,
        "Gold": item.gold,
        "Silver": item.silver,
        "Bronze": item.bronze,
        "Platinum": item.platinum,
      }
    });

    self.state.columns = this.GetColumns();

    self.setState({

      TableColumns: self.state.columns,
      productData: self.state.productData,
    });


  }

  //SelectProductDetails
  /*USED TO VIEW THE STORED PRODUCT LIST IN SLIDEPANE */
 /*USED TO VIEW THE STORED PRODUCT LIST IN SLIDEPANE */
  viewProduct() {
    var self = this;
    if (self.state.productCode === undefined || self.state.productCode == "") {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Kindly, Select the Product! ',

      })
    }
    else {

      self.state.isProductViewPaneOpen = true;
    //  console.log("isProductViewPaneOpen", self.state.isProductViewPaneOpen);
      self.setState({
        isProductViewPaneOpen: self.state.isProductViewPaneOpen,
      })
    }
  
  }

  /*USED TO CLOSE THE SLIDEPANE VIEW PRODUCT LIST */
  CloseProductView() {

    this.state.selected = -1;
    this.state.isProductViewPaneOpen = false;
    this.state.selected = -1;
    this.state.productCode="";
  
    this.setState({
      productCode: this.state.productCode,
      isProductViewPaneOpen: this.state.isProductViewPaneOpen,
      selected: this.state.selected
    })
    
  }
  componentDidMount() {


    dataCount = 0;
    dataCountArray = [];
    itemData = 1;
    pageArray = [];

    dataCountArray.push(0);
    pageArray.push(1);

    $("#tableOverflow1").hide();

    $("ReactHTMLTableToExcel").css("background-color", "#00305B");
    $(".btn-default").css("background-color", " #00305B");
    $(".btn-default").css("color", "white");
    $("ReactHTMLTableToExcel").css("color", "white");
    this.setState({
      columns: this.state.columns
    })

    this.getData();

  }

  /* HANDLE ROW SELECTION-USED TO STORE THE SELECTED ROW DATAS [IN TABLE WHILE SELECTING THE ROW]- IMPLEMENTED BY DURGA 22-04-2022 */
  onTrRowClick = (state, rowInfo, column, instance) => {
    var self = this;

    if (typeof rowInfo !== "undefined") {
      return {
        onClick: (e, handleOriginal) => {
          this.setState({
            selected: rowInfo.index
          });
          if (handleOriginal) {
            handleOriginal()
          }

          self.state.productCode = rowInfo.original["ProductCode"];
          self.state.productName = rowInfo.original["ProductName"];
          self.state.rate = rowInfo.original["Rate"];
          self.state.hsnCOde = rowInfo.original["HsnCode"];
          self.state.description = rowInfo.original["Description"];
          self.state.visibilityStatus = rowInfo.original["Visibility"];
          self.state.date = rowInfo.original["Date"];
          self.state.time = rowInfo.original["Time"];

          self.state.igst = rowInfo.original["IGST"];
          self.state.sgst = rowInfo.original["SGST"];
          self.state.cgst = rowInfo.original["CGST"];
          self.state.hsnCode = rowInfo.original["HSNCode"];

          self.state.normal = rowInfo.original["Normal"];
          self.state.gold = rowInfo.original["Gold"];
          self.state.silver = rowInfo.original["Silver"];
          self.state.bronze = rowInfo.original["Bronze"];
          self.state.platinum = rowInfo.original["Platinum"];

          self.setState({
            igst: self.state.igst,
            sgst: self.state.sgst,
            cgst: self.state.cgst,
            hsnCode: self.state.hsnCode,
            productCode: self.state.productCode,
            productName: self.state.productName,
            rate: self.state.rate,
            visibilityStatus: self.state.visibilityStatus,
            hsnCode: self.state.hsnCode,
            date: self.state.date,
            time: self.state.time,
            normal: self.state.normal,
            gold: self.state.gold,
            bronze: self.state.bronze,
            silver: self.state.silver,
            platinum: self.state.platinum,
          })

          this.state.rowIndexValue = rowInfo.index;
        },
        style: {
          background: rowInfo.index === this.state.selected ? '#407ad67a' : ' ',
        },
      }
    }
    else {
      return {
        onClick: (e, handleOriginal) => {
          if (handleOriginal) {
            handleOriginal()
          }
        },
        style: {

        },
      }
    }
  };


  /*
  FUNCTION USED FOR GETTING THE DATA OF THE PRODUCT LIST
  TO BE DOWNLOADED
  IMPLEMENTED BY PRIYANKA - 07-05-2022
  */
  DownloadProduct() {

    var self = this;
    var xlsRows = [];

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("CompanyId"),
      }),
      url: "http://15.206.129.105:8080/IceilLiveAPI/ProductWebService/DownloadProductDetails",
      contentType: "application/json",
      dataType: 'json',
      async: false,

      success: function (data, textStatus, jqXHR) {

      //  console.log("data", data);

        var count = 0;
        if (data.productList.length > 0) {

          $.each(data.productList, function (i, item) {

            var visibility = "Yes";
            count = Number(count) + Number(1);
            if (item.visibilityStatus == '0') {
              visibility = "No";
            }

            xlsRows.push(count);
            xlsRows.push(item.productCode);
            xlsRows.push(item.productName);
            xlsRows.push(item.hsnCode);
            xlsRows.push(item.unit);
            xlsRows.push(item.rate);
            xlsRows.push(item.cgst);
            xlsRows.push(item.sgst);
            xlsRows.push(item.igst);
            xlsRows.push(item.description);
            xlsRows.push(visibility);
            xlsRows.push(item.normal);
            xlsRows.push(item.bronze);
            xlsRows.push(item.silver);
            xlsRows.push(item.gold);
            xlsRows.push(item.platinum);

            xlsRows.push("+");
          });

          self.GenerateExcel(xlsRows);
        } else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'No data',
            showConfirmButton: false,
            timer: 2000
          })
        }

      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })
      },
    });

  }


  /*
  FUNCTION USED FOR GENERATING & DOWNLOADING THE PRODUCT LIST
  IMPLEMENTED BY PRIYANKA - 07-05-2022
  */
  GenerateExcel(xlsRows) {


    var createXLSLFormatObj = [];
    var emptyRowData = [];
    var indexValue = 0;


    // var xlsHeaderMain = ["PRODUCT LIST"];
    // createXLSLFormatObj.push(xlsHeaderMain);

    // createXLSLFormatObj.push(emptyRowData);
    // createXLSLFormatObj.push(emptyRowData);

    /* XLS Head Columns */
    var xlsHeader = ["S.NO", "ProductCode", "ProductName",
      "HSNCode", "Unit", "Rate", "CGST", "SGST",
      "IGST", "Description", "VisibilityStatus", "Normal",
      "Bronze", "Silver", "Gold", "Platinum"];

    createXLSLFormatObj.push(xlsHeader);

    var listInnerRowData = [];

    for (var z = 0; z < xlsRows.length; z++) {

      if (xlsRows[z] != "+") {
        listInnerRowData.push(xlsRows[z]);
      } else {
        createXLSLFormatObj.push(listInnerRowData);
        listInnerRowData = [];
      }

    }

    /* File Name */
    var filename = "ProductList" + ".xlsx";

    /* Sheet Name */
    var ws_name = "ProductSheet";

    var wb = XLSX.utils.book_new(),
      ws = XLSX.utils.aoa_to_sheet(createXLSLFormatObj);

    var newIndexValue = Number(indexValue) + 1;
    newIndexValue = Number(newIndexValue) / 15;
    newIndexValue = Math.round(newIndexValue);
    newIndexValue = Number(newIndexValue) + 3;



    /* merge cells A1:B1 */
  //   var merge = { s: { r: 0, c: 0 }, e: { r: 0, c: 28 } };

  //   /* merge cells A1:B1 */
  // //  var merge1 = { s: { r: newIndexValue, c: 0 }, e: { r: newIndexValue, c: 35 } };

  //   /* add merges */
  //   if (!ws['!merges']) ws['!merges'] = [];
  //   ws['!merges'].push(merge);

    /* add merges */
   /* if (!ws['!merges']) ws['!merges'] = [];
    ws['!merges'].push(merge1);
    */

    var xlsHeader = ["S.NO", "ProductCode", "ProductName",
      "HSNCode", "Unit", "Rate", "CGST", "SGST",
      "IGST", "Description", "VisibilityStatus", "Normal",
      "Bronze", "Silver", "Gold", "Platinum"];

    /* set column width */
    var wscols = [
      { wch: 10 }, //sno
      { wch: 20 }, //productcode
      { wch: 50 }, //productname
      { wch: 15 }, //hsn_code
      { wch: 15 }, //unit
      { wch: 25 }, //rate
      { wch: 25 }, //CGST
      { wch: 15 }, //SGST
      { wch: 15 }, //IGST
      { wch: 20 }, //Description
      { wch: 10 }, //visibility
      { wch: 10 }, //normal
      { wch: 10 }, //bronze
      { wch: 10 }, //silver
      { wch: 10 }, //gold
      { wch: 10 }, //platinum

      , { hidden: true }, // hide column,

    ];

    /* set row height */
    var wsrows = [
      { hpt: 25 }, // "points"
      //	{hpx: 16}, // "pixels"
      ,
      //	{hpx: 24, level:3},
      //	{hidden: true}, // hide row
      //	{hidden: false}
    ];

    /*add column width */
    ws['!cols'] = wscols;

    /* add row height */
    ws['!rows'] = wsrows;

    /* Add worksheet to workbook */
    XLSX.utils.book_append_sheet(wb, ws, ws_name);

    /* Write workbook and Download */
    XLSX.writeFile(wb, filename, { cellStyles: true });

  }


  render() {
    return (
      <div>
        <div className="">
          <div className=" top-menus">
              <ProductListIcons onViewProduct={this.viewProduct} onDownloadProduct={this.DownloadProduct} />
            <Pagination
              activePage={this.state.activePage}
              itemsCountPerPage={this.state.itemsPerPage}
              totalItemsCount={this.state.totlaItemCount}
              pageRangeDisplayed={5}
              itemClass="page-item"
              linkClass="page-link"
              onChange={this.handlePageChange.bind(this)}
            />
 </div>
            <ReactTable style={{ overflow: "auto" }}
              data={this.state.productData}
              columns={this.state.columns}
              noDataText="No Data Available"
              filterable
              defaultPageSize={5}
              className="-striped -highlight react-table"
              defaultFilterMethod={(filter, row, column) => {
                const id = filter.pivotId || filter.id;
                return row[id] !== undefined
                  ? String(row[id])
                    .toLowerCase()
                    .indexOf(filter.value.toLowerCase()) !== -1
                  : true;
              }}
              showPaginationTop={true}
              showPaginationBottom={false}
              getTrProps={this.onTrRowClick}
            />
         

          {/* <div style={{ marginBottom: "3%" }} className="pull-right" id="paginationdiv">
            <Pagination
              activePage={this.state.activePage}
              itemsCountPerPage={this.state.itemsPerPage}
              totalItemsCount={this.state.totlaItemCount}
              pageRangeDisplayed={5}
              itemClass="page-item"
              linkClass="page-link"
              onChange={this.handlePageChange.bind(this)}
            /></div> */}
        </div>
        <SlidingPane
          className="some-custom-class"
          overlayClassName="some-custom-overlay-class"
          isOpen={this.state.isProductViewPaneOpen}
          title={"Product List - View"}
          // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
          onRequestClose={() => {
            // triggered on "<" on left top click or on outside click
            // setState({ isPaneOpen: false });  SetViewData={this.SetEstimateTableData}
            this.CloseProductView()
          }}
        >
          <ViewProduct stateData={this.state} CancelClicked={this.CloseProductView} /> {/* addded by durga*/}
        </SlidingPane>





      </div>
    );
  };
}
export default ProductList;
