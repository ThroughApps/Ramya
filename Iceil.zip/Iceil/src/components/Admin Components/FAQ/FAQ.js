import React, { Component } from 'react';
import CreatableSelect from 'react-select/creatable';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import TextField from '@mui/material/TextField';
import ReactDOM from 'react-dom';
import { ErrorClass } from '../../Validation Components/Loginvalidation';
import _ from 'underscore';
import $ from 'jquery';
import moment from 'moment';
import { CapitalCaseFunc, GetLocalStorageData, TimeZoneDateTime } from '../../Common Components/CommonComponents';
// import datepicker from 'jquery-ui/ui/widgets/datepicker';
import { ThemeProvider, createTheme } from '@mui/material/styles';


const darkTheme = createTheme({
  palette: {
    mode: 'dark',
  },
});

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

const customStyles_Dropdown = {
  control: (base, state) => ({
    ...base,
    background: "transparent",

    //   borderRadius: state.isFocused ? "3px 3px 0 0" : 3,
    //   borderColor: state.isFocused ? "yellow" : "green",
    boxShadow: state.isFocused ? null : null,
    //   "&:hover": {
    //     borderColor: state.isFocused ? "red" : "blue"
    //   }
  }),
  menu: (base) => ({
    ...base,
    borderRadius: 0,
    marginTop: 0
  }),
  menuList: (base) => ({
    ...base,
    padding: 0
  })
};

class FAQ extends Component {
  constructor(props) {
    super(props)
    this.state = {
      question: '',
      answer: '',
      selectedMenu: '',
      moduleList: [],
      moduleName: '',
      moduleId: '',
      selectedModule: [],
      moduleListOptions: [],

      formErrors: {
        question: '',
        answer: '',
        selectedModule: '',
      },
      questionValid: false,
      answerValid: false,
      selectedModuleValid: false,


    }
    this.PopulateDropdownData = this.PopulateDropdownData.bind(this);
  }

  /*
THIS FUNCTION LOADS IMMEDIATLY AFTER THE PAGE IS LOADED
 IMPLEMENTED BY PRIYANKA ON 13-05-2022
*/
  componentDidMount() {

    this.GetMenuData();

    /*
      GETTING DATE & TIME FOR THE CURRENT LOGIN
      - IMPLEMENTED BY PRIYANKA - 20-04-2022
      */
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    // console.log("dateTimeData :", dateTimeData);

    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.setState({
      date: this.state.date,
      time: this.state.time,
    })


  }

  /*
THIS FUNCTION USED TO GET THE MENU/MODULES ADDED
IN FAQ SO FAR
IMPLEMENTED BY PRIYANKA ON 13-05-2022
*/
  GetMenuData() {

    var self = this;

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("CompanyId"),
        module: "FAQ",
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/AdminFAQ/SelectFAQExistingMenu",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //  console.log("FAQ DATA :", data);

        if (data.moduleList.length > 0) {
          self.PopulateDropdownData(data.moduleList);
        }

      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });

  }

  /*
THIS FUNCTION USED POPULATE THE MENU/MODULES ADDED
IN FAQ SO FAR
IMPLEMENTED BY PRIYANKA ON 13-05-2022
*/
  PopulateDropdownData(moduleList) {

    this.state.moduleListOptions = [];
    this.setState({
      moduleListOptions: this.state.moduleListOptions,
    })

    var moduleListOptionsArray = [];
    $.each(moduleList, function (i, item) {
      moduleListOptionsArray.push({ label: item.moduleName, value: item.moduleId })
    })

    this.state.moduleListOptions = moduleListOptionsArray;
    this.setState({
      moduleListOptions: this.state.moduleListOptions,
    })



  }

  /* THIS FUCNTION USED FOR SETTING VALIDATION FOR QUES AND ANSWER IMPLEMENTED BY NANDHINI - 02-05-2022*/

  validateField(fieldName, value, inputValue) {

    let fieldValidationErrors = this.state.formErrors;
    let questionValid = this.state.questionValid;
    let selectedModuleValid = this.state.selectedModuleValid;
    let answerValid = this.state.answerValid;


    //   console.log("value", value, "fieldName", fieldName);
    switch (fieldName) {
      case 'question':
        if (value.length == 0) {
          fieldValidationErrors.question = '';
          questionValid = false;
        }
        else if (value.length < 3) {
          fieldValidationErrors.question = 'Should Contain Atleast 3 Characters';
          questionValid = false;
        }
        else if (value.length > 80) {
          fieldValidationErrors.question = 'Sorry! You are Exceeding the Limit';
          questionValid = false;
        }
        else {
          questionValid = value.match(/^([a-zA-Z]+)([a-zA-Z ? ])*$/);
          fieldValidationErrors.question = questionValid ? '' : ' is InCorrect';
        }
        break;



      case 'answer':
        if (value.length == 0) {
          fieldValidationErrors.answer = ' ';
          answerValid = false;
        }
        else if (value.length < 3) {
          fieldValidationErrors.answer = 'Should Contain Atleast 3 Characters';
          answerValid = false;
        }
        else if (value.length > 150) {
          fieldValidationErrors.answer = 'Sorry! You are Exceeding the Limit';
          answerValid = false;
        }
        else {
          answerValid = value.match();
          fieldValidationErrors.answer = answerValid ? '' : ' is InCorrect';
        }
        break;



    }


    this.setState({
      questionValid: questionValid,
      answerValid: answerValid,
      selectedModuleValid: selectedModuleValid

    }, this.validateForm);
  }

  /* THIS FUCNTION USED FOR SETTING VALIDATION FOR QUES AND ANSWER IMPLEMENTED BY NANDHINI - 02-05-2022*/
  validateForm() {
    this.setState({
      formValid:

        this.state.questionValid
        && this.state.answerValid
        && this.state.selectedModuleValid

    });

    //   console.log("selected node", this.state.selectedModuleValid);
  }

  errorClass(error) {
    return (error.length === 0 ? '' : 'has-error');
  }

  /* THIS FUCNTION USED SETTING A CREATABLE SELECT IMPLEMENTED BY NANDHINI - 12-05-2022*/


  handleInputChangeFAQModule = (inputValue, actionMeta, selectedModule) => {
    var self = this;
    //  console.log("handleInputChangeFAQModule  :", inputValue);

    var camelcaseData = CapitalCaseFunc(inputValue);
    self.state.moduleName = camelcaseData;

    self.state.selectedModule = { value: camelcaseData, label: camelcaseData };
    self.state.moduleCreateStatus = 'Yes';

    self.state.moduleId = '';
    // self.state.moduleName = inputValue;




    self.setState({
      moduleId: self.state.moduleId,
      moduleName: self.state.moduleName,
      selectedModule: self.state.selectedModule,
      moduleCreateStatus: self.state.moduleCreateStatus,
    })

    var tempselectedNodesValid = false;
    if (inputValue != null) {
      tempselectedNodesValid = true;

    }
    else {
      tempselectedNodesValid = false;

    }

    this.setState({
      selectedModuleValid: tempselectedNodesValid
    }, this.validateForm)
    //  console.log("input :", inputValue);
    // console.log("input :", selectedModule);



  }
  handleChangeSelectFAQModule = (newValue, actionMeta) => {

    //alert("handleChangeSelectFAQModule :" + newValue.value);

    var tempselectedNodesValid = false;

    this.state.selectedModule = "";
    this.state.selectedModuleValid = tempselectedNodesValid;

    this.setState({
      selectedModule: this.state.selectedModule,
      selectedModuleValid: tempselectedNodesValid
    }, this.validateForm)

    // console.log("***** newValue:"+newValue);
    if (newValue != null) {

      this.state.moduleId = newValue.value;
      this.state.moduleName = newValue.label
      this.state.selectedModule = { value: newValue.value, label: newValue.label };
      tempselectedNodesValid = true;

      this.setState({
        moduleId: this.state.moduleId,
        moduleName: this.state.moduleName,
        selectedModule: this.state.selectedModule,
        selectedModuleValid: tempselectedNodesValid
      }, this.validateForm)

    }

  };
  /* THIS FUCNTION USED FOR SETTING QUESTION IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserInputQuestion = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    // alert("value"+e.target.value)

    var camelcaseData = CapitalCaseFunc(value);
    this.state[name] = camelcaseData;

    this.setState({ [name]: camelcaseData },
      () => { this.validateField(name, camelcaseData) });

  }


  /* THIS FUCNTION USED FOR SETTING ANSWER IMPLEMENTED BY NANDHINI - 02-05-2022*/
  handleUserInputAnswer = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    // alert("value"+e.target.value)

    var camelcaseData = CapitalCaseFunc(value);
    this.state[name] = camelcaseData;

    this.setState({ [name]: camelcaseData },
      () => { this.validateField(name, camelcaseData) });

  }
  /* THIS FUCNTION USED FOR SUBMIT FUNCTION IMPLEMENTED BY NANDHINI - 02-05-2022*/
  Submitfunc() {
    var self = this;

    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        companyId: GetLocalStorageData("CompanyId"),
        moduleId: this.state.moduleId,
        moduleName: this.state.moduleName,
        question: this.state.question,
        answer: this.state.answer,
        module: "FAQ",
        date: this.state.date,
        time: this.state.time,
        recentDate: this.state.date,
        recentTime: this.state.time,

      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/AdminFAQ/AddFAQData",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        //  console.log("FAQ DATA :", data);

        if (data.moduleList.length > 0) {
          self.PopulateDropdownData(data.moduleList);
        }

        if (data.response == "Success") {
          Swal.fire({
            position: 'center',
            icon: 'success',
            text: 'Question & answer addedd successfully',
            showConfirmButton: false,
            timer: 2000
          })

          self.ClearFunc();
        } else if (data.response == "Fail") {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Failed to add Q & A, kindly try again later',
            showConfirmButton: false,
            timer: 2000
          })
        }
      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });

  }
  CancelFunc() {

    this.ClearFunc()

  }

  ClearFunc() {
    this.state.selectedModule = [];
    this.state.moduleId = "";
    this.state.moduleName = "";
    this.state.answer = "";
    this.state.question = "";
    this.state.questionValid = false,
      this.state.answerValid = false,
      this.state.selectedModuleValid = false,


      this.setState({
        selectedModule: this.state.selectedModule,
        moduleId: this.state.moduleId,
        moduleName: this.state.moduleName,
        answer: this.state.answer,
        question: this.state.question,
        questionValid: false,
        answerValid: false,
        selectedModuleValid: false,
      })
    // ReactDOM.render(<FAQ />, document.getElementById("contentRender"));
    $("#submit").prop("disabled", true);
  }

  render() {

    return (

      <div class="">
        <div class="toptitle">
          <h4>FAQ</h4>
        </div>

        <div class="container-fluid">

        <label for="UserName"> Modules<span style={{ color: 'red' }}>*</span></label>

            <div class="row ">
              {/*CREATABLE SELECT DROPDOWN FOR MODULES  */}
              
              
              <div class="col-md-4" style={{marginTop:'10px',zIndex:'100',backgroundColor:'#233044 !important',color:'black'}}>
                <CreatableSelect
                  styles={customStyles_Dropdown}
                  isClearable
                  onChange={this.handleChangeSelectFAQModule}
                  onCreateOption={this.handleInputChangeFAQModule}
                  options={this.state.moduleListOptions}
                  value={this.state.selectedModule}
                  id="selectinput"
                />
                {/* <ErrorClass errorContent={this.state.formErrors.selectedMenu}/> */}
              </div>
           
        
          <ThemeProvider theme={darkTheme}>
          {/*INPUT FIELD USED TO GET QUESTION   */}
          {/* <div class="row input_wrapper"> */}
            <div class="col-md-4" >
              <div class=" control_label_text">
                {/* <label for="question"> Question<span style={{ color: 'red' }}>*</span></label> */}
              </div>
              <div class="">
              {/*  <textarea rows="2" class="form-control" value={this.state.question} onChange={this.handleUserInputQuestion} name="question" id="question" > </textarea> */}
              
                 <TextField fullWidth margin="normal" rows="2" required size="small"  style={{color:'white !important'}}  multiline variant="outlined" label="Question" name="question" onChange={this.handleUserInputQuestion} value={this.state.question}  />

                <ErrorClass errorContent={this.state.formErrors.question} />
              </div>
            </div>


            {/*INPUT FIELD USED TO GET ANSWER   */}

            <div class="col-md-4 "  >
              <div class=" control_label_text" >
                {/* <label for="UserName"> Answer<span style={{ color: 'red' }}>*</span></label> */}
              </div>
              <div class="">
              {/*  <textarea rows="2" class="form-control" value={this.state.answer} onChange={this.handleUserInputAnswer} name="answer" id="answer" > </textarea> */}
                 <TextField fullWidth margin="normal" rows="2" required size="small" style={{color:'white !important'}}  multiline variant="outlined" label="Answer" name="answer" onChange={this.handleUserInputAnswer} value={this.state.answer}  />

                <ErrorClass errorContent={this.state.formErrors.answer} />
              </div>
            </div>
          {/* </div> */}
          
          </ThemeProvider>
        
          </div>

          <div class="text-center">

            <button class="btn btn-primary btn-submit btn-cancel" id="submit" disabled={!this.state.formValid} onClick={() => this.Submitfunc()}>Submit</button>
            <button class="btn btn-primary btn-cancel" style={{ marginLeft: '4px' }} onClick={() => this.CancelFunc()}>Cancel</button>
          </div>
        </div>
      </div>
    );
  }
}
export default FAQ;


