//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import _, { size } from 'underscore';
import $ from 'jquery';
import DropdownTreeSelect from 'react-dropdown-tree-select';
import 'react-dropdown-tree-select/dist/styles.css'
import Swal from 'sweetalert2/dist/sweetalert2.js'
import * as AiIcons from 'react-icons/ai';
import SelectSearch from 'react-select';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
import ReactPlayer from 'react-player';
import CryptoJS from 'crypto-js';

import * as FcIcons from 'react-icons/fc';

// import statement for class component css
import '../../StyleCss.css';
import '../MenuUpload/MenuUploadCss.css';
// import statement for react class component
import { FormErrors } from '../../Validation Components/FormErrors';
import { CapitalCaseFunc, GetLocalStorageData, GetVideoThumbNail, List_To_Tree_With_KeyNameChange_Without_RootMenu, TimeZoneDateTime } from "../../Common Components/CommonComponents";
import { TreeDropdownContainer } from "../../Assets Components/DropdownComponents/DropdownComponent";
import { GetFileName, UploadToAWS } from "../../AWS/AWSFunctionality";
import * as FileSaver from 'file-saver';

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
UI WAY IMPLEMENTED BY RAMYA.
THE FUNCTIONALITIES LIKE GETTING THE EXISTING MENU ITEMS, 
UPLOADING IMAGES/ VIDEO - IMPLEMENTED BY PRIYANKA - 20-04 2022
*/

const customStyles_Dropdown = {
    control: (base, state) => ({
        ...base,
        background: "transparent",

        //   borderRadius: state.isFocused ? "3px 3px 0 0" : 3,
        //   borderColor: state.isFocused ? "yellow" : "green",
        boxShadow: state.isFocused ? null : null,
        //   "&:hover": {
        //     borderColor: state.isFocused ? "red" : "blue"
        //   }
    }),
    menu: (base) => ({
        ...base,
        borderRadius: 0,
        marginTop: 0
    }),
    menuList: (base) => ({
        ...base,
        padding: 0
    })
};

var menuList = [];
var treeList;
var videoURL;
var videoArray = [];
var videoThumbNailArray = [];
var imageArray = [];
var selectedNodesValid = false;
export class MenuUpload extends React.Component {
    constructor() {
        super();
        this.state = {
            operation: 'refresh',
            data: [],
            printPreviewOptions: [],
            url: "",
            uploadedFileUrl: "",
            printPreviewParameter: "1",
            convertedFileSize: 0,
            imageArrayLength: 0,
            videoArrayLength: 0,
            imageArray: [],
            videoURLArray: [],
            dropdownValue: [],
            uploadType: "",
            description: "",
            selectedpreviewOption: "",
            formErrors: {
                Menu: '',
                imageUploadValid: '',
                videoUploadValid: '',
                selectedNodesError: '',
            },
            selectedNodesError: '',
            fileSize: 0,
            folderPath: "",
        };

        this.fileChangedHandler = this.fileChangedHandler.bind(this);
        this.handleVideo = this.handleVideo.bind(this);
        this.handleImage = this.handleImage.bind(this);
    }

    componentDidMount() {

        //HIDING THE PREVIEW OPTIONS INITIALLY FROM BEING DISPLAYED - PRIYANKA - 20-04-2022
        $(".imagepreview").hide();
        $(".videopreview").hide();

        /*
       GETTING DATE & TIME FOR THE CURRENT LOGIN
       - IMPLEMENTED BY PRIYANKA - 20-04-2022
       */
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        //   console.log("dateTimeData :", dateTimeData);

        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.setState({
            date: this.state.date,
            time: this.state.time,
        })

        /*
        SETTING UP PRINT PREVIEW OPTION DATA
        - IMPLEMENTED BY PRIYANKA - 20-04-2022
        */
        var printPreviewOptions = [];
        for (var i = 1; i <= 10; i++) {
            printPreviewOptions.push({ label: i, value: i })
        }
        this.state.printPreviewOptions = printPreviewOptions;
        this.state.printPreviewParameter = "1";
        this.state.selectedpreviewOption = { label: "1", value: "1" };
        this.setState({
            printPreviewOptions: this.state.printPreviewOptions,
            selectedpreviewOption: this.state.selectedpreviewOption,
            printPreviewParameter: this.state.printPreviewParameter
        })

        /*
      GETTING EXISTING MENU ADDED INTO THE SYSTEM
      IMPLEMENTED BY PRIYANKA - 19-04-2022
      */
        this.GetExistingMenu();

    }

    /*
 FUNCTION USED FOR OPEN THE FOLDER PATH TO ADD IMAGE OR VIDEo INTO THE SYSTEM
 IMPLEMENTED BY RAMYA - 28-04-2022
 */
    uploadfiles() {
        document.getElementById("customFile").click();
    }

    /*
   FUNCTION USED FOR GETTING AN EXISTING MENU ITEMS ADDED INTO THE SYSTEM
   IMPLEMENTED BY PRIYANKA - 19-04-2022
   */
    GetExistingMenu() {

        var self = this;
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("CompanyId"),
            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/Configuration/SelectExistingMenu",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                //     console.log("GET EXISTING MENU DATA :", data);

                menuList = [];
                menuList = data.menuList;

                //CONVERTING THE FLAT ARRAY OF OBJECTS INTO TREE LIST WITH NEW ROOT MENU(PARENT - CHILD RELATIONSHIP)
                treeList = "";
                treeList = List_To_Tree_With_KeyNameChange_Without_RootMenu(menuList);

                //    console.log("treeList :", JSON.stringify(treeList));

                self.state.data = treeList;
                self.setState({
                    data: self.state.data
                })



            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });
    }

    /*USED TO STORE INPUTFIELDS IMPLEMENTED BY RAMYA - 28-04-2022*/
    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
        this.setState({ [name]: value },
            () => { this.validateField(name, value) });
    }


    /*USED TO STORE INPUTFIELDS IMPLEMENTED BY RAMYA - 28-04-2022*/
    handleUserInputdescription = (e) => {
        const name = e.target.name;
        //   const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
        const value = e.target.value;
        var camelcaseData = CapitalCaseFunc(value);
        this.setState({ [name]: camelcaseData })
    }

    /*USED TO VALIDATE THE NECESSARY FIELDS IMPLEMENTED BY RAMYA - 28-04-2022*/

    validateForm() {
        this.setState({
            formValid:
                this.state.imageUploadValid
                && selectedNodesValid
        });
        console.log("formValid", this.state.formValid);
        console.log("imageUploadValid", this.state.imageUploadValid);
        console.log("selectedNodesValid", selectedNodesValid);
    }


    /*USED TO SHOW THE ERRORS IMPLEMENTED BY RAMYA - 28-04-2022*/
    errorClass(error) {
        return (error.length == 0 ? '' : 'has-error');
    }


    /*
   FUCNTION USED FOR RECORDING ONCHANGE (ON SELECTING AN MENU)
   IMPLEMENTED BY PRIYANKA - 20-04-2022
   */

    onDropDownTreeChange = (currentNode, selectedNodes) => {

        console.log("currentNode :", currentNode);
        console.log("selectedNodes :", selectedNodes);
        console.log("selectedNodes 1:", selectedNodes.length);

        //   console.log("CHILDREN NODES :", selectedNodes[0]._children);
        $("#menuerror").empty("");
        this.state.operation = "noRefresh";
        this.setState({
            operation: this.state.operation,
        })
        var folderPath = "";

        if (selectedNodes.length !== 0) {
            console.log("selectedNodes 1:", selectedNodes.length);
            console.log("selectedNodes[0]._children.length", selectedNodes[0]._children.length);

            folderPath = selectedNodes[0].label;
            var parentId = selectedNodes[0].parent;

            if (parentId != null) {

                do {

                    console.log(" *** parentId :", parentId);

                    var currentFolder = _.where(menuList, { menuId: parentId });

                    console.log(" *** currentFolder :", currentFolder);

                    if (currentFolder.length > 0) {
                        folderPath = currentFolder[0].menuName + "/" + folderPath;
                        parentId = currentFolder[0].parentMenuId;
                    } else {
                        parentId = null
                    }
                    console.log(" *** folderPath:", folderPath);
                } while (parentId != null)

            }

            console.log(" *** folderPath:", folderPath);



            this.state.menuId = selectedNodes[0].id;
            this.state.moduleName = selectedNodes[0].module;
            this.state.folderPath = folderPath;

            if (selectedNodes[0]._children.length != 0) {
                selectedNodesValid = false;
                $("#menuerror").append("Upload cannot be done at root menu, kindly select submenu");
                // selectedNodesError = "Upload cannot be done at root menu, kindly select submenu"
                // Swal.fire({
                //     position: 'center',
                //     icon: 'warning',
                //     text: 'Upload cannot be done at root menu, kindly select submenu',
                //     showConfirmButton: false,
                //     timer: 2000
                // })
            }
            else if (selectedNodes != null || selectedNodes != undefined) {
                selectedNodesValid = true;
                $("#menuerror").empty("");
            }
            else {
                selectedNodesValid = false;
                this.state.folderPath = "";
                $("#menuerror").empty("");
            }
        }
        else {
            selectedNodesValid = false;
            this.state.folderPath = "";
            $("#menuerror").empty("");
        }
        this.setState({
            selectedNodesValid: selectedNodesValid,
            folderPath: this.state.folderPath,
        }, this.validateForm)

        console.log("menuId :", this.state.menuId);
        console.log("moduleName :", this.state.moduleName);
        console.log("selectedNodes :", selectedNodes);


    };


    /*USED TO STORE PRINTPREVIEW - IMPLEMENTED BY RAMYA */
    handleUserInputPreview = (e) => {
        const name = e.name;
        const value = e.value;
        this.state.selectedpreviewOption = e;

        this.state.printPreviewParameter = e.value;

        this.setState({
            [name]: value,
            selectedpreviewOption: this.state.selectedpreviewOption,
            printPreviewParameter: this.state.printPreviewParameter
        },
        );
    }

    /*
    FUNCTION USED TO HANDLE FILE UPLOAD(IMAGE/VIDEO)
    - IMPLEMENTED BY PRIYANKA - 20-04-2022
    */
    fileChangedHandler(event) {

        var self = this;

        var fileInput = false;

        if (event.target.files[0]) {
            fileInput = true;
        }


        console.log("event.target.files[0] :", event.target.files[0]);

        var files = event.target.files[0];

        // for getting only extension 
        // var fileExtension = files.type.split("/").pop();

        //   var fileExtension = files.type.split("/")[0];

        var fileType = event.target.files[0].type.split("/")[0];

        if (fileInput) {

            for (var i = 0; i < event.target.files.length; i++) {

                //  var fileType = event.target.files[i].type;
                var currentFileType = event.target.files[0].type.split("/")[0];
                // var fileSize = event.target.files[0].size;

                //    if (fileType == "image/jpeg" || fileType == "image/png" || fileType == "image/*" || fileType == "image/webp") {

                //  if (fileType == currentFileType) {
                if (fileType == "image") {

                    //UPLOADED FILE BEING IMAGE OR JPEG OR PNG
                    //   console.log("IMAGE ARRAY :", imageArray);
                    //   console.log("VIDEO ARRAY :", videoArray);


                    self.state.imageArrayLength = Number(self.state.imageArrayLength) + Number(1);
                    self.setState({
                        imageArrayLength: self.state.imageArrayLength
                    })

                    self.state.videoURLArray = [],
                        videoArray = [];
                    self.state.videoArrayLength = 0;
                    self.setState({
                        videoURLArray: [],
                        videoArrayLength: 0,
                    })

                    //  alert("self.state.imageArrayLength :" + self.state.imageArrayLength);

                    if (self.state.imageArrayLength <= 4) {
                        //ONLY 10 IMAGES CAN BE UPLOADED AT A TIME
                        $(".imagepreview").show();
                        $(".videopreview").hide();
                        $("#previewvideo").show();

                        var preview = this.state.printPreviewParameter;

                        var imageUploadValid = "false"
                        if (fileType == "image" && preview >= 1) {
                            imageUploadValid = true;
                        }
                        else {
                            imageUploadValid = false;
                        }
                        this.setState({
                            imageUploadValid: imageUploadValid,
                        }, this.validateForm)

                        console.log("imageUploadValid", this.state.imageUploadValid);
                        self.state.videoURL = "";
                        videoArray = [];
                        videoURL = "";
                        self.setState({
                            videoURL: "",
                        })

                        //CONVERTING THE UPLOADED BLOB(IMAGE/JPEG/PNG) TO URL - IMPLEMENTED BY PRIYANKA - 20-04-2022
                        //    blobToURL(event.target.files[i]).then((url) => (self.state.uploadedFileUrl = url, self.setState({ uploadedFileUrl: url })));

                        //COMPRESING & CHECKING FOR THE SIZE OF THE UPLOADED & COMPRESSED FILE SIZE - IMPLEMENTED BY PRIYANKA - 20-04-2022

                        self.handleImage(event.target.files[i], self.state.imageArrayLength);


                    } else {
                        Swal.fire({
                            position: 'center',
                            icon: 'warning',
                            text: 'Only 4 images can be uploaded at a time',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }



                    //  } else if (fileType == "video/mp4" || fileType == "video/x-m4v" || fileType == "video/*") {
                } else if (fileType == "video") {

                    //   $("#previewvideo").hide();
                    //UPLOADED FILE BEING VIDEO 
                    // let filename = document.getElementById('file-name');
                    // let uploadfilename = event.target.files[0].name;
                    // filename.textContent = uploadfilename;
                    // console.log("uploadfilename", uploadfilename)

                    //UPLOADED FILE BEING VIDEO 

                    self.state.videoArrayLength = Number(self.state.videoArrayLength) + Number(1);
                    self.setState({
                        videoArrayLength: self.state.videoArrayLength
                    })

                    if (self.state.videoArrayLength <= 3) {
                        //ONLY ONE VIDEO CAN BE UPLOADED AT A TIME
                        $(".imagepreview").hide();
                        $(".videopreview").show();

                        //   console.log("IMAGE ARRAY :", self.state.imageArray);
                        //   console.log("VIDEO ARRAY :", videoArray);

                        self.state.imageArray = [],
                            imageArray = [];
                        self.state.imageArrayLength = 0;
                        self.setState({
                            imageArray: [],
                            imageArrayLength: 0,
                        })

                        self.handleVideo(event.target.files[i], self.state.videoArrayLength);

                    } else {
                        Swal.fire({
                            position: 'center',
                            icon: 'warning',
                            text: 'Only 3 video can be uploaded at a time',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }
                } else {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Only image and video can be uploaded',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }
                /*  } else {
                      Swal.fire({
                          position: 'center',
                          icon: 'warning',
                          text: 'Only ' + fileType + ' can be uploaded',
                          showConfirmButton: false,
                          timer: 2000
                      })
  
                  } */
            }


        }

        $("#customFile")[0].value = '';

    }

    /*
   FUNCTION USED TO HANDLE THE UPLOADED IMAGE(IMAGE/PNG/JPEG)
   REPLACED & REMOVED THE HANDLE BLOB FUNCTION TO REMOVE THE COMPRESSION PART
   APPLIED ON THE IMAGE
   - IMPLEMENTED BY PRIYANKA - 02-07-2022
   */
    handleImage = (file, count) => {

        var self = this;
        var imageData;
        console.log("***** file :", file);


        var fileSize_GB = (file.size / (1000 * 1000 * 1000)).toFixed(2);

        if (fileSize_GB <= 3) {
            var reader = new FileReader();
            reader.readAsDataURL(file);

            this.state.fileSize = Number(this.state.fileSize) + Number(fileSize_GB);
            this.setState({
                fileSize: this.state.fileSize
            })

            console.log("this.state.fileSize :", this.state.fileSize);

            // alert("file.type :"+file.type);
            reader.onloadend = function () {
                //  console.log('RESULT', reader.result)
                imageData = {
                    originalName: file.name,
                    name: count,
                    data: file,
                    src: reader.result,
                    size: fileSize_GB,
                    fileType: file.type
                },
                    console.log(" **** imageData : ", imageData);

                self.state.imageArray.push(imageData),
                    imageArray.push(reader.result),
                    self.setState({ imageArray: self.state.imageArray })
                console.log("self.state.imageArray :", self.state.imageArray);

            }
        } else {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: "Size of " + file.name + " is greater than 3 GB",
                timer: 3000,
                showConfirmButton: true,
            });
        }


    }





    /*
    FUNCTION USED TO HANDLE THE UPLOADED VIDEO
    - IMPLEMENTED BY PRIYANKA - 20-04-2022
    */
    handleVideo = (file, count) => {
        //  alert("handle video");
        // var file = event.target.files[0];
        //  var file = event;

        var self = this;

        var videoData;

        //    alert("file.size :" + file.size);
        var fileSize_GB = (file.size / (1000 * 1000 * 1000)).toFixed(2);
        //   alert("fileSize_GB :" + fileSize_GB);

        if (fileSize_GB <= 3) {
            // console.log("FILE :", file);
            // Encode the file using the FileReader API

            const url = URL.createObjectURL(file);
            //  self.state.videoURL = url;
            self.state.videoURLArray.push(url);
            self.setState({
                //     videoURL: self.state.videoURL,
                videoURLArray: self.state.videoURLArray,
            })

            var reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onloadend = function () {
                //  console.log('RESULT', reader.result)
                videoData = {
                    originalName: file.name,
                    name: count,
                    data: file,
                    src: reader.result,
                    size: fileSize_GB,
                    fileType: file.type
                },
                    console.log(" **** videoData : ", videoData);

                videoArray.push(videoData),

                    console.log("videoArray :", videoArray);

            }

            this.setState({ imageUploadValid: true }, this.validateForm);
            $("#previewvideo").hide();

            var videoThumbNailData;
            GetVideoThumbNail(file, '').then(function (videoThumbNail) {
                // FileSaver.saveAs(videoThumbNail, "image.jpg"),
                videoThumbNailData = {
                    name: count,
                    data: videoThumbNail,
                    fileType: videoThumbNail.type
                },
                    videoThumbNailArray.push(videoThumbNailData)
            });


            console.log(" ******* videoThumbNailArray :", videoThumbNailArray);
        } else {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: "Size of " + file.name + " is greater than 3 GB",
                timer: 3000,
                showConfirmButton: true,
            });
        }

    };



    /*
    FUNCTION USED FOR REMOVING AN IMAGE 
    - IMPLEMENETED BY PRIYANKA -  20-04-2022
    */
    RemoveImage(image) {

        this.state.fileSize = 0;
        this.setState({
            fileSize: this.state.fileSize
        })

        this.state.imageArray.splice(this.state.imageArray.findIndex(imageData => imageData.data === image), 1)
        this.setState({
            imageArray: this.state.imageArray,
        })

        this.state.imageArrayLength = this.state.imageArray.length;
        this.setState({
            imageArrayLength: this.state.imageArrayLength,
        })


        /*  var presentFileData = _.pluck(self.state.imageArray, 'size');
          self.state.fileSize = presentFileData.reduce((fileSize, currentFileSize) => fileSize + currentFileSize, 0);

          self.setState({
              fileSize: self.state.fileSize,
          })
*/

        if (this.state.imageArray.length != 0) {
            this.state.imageUploadValid = true;
            this.setState({
                imageUploadValid: true,
            }, this.validateForm)
        }
        else {
            this.state.imageUploadValid = false;
            this.setState({
                imageUploadValid: false,
            }, this.validateForm)
        }
        //   console.log("formValid :", formValid);
        //   console.log("this.state.imageArray :", this.state.imageArray);
    }


    /*
   FUNCTION USED FOR REMOVING AN VIDEO 
   - IMPLEMENETED BY PRIYANKA -  29-04-2022
   */
    RemoveVideo(video) {

        console.log("***** REMOVE VIDEO DATA :", video);
        console.log("***** REMOVE VIDEO DATA  BEFORE *************");
        console.log("*****  this.state.videoURLArray : ", this.state.videoURLArray);
        console.log("*****  videoArray : ", videoArray);
        console.log("*****  videoThumbNailArray : ", videoThumbNailArray);

        //   alert("index :" + this.state.videoURLArray.findIndex(videoData => videoData === video));

        var index = this.state.videoURLArray.findIndex(videoData => videoData === video);
        this.state.videoURLArray.splice(this.state.videoURLArray.findIndex(videoData => videoData === video), 1)
        videoArray.splice(index, 1);
        videoThumbNailArray.splice(index, 1);

        this.setState({
            videoURLArray: this.state.videoURLArray,
        })

        this.state.videoArrayLength = this.state.videoURLArray.length;
        this.setState({
            videoArrayLength: this.state.videoArrayLength,
        })

        if (this.state.videoURLArray.length != 0) {
            this.state.imageUploadValid = true;
            this.setState({
                imageUploadValid: true,
            }, this.validateForm)
        }
        else {

            $("#previewvideo").show();
            this.state.imageUploadValid = false;
            this.setState({
                imageUploadValid: false,
            }, this.validateForm)
        }

        this.state.videoURLArrayLength = this.state.videoURLArray.length;
        this.setState({
            videoURLArrayLength: this.state.videoURLArrayLength,
        })

        /* console.log("this.state.videoURLArray :", this.state.videoURLArray);
         console.log("video Array :", videoArray);
 */
        console.log("***** REMOVE VIDEO DATA  BEFORE *************");
        console.log("*****  this.state.videoURLArray : ", this.state.videoURLArray);
        console.log("*****  videoArray : ", videoArray);
        console.log("*****  videoThumbNailArray : ", videoThumbNailArray);

    }

    Submit() {


        var self = this;
        var uploadData;

        if (this.state.imageArray.length > 0) {
            uploadData = this.state.imageArray;
        } else if (videoArray.length > 0) {
            uploadData = videoArray;
        }

        var metaData = {
            description: this.state.description,
            printPreviewParameter: this.state.printPreviewParameter.toString(),
        }

        self.state.data = [];
        self.setState({
            data: self.state.data
        })


        GetFileName(this.state.folderPath).then(function (response) {
            console.log("** RESPONSE :", response)
            if (response !== "Error") {
                // self.UpdateProfileImage(fileName);
                console.log("** RESPONSE CONTENTS :", response.Contents)

                var contentsLength = (response.Contents.length) - 1;
                console.log("contentsLength :", contentsLength);

                var fileNameArray = response.Contents.map(function (el) {


                    var splitData = (el.Key).split(/[\s/]+/);
                    var onlyFilename = splitData[splitData.length - 1];
                    return onlyFilename.split(".")[0]
                });

                var fileNameArrayInt = fileNameArray.map(Number);
                /*  var lastFileName = response.Contents[contentsLength].Key;
                  console.log("lastFileName :", lastFileName);
                  var splitData = lastFileName.split(/[\s/]+/)
                  var keyName = splitData[splitData.length - 1]
                  */

                console.log("fileNameArrayInt :", fileNameArrayInt);

                var keyName = Math.max(...fileNameArrayInt);
                //  var imageArray = self.state.imageArray;
                //   var newImageArray=[];

                // alert("MAX KEY NAME :"+keyName);
                console.log(" **** uploadData :", uploadData);


                if (videoThumbNailArray.length > 0) {
                    for (var i = 0; i < uploadData.length; i++) {
                        keyName = Number(keyName) + Number(1);
                        uploadData[i].name = keyName.toString();
                        videoThumbNailArray[i].name = keyName.toString();
                        //   uploadData[i].name = keyName.toString()+".jpg";
                    }
                } else {
                    for (var i = 0; i < uploadData.length; i++) {
                        keyName = Number(keyName) + Number(1);
                        uploadData[i].name = keyName.toString();
                        //   uploadData[i].name = keyName.toString()+".jpg";
                    }
                }

                console.log(" **** uploadData :", uploadData);

                /* self.state.imageArray = [];
                 self.setState({
                     imageArray: self.state.imageArray
                 })
 
                 self.state.imageArray = imageArray;
                 self.setState({
                     imageArray: self.state.imageArray
                 })
                */


                UploadToAWS(self.state.folderPath, uploadData, metaData).then(function (response) {
                    console.log(" ***** UploadToAWS response :", response);
                    if (response == "Uploaded") {
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            text: 'Uploaded Successfully',
                            showConfirmButton: false,
                            timer: 2000
                        })

                    } else if (response == "Error") {
                        Swal.fire({
                            position: 'center',
                            icon: 'warning',
                            text: 'Upload done partially, kindly try after sometime',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }

                    $(".imagepreview").hide();
                    $(".videopreview").hide();

                    // menuList = [];
                    //menuList = self.state.data;

                    //  window.location.reload(false);
                    //CONVERTING THE FLAT ARRAY OF OBJECTS INTO TREE LIST (PARENT - CHILD RELATIONSHIP)
                    treeList = "";
                    treeList = List_To_Tree_With_KeyNameChange_Without_RootMenu(menuList);

                    //  console.log("treeList :", JSON.stringify(treeList));

                    console.log(" ************************* EMPTY self.state.data :", self.state.data);
                    self.state.data = treeList;
                    self.state.operation = "refresh";

                    self.setState({
                        data: self.state.data,
                        operation: self.state.operation,
                    })
                    console.log(" ************************* NOT EMPTY self.state.data :", self.state.data);


                    self.ClearFunc();

                })

                if (videoThumbNailArray.length > 0) {
                    UploadToAWS(self.state.folderPath + "/ThumbNail", videoThumbNailArray, metaData).then(function (response) {
                        console.log(" ***** UploadToAWS THUMB NAIL :", response);

                    });
                }

            }
        });



    }

    Cancel() {
        this.ClearFunc();

        this.state.formValid = false,

            this.state.data = [];
        this.setState({
            data: this.state.data
        })

        this.state.data = treeList;
        this.state.operation = "refresh";

        this.setState({
            formValid: false,
            data: this.state.data,
            operation: this.state.operation,
        })
    }


    ClearFunc() {

        //  window.TreeDropdownContainerComponent.uncheckAll;

        $("#menuerror").empty("");
        $("#previewvideo").show();

        videoArray = [];
        videoThumbNailArray = [];
        this.state.menuId = "";
        this.state.videoURL = "";
        this.state.moduleName = "";
        this.state.imageArray = [];
        this.state.videoArray = [];
        this.state.videoURLArray = [];
        this.state.imageArrayLength = 0;
        this.state.videoArrayLength = 0;
        this.state.description = "";
        this.state.imageUploadType = "";
        this.state.printPreviewParameter = "1";
        this.state.selectedpreviewOption = { label: "1", value: "1" };
        this.state.selectedNodes = [];
        this.state.currentNode = [];
        this.state.dropdownValue = [];
        this.state.imageUploadValid = false;
        selectedNodesValid = false;
        this.state.fileSize = 0;
        this.state.operation = "norefresh";
        this.state.folderPath = "";

        this.setState({
            operation: this.state.operation
        })

        this.setState({
            menuId: this.state.menuId,
            videoURL: this.state.videoURL,
            moduleName: this.state.moduleName,
            imageArray: this.state.imageArray,
            videoArray: this.state.videoArray,
            videoURLArray: this.state.videoURLArray,
            imageArrayLength: this.state.imageArrayLength,
            videoArrayLength: this.state.videoArrayLength,
            description: this.state.description,
            imageUploadType: this.state.imageUploadType,
            printPreviewParameter: this.state.printPreviewParameter,
            selectedpreviewOption: this.state.selectedpreviewOption,
            dropdownValue: this.state.dropdownValue,
            selectedNodes: this.state.selectedNodes,
            currentNode: this.state.currentNode,
            imageUploadValid: this.state.imageUploadValid,
            selectedNodesValid: selectedNodesValid,

            folderPath: this.state.folderPath,

            fileSize: this.state.fileSize
        }, this.validateForm)

    }



    render() {

        return (
            <div className="">

                <div className="toptitle">
                    <h4>Menu Upload</h4>
                </div>
                <div className="container-fluid">

                    <div className="row">
                        <div class="col-md-4" >
                            <label>Menu <span class="mandatoryfields">*</span></label>
                            {/* Field used to get menus item - it's mandatory field */}
                            <TreeDropdownContainer data={this.state.data} operation={this.state.operation} onChange={this.onDropDownTreeChange} />
                            <span id="menuerror"></span>
                        </div>

                        <div class="col-md-4" style={{color: 'black' }}>
                            {/* Field used to set the PRINT PREVIEW - it's mandatory field */}

                            <label>Print Preview Parameter <span id="previewvideo" class="mandatoryfields">*</span></label>
                            <div className="" style={{marginTop: "7px"}}>
                                <SelectSearch styles={customStyles_Dropdown} options={this.state.printPreviewOptions} value={this.state.selectedpreviewOption} name="selectedpreviewOption" id="preview"
                                    onChange={(e) => this.handleUserInputPreview(e)} placeholder="Select Your Preview Parameter"></SelectSearch>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Description</label>
                            {/* Field used to set the description text - it's non-mandatory field */}
                            <input type="text"
                                className=" textfield_class form-control textcolor_form"
                                onChange={this.handleUserInputdescription}
                                name="description"
                                placeholder="Description"
                                value={this.state.description}
                                required />
                        </div>
                        <div class="col-md-6" id="image" style={{ marginTop: "6px" }}>
                            <label>Upload Files  <span class="mandatoryfields">*</span></label>
                            {/* Field used to upload the image - it's mandatory field */}
                            {/*  <div className="textfield aligncamera">
                                <input type="file" multiple onChange={this.fileChangedHandler} class="form-control" id="customFile" style={{ background: "#f9f9fd" }} />

                            </div>
                            */}
                            <div className="aligncamera">
                                <a class="uploadicontextfield" onClick={this.uploadfiles}>
                                    <input type="file" multiple onChange={this.fileChangedHandler} style={{ display: "none" }} id="customFile" /><span id="file-name">Upload</span>
                                </a>
                            </div>
                        </div>




                    </div>

                    <div className="row">
                        {(this.state.imageArray.length > 0 ?
                            (this.state.imageArray.map((data) => (
                                data.src != null && data.src != undefined
                                    ? (<div class="col-md-3 imagepreview" >
                                        <div class="card card-box">
                                            <h4 style={{ textAlign: "center" }}>Image Preview</h4>
                                            <h5 style={{ textAlign: "center" }}>{data.size + "GB"}</h5>
                                            <div class="text-center">
                                                <img id="image" src={data.src} style={{ width: "100%" }} />
                                                <button className="removebtn" onClick={() => this.RemoveImage(data.data)} ><FcIcons.FcRemoveImage /> </button>
                                            </div>
                                        </div>
                                    </div>)

                                    : (<div class="">

                                    </div>)
                            ))) : (<div class="">

                            </div>)

                        )}
 
                        {(this.state.videoURLArray.length > 0 ?
                            (this.state.videoURLArray.map((data) => (
                                data != null && data != undefined
                                    ? (
                                        <div class="col-md-3 videopreview" >
                                            <div class="card card-box">
                                                <h4 style={{ textAlign: "center" }}>Video Preview</h4>
                                                <div class="text-center">
                                                    <ReactPlayer url={data} className='react-player' playing={false}
                                                        controls width='100%' height='180px' id="videoplayer" />
                                                    <button className="removebtn" onClick={() => this.RemoveVideo(data)} ><FcIcons.FcRemoveImage /></button>
                                                </div>


                                            </div>

                                        </div>)

                                    : (<div class="">

                                    </div>)
                            ))) : (<div class="">

                            </div>)

                        )}
                    </div>



                    {/*
                    <div class="col-md-4 col-xs-12 logopreview" >
                        <div class="card cardlogo" style={{ background: "#fff" }}>
                            <h4 style={{ textAlign: "center" }}>Image Preview</h4>
                            <h5 style={{ textAlign: "center" }}>{this.state.convertedFileSize + "KB"}</h5>
                            <div class="text-center">
                                <img id="logopreview" src={this.state.url} alt="" style={{ padding: "20x" }}></img>
                            </div>
                        </div>

                    </div>
*/}


                    {/*    <div class="col-md-4 col-xs-12 videopreview" >
                        <div class="card cardlogo" style={{ background: "#fff" }}>
                            <h4 style={{ textAlign: "center" }}>Video Preview</h4>
                            <div class="text-center">
                                <ReactPlayer url={this.state.videoURL} className='react-player' playing={false}
                                    controls width='320px' height='180px' />
                            </div>
                        </div>

                    </div>
                    */}

                    <div className="text-center">
                        <button class="btn btn-primary btn-submit" disabled={!this.state.formValid} onClick={() => this.Submit()}>Submit</button>
                        <button class="btn btn-primary btn-cancel" onClick={() => this.Cancel()}>Cancel</button>

                    </div>
                </div>

            </div>
        )
    }
}
export default MenuUpload;

const getSize = (size) => (console.log("GET SIZE :", size), (size / 1024).toFixed(3));



