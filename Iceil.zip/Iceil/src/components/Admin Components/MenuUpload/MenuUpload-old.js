//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import _ from 'underscore';
import $ from 'jquery';
import DropdownTreeSelect from 'react-dropdown-tree-select';
import 'react-dropdown-tree-select/dist/styles.css'
import Swal from 'sweetalert2/dist/sweetalert2.js'
import * as AiIcons from 'react-icons/ai';
import SelectSearch from 'react-select';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
import ReactPlayer from 'react-player';
import CryptoJS from 'crypto-js';

import * as FcIcons from 'react-icons/fc';

// import statement for class component css
import '../../StyleCss.css';
import '../MenuUpload/MenuUploadCss.css';
// import statement for react class component
import { FormErrors } from '../../Validation Components/FormErrors';
import { GetLocalStorageData, List_To_Tree_With_KeyNameChange_Without_RootMenu, TimeZoneDateTime } from "../../Common Components/CommonComponents";
import TreeDropdownContainer from "../../Assets Components/DropdownComponents/DropdownComponent";

/*
UI WAY IMPLEMENTED BY RAMYA.
THE FUNCTIONALITIES LIKE GETTING THE EXISTING MENU ITEMS, 
UPLOADING IMAGES/ VIDEO - IMPLEMENTED BY PRIYANKA - 20-04 2022
*/

var menuList = [];
var videoURL;
var videoArray = [];
var imageArray = [];
var standardFileSize = 5120.000;

export class MenuUpload extends React.Component {
    constructor() {
        super();
        this.state = {
            data: [],
            printPreviewOptions: [],
            url: "",
            uploadedFileUrl: "",
            printPreviewParameter: "1",
            convertedFileSize: 0,
            imageArrayLength: 0,
            imageArray: [],
            videoURLArray: [],
            dropdownValue: [],
            uploadType: "",
            description: "",
            selectedpreviewOption: "",
            formErrors: {
                Type: '',
                Menu: '',
                imageUploadValid: '',
                videoUploadValid: '',
            },
            selectedNodesError: '',
        };

        this.fileChangedHandler = this.fileChangedHandler.bind(this);
        this.handleBlob = this.handleBlob.bind(this);
        this.handleVideo = this.handleVideo.bind(this);
    }

    componentDidMount() {

        //HIDING THE PREVIEW OPTIONS INITIALLY FROM BEING DISPLAYED - PRIYANKA - 20-04-2022
        $(".imagepreview").hide();
        $(".videopreview").hide();

        /*
       GETTING DATE & TIME FOR THE CURRENT LOGIN
       - IMPLEMENTED BY PRIYANKA - 20-04-2022
       */
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        console.log("dateTimeData :", dateTimeData);

        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.setState({
            date: this.state.date,
            time: this.state.time,
        })

        /*
        SETTING UP PRINT PREVIEW OPTION DATA
        - IMPLEMENTED BY PRIYANKA - 20-04-2022
        */
        var printPreviewOptions = [];
        for (var i = 1; i <= 10; i++) {
            printPreviewOptions.push({ label: i, value: i })
        }
        this.state.printPreviewOptions = printPreviewOptions;
        this.state.printPreviewParameter = "1";
        this.state.selectedpreviewOption = { label: "1", value: "1" };
        this.setState({
            printPreviewOptions: this.state.printPreviewOptions,
            selectedpreviewOption: this.state.selectedpreviewOption,
            printPreviewParameter: this.state.printPreviewParameter
        })

        /*
      GETTING EXISTING MENU ADDED INTO THE SYSTEM
      IMPLEMENTED BY PRIYANKA - 19-04-2022
      */
        this.GetExistingMenu();

    }

    /*
 FUNCTION USED FOR OPEN THE FOLDER PATH TO ADD IMAGE OR VIDEo INTO THE SYSTEM
 IMPLEMENTED BY RAMYA - 28-04-2022
 */
    uploadfiles() {
        document.getElementById("customFile").click();
    }

    /*
   FUNCTION USED FOR GETTING AN EXISTING MENU ITEMS ADDED INTO THE SYSTEM
   IMPLEMENTED BY PRIYANKA - 19-04-2022
   */
    GetExistingMenu() {

        // var self = this;
        // $.ajax({
        //     type: 'POST',
        //     data: JSON.stringify({
        //         companyId: GetLocalStorageData("CompanyId"),
        //     }),

        //     url: "http://localhost:8080/IceilAPI/Configuration/SelectExistingMenu",

        //     contentType: "application/json",
        //     dataType: 'json',
        //     async: false,
        //     success: function (data, textStatus, jqXHR) {

        //         console.log("GET EXISTING MENU DATA :", data);

        //         menuList = [];
        //         menuList = data.menuList;

        //         //CONVERTING THE FLAT ARRAY OF OBJECTS INTO TREE LIST WITH NEW ROOT MENU(PARENT - CHILD RELATIONSHIP)
        //         var treeList = List_To_Tree_With_KeyNameChange_Without_RootMenu(menuList);

        //         //    console.log("treeList :", JSON.stringify(treeList));

        //         self.state.data = treeList;
        //         self.setState({
        //             data: self.state.data
        //         })



        //     },
        //     error: function (data) {
        //         Swal.fire({
        //             position: 'center',
        //             icon: 'error',
        //             title: 'Network Connection Problem',
        //             showConfirmButton: false,
        //             timer: 2000
        //         })


        //     },
        // });
    }

    /*USED TO STORE INPUTFIELDS IMPLEMENTED BY RAMYA - 28-04-2022*/
    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
        this.setState({ [name]: value },
            () => { this.validateField(name, value) });
    }

    /*USED TO VALIDATE THE NECESSARY FIELDS IMPLEMENTED BY RAMYA - 28-04-2022*/

    validateForm() {
        this.setState({
            formValid:
                this.state.imageUploadValid
                // && this.state.selectedNodesValid
        });
    }

    /*USED TO SHOW THE ERRORS IMPLEMENTED BY RAMYA - 28-04-2022*/
    errorClass(error) {
        return (error.length == 0 ? '' : 'has-error');
    }


    /*
   FUCNTION USED FOR RECORDING ONCHANGE (ON SELECTING AN MENU)
   IMPLEMENTED BY PRIYANKA - 20-04-2022
   */

    onDropDownTreeChange = (currentNode, selectedNodes) => {

        console.log("currentNode :", currentNode);
        console.log("selectedNodes :", selectedNodes);

        console.log("CHILDREN NODES :", selectedNodes[0]._children);


        if (selectedNodes[0]._children.length != 0) {

            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Upload cannot be done at root menu, kindly select submenu',
                showConfirmButton: false,
                timer: 2000
            })
        }
        this.state.menuId = selectedNodes[0].id;
        this.state.moduleName = selectedNodes[0].module;


        var tempselectedNodesValid = false;
        if (selectedNodes != null && selectedNodes != undefined) {
            tempselectedNodesValid = true;
        }
        else {
            tempselectedNodesValid = false;
        }
        this.setState({
            selectedNodesValid: tempselectedNodesValid
        }, this.validateForm)
        console.log("menuId :", this.state.menuId);
        console.log("moduleName :", this.state.moduleName);

    };


    /*USED TO STORE PRINTPREVIEW - IMPLEMENTED BY RAMYA */
    handleUserInputPreview = (e) => {
        const name = e.name;
        const value = e.value;
        this.state.selectedpreviewOption = e;

        this.state.printPreviewParameter = e.value;

        this.setState({
            [name]: value,
            selectedpreviewOption: this.state.selectedpreviewOption,
            printPreviewParameter: this.state.printPreviewParameter
        },
        );
    }

    /*
    FUNCTION USED TO HANDLE FILE UPLOAD(IMAGE/VIDEO)
    - IMPLEMENTED BY PRIYANKA - 20-04-2022
    */
    fileChangedHandler(event) {

        var self = this;

        var fileInput = false;

        if (event.target.files[0]) {
            fileInput = true;
        }


        console.log("event.target.files[0] :", event.target.files);

        var files = event.target.files[0];

        // for getting only extension 
        // var fileExtension = files.type.split("/").pop();

        //   var fileExtension = files.type.split("/")[0];

        var fileType = event.target.files[0].type.split("/")[0];

        if (fileInput) {

            for (var i = 0; i < event.target.files.length; i++) {

                //  var fileType = event.target.files[i].type;
                var currentFileType = event.target.files[0].type.split("/")[0];

                //    if (fileType == "image/jpeg" || fileType == "image/png" || fileType == "image/*" || fileType == "image/webp") {

                //  if (fileType == currentFileType) {
                if (fileType == "image") {

                    //UPLOADED FILE BEING IMAGE OR JPEG OR PNG
                    console.log("IMAGE ARRAY :", imageArray);
                    console.log("VIDEO ARRAY :", videoArray);


                    self.state.imageArrayLength = Number(self.state.imageArrayLength) + Number(1);
                    self.setState({
                        imageArrayLength: self.state.imageArrayLength
                    })

                    //  alert("self.state.imageArrayLength :" + self.state.imageArrayLength);

                    if (self.state.imageArrayLength <= 10) {
                        //ONLY 10 IMAGES CAN BE UPLOADED AT A TIME
                        $(".imagepreview").show();
                        $(".videopreview").hide();
                        $("#previewvideo").show();

                        var preview = this.state.printPreviewParameter;

                        var imageUploadValid = "false"
                        console.log("imagelength", self.state.imageArrayLength);
                        if (fileType == "image" && preview >= 1) {
                            imageUploadValid = true;                           
                        }      
                        else if(self.state.imageArrayLength == 0){
                            imageUploadValid = false;
                            console.log("vlvalid", self.state.imageArrayLength)                   
                        }
                        else {
                            imageUploadValid = false;
                        }
                        this.setState({
                            imageUploadValid: imageUploadValid
                        }, this.validateForm)

                        self.state.videoURL = "";
                        videoArray = [];
                        videoURL = "";
                        self.setState({
                            videoURL: "",
                        })

                        //CONVERTING THE UPLOADED BLOB(IMAGE/JPEG/PNG) TO URL - IMPLEMENTED BY PRIYANKA - 20-04-2022
                        blobToURL(event.target.files[i]).then((url) => (self.state.uploadedFileUrl = url, self.setState({ uploadedFileUrl: url })));

                        //COMPRESING & CHECKING FOR THE SIZE OF THE UPLOADED & COMPRESSED FILE SIZE - IMPLEMENTED BY PRIYANKA - 20-04-2022

                        self.handleBlob(event.target.files[i]);


                    } else {
                        Swal.fire({
                            position: 'center',
                            icon: 'warning',
                            text: 'Only 10 images can be uploaded at a time',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }

                    //  } else if (fileType == "video/mp4" || fileType == "video/x-m4v" || fileType == "video/*") {
                } else if (fileType == "video") {

                    this.setState({ imageUploadValid: true }, this.validateForm);
                    $("#previewvideo").hide();
                    //UPLOADED FILE BEING VIDEO 
                    // let filename = document.getElementById('file-name');
                    // let uploadfilename = event.target.files[0].name;
                    // filename.textContent = uploadfilename;
                    // console.log("uploadfilename", uploadfilename)

                    //UPLOADED FILE BEING VIDEO 

                    if (videoArray.length == 0) {
                        //ONLY ONE VIDEO CAN BE UPLOADED AT A TIME
                        $(".imagepreview").hide();
                        $(".videopreview").show();

                        console.log("IMAGE ARRAY :", self.state.imageArray);
                        console.log("VIDEO ARRAY :", videoArray);

                        self.state.imageArray = [];
                            imageArray = [];
                        self.state.imageArrayLength = 0;
                        self.setState({
                            imageArray: [],
                            imageArrayLength: 0,
                        })

                        self.handleVideo(event.target.files[i]);
                    } else {
                        Swal.fire({
                            position: 'center',
                            icon: 'warning',
                            text: 'Only 1 video can be uploaded at a time',
                            showConfirmButton: false,
                            timer: 2000
                        })
                    }
                } else {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Only image and video can be uploaded',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }
                /*  } else {
                      Swal.fire({
                          position: 'center',
                          icon: 'warning',
                          text: 'Only ' + fileType + ' can be uploaded',
                          showConfirmButton: false,
                          timer: 2000
                      })
  
                  } */
            }


        }
    }

    /*
    FUNCTION USED TO HANDLE THE UPLOADED IMAGE(IMAGE/PNG/JPEG)
    - IMPLEMENTED BY PRIYANKA - 20-04-2022
    */
    handleBlob = (blobFile) => {

        var self = this;

        // quality value for webp and jpeg formats.
        const quality = 80;
        // output width. 0 will keep its original width and 'auto' will calculate its scale from height.
        const width = 200;
        // output height. 0 will keep its original height and 'auto' will calculate its scale from width.
        const height = "auto";
        // file format: png, jpeg, bmp, gif, webp. If null, original format will be used.
        const format = 'png';

        var reducedFileSize = 0;
        self.state.convertedFileSize = 0;

        // console.log("HANDLE BLOB ************ blobFile :", blobFile);
        // note only the blobFile argument is required
        var originalImage;
        var finalImage;
        var imageData;


        fromBlob(blobFile, quality, width, height, format).then((blob) => {
            // will output the converted blob file
            //  console.log("*** handleBlob blob :", blob);

            // will generate a url to the converted file
            blobToURL(blob).then((url) => (
                //  alert("then"),
                self.state.url = url,
                self.setState({ url: self.state.url }),



                /* getBase64(blob).then(
                 data => (console.log("BASE 64 DATA :",data),
                 self.state.url=data, 
                 self.setState({ url:self.state.url })
                  ) ), */
                // console.log(" uploaded blobFile.size :", blobFile.size, " converted blob.size :", blob.size),
                reducedFileSize = getSize((Number(blobFile.size) - Number(blob.size))),
                self.state.convertedFileSize = getSize(blob.size),
                self.setState({
                    convertedFileSize: self.state.convertedFileSize
                }),
                //  console.log("convertedFileSize :", self.state.convertedFileSize)
                // console.log("*** handleBlob url :",url.size)

                imageData = {
                    data: self.state.url,
                    size: self.state.convertedFileSize
                },

                self.state.imageArray.push(imageData),
                imageArray.push(self.state.url),
                self.setState({ imageArray: self.state.imageArray }),


                /*
                   (convertedFileSize <= standardFileSize).then(()=> 
                   
                   self.state.imageArray.push(imageData),
                   imageArray.push(self.state.url),
                   self.setState({ imageArray: self.state.imageArray }),

                   ).catch(
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'File greater than 5 MB',
                        showConfirmButton: false,
                        timer: 2000
                    })
                    ),
                    */



                console.log("self.state.imageArray :", self.state.imageArray),
                console.log("imageArray :", imageArray)
            ))

        });










    };


    /*
    FUNCTION USED TO HANDLE THE UPLOADED VIDEO
    - IMPLEMENTED BY PRIYANKA - 20-04-2022
    */
    handleVideo = (event) => {
        // var file = event.target.files[0];
        var file = event;


        // console.log("FILE :", file);
        // Encode the file using the FileReader API
        const reader = new FileReader();

        const url = URL.createObjectURL(file);

        this.state.videoURL = url;
        this.state.videoURLArray.push(url);
        this.setState({
            videoURL: this.state.videoURL,
            videoURLArray: this.state.videoURLArray,
        })

        //  console.log("this.state.videoURL :", this.state.videoURL);

        reader.onloadend = () => {
            // Use a regex to remove data url part
            const base64String = reader.result;
            //  .replace('data:', '')
            //   .replace(/^.+,/, '');

            //  console.log("base64String :",base64String);
            videoURL = base64String;
            var videoData = {
                data: videoURL
            }
            videoArray.push(videoURL);


            /*  self.state.videoURL_State = base64String;
              self.setState({
                  videoURL_State: self.state.videoURL
              })
              */
            // Logs wL2dvYWwgbW9yZ...
            //  console.log("videoURL :", videoURL);


        };
        reader.readAsDataURL(file);
        console.log("videoArray :", videoArray);
    };

    /*
    FUNCTION USED FOR REMOVING AN IMAGE 
    - IMPLEMENETED BY PRIYANKA -  20-04-2022
    */
    RemoveImage(image) {

        this.state.imageArray.splice(this.state.imageArray.findIndex(imageData => imageData.data === image), 1)
        this.setState({
            imageArray: this.state.imageArray,
        })

        this.state.imageArrayLength = this.state.imageArray.length;
        this.setState({
            imageArrayLength: this.state.imageArrayLength,
        })
        if(this.state.imageArrayLength == 0){
            this.setState({ imageUploadValid: false }, this.validateForm);
            console.log("this.state.imageArrayLength", this.state.imageArrayLength)
        }
        console.log("this.state.imageArray :", this.state.imageArray);
    }


    /*
   FUNCTION USED FOR REMOVING AN VIDEO 
   - IMPLEMENETED BY PRIYANKA -  29-04-2022
   */
    RemoveVideo(video) {

        this.state.videoURLArray.splice(this.state.videoURLArray.findIndex(videoData => videoData === video), 1)
        this.setState({
            videoURLArray: this.state.videoURLArray,
        })

        this.state.videoURLArrayLength = this.state.videoURLArray.length;
        this.setState({
            videoURLArrayLength: this.state.videoURLArrayLength,
        })
        if(this.state.videoURLArray == 0){
            this.setState({ imageUploadValid: false }, this.validateForm);
            console.log("this.state.imageArrayLength", this.state.imageArrayLength)
        }

        console.log("this.state.videoURLArray :", this.state.videoURLArray);
    }

    Submit() {


        var self = this;
        var uploadData;

        // standardFileSize = 5120.000; //5 MB IN TERMS OF KB
        standardFileSize = 1000000; // 1 GB IN TERMS OF KB
        var uploadType = "Image";
        var sizeCheck = "Yes";
        $("#submit").prop("disabled", true);
        if (videoArray.length > 0) {
            uploadType = "Video";
            uploadData = videoArray;
        } else {
            var imageData = this.state.imageArray.map(function (Img) {
                if (Img.size <= standardFileSize) {
                    return Img.data;
                } else {
                    sizeCheck = "No";
                }
            });
            uploadData = imageData;
        }

        if (sizeCheck == "No") {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                text: uploadType + ' of size greater than 5 MB will not be uploaded',
                showConfirmButton: false,
                timer: 2000
            })
        }

        console.log("SUBMIT DTA :", JSON.stringify({
            companyId: '1',
            uploadData: uploadData,
            module: this.state.moduleName,
            date: this.state.date,
            time: this.state.time,
            menuId: this.state.menuId,
            description: this.state.description,
            uploadType: uploadType,

        }));

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("CompanyId"),
                uploadData: uploadData,
                module: this.state.moduleName,
                date: this.state.date,
                time: this.state.time,
                menuId: this.state.menuId,
                description: this.state.description,
                uploadType: uploadType,
                printPreviewParameter: this.state.printPreviewParameter,

            }),

            url: "http://localhost:8080/IceilAPI/AdminUpload/ItemsUpload",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("MENU UPLOAD DATA :", data);


                if (data.response == "Success") {
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        text: 'Uploaded Successfully',
                        showConfirmButton: false,
                        timer: 2000
                    })



                } else if (data.response == "Few Failed") {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Upload done partially, kindly try after sometime',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }

                $(".imagepreview").hide();
                $(".videopreview").hide();

                menuList = [];
                menuList = data.menuList;

                //CONVERTING THE FLAT ARRAY OF OBJECTS INTO TREE LIST (PARENT - CHILD RELATIONSHIP)
                var treeList = List_To_Tree_With_KeyNameChange_Without_RootMenu(menuList);

                console.log("treeList :", JSON.stringify(treeList));


                self.state.data = [];
                self.state.data = treeList;
                self.setState({
                    data: self.state.data
                })
                self.ClearFunc();

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });
        this.ClearFunc();
    }

    Cancel() {
        this.ClearFunc();
        $("#submit").prop("disabled", true);    
    }


    ClearFunc() {

        window.TreeDropdownContainerComponent.uncheckAll();

        videoArray = [];
        this.state.menuId = "";
        this.state.videoURL = "";
        this.state.moduleName = "";
        this.state.imageArray = [];
        this.state.videoArray = [];
        this.state.videoURLArray = 0;
        this.state.imageArrayLength = 0;
        this.state.description = "";
        this.state.imageUploadType = "";
        this.state.printPreviewParameter = "1";
        this.state.selectedpreviewOption = { label: "1", value: "1" };
        this.state.selectedNodes = "";
            this.state.dropdownValue = [];



        this.setState({
            menuId: this.state.menuId,
            videoURL: this.state.videoURL,
            moduleName: this.state.moduleName,
            imageArray: this.state.imageArray,
            videoArray: this.state.videoArray,
            videoURLArray: this.state.videoURLArray,
            imageArrayLength: this.state.imageArrayLength,
            description: this.state.description,
            imageUploadType: this.state.imageUploadType,
            printPreviewParameter: this.state.printPreviewParameter,
            selectedpreviewOption: this.state.selectedpreviewOption,
            dropdownValue: this.state.dropdownValue,
            selectedNodes: this.state.selectedNodes,
        })
    }

    render() {

        return (
            <div className="">

                <div className="toptitle">
                    <h3>Menu Upload</h3>
                </div>
                <div className="">

                    <div className="row">
                        <div class="col-md-6">
                            <FormErrors formErrors={this.state.selectedNodesError} />
                            <label>Menu <span class="mandatoryfields">*</span></label>
                            {/* Field used to get menus item - it's mandatory field */}
                            <TreeDropdownContainer data={this.state.data} onChange={this.onDropDownTreeChange} />
                        </div>
                        <div class="col-md-6">
                            {/* Field used to set the PRINT PREVIEW - it's mandatory field */}

                            <label>Print Preview Parameter <span id="previewvideo" class="mandatoryfields">*</span></label>
                            <div className={`${this.errorClass(this.state.formErrors.Type)}`}>
                                <SelectSearch options={this.state.printPreviewOptions} value={this.state.selectedpreviewOption} name="selectedpreviewOption" id="preview"
                                    onChange={(e) => this.handleUserInputPreview(e)} placeholder="Select Your Preview Parameter"></SelectSearch>

                            </div>
                        </div>
                        <div class="col-md-6" id="image">
                            <label>Upload Files  <span class="mandatoryfields">*</span></label>
                            {/* Field used to upload the image - it's mandatory field */}
                            {/*  <div className="textfield aligncamera">
                                <input type="file" multiple onChange={this.fileChangedHandler} class="form-control" id="customFile" style={{ background: "#f9f9fd" }} />

                            </div>
                            */}
                            <div className="aligncamera">
                                <a class="uploadicontextfield" onClick={this.uploadfiles}>
                                    <input type="file" multiple onChange={this.fileChangedHandler} style={{ display: "none" }} id="customFile" /><span id="file-name">Upload</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label>Description</label>
                            {/* Field used to set the description text - it's non-mandatory field */}
                            <input type="text"
                                className="textfield textfield_class "
                                onChange={this.handleUserInput}
                                name="description"
                                placeholder="Description"
                                value={this.state.description}
                                required />
                        </div>
                    </div>

                    <div className="row">
                        {(this.state.imageArray.length > 0 ?
                            (this.state.imageArray.map((data) => (
                                data != null && data != undefined
                                    ? (<div class="col-md-3 imagepreview" >
                                        <div class="card card-box" style={{ background: "#fff" }}>
                                            <h4 style={{ textAlign: "center" }}>Image Preview</h4>
                                            {(data.size <= standardFileSize ?
                                                <h5 style={{ textAlign: "center" }}>{data.size + "KB"}</h5> :
                                                <h5 style={{ textAlign: "center", color: 'red' }}>{data.size + "KB"}</h5>
                                            )}
                                            <div class="text-center">
                                                <img id="image" src={data.data} style={{ width: "100%" }} />
                                                <button className="removebtn" onClick={() => this.RemoveImage(data.data)} ><FcIcons.FcRemoveImage /> </button>
                                            </div>
                                        </div>
                                    </div>)

                                    : (<div class="col-md-3">

                                    </div>)
                            ))) : (<div class="col-md-3">

                            </div>)

                        )}

                        {(this.state.videoURLArray.length > 0 ?
                            (this.state.videoURLArray.map((data) => (
                                data != null && data != undefined
                                    ? (
                                        <div class="col-md-3 videopreview" >
                                            <div class="card card-box" style={{ background: "#fff" }}>
                                                <h4 style={{ textAlign: "center" }}>Video Preview</h4>
                                                <div class="text-center">
                                                    <ReactPlayer url={data} className='react-player' playing={false}
                                                        controls width='100%' height='180px' />
                                                    <button className="removebtn" onClick={() => this.RemoveVideo(data)} ><FcIcons.FcRemoveImage /></button>
                                                </div>
                                            </div>

                                        </div>)

                                    : (<div class="col-md-3">

                                    </div>)
                            ))) : (<div class="col-md-3">

                            </div>)

                        )}
                    </div>

                    {/*
                    <div class="col-md-4 col-xs-12 logopreview" >
                        <div class="card cardlogo" style={{ background: "#fff" }}>
                            <h4 style={{ textAlign: "center" }}>Image Preview</h4>
                            <h5 style={{ textAlign: "center" }}>{this.state.convertedFileSize + "KB"}</h5>
                            <div class="text-center">
                                <img id="logopreview" src={this.state.url} alt="" style={{ padding: "20x" }}></img>
                            </div>
                        </div>

                    </div>
*/}


                    {/*    <div class="col-md-4 col-xs-12 videopreview" >
                        <div class="card cardlogo" style={{ background: "#fff" }}>
                            <h4 style={{ textAlign: "center" }}>Video Preview</h4>
                            <div class="text-center">
                                <ReactPlayer url={this.state.videoURL} className='react-player' playing={false}
                                    controls width='320px' height='180px' />
                            </div>
                        </div>

                    </div>
                    */}

                    <div className="text-center">
                        <button id="submit" class="btn btn-primary btn-submit" disabled={!this.state.formValid} onClick={() => this.Submit()}>Submit</button>
                        <button class="btn btn-primary btn-cancel" onClick={() => this.Cancel()}>Cancel</button>

                    </div>
                </div>

            </div>
        )
    }
}
export default MenuUpload;

const getSize = (size) => (console.log("GET SIZE :", size), (size / 1024).toFixed(3));
