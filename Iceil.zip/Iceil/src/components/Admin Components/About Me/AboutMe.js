import React, { Component, Suspense } from 'react';

import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import ReactDOM from 'react-dom';
import $ from 'jquery';

import Case from "case";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';

import CryptoJS from 'crypto-js';
import * as FaIcons from 'react-icons/fa';
import { GetLocalStorageData } from '../../Common Components/CommonComponents';
import TextField from '@mui/material/TextField';
import { ThemeProvider, createTheme } from '@mui/material/styles';


const darkTheme = createTheme({
    palette: {
      mode: 'dark',
    },
  });

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class AboutMe extends Component {



    constructor(props) {
        super(props);
        this.state = {

        }
    }


    componentDidMount() {


        this.state.userName = GetLocalStorageData("UserName");
        this.state.email = GetLocalStorageData("EmailId");
        this.state.userType = GetLocalStorageData("UserType");
        this.state.companyName = GetLocalStorageData("CompanyName");


        if (this.state.userType == 'User_Franchise') {
            this.state.userType = "Franchise";
        }

        this.setState({
            userName: this.state.userName,
            email: this.state.email,
            userType: this.state.userType,
            companyName: this.state.companyName,
        })
    }


    render() {


        return (

            <div class="">
                 <ThemeProvider theme={darkTheme}>
                <div class="col-md-12">
                    <div class="toptitle">
                        <h4>About Me</h4>
                    </div>

                    <div class="container-fluid" style={{ padding: '30px' }}>

                        <div class="row">
                            <div class="col-md-6">
                                {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD   */}
                                {/* <label class="control_label_text">User Name</label> */}
                                {/* <input type="text" class="form-control" id="userEmail" name="userName"
                                    value={this.state.userName} readOnly ></input> */}
                                     <TextField fullWidth margin="normal" label=' User Name'  id="userEmail" name="userName"
                                    value={this.state.userName} InputProps={{readOnly: true,}}  />
                                <br />
                            </div>
                            <div class="col-md-6">
                                {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
                                {/* <label class="control_label_text">Email/Mobile No</label>
                                <input type="text" class="form-control" id="email" value={this.state.email}
                                    name="email" readOnly /> */}
                                      <TextField fullWidth margin="normal" label=' Email/Mobile No' id="email" value={this.state.email}
                                    name="email" InputProps={{readOnly: true,}}  />
                                <br />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
                                {/* <label class="control_label_text">User Type</label>
                                <input type="userType" class="form-control" id="userType" value={this.state.userType}
                                    name="userType" readOnly /> */}
                                       <TextField fullWidth margin="normal" label=' User Type'  id="userType" value={this.state.userType}
                                    name="userType" InputProps={{readOnly: true,}}  />
                                <br />
                            </div>
                            <div class="col-md-6">
                                {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
                                {/* <label class="control_label_text">Organization</label>
                                <input type="userType" class="form-control" id="userType" value={this.state.companyName}
                                    name="userType" readOnly /> */}
                                      <TextField fullWidth margin="normal" label=' Organization' id="userType" value={this.state.companyName}
                                    name="userType" InputProps={{readOnly: true,}}  />
                                <br />
                            </div>
                        </div>

                    </div>
                </div>
                </ThemeProvider>
            </div>

        );
    }

}
export default AboutMe;
