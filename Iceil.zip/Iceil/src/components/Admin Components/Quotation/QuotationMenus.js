//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import { BrowserRouter,Routes,Route} from 'react-router-dom';
import ReactDOM from "react-dom";
import $ from "jquery";
// import statement for react class component
import GenerateQuotation from "./GenerateQuotation";
import QuotationList from "./QuotationList";

class QuotationMenus extends React.Component{
    constructor(){
        super();
        this.state={
            quotationData: 'GenerateQuotation',
        }
    }  
    componentDidMount(){
console.log("this did mount quotation");
    }
    generateQuotation(){
        $(".tabs").removeClass("active");
        $(".generatequotation").addClass("active");
        this.state.quotationData='GenerateQuotation';
        this.setState({
            quotationData:this.state.quotationData
          })
        ReactDOM.render(
        <BrowserRouter>
<Routes>
<Route path="/" element={<QuotationMenus />} />
 <Route path="/" element={<GenerateQuotation />} />
                </Routes>
</BrowserRouter>,
            document.getElementById("contentRender")
        );
    }
    quotationList(){
        $(".tabs").removeClass("active");
        $(".quotationlist").addClass("active");
        this.state.quotationData='QuotationList';
        this.setState({
            quotationData:this.state.quotationData
          })
        ReactDOM.render(
        <BrowserRouter>
<Routes>
    
<Route path="/" element={<QuotationMenus />} />
 <Route path="/" element={<QuotationList />} />
                </Routes>
</BrowserRouter>,
            document.getElementById("contentRender")
        );
    }
  RenderComponenets(quotationData) {

    var self = this;

    switch (quotationData) {
      case 'GenerateQuotation':
        return  <GenerateQuotation /> 
      case 'QuotationList':
        return  <QuotationList /> 
      default:
        return <div></div>;
    }

  }
render() {

    return (
        <div className="">
<div className="toptitle">
<h3>Quotation</h3>
</div>
<div className="container-fluid">
<ul class="nav nav-tabs">
          <li class="generatequotation tabs  active"><a onClick={() => this.generateQuotation()}><span style={{ display: "inline-grid" }}>Generate Quotation</span></a></li>
          <li className="quotationlist tabs"><a onClick={() => this.quotationList()}><span style={{ display: "inline-grid" }}>Quotation List</span></a></li>
        </ul>
     {this.RenderComponenets(this.state.quotationData)}
     </div>
        </div>

    );
};
}
export default QuotationMenus;