//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import ReactTable from "react-table-v6";
import SlidingPane from "react-sliding-pane";
import $ from 'jquery';
import _ from 'underscore';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import Pagination from "react-js-pagination";
import MonthYearPicker from 'react-month-year-picker';
import moment from "moment";
// import statement for react class component
import {StatusDropDown} from '../../Assets Components/DropdownComponents/DropdownComponent';
import {QuotationViewIcons} from '../../Assets Components/Icon Components/Iconcomponents';
import {TimeZoneDateTime } from '../../Common Components/CommonComponents';
import QuotationView from "../Quotation/QuotationView";
import "./QuotationCss.css";
// import statement for react component css
import "react-table-v6/react-table.css";
import "react-sliding-pane/dist/react-sliding-pane.css";

var quotationList;

var dataCount = 0;
var dataCountArray = [];
var itemData = 1;
var pageArray = [];
var pageData_Status;
class QuotationList extends React.Component{
       constructor(){
         super();      
    this.state= {
        totlaItemCount: 0,
        itemsPerPage: 10,
        activePage: 1,
        month: "",
        presentyear: 2022,
        quotationData: [],
        columns: [],
        isQuotationViewPaneOpen: false,
        }
               this.quotationView = this.quotationView.bind(this);
    }
    componentDidMount(){
        $("#tableOverflow1").hide();
        console.log("quotation list page");
        this.state.columns = [
            {
                Header: 'SNO',
                accessor: 'SNO'
            },
            {
                Header: 'Id',
                accessor: 'Id'
            },
            {
                Header: 'Amount',
                accessor: 'Amount'
            },
            {
                Header: 'Status',
                accessor: 'Status'
            }
        ]

        this.setState({
            columns: this.state.columns,
        })
        this.getData();
                /*
        GETTING DATE & TIME FOR DATEPICKER
        - IMPLEMENTED BY RAMYA - 14-05-2022
        */
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        console.log("dateTimeData :", dateTimeData);
        var year = dateTimeData.date.split("-")[0];
        var month = dateTimeData.date.split("-")[1];
        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.state.currentyear = year;
        this.state.currentmonth = moment(month, 'M').format('MMMM');
        this.setState({
            date: this.state.date,
            time: this.state.time, 
            currentyear: this.state.currentyear,
            currentmonth: this.state.currentmonth,
        })
        $(document).ready(function () {
          $("#monthselect").click(function () {
              $(".month-year-picker").toggleClass("active");
          });                    
      });
    $(document).ready(function () {
      $(".month-year-picker .month-picker > div > div").click(function () {
          $(".month-year-picker").removeClass("active");
      });            
  });
  $(document).ready(function () {
    $(".reactIcon_Btn > ul > li").click(function () {
        $(".month-year-picker").removeClass("active");
    });  
});
    
    }


        /* USED TO HANDLE THE PAGINATION- IMPLEMENTED BY DURGA 29-04-2022 */   
        handlePageChange(pageNumber) {

            this.state.activePage = pageNumber;
            this.setState({ activePage: pageNumber });
        
            var self = this;
        
        
            pageData_Status = false;
            pageData_Status = _.contains(pageArray, this.state.activePage);
        
            dataCount = 0;
            self.state.oldPageAcces = "false";
            self.setState({
              oldPageAcces: self.state.oldPageAcces
            });
        
            if (pageData_Status == false) {
        
              pageArray.push(pageNumber);
              dataCount = Math.round((Number(dataCount)) + ((Number(pageNumber) - 1) * 10));
              dataCountArray.push(dataCount);
        
            } else if (pageData_Status == true) {
        
              var currentPageIndex = _.indexOf(pageArray, this.state.activePage);
              dataCount = dataCountArray[currentPageIndex];
        
            }
            this.getData();
          }
      
       /* USED TO GET THE QUOTATION LIST DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 29-04-2022 */       
        getData()
        {
        console.log("get data");
          var self=this;
          $.ajax({
            type: 'POST',
            data: JSON.stringify({
            companyId:'1',
            dataCount: dataCount,
            totlaItemCount: this.state.totalItemCount,
            }),
              url: "http://localhost:8080/IceilAPI/QuotationWebService/SelectQuotationDetails",
              contentType: "application/json",
              dataType: 'json',
              async: false,
      
            success: function (data, textStatus, jqXHR) {
      
                console.log("data",data);
      
                quotationList = data.quotationList;
                console.log(quotationList);
                if (data.quotationList !== null && data.quotationList.length != 0) {
                  var no = 0;
                  if (itemData == "1") {
                    self.state.totlaItemCount = data.totlaItemCount;
        
                    itemData = Number(itemData) + 1;
                  }
        
                } else {
                  itemData = "1";
                  self.state.totlaItemCount = 0;
                }
      
      
                 self.PopulateProductData(quotationList);
        },
        error: function (data) {
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'Network Connection Problem',
            showConfirmButton: false,
            timer: 2000
          })
        },
      });
      } 
      GetColumns() {
      
          return Object.keys(this.state.quotationData[0]).map(key => {
        
              return {
                  Header: key,
                  accessor: key,
        
              };
        
          });
        }
      
      /* USED TO POPULATE QUOTATION LIST INTO TABLE- IMPLEMENTED BY DURGA 22-04-2022 */       
      PopulateProductData(quotationList)
      {
          var self=this;
          var count=0;  
         console.log("populate data",quotationList);
         self.state.quotationData=[];
        $("#tableHeadings").empty();
      
          var tab = '<thead><tr class="headcolor"><th>SNO</th><th>Id</th><th>Amount</th><th>Status</th></tr></thead>';
          var tempStatus;
          $.each(quotationList, function (i, item) {
           
            count=Number(count)+1;
            console.log(item.rate,item.status);

            if (item.status == 0) {

                tempStatus = <span style={{ color: "green", fontWeight: "700" }}>Generated</span>
              }
                
            tab += '<tbody id= "myTable" ><tr  id="tabletextcol" ><td>' + count + '</td>'
            +'<td>' + item.quotationId + '</td>'
            +'<td>' + item.rate + '</td>'
            +'<td>' + tempStatus + '</td>' 
           
                  self.state.quotationData[i]={ 

                      "SNO":count,
                      "Id":item.quotationId,
                      "Amount":item.rate,
                      "Status":tempStatus
                    }
              });
      
              $("#tableHeadings").append(tab);
      
              self.state.columns=this.GetColumns();
      
              self.setState({
      
                 TableColumns:self.state.columns,
                 quotationData:self.state.quotationData,
              });
                 console.log("data",self.state.quotationData) ;
      
      }
      
      
/* HANDLE ROW SELECTION-USED TO STORE THE SELECTED ROW DATAS [IN TABLE WHILE SELECTING THE ROW]- IMPLEMENTED BY DURGA 22-04-2022 */ 
onTrRowClick = (state, rowInfo, column, instance) => {
    var self = this;

    if (typeof rowInfo !== "undefined") {
      return {
        onClick: (e, handleOriginal) => {
          this.setState({
            selected: rowInfo.index
          });
          if (handleOriginal) {
            handleOriginal()
          }


          this.state.rowIndexValue = rowInfo.index;
          
          console.log("index value",this.state.rowIndexValue);
          console.log("index value",quotationList[rowInfo.index]);

          this.state.selectedData=quotationList[rowInfo.index];
          this.setState({
            rowIndexValue: this.state.rowIndexValue,
            selectedData:this.state.selectedData
          });

          console.log("selectedData",this.state.selectedData);
          
        },
        style: {
          background: rowInfo.index === this.state.selected ? '#DB7093' :' ',
        },
      }
    }
    else {
      return {
        onClick: (e, handleOriginal) => {
          if (handleOriginal) {
            handleOriginal()
          }
        },
        style: {
         
        },
      }
    }
  };
    quotationView(){
        var self=this;
        if (self.state.rowIndexValue === undefined || self.state.rowIndexValue == "") {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Kindly, Select the Quotation to View! ',
            timer:2000
          })
        }
        else
        {
          self.state.isQuotationViewPaneOpen = true;
          self.setState({
              isQuotationViewPaneOpen: self.state.isQuotationViewPaneOpen,
          }) 
  }
       
    }
    CloseQuotationView() {
        this.state.isQuotationViewPaneOpen = false;
        this.setState({
            isQuotationViewPaneOpen: this.state.isQuotationViewPaneOpen,
        })
    }
    render(){
        return( 
<div>
<div className="text-center mt-40">
<h3>{this.state.currentmonth} - <span> {this.state.presentyear} </span></h3>
    </div>
    <div className="row mt-20"> 
<div class="top-menus">
{/* FIELD USED TO get the status */}
<StatusDropDown />
{/* FIELD USED TO get the month and year */}
<div className="site_dropstyle">
    <label>Select Month</label>
    <div>
    <input className="form-control" value={this.state.currentmonth +  " " + this.state.presentyear} type="text" id="monthselect"  />
    <MonthYearPicker
          selectedMonth={this.state.month}
          selectedYear={this.state.presentyear}
          minYear={2010}
          maxYear={2030}
          onChangeYear={year => this.setState({ presentyear: year })}
          onChangeMonth={month =>(
           this.setState({ currentmonth: moment(month, 'M').format('MMMM') }))}    
        />
              </div>
              </div>
<QuotationViewIcons onQuotationView={this.quotationView} />
</div>
           
            <div id="tableOverflow1">
              <table style={{ margin: "auto" }} class="table table-bordered" id="tableHeadings">
              </table>
            </div>
            <div style={{ marginTop: '50px' }}>
                    <ReactTable
                        data={this.state.quotationData}
                        columns={this.state.columns}
                        noDataText="No Data Available"
                        filterable
                        defaultPageSize={10}
                        className="-striped -highlight"
                        defaultFilterMethod={(filter, row, column) => {
                            const id = filter.pivotId || filter.id;
                            return row[id] !== undefined
                                ? String(row[id])
                                    .toLowerCase()
                                    .indexOf(filter.value.toLowerCase()) !== -1
                                : true;
                        }}
                        showPaginationTop={false}
                        showPaginationBottom={true}
                        getTrProps={this.onTrRowClick}
                    /></div>
        
        <div style={{ marginBottom: "3%" }} className="pull-right" id="paginationdiv">
         
         <Pagination
           activePage={this.state.activePage}
           itemsCountPerPage={this.state.itemsPerPage}
           totalItemsCount={this.state.totlaItemCount}
           pageRangeDisplayed={5}
           itemClass="page-item"
           linkClass="page-link"
           onChange={this.handlePageChange.bind(this)}
         /></div>

</div>
            <SlidingPane
              className="some-custom-class"
              overlayClassName="some-custom-overlay-class"
              isOpen={this.state.isQuotationViewPaneOpen}
              title={"Quotation View"}
              onRequestClose={() => {
                  this.CloseQuotationView()
              }} >
                    <QuotationView  selectedData={this.state.selectedData} />
                </SlidingPane>
</div>
        );
    }
}

export default QuotationList;