//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
// import statement for image
import $ from 'jquery';
import _ from 'underscore';
import Modal from 'react-modal';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { QuotationImage, QuotationProduct } from './QuotationComponent';
import { GetLocalStorageData,TimeZoneDateTime } from "../../Common Components/CommonComponents";
import { Truncate_2DecimalPlaces } from "../../Validation Components/FormErrors";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    }
};
class QuotationEdit extends React.Component {
    constructor() {
        super();
        this.state = {
            cartData: [],
            imageCartData: [],
            quotationNo: '',
            status: '',
            submittedDate: '',
            totalIteminCart: '',
            totalAmount: 0,
            gstTax: 0,
            amounttobePaid: 0,
            date:'',
            time:''
        }
     //   this.editProduct = this.editProduct.bind(this);
         this.ReplaceNewValueFunc=this.ReplaceNewValueFunc.bind(this);
         this.UpdateQuotation=this.UpdateQuotation.bind(this);
         this.CancelFunc = this.CancelFunc.bind(this);
    }

    componentDidMount() {
        var self = this;

        //console.log("qut edit");
        //console.log(self.props.selectedData);
        this.GetData();
    }

    handleUserInput = (e) => {

        //console.log("handleUserInputproductName", e);

        const name = e.target.name;
        const value = e.target.value;
        this.setState({ [name]: value });
        //console.log("productname", this.state.productName);

    }
    /* USED TO GET THE SINGLE QUOTATION DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 29-04-2022 */   
    GetData() {
            var self = this;
            $.ajax({
                type: 'POST',
                data: JSON.stringify({
                    quotationNo: this.props.selectedData.quotationNo,
                    companyId: GetLocalStorageData("CompanyId"),
                }),
            
                url: "http://15.206.129.105:8080/IceilLiveAPI/AdminQuotationWebService/SelectQuotation",
                contentType: "application/json",
                dataType: 'json',
                async: false,
                crossDomain: true,
                success: function (data, textStatus, jqXHR) {
                    //console.log("data.viewQuotationList", data.viewQuotationList);
                    if (data.viewQuotationList != null || data.viewQuotationList != undefined) {

                        var ProductQuotationList = _.where(data.viewQuotationList, { type: "Product" });
                        var ImageQuotationList = _.where(data.viewQuotationList, { type: "Image" });
        
                        self.state.quotationNo = data.viewQuotationList[0].quotationNo;
                        self.state.status = data.viewQuotationList[0].status;
                        if (self.state.status == 0) {//Status= 0 - Quotation submitted 

                            self.state.status = 'Submitted';
                        }
                        else if (self.state.status == 1) {//Status=1 - Cancelled  
                            self.state.status = 'Cancelled';
                        }
                        else if (self.state.status == 2) { //Status=2 - Accepeted-inprogress 
                            self.state.status = 'Inprogress';
                        }
                        else if (self.state.status == 3) {//Status=3 - Completed    
                            self.state.status = 'Completed';
                        }
                        else if (self.state.status == 4) { //Status=4 - Edited
                            self.state.status = 'Edited';
                        }
                       
                        self.state.submittedDate = data.viewQuotationList[0].date;
                        self.state.totalIteminCart = data.viewQuotationList[0].totalIteminCart;
                        self.state.totalAmount = data.viewQuotationList[0].totalAmount;
                        self.state.gstTax = data.viewQuotationList[0].totalGstTax;
                        self.state.amounttobePaid = data.viewQuotationList[0].amounttobePaid;
                        self.state.franchiseName = data.viewQuotationList[0].franchiseName;
                        self.state.franchiseId = data.viewQuotationList[0].franchiseId;
                        self.state.quantity = data.viewQuotationList[0].quantity;
                        self.state.cartData = ProductQuotationList;
                        self.state.imageCartData = ImageQuotationList;

                        self.setState({
                            cartData: self.state.cartData,
                            imageCartData:  self.state.imageCartData,
                            quantity:self.state.quantity,
                            franchiseName: self.state.franchiseName,
                            franchiseId: self.state.franchiseId,
                            quotationNo: self.state.quotationNo,
                            status: self.state.status,
                            submittedDate: self.state.submittedDate,
                            totalIteminCart: self.state.totalIteminCart,
                            totalAmount: self.state.totalAmount,
                            gstTax: self.state.gstTax,
                            amounttobePaid: self.state.amounttobePaid,

                        })

                        //console.log("gstTax", self.state.gstTax,"franchiseName",self.state.franchiseName);
                        //console.log("cartData-edit", self.state.cartData);
                        window.QuotationImageComponent.SetImageList(self.state.imageCartData);
                        window.QuotationProductComponent.SetProductList(self.state.cartData);
                        
                    }

                },
                error: function (data) {
                    Swal.fire({
                        position: 'center',
                        icon: 'error',
                        title: 'Network Connection Problem',
                        showConfirmButton: false,
                        timer: 2000
                    })
                },
            });


    }
    /*USED RE-CALCULATE THE TOTAL AMOUNT,TAX AFTER POP EDIT VALUES - IMPLEMENTED BY DURGA 23-05-2022 */   
    ReplaceNewValueFunc(newCartData)
        {
            //console.log("b4 cartDataCopy parent",this.state.cartData);
        // //console.log("parent-ReplaceNewValueFunc",newCartData);
        
            var cartDataCopy = [...this.state.cartData]; // make a separate copy of the array
        
            var index=_.findIndex(cartDataCopy, { ProductCode: newCartData.productCode});
            cartDataCopy.splice(index, 1, newCartData);

            //console.log("atr cartDataCopy parent",cartDataCopy);

            var totalAmount=0;
            var gstTax=0,amounttobePaid=0;
           
            for(var i=0;i<cartDataCopy.length;i++)
            {
                //console.log(gstTax,"gstTax","cartDataCopy[i].gstTax",cartDataCopy[i].gstTax);

                totalAmount=Number(totalAmount)+Number(cartDataCopy[i].rate);
                gstTax=Number(gstTax)+Number(cartDataCopy[i].gstTax);

            }
            amounttobePaid=Number(totalAmount)+Number(gstTax);
            this.state.totalAmount=Truncate_2DecimalPlaces(totalAmount);
            this.state.gstTax=Truncate_2DecimalPlaces(gstTax);
            this.state.amounttobePaid=Truncate_2DecimalPlaces(amounttobePaid);
            this.state.cartData=cartDataCopy;

            this.setState({
                cartData:this.state.cartData,
                totalAmount: this.state.totalAmount,
                gstTax: this.state.gstTax,
                amounttobePaid: this.state.amounttobePaid,
                totalIteminCart:this.state.totalIteminCart
                })
                //console.log("final cart data",this.state.cartData);
                
                window.QuotationProductComponent.SetProductList(this.state.cartData); //RENDER THE EDITED VALUES ON CARDVIEW
                //console.log("quotationNo",this.state.quotationNo,"totalIteminCart",this.state.totalIteminCart,
               // "totalAmount",this.state.totalAmount,"amounttobePaid",this.state.amounttobePaid,"gstTax",this.state.gstTax,);
    }
    /*USED RE-CALCULATE THE IMAGE-AFTER POP EDIT VALUES - IMPLEMENTED BY DURGA 23-05-2022 */  
        ImageReplaceNewValueFunc(newImageCartData)
            {
                // //console.log("b4 cartDataCopy parent",this.state.imageCartData);
            
                // var imageCartDataCopy = [...this.state.imageCartData]; // make a separate copy of the array
            
                // var index=_.findIndex(imageCartDataCopy, { id: newImageCartData.id});
                // imageCartDataCopy.splice(index, 1, newImageCartData);

            
        }
    /* UPDATING QUOTATION AFTER EDIT THE PRODUCT AND IMAGE DETAILS-IMPLEMENTED BY DURGA 02-05-2022*/
        UpdateQuotation()
        {
        var self = this;
        //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 29-04-2022
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        //console.log("dateTimeData :", dateTimeData);
        self.state.date = dateTimeData.date;
        self.state.time = dateTimeData.time;
        self.setState({
            date:self.state.date,
            time:self.state.time,
        })

            //console.log("this.state.franchiseId",this.state.franchiseId,"imageCartData",this.state.imageCartData,"totalIteminCart",this.state.totalIteminCart,
           // "totalAmount",this.state.totalAmount,"amountToBePaid",this.state.amounttobePaid,"gstTax",this.state.gstTax,);
            $.ajax({
                type: 'POST',
                data: JSON.stringify({
                    companyId: GetLocalStorageData("CompanyId"),
                    userName:this.state.franchiseName,
                    franchiseId:this.state.franchiseId,
                    quotationNo: this.state.quotationNo,
                    date:this.state.date,
                    time:this.state.time,
                    totalIteminCart:this.state.totalIteminCart,
                    totalAmount:this.state.totalAmount,
                    amounttobePaid:this.state.amounttobePaid,
                    totalGstTax:this.state.gstTax,
                    cartProductList:JSON.stringify(this.state.cartData),
                    cartImageList: JSON.stringify(this.state.imageCartData),
                }),
//15.206.129.105
                url: "http://15.206.129.105:8080/IceilLiveAPI/AdminQuotationWebService/UpdateQuotation",
                contentType: "application/json",
                dataType: 'json',
                async: false,
                crossDomain: true,
                success: function (data, textStatus, jqXHR) {
                    //console.log(data);
                    if(data.response=="UpdateSuccess")
                    {
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            text: 'Update Quotation Success',
                            showConfirmButton: false,
                            timer: 2000
                        })
                        self.CancelFunc();
                    }

                    self.props.AfterEditGetData();
                },
                error: function (data) {
                    Swal.fire({
                        position: 'center',
                        icon: 'error',
                        title: 'Network Connection Problem',
                        showConfirmButton: false,
                        timer: 2000
                    })
                },
            });
           
        }
            /*USED TO CLOSE THE SIDEPANEL EDIT WHILE CLICKING SUBMIT AND CANCEL IMPLEMENTED BY RAMYA 01-06-2022*/
            CancelFunc(){
                this.props.CancelClicked(this);
            }

    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-3">
                        <label>Franchise</label>
                        <div>
                            {/* FIELD USED TO VIEW Franchise */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.props.selectedData.franchiseName} id="franchise" name="franchise" readOnly />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <label>Quotation No</label>
                        <div>
                            {/* FIELD USED TO VIEW Quotation No */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.quotationNo} id="quotationNo" name="quotationNo" readOnly />
                        </div>
                    </div>
                    <div className="col-md-3"><label>Status</label>
                        <div>
                            {/* FIELD USED TO VIEW Status  */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.status} id="status" name="status" readOnly />
                        </div></div>
                    <div className="col-md-3"><label>Submitted Date</label>
                        <div>
                            {/* FIELD USED TO VIEW Submitted Date */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.submittedDate} id="submittedDate" name="submittedDate" readOnly />
                        </div></div>
                    <div className="col-md-3"><label>Accepted Date </label>
                        <div>
                            {/* FIELD USED TO VIEW Accepted Date  */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.acceptedDate} id="acceptedDate" name="acceptedDate" readOnly />
                        </div></div>
                    <div className="col-md-3"><label>Completed Date</label>
                        <div>
                            {/* FIELD USED TO VIEW Completed Date */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.completedDate} id="completedDate" name="completedDate" readOnly />
                        </div></div>
                    <div className="col-md-3"><label>Cancelled Date</label>
                        <div>
                            {/* FIELD USED TO VIEW Submitted Date */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.cancelledDate} id="cancelledDate" name="cancelledDate" readOnly />
                        </div>
                    </div>
                </div>
                <div className="row card-box">
                    <div className="col-md-3">
                        <label>Total Amount</label>
                        <div>
                            {/* FIELD USED TO edit Total Amount */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" readOnly />
                        </div></div>
                    <div className="col-md-3">
                        <label>GST Tax</label>
                        <div>
                            {/* FIELD USED TO edit GST Tax */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.gstTax} id="gstTax" name="gstTax" readOnly />
                        </div></div>
                    <div className="col-md-3">
                        <label>Amount to be paid</label>
                        <div>
                            {/* FIELD USED TO edit Amount to be paid*/}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.amounttobePaid} id="amounttobePaid" name="amounttobePaid" readOnly />
                        </div></div>
                    <div className="col-md-3">
                        <label>Total Item on Cart</label>
                        <div>
                            {/* FIELD USED TO edit Total Amount */}
                            <input className="textfield" type="text" onChange={this.handleUserInput} value={this.state.totalIteminCart} id="totalAmount" name="totalAmount" readOnly />
                        </div></div>

                </div>
                <QuotationImage imageCartData={this.state.imageCartData} ImageReplaceNewValueFunc={this.ImageReplaceNewValueFunc}/>
                 <QuotationProduct stateData={this.state} cartData={this.state.cartData} ReplaceNewValueFunc={this.ReplaceNewValueFunc}/> 

                <div className="text-center mt-20">
                    <button className="btn btn-primary btn-submit" onClick={this.UpdateQuotation}>Submit</button>
                    <button className="btn btn-primary btn-cancel"  onClick={this.CancelFunc}>Cancel</button>
                    
                </div>
            </div>
        );
    }
}

export default QuotationEdit;


