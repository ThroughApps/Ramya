//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import SelectSearch from 'react-select';
import $ from 'jquery';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import _ from "underscore";
import { Truncate_2DecimalPlaces,CheckNumberFormat_WithoutDecimal} from "../../Validation Components/FormErrors";
import { ErrorClass } from '../../Validation Components/Loginvalidation';
// import statement for class component css
import '../../StyleCss.css';

// import statement for react component css
import "react-table-v6/react-table.css";
import "react-sliding-pane/dist/react-sliding-pane.css";

// import statement for react class component
import {FranchiseQuotationImage, FranchiseQuotationProduct} from '../Quotation/QuotationMenus';


class Quotation extends React.Component{
    
    constructor(){
        super();
        //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 29-04-2022
        var today = new Date();
        var tempDate = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
        var tempTime=today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
        
        this.state={
            date:tempDate,
            time:tempTime,
            productOptions: [],
            quantity:1,
            totalAmount:0,
            totalIteminCart:0,
            amountToBePaid:0,
            gstTax:0,
            selectedProductName:'',
            cartData:[],

            isQuotationEditPaneOpen: false,
            isQuotationViewPaneOpen: false,
        }
        this.quotationEdit = this.quotationEdit.bind(this);
        this.quotationView = this.quotationView.bind(this);
        this.AddtoCartFunc=this.AddtoCartFunc.bind(this);
        this.CancelFunc=this.CancelFunc.bind(this);
    }

    /*
   FUNCTION USED TO OPEN THE QUOTATION EDIT SIDEPANE
   IMPLEMENTED BY RAMYA - 28-04-2022
   */
quotationEdit(){
    var self=this;
    self.state.isQuotationEditPaneOpen = true;
    self.setState({
        isQuotationEditPaneOpen: self.state.isQuotationEditPaneOpen,
    }) 
}
    /*
   FUNCTION USED TO OPEN THE QUOTATION VIEW SIDEPANE
   IMPLEMENTED BY RAMYA - 28-04-2022
   */
quotationView(){
    var self=this;
    self.state.isQuotationViewPaneOpen = true;
    self.setState({
        isQuotationViewPaneOpen: self.state.isQuotationViewPaneOpen,
    }) 
}
quotationAccept(){}
quotationCancel(){}
quotationComplete(){}
    /*
   FUNCTION USED TO CLOSE THE QUOTATION EDIT SIDEPANE
   IMPLEMENTED BY RAMYA - 28-04-2022
   */
CloseQuotationEdit() {
    this.state.isQuotationEditPaneOpen = false;
    this.setState({
        isQuotationEditPaneOpen: this.state.isQuotationEditPaneOpen,
    })
}
    /*
   FUNCTION USED TO CLOSE THE QUOTATION VIEW SIDEPANE
   IMPLEMENTED BY RAMYA - 28-04-2022
   */
CloseQuotationView() {
    this.state.isQuotationViewPaneOpen = false;
    this.setState({
        isQuotationViewPaneOpen: this.state.isQuotationViewPaneOpen,
    })
}
componentDidMount(){
   // console.log("generate quotation ");
    var self= this;
    this.getData();
    //AFTER GET THE PRODUCT DETAILS ITERATE THE ARRAY AND PUSH THE PRODUCTLIST INTO REACT ARRAY-IMPLEMENTED BY DURGA 27-04-2022 //
    var productOptions = [];
    $.each(self.state.productArrayList, function (i, item) 
    {
        productOptions.push({ label: item.productName , value: item.productCode });
    })

    self.state.productOptions = productOptions;
    self.setState({
        productOptions: productOptions,
    })
}


/* USED TO GET THE PRODUCT LIST DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 27-04-2022 */      
getData()
{
    var self=this;
      
        $.ajax({
          type: 'POST',
          data: JSON.stringify({
            companyId: '1',
          }),
          url: "http://localhost:8080/IceilAPI/QuotationWebService/SelectProductDetails",
          contentType: "application/json",
          dataType: 'json',
          async: false,
    
          success: function (data, textStatus, jqXHR) {
            
           // console.log("data",data);

          if(data.productList!=null)
          {
            self.state.productArrayList=data.productList;
            self.setState({productArrayList:self.state.productArrayList})
          //  console.log("self ProductList data", self.state.productArrayList);
          }

          },
          error: function (data) {
            Swal.fire({
              position: 'center',
              icon: 'error',
              title: 'Network Connection Problem',
              showConfirmButton: false,
              timer: 2000
            })
          },
        });
}
/*HANDLE THE PRODUCT SELECTION,RATE & TAX  FIELDS
SET & POPUP IN UI IMPLEMENTED BY DURGA 27-04-2022 */

handleProductDetails(e){

    var self=this;
    const name = e.name;
    const value = e.value;
    this.state.selectedProductName = e;
    //console.log(e);
    if(this.state.cartData.length > 0)
    {
        $("#addtocart").prop('disabled', false);
    }
    
    var productDetails = _.findWhere(this.state.productArrayList, { productCode: value });
    console.log("productdetails",productDetails);

    self.state.ratePerUnit=productDetails.rate;
    self.state.sgst=productDetails.sgst;
    self.state.cgst=productDetails.cgst;
    self.state.igst=productDetails.igst;
    self.state.hsnCode=productDetails.hsnCode;
    self.state.productId=productDetails.productId;
    self.state.quantity=1;
//console.log("quantity",self.state.quantity);
//RATEPERUNIT=>Rate per product //RATE=> Quantity * Rate per product
var RateTemp= Number(self.state.ratePerUnit)*Number(self.state.quantity); //1-quantity
RateTemp=Truncate_2DecimalPlaces(RateTemp);
    this.setState({
    selectedProductName: this.state.selectedProductName,
    ratePerUnit: self.state.ratePerUnit,
    sgst:self.state.sgst,
    cgst:self.state.cgst,
    igst:self.state.igst,
    rate:RateTemp,
    hsnCode:self.state.hsnCode,
    productId:self.state.productId
    })
    var productdetailValid =false;
    if(this.state.selectedProductName != " "){
        productdetailValid = true;
    }
    else{
        productdetailValid = false;
    }
    this.setState({
        productdetailValid: productdetailValid
    }, this.validateForm)
}
/*HANDLE ADDTOCARTFUNC THE PRODUCT SELECTION,RATE WITH TAX CALCULATION 
SET & POPUP THE TAX,TOTAL RATE FIELDS IN UI- IMPLEMENTED BY DURGA 28-04-2022 */
AddtoCartFunc()
{
    $("#AddtoCartFunc").prop("disabled", true)
    console.log("this.state.quantity",this.state.quantity);
    var self=this;
    //console.log("this.state.prodectname",this.state.selectedProductName) ;
    
    this.state.productName=this.state.selectedProductName.label;
    this.state.productCode=this.state.selectedProductName.value;

    
    //TO CHECK IF THE PRODCUT IS ALREADY EXIST IN CART OR NOT! //
    var cartDataCopy=[...this.state.cartData];
    var index=_.findIndex(cartDataCopy, { ProductCode:  this.state.productCode}); 
    console.log("index",index);
    

    if(index!=-1)
    {
        Swal.fire({
            position: 'center',
            icon: 'info',
            title: 'Product Already Exist on Cart',
            text: 'Do You Want to Update Qty! ',
            showConfirmButton: true,
            showCancelButton: true,
            confirmButtonText: 'Yes,Update!',
            cancelButtonText: 'No, keep it'
          }).then((result) => {
            if (result.value) {
                console.log(result.value);
              console.log("print",cartDataCopy[index],cartDataCopy[index].Quantity);

              cartDataCopy[index].Quantity=Number(cartDataCopy[index].Quantity) + Number(this.state.quantity); //add current quantity with existing quantity
             
              var Recalculate=Number(cartDataCopy[index].RatePerUnit) * Number(this.state.quantity); // add newrate with existing rate
             Recalculate=Truncate_2DecimalPlaces(Recalculate);
             cartDataCopy[index].Rate=Number(cartDataCopy[index].Rate)+Number(Recalculate);
             cartDataCopy[index].Rate=Truncate_2DecimalPlaces(cartDataCopy[index].Rate);

             cartDataCopy[index].TotalAmount= Number(cartDataCopy[index].Rate);

             var currentgstTax=Number(cartDataCopy[index].GstTax) * Number(this.state.quantity);
             cartDataCopy[index].GstTax=  Number(cartDataCopy[index].GstTax) +Number(currentgstTax)
             cartDataCopy[index].GstTax=Truncate_2DecimalPlaces(cartDataCopy[index].GstTax);
            

             cartDataCopy[index].AmountToBePaid=Number(cartDataCopy[index].AmountToBePaid)+(Number(Recalculate)+Number(currentgstTax));
             cartDataCopy[index].AmountToBePaid=Truncate_2DecimalPlaces( cartDataCopy[index].AmountToBePaid);

              this.setState({cartData:cartDataCopy})
              console.log("add quantity",cartDataCopy);
             console.log("add quantity",this.state.cartData);

              this.state.totalAmount=Number(this.state.totalAmount)+Number(Recalculate);
              this.state.totalAmount= Truncate_2DecimalPlaces(this.state.totalAmount);

              this.state.gstTax=Number(this.state.gstTax)+Number(currentgstTax);
              this.state.gstTax=Truncate_2DecimalPlaces( this.state.gstTax);

              this.state.amountToBePaid=Number(this.state.amountToBePaid)+(Number(Recalculate)+Number(currentgstTax));
              this.state.amountToBePaid=Truncate_2DecimalPlaces(this.state.amountToBePaid);

              this.state.productName="";
              this.state.productCode="";
            this.state.productId="";
            this.state.hsnCode="";
            this.state.rate="";
            this.state.quantity="1";
            this.state.cgst="";
            this.state.sgst="";
            this.state.igst=""; 
              this.setState({          
                ProductName: this.state.productName,
                Rate: this.state.rate,
                Quantity: this.state.quantity,
                CGST:this.state.cgst,
                SGST:this.state.sgst,
                IGST:this.state.igst, 
            })
            } })
    }
    else{

    //TOTAL ITEM ON CART CALCULATION//
    this.state.totalIteminCart=this.state.totalIteminCart+1;
    
    //CODE FOR CALCULATING RATEWITHTAX BY USING 3 TAX FRM DATA ARRAY IMPLEMENTED BY DURGA 27-04-2022 */
    //FORMULA= Rate+( (Rate*cgst%/100) + (Rate*sgst%/100) + (Rate*igst%/100) );
        // var productRateTemp=Truncate_2DecimalPlaces( Number(parseInt(productDetails.rate))+(
        // (productDetails.rate*productDetails.cgst/100)+
        // (productDetails.rate*productDetails.sgst/100)+
        // (productDetails.rate*productDetails.igst/100)));
        
    //Total Amount-[RATE*QUANTITY]
    //GST Tax-[SUMMATION OF TOTAL TAX PER PRODUCT]
    //Amount to be paid-[SUMMATION OF TOTAL AMOUNT + SUMMATION OF GSTTAX]
    //Total Item on Cart-[NUMBER OF ITEMS IN CART]
 //TOTAL AMOUNT CALCULATION//
 console.log("this.state.totalAmount b4",this.state.totalAmount);
 this.state.totalAmount=Number(this.state.totalAmount)+Number(this.state.rate);
 this.state.totalAmount=Truncate_2DecimalPlaces(this.state.totalAmount);
 
 console.log("this.state.totalAmount after",this.state.totalAmount);
 //TOTAL GST CALCULATION//
 console.log("this.state.gstTax b4",this.state.gstTax);
     var CGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.cgst)) / 100;
     this.state.CGSTAmount = Truncate_2DecimalPlaces(CGSTAmount);

     var SGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.sgst)) / 100;
     this.state.SGSTAmount = Truncate_2DecimalPlaces(SGSTAmount);

     var IGSTAmount = (Number(this.state.ratePerUnit) * Number(this.state.igst)) / 100;
     this.state.IGSTAmount = Truncate_2DecimalPlaces(IGSTAmount);

     // this.state.gstTax=CGSTAmount+SGSTAmount;
     //         if(IGSTAmount!=0)
     //         {
     //             this.state.gstTax=IGSTAmount;
     //         }
     var currentgstTax=(CGSTAmount+SGSTAmount+IGSTAmount)*self.state.quantity;
     currentgstTax=Truncate_2DecimalPlaces(currentgstTax);

     // console.log("currentgstTax",currentgstTax);
     // console.log("this.state.gstTax",this.state.gstTax,"currentgstTax",currentgstTax);

     this.state.gstTax=Number(this.state.gstTax)+Number(currentgstTax);

     this.state.gstTax=Truncate_2DecimalPlaces(this.state.gstTax);
     console.log("this.state.gstTax after",this.state.gstTax);
     //AMOUNT TO BE PAID CALCULATION//

     console.log("amountToBePaid b4", this.state.amountToBePaid);
     var currentamountToBePaid=Number(this.state.rate)+Number(currentgstTax);

     // console.log(this.state.rate,currentgstTax);
      console.log("currentamountToBePaid",currentamountToBePaid);

     this.state.amountToBePaid=Number(this.state.amountToBePaid)+currentamountToBePaid;
     this.state.amountToBePaid= Truncate_2DecimalPlaces( this.state.amountToBePaid);

     
     console.log("amountToBePaid after", this.state.amountToBePaid);
     
    this.setState({
        productName:this.state.productName,
        productCode:this.state.productCode,
        totalIteminCart:this.state.totalIteminCart,

        CGSTAmount:this.state.CGSTAmount,
        IGSTAmount:this.state.IGSTAmount,
        SGSTAmount:this.state.SGSTAmount,

        totalAmount:this.state.totalAmount,
        gstTax:this.state.gstTax,
        amountToBePaid:this.state.amountToBePaid,
    })

    var newCartData = {
        ProductName: this.state.productName,
        ProductCode:this.state.productCode,
        ProductId:this.state.productId,
        HSNCode:this.state.hsnCode,
        Rate: this.state.rate,
        Quantity: this.state.quantity,
        CGST:this.state.cgst,
        SGST:this.state.sgst,
        IGST:this.state.igst,
        RatePerUnit:this.state.ratePerUnit,
        TotalAmount:this.state.rate,
        GstTax:currentgstTax,
        AmountToBePaid:currentamountToBePaid,
      }

    this.state.cartData.unshift(newCartData); //unshift-adds new items to the beginning of an array
    this.setState({cartdata: this.state.cartdata})

    }
    this.CartClearFunc();
}
    /*
   FUNCTION USED TO GET THE INPUT FIELDS 
   IMPLEMENTED BY RAMYA - 28-04-2022
   */
handleUserInput=(e)=>
{
   
console.log("e",e);
if(e.target.name="quantity")
{
   var quantity=e.target.value;
   var qtyValidationData = CheckNumberFormat_WithoutDecimal(this.state.productCartFieldKeys, e.target.value);

    console.log("this.state.quantitye",quantity);
    this.state.rate=Number(this.state.ratePerUnit) * Number(quantity); //1-quantity
    this.state.rate=Truncate_2DecimalPlaces( this.state.rate);

    this.setState({quantity:quantity,rate:this.state.rate})
}
   
console.log("this.state.quantity",this.state.quantity);
}
    /*
   FUNCTION USED TO GET THE INPUT FIELD OF QUANTITY
   IMPLEMENTED BY RAMYA - 04-05-2022
   */
handleUserInputQuantity=(e)=>{
    const name = e.target.name;
    const value = e.target.value;
    $("#quantityerror").empty("");
    var value1 = value;
    var cleanNum;
    var qtydecimalvalidation = CheckNumberFormat_WithoutDecimal(value);
    var quantityValid = false;

    if (value1 != "") {

      var isNumberDt = $.isNumeric(value1);
      if (isNumberDt !== false) {
        var sign_data = Math.sign(value1);
        if (sign_data != -1) {

          cleanNum = value1.match(/^\d+\.?\d{0,2}/);
          if (value == "0") {
            alert("Value Cant Be Zero");
          }
          else {

            if (Number(value1) <= 1000) {
              this.state[name] = cleanNum;
              this.setState({ [name]: cleanNum });
            } else {
              this.state[name] = '';
              this.setState({ [name]: '' });
            }
            if(qtydecimalvalidation == true){
                quantityValid = true;
            }
            else{
                quantityValid = false;
                $("#quantityerror").append("is incorrect");
            console.log("value is", CheckNumberFormat_WithoutDecimal(value));
          }
          }

        } else {
          this.state[name] = '';
          this.setState({ [name]: '' });

        }
      } else {
        this.state[name] = '';
        this.setState({ [name]: '' });
      }

  this.setState({
    quantityValid: quantityValid
}, this.validateForm)
    }
    
    else {

      this.state[name] = '';
      this.setState({ [name]: '' });

    }

}


    /*
   FUNCTION USED TO DELETE THE FIELDS
   IMPLEMENTED BY DURGA - 04-05-2022
   */
handleProductDelete=(e)=>
{
  //  console.log("e",e.target.id);

    var cartDataCopy = [...this.state.cartData]; // make a separate copy of the array

    var index=_.findIndex(cartDataCopy, { ProductCode: e.target.id}); 
    console.log("cartDataCopy",cartDataCopy); console.log("one",index); console.log("cartDataCopy",cartDataCopy[index]);

    // Total Amount-Total Amount
    // GST Tax-GST Tax
    // Amount to be paid -Total Amount-GST Tax
    // Total Item on Cart--
    //Truncate_2DecimalPlaces //Number(

    this.state.totalAmount=Number(this.state.totalAmount)-Number(cartDataCopy[index].TotalAmount);
    this.state.totalAmount=Truncate_2DecimalPlaces(this.state.totalAmount);

    this.state.gstTax=Number(this.state.gstTax)-Number(cartDataCopy[index].GstTax);
    this.state.gstTax=Truncate_2DecimalPlaces( this.state.gstTax);

    this.state.amountToBePaid=Number(this.state.amountToBePaid)-Number(cartDataCopy[index].AmountToBePaid);
    this.state.amountToBePaid=Truncate_2DecimalPlaces(this.state.amountToBePaid);

    this.state.totalIteminCart=this.state.totalIteminCart-1;

    cartDataCopy.splice(index, 1);

    this.setState({
        totalAmount:this.state.totalAmount,
        gstTax:this.state.gstTax,
        amountToBePaid:this.state.amountToBePaid,
        totalIteminCart:this.state.totalIteminCart,
        cartData:cartDataCopy })

   // console.log("cartdata after populate",this.state.cartData);
                
}
    /*
   FUNCTION USED TO SUBMIT ALL THE FIELDS ARE VALID
   IMPLEMENTED BY DURGA - 04-05-2022
   */
   handleSubmit=(e)=>
   {
       var self = this;
   console.log("cartdata",this.state.cartData);
       $.ajax({
         type: 'POST',
         data: JSON.stringify({
   
           companyId: '1',
           cartProductList: JSON.stringify(this.state.cartData),
           date:this.state.date,
           time:this.state.time,
           totalIteminCart:this.state.totalIteminCart,
   
         }),
         url: "http://localhost:8080/IceilAPI/FranchiseQuotationWebService/AddQuotation",
         contentType: "application/json",
         dataType: 'json',
         async: false,
   
         success: function (data, textStatus, jqXHR) {
   
           console.log( data);
           
           alert("Quotation Added Successfully!");
           // Swal.fire({
           //     position: 'center',
           //     icon: 'success',
           //     text: 'Quotation Added Successfully!',
           //     showConfirmButton: false,
           //     timer: 2000
           //   })
           
             self.CancelFunc();
         },
         error: function (data) {
           console.log("insert error");
         },
   
       });
   }
  /*USED TO VALIDATE THE NECESSARY FIELDS IMPLEMENTED BY RAMYA - 13-05-2022*/

  validateForm() {
    this.setState({
        formValid:
            // this.state.productnameValid &&
            this.state.quantityValid
            // this.state.selectedNodesValid
    });
}
 /*USED TO CLEAR ALL THE FIELDS OF ADD TO CART IMPLEMENTED BY RAMYA - 13-05-2022*/
 CartClearFunc() {
  
    this.state.productName="";
  this.state.rate="";
  this.state.quantity="1";
  this.state.cgst="";
  this.state.sgst="";
  this.state.igst=""; 
    this.setState({
      ProductName: this.state.productName,
      HSNCode:this.state.hsnCode,
      Rate: this.state.rate,
      Quantity: this.state.quantity,
      CGST:this.state.cgst,
      SGST:this.state.sgst,
      IGST:this.state.igst, 
  })
}
CancelFunc()
{
    var self=this;

        self.state.date='';
        self.state.time='';
        self.state.productOptions= [];
        self.state.quantity='';
        self.state.totalAmount='';
        self.state.totalIteminCart='';
        self.state.amountToBePaid=0;
        self.state.gstTax=0;
        self.state.selectedProductName='';
        self.state.cartData=[];
        self.state.ratePerUnit='';
        self.state.sgst='';
        self.state.cgst='';
        self.state.igst='';
        self.state.rate='';

    self.setState({
    ratePerUnit:self.state.ratePerUnit,
    sgst: self.state.sgst,
    cgst: self.state.cgst,
    igst: self.state.igst,
    rate: self.state.rate,
    date:self.state.date,
    time:self.state.time,
    productOptions:self.state.productOptions,
    quantity:self.state.quantity,
    totalAmount:self.state.totalAmount,
    totalIteminCart: self.state.totalIteminCart,
    amountToBePaid:self.state.amountToBePaid,
    gstTax:self.state.gstTax,
    selectedProductName:self.state.selectedProductName,
    cartData:self.state.cartData})
}
render(){
    return(
<div className="mt-40">
<div className="row">
                    <div className="col-md-3">
                    <label>Product <span class="mandatoryfields">*</span></label>    
            <div>      
            {/* FIELD USED TO create Product - it's non-mandatory field */}
            <SelectSearch options={this.state.productOptions} value={this.state.selectedProductName}
                    // isMulti={false}
                    onChange={(e) => this.handleProductDetails(e)} name="productName" id="productName" placeholder="Select Product" />
            </div>
            </div>
            <div className="col-md-3">
                    <label>Rate/Unit</label>    
            <div>      
            {/* FIELD USED TO create Rate/Unit - it's mandatory field  */}
            <input className="textfield" type="number" onChange={this.handleUserInputQuantity} value={this.state.ratePerUnit } id="ratePerUnit" name="ratePerUnit" readOnly/>
            </div>
            </div>
            <div className="col-md-3">
                    <label>Quantity <span class="mandatoryfields">*</span></label>    
            <div>      
            {/* FIELD USED TO create quantity - it's mandatory field min="1" */}
            <input className="textfield" type="text" min="1" max="5" onChange={this.handleUserInput} value={this.state.quantity} id="quantity" name="quantity" />
            <span id="quantityerror"></span>
            {/* <ErrorClass errorContent={this.state.formErrors.quantity}/> */}
            </div>
            </div>
            <div className="col-md-3">
                    <label>SGST(%)</label>    
            <div>      
            {/* FIELD USED TO create sGST(%) - it's mandatory field  */}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.sgst } id="sgst" name="sgst" readOnly/>
            </div>
            </div>
            <div className="col-md-3">
                    <label>CGST(%)</label>    
            <div>      
            {/* FIELD USED TO create CGST(%) - it's mandatory field  */}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.cgst } id="cgst" name="cgst" readOnly/>
            </div>
            </div>
            <div className="col-md-3">
                    <label>IGST(%)</label>    
            <div>      
            {/* FIELD USED TO create iGST(%) - it's mandatory field  */}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.igst } id="igst" name="igst" readOnly/>
            </div>
            </div>
            <div className="col-md-3">
                    <label>Rate</label>    
            <div>      
            {/* FIELD USED TO create Rate/Unit - it's mandatory field  */} {/*AddtoCartFunc*/}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.rate } id="rate" name="rate" readOnly/>
            </div>
            </div>
            <div className="text-center mt-40">
            
                <button className="btn btn-primary btn-submit" id="AddtoCart" disabled={!this.state.formValid} onClick={this.AddtoCartFunc}><i class="fa fa-cart-plus" id="addtocart" aria-hidden="true" ></i> Add to cart</button>
                <button className="btn btn-primary btn-cancel"><i class="fa fa-times" aria-hidden="true"></i> Cancel</button>
            </div>
                </div>
            <div className="row card-box mt-40">
             <div className="col-md-3">
            <label>Total Amount</label>    
            <div>      
            {/* FIELD USED TO create Total Amount */}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.totalAmount} id="totalAmount" name="totalAmount" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>GST Tax</label>    
            <div>      
            {/* FIELD USED TO create GST Tax */}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.gstTax} id="gstTax" name="gstTax" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Amount to be paid</label>    
            <div>      
            {/* FIELD USED TO create Amount to be paid*/}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.amountToBePaid} id="amountToBePaid" name="amountToBePaid" readOnly/>
            </div></div>
             <div className="col-md-3">
            <label>Total Item on Cart</label>    
            <div>      
            {/* FIELD USED TO create Total Amount */}
            <input className="textfield" type="number" onChange={this.handleUserInput} value={this.state.totalIteminCart} id="totalIteminCart" name="totalIteminCart" readOnly/>
            </div></div>
  
            </div>
            {/* <FranchiseQuotationImage />
            <FranchiseQuotationProduct /> */}
            {
                this.state.cartData.map((element) =>(
                     <div className="row mt-20 card-box Quotationproduct">
                        <div className="col-md-6">
                            <div className="row quotation-card-box">
                            <div className="col-md-6">
                        <label>Product Name</label>    
                        <div>      
                        {/* FIELD USED TO create Product */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.ProductName} id="product" name="product" readOnly/>
                        </div></div>
                        <div className="col-md-6">
                        <label>Product Code </label>    
                        <div>      
                        {/* FIELD USED TO create Product Code */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.ProductCode} id="productCode" name="productCode" readOnly/>
                        </div></div> 
                        <div className="col-md-6">
                        <label>Rate </label>    
                        <div>      
                        {/* FIELD USED TO create Rate  */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.Rate} id="rate" name="rate" readOnly/>
                        </div></div>   
                        <div className="col-md-6">
                        <label>HSN Code</label>    
                        <div>      
                        {/* FIELD USED TO create HSN Code  */}
                        <input className="textfield" type="text" onChange={this.handleUserInput} value={element.HSNCode } id="hsnCode" name="hsnCode" readOnly/>
                        </div></div>     
                            </div>
                            </div>
                            <div className="col-md-6">
                            <div className="quotation-card-box">
                        <table className="table">
                            <tbody>
                                <tr>
                                    <td>Rate/Unit</td>
                                    <td>{element.RatePerUnit}</td>
                                </tr>
                                <tr>
                                    <td>Quantity</td>
                                    <td>{element.Quantity}</td>
                                </tr>
                                <tr>
                                    <td>CGST(%)</td>
                                    <td>{element.CGST}</td>
                                </tr>
                                <tr>
                                    <td>SGST(%)</td>
                                    <td>{element.SGST}</td>
                                </tr>
                                <tr>
                                    <td>IGST(%)</td>
                                    <td>{element.IGST}</td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                        </div>
                        <div className="text-center">
                            <button className="btn btn-primary btn-submit" id={element.ProductCode} onClick={this.handleProductDelete}>Delete</button>
                        </div>
                        </div>
                ))
            }                     
            <div className="text-center mt-20">
                <button className="btn btn-primary btn-submit" onClick={this.handleSubmit}>Submit</button>
                <button className="btn btn-primary btn-cancel" onClick={this.CancelFunc}>Cancel</button>
            </div>
    </div>
    )
}
}
export default Quotation;