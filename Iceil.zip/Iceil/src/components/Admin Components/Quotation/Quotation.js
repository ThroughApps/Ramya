//IMPORT STATEMENTS FOR REACT COMPONENT
import React from "react";
import ReactTable from "react-table-v6";
import SlidingPane from "react-sliding-pane";
import $ from 'jquery';
import _ from 'underscore';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import Pagination from "react-js-pagination";
import moment from 'moment';
// import statement for class component css
import '../../StyleCss.css';
import './QuotationCss.css';
// import statement for react component css
import "react-table-v6/react-table.css";
import "react-sliding-pane/dist/react-sliding-pane.css";

// import statement for react class component
import {FranchiseDropDown, StatusDropDown} from '../../Assets Components/DropdownComponents/DropdownComponent';
import { QuotationListIcons } from "../../Assets Components/Icon Components/Iconcomponents";
import QuotationEdit from './QuotationEdit'
import QuotationView from "./QuotationView";
import { GetLocalStorageData ,TimeZoneDateTime} from "../../Common Components/CommonComponents";
import {StatusChangeAlert} from '../../Assets Components/Alert Components/AlertComponent'
import MonthYearPicker from 'react-month-year-picker';

var quotationList;
var dataCount = 0;
var dataCountArray = [];
var itemData = 1;
var pageArray = [];
var pageData_Status;
var days1;

//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

class Quotation extends React.Component{
    constructor(){
      super();
       //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 29-04-2022
      //  var today = new Date();
      //  var tempYear = today.getFullYear() ;
            
   this.state= {
            adminId:'',
            totlaItemCount: 0,
            itemsPerPage: 10,
            activePage: 1,
            data: [],
            columns: [
              {
                Header: 'SNO',
                accessor: 'SNO'
              },
              {
                Header: 'QuotationNumber',
                accessor: 'QuotationNumber'
              },
              {
                Header: 'Amount',
                accessor: 'Amount'
              },
              {
                Header: 'Franchise',
                accessor: 'Franchise'
              },
              
              {
                Header: 'Status',
                accessor: 'Status'
              }
            ],
            isQuotationEditPaneOpen: false,
            isQuotationViewPaneOpen: false,
            month: "",
           // presentyear: tempYear,//2022,
            statusValue:'',//used to hold the submitted,cancelled,completed,inprogress
            quotationNo:'',
            acceptedDate:'',
            acceptedTime:'',
            cancelledDate:'',
            cancelledTime:'',
            completedDate:'',
            completedTime:'',
            performUpdate:true,
            propsSelectedFranchise:'',
            propsSelectedStatus:'',
            franchiseList:[],
        }
        this.quotationEdit = this.quotationEdit.bind(this);
        this.quotationView = this.quotationView.bind(this);
        this.quotationAccept = this.quotationAccept.bind(this);
        this.quotationCancel = this.quotationCancel.bind(this);
        this.quotationComplete = this.quotationComplete.bind(this);
        this.UpdateStatus = this.UpdateStatus.bind(this);
        this.PopulateQuotationData=this.PopulateQuotationData.bind(this);
        this.StatusOnChange = this.StatusOnChange.bind(this);
        this.FranchiseOnChange = this.FranchiseOnChange.bind(this);
        this.GetData=this.GetData.bind(this);
    }
componentDidMount(){
 // //console.log("did");
  $("#tableOverflow1").hide();
    /* GETTING DATE & TIME FOR DATEPICKER
     - IMPLEMENTED BY RAMYA - 14-05-2022
     */
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
  //  //console.log("dateTimeData :", dateTimeData);
    var year = dateTimeData.date.split("-")[0];
    var month = dateTimeData.date.split("-")[1];
    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.state.currentYear = year;
    this.state.currentMonthNumber=month; 
    this.state.currentMonth = moment(month, 'M').format('MMMM');

    this.setState({
      date: this.state.date,
      time: this.state.time,
      currentYear: this.state.currentYear,
      currentMonth: this.state.currentMonth,
      currentMonthNumber: this.state.currentMonthNumber
    })
    // //console.log("currentMonth", this.state.currentMonth, "this.state.currentYear", this.state.currentYear);
    this.GetMonthData(this.state.currentMonthNumber, this.state.currentYear);

    $(document).ready(function () {
      $("#monthselect").click(function () {
          $(".month-year-picker").toggleClass("active");
      });        

  });
  $(document).ready(function () {
  $(".month-year-picker .month-picker > div > div").click(function () {
      $(".month-year-picker").removeClass("active");
    
  });  
  
});  
$(document).ready(function () {
  $(".reactIcon_Btn > ul > li").click(function () {
      $(".month-year-picker").removeClass("active");
  });  
});  
    // this.GetData();
}
/* USED TO CONVERT THE NO DAYS IN A MONTH-IMPLEMENTED BY DURGA 29-04-2022 */   //[Ref:garageapp]    
  GetMonthData(selectedMonth, year) { 
    itemData = 1;
    this.state.totlaItemCount = 0;
    dataCountArray = [];
    dataCount = 0;
    pageArray = [];
    dataCountArray.push(dataCount);
    pageArray.push(1);
    
  //  //console.log("inside GetMonthData", selectedMonth, year);
    this.state.year = year;
    this.setState({ year: this.state.year })
    var today = new Date();
    var currentMonth = today.getMonth() + 1;
    days1 = new Date(year, selectedMonth, 0).getDate();

    if (
      selectedMonth == "01" || //"January" March May July August october december
      selectedMonth == "03" ||
      selectedMonth == "05" ||
      selectedMonth == "07" ||
      selectedMonth == "08" ||
      selectedMonth == "10" ||
      selectedMonth == "12"
    ) {
      if (selectedMonth == currentMonth) {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + today.getDate();
      } else {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + "31";
      }

      this.setState({
        fromDate: this.state.fromDate,
        toDate: this.state.toDate,
        month: this.state.month
      });

    //  //console.log("this.state.fromDate", this.state.fromDate, this.state.toDate, this.state.month);
    } else if (
      selectedMonth == "04" || //April june september november
      selectedMonth == "06" ||
      selectedMonth == "09" ||
      selectedMonth == "11"
    ) {
      if (selectedMonth == currentMonth) {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + today.getDate();
      } else {
        this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
        this.state.toDate = year + "-" + selectedMonth + "-" + "30";
      }
      this.setState({
        fromDate: this.state.fromDate,
        toDate: this.state.toDate,
        month: this.state.month
      });
    } else if (selectedMonth == "02") { //february 
      if (year % 100 == 0 && year % 400 == 0 && year % 4 == 0) {
        if (selectedMonth == currentMonth) {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate =
            year + "-" + selectedMonth + "-" + today.getDate();
        } else {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate = year + "-" + selectedMonth + "-" + "29";
        }
        this.setState({
          fromDate: this.state.fromDate,
          toDate: this.state.toDate,
          month: this.state.month
        });
      } else {
        if (selectedMonth == currentMonth) {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate =
            year + "-" + selectedMonth + "-" + today.getDate();
        } else {
          this.state.fromDate = year + "-" + selectedMonth + "-" + "01";
          this.state.toDate = year + "-" + selectedMonth + "-" + "28";
        }
        this.setState({
          fromDate: this.state.fromDate,
          toDate: this.state.toDate,
          month: this.state.month
        });
      }
    }

    this.GetData();
  }
/* USED TO GET THE QUOTATION LIST DETAILS FROM DATABASE- IMPLEMENTED BY DURGA 29-04-2022 */       
GetData()
    {
      var self=this;
      //console.log("GetData called");
  
    //console.log("get data",dataCount,self.state.totalItemCount);
    //console.log("toDate", self.state.toDate, "fromDate", self.state.fromDate, "year");
    self.SearchBarClearFunc();

      $.ajax({

        type: 'POST',
        data: JSON.stringify({
        companyId:GetLocalStorageData("CompanyId"),
        dataCount: dataCount,
        totlaItemCount: this.state.totalItemCount,
        fromDate: this.state.fromDate,
        toDate: this.state.toDate,
        }),
         url: "http://15.206.129.105:8080/IceilLiveAPI/AdminQuotationWebService/SelectQuotationDetails",
          contentType: "application/json",
          dataType: 'json',
          async: false,
  
        success: function (data, textStatus, jqXHR) {
  
            //console.log("Admin data",data);
  
            //console.log("Admin data",data.franchiseList);

            quotationList = data.quotationList;
            //console.log(quotationList);
          
         
            if(data.franchiseList!=null)
            {
              // $.each(data.franchiseList, function (i, item) {
              // franchiseList.push({ label: item.franchiseName, value: item.franchiseId });
              // });

              // // franchiseList=data.franchiseList;
              // // self.setState({franchiseList:franchiseList})
              // //console.log("franchiselist each",franchiseList);
             // franchiseList=data.franchiseList;
            self.state.franchiseList=data.franchiseList
            self.setState({franchiseList:self.state.franchiseList})
            //console.log("franchiselist",self.state.franchiseList);
            window.FranchiseDropDownComponent.SetFranchiseList(self.state.franchiseList);
            }
            
          

            if (data.quotationList !== null && data.quotationList.length != 0) {
              var no = 0;
              if (itemData == "1") {
                self.state.totlaItemCount = data.totlaItemCount;
    
                itemData = Number(itemData) + 1;
              }
             
            } else {
              itemData = "1";
              self.state.totlaItemCount = 0;
            }
            self.PopulateQuotationData(quotationList);
  
           
    },
    error: function (data) {
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Network Connection Problem',
        showConfirmButton: false,
        timer: 2000
      })
    },
  });
  } 
GetColumns() {
    //console.log("get col",this.state.quotationData[0]);
  if(!this.state.quotationData.length==0)
  {
        return Object.keys(this.state.quotationData[0]).map(key => {
      
            return {
                Header: key,
                accessor: key,
      
            };
      
        });
      }
  }
/* USED TO POPULATE QUOTATION LIST INTO TABLE- IMPLEMENTED BY DURGA 22-04-2022 */       
PopulateQuotationData(quotationList)
  {
      var self=this;
      var count=dataCount;  
     
     self.state.quotationData=[];

     self.setState({quotationData:self.state.quotationData})
     //console.log("populate data",quotationList);
    $("#tableHeadings").empty();
  
      //var tab = '<thead><tr class="headcolor"><th>SNO</th><th>Id</th><th>Amount</th><th>Franchise</th><th>Status</th></tr></thead>';
      var tempStatus;
      $.each(quotationList, function (i, item) {
       
        
        count=Number(count)+1;

        if (item.status == 0) {//Status= 0 - Quotation submitted 

            tempStatus = <span style={{ color: "blue", fontWeight: "700" }}>Submitted</span>
          }
          else if(item.status == 1) {//Status=1 - Cancelled  
            tempStatus = <span style={{ color: "red", fontWeight: "700" }}>Cancelled</span>
          }
          else if(item.status == 2) { //Status=2 - Accepeted-inprogress 
            tempStatus = <span style={{ color: "#FFD700", fontWeight: "700" }}>Inprogress</span>
          }
          else if(item.status == 3) {//Status=3 - Completed    
            tempStatus = <span style={{ color: "green", fontWeight: "700" }}>Completed</span>
          }
          else if(item.status == 5) { //Status=5 - Edited
            tempStatus = <span style={{ color: "#800080", fontWeight: "700" }}>Edited</span>
          }
            
       // tab += '<tbody id= "myTable" ><tr  id="tabletextcol" ><td>' + count + '</td>'
      //   +'<td>' + item.quotationNo + '</td>'
      //   +'<td>' + item.rate + '</td>'
      //   +'<td>' + item.franchiseName + '</td>'
      //   +'<td>' + tempStatus + '</td>' 
       
              self.state.quotationData[i]={ 

                  "SNO":count,
                  "QuotationNumber":item.quotationNo,
                  "Amount":item.amounttobePaid,
                  "Franchise":item.franchiseName,
                  "Status":tempStatus
                }
          });
  
         // $("#tableHeadings").append(tab);
  
         // self.state.columns=this.GetColumns();
          self.state.selected = -1;
          self.setState({
              selected:self.state.selected,
            // TableColumns:self.state.columns,
             quotationData:self.state.quotationData,
          });
             //console.log("data",self.state.quotationData) ;       
  }
  
/* HANDLE ROW SELECTION-USED TO STORE THE SELECTED ROW DATAS [IN TABLE WHILE SELECTING THE ROW]- IMPLEMENTED BY DURGA 22-04-2022 */ 
OnTrRowClick = (state, rowInfo, column, instance) => {
var self = this;
////console.log("rowinfo",rowInfo);
if (typeof rowInfo !== "undefined") {
  return {
    onClick: (e, handleOriginal) => {
      this.setState({ selected: rowInfo.index});
      //console.log("e",e);
      //console.log("handleOriginal",handleOriginal);
      if (handleOriginal) {
        handleOriginal()
      }
      this.state.rowIndexValue = rowInfo.index;
      this.state.quotationNo=quotationList[rowInfo.index].quotationNo
      this.state.selectedData=quotationList[rowInfo.index];
      //console.log("index value",this.state.rowIndexValue);
      //console.log("index value",quotationList[rowInfo.index]);

      this.setState({
        rowIndexValue: this.state.rowIndexValue,
        quotationNo: this.state.quotationNo,
        selectedData:this.state.selectedData,
      });
      //console.log("index  this.state.selectedData",this.state.selectedData);
    },
    style: {
      background: rowInfo.index === this.state.selected ? '#00afec' :' ',
    },
  }

}
else {
  return {
    onClick: (e, handleOriginal) => {
      if (handleOriginal) {
        handleOriginal()
      }
    },
    style: {
     
    },
  }
}

};

/* USED TO CLEAR THE SEARCH BAR VALUES WHILE YEAR OR MONTH SELECTED- IMPLEMENTED BY DURGA 24-05-2022 */ 
SearchBarClearFunc()
{
  window.FranchiseDropDownComponent.ResetStatus();
  window.StatusDropDownComponent.ResetStatus();
}       
/* USED TO HANDLE THE PAGINATION- IMPLEMENTED BY DURGA 29-04-2022 */   
handlePageChange(pageNumber) {

    this.state.activePage = pageNumber;
    this.setState({ activePage: pageNumber });

    var self = this;


    pageData_Status = false;
    pageData_Status = _.contains(pageArray, this.state.activePage);

    dataCount = 0;
    self.state.oldPageAcces = "false";
    self.setState({
      oldPageAcces: self.state.oldPageAcces
    });

    if (pageData_Status == false) {

      pageArray.push(pageNumber);
      dataCount = Math.round((Number(dataCount)) + ((Number(pageNumber) - 1) * 10));
      dataCountArray.push(dataCount);

    } else if (pageData_Status == true) {

      var currentPageIndex = _.indexOf(pageArray, this.state.activePage);
      dataCount = dataCountArray[currentPageIndex];

    }
    this.GetData();
  }
/***USED TO HANDLE THE FUNCTIONLITIES OF QUOTATION VIEW,EDIT,ACCEPT,CENCEL,COMPLETED NAME STRUCTURE BY UI TEAM- IMPLEMENTED BY DURGA 29-04-2022 ***/   
quotationEdit(){

    var self=this;
    if (self.state.rowIndexValue === undefined ||self.state.rowIndexValue === ''  )
    {
        Swal.fire({
          position: 'center',
          icon: 'warning',
          text: 'Kindly, Select the Quotation to Edit! ',
          timer:2000
        })
    }
    else
    {
        if(self.state.selectedData.status=="0" ||self.state.selectedData.status=="2" ||self.state.selectedData.status=="5")
        {
          //Status=5 - Edited
          
          self.state.statusValue=5;
          //console.log("b4 edit",this.state.selectedData);
          self.state.isQuotationEditPaneOpen = true;
        
          self.setState({
          isQuotationEditPaneOpen: self.state.isQuotationEditPaneOpen }) 
        }
        else
        {
          var status = "Completed";
          if(self.state.selectedData.status=="1")
            {status = "Cancelled";}
              Swal.fire({
                position: 'center',
                icon: 'warning',
                text: status + " Quotation Cannot be Updated!",
                showConfirmButton: false,
                timer: 2000
              })
             
      }
    }  
    self.state.selected = -1;
    self.state.rowIndexValue="";

    self.setState({
      selected:self.state.selected,
      rowIndexValue:self.state.rowIndexValue }) 
}
quotationView(){
   
    var self=this;
   // alert("self.state.rowIndexValue"+self.state.rowIndexValue)
    if (self.state.rowIndexValue === undefined ||self.state.rowIndexValue === '' ) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        text: 'Kindly, Select the Quotation to View! ',
        timer:2000
      })
    }
    else
    {
      self.state.selected = -1
      self.state.rowIndexValue="";
      self.state.isQuotationViewPaneOpen = true;
      self.setState({
        rowIndexValue:self.state.rowIndexValue,
          selected:self.state.selected,
          isQuotationViewPaneOpen: self.state.isQuotationViewPaneOpen,
      }) 
}
   
}
quotationAccept(){
    var self=this;

    if (self.state.rowIndexValue === undefined ||self.state.rowIndexValue === ''  ) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        text: 'Kindly, Select the Quotation to Change Status! ',
        timer:2000
      })
    }
    else{
          if(self.state.selectedData.status=="0" )
          {
            //self.state.statusValue="Inprogress"; Status=2 - Accepeted  
            self.state.statusValue=2;
            self.state.acceptedDate=this.state.date;
            self.state.acceptedTime=this.state.time;
            self.setState({
                statusValue:  self.state.statusValue,
                acceptedDate:self.state.acceptedDate,
                acceptedTime:self.state.acceptedTime
            })
            this.UpdateStatus();
          }
          else{
            var status = "Inprogress";
            if(self.state.selectedData.status=="1" ){
              status = "Cancelled";}
              else if(self.state.selectedData.status=="3" ){
                status = "Completed";}
                else if(self.state.selectedData.status=="5")
                {
                  status = "Edited"; 
                }
              // alert(status + " Quotation Cannot be Accepted!");
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: status + " Quotation Cannot be Accepted!",
              showConfirmButton: false,
              timer: 2000
            })
            
            }
     }
    self.state.selected=-1;
    self.state.rowIndexValue='';
    self.setState({selected:self.state.selected,rowIndexValue:  self.state.rowIndexValue})
}                                                                                                                            
quotationCancel(){
    var self=this;
    if (self.state.rowIndexValue === undefined ||self.state.rowIndexValue === '' ) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        text: 'Kindly, Select the Quotation to Change Status! ',
        timer:2000
      })
    }
    else{
      if(self.state.selectedData.status=="0" || self.state.selectedData.status=="2"||  self.state.selectedData.status=="5")
      {
        //self.state.statusValue="Cancelled"; Status=1 - Cancelled       
        self.state.statusValue=1;
        self.state.cancelledDate=this.state.date;
        self.state.cancelledTime=this.state.time;
        self.setState({
            statusValue:  self.state.statusValue,
            cancelledDate:self.state.cancelledDate,
            cancelledTime:self.state.cancelledTime
        })
        this.UpdateStatus();
      }
      
      else{
        var status = "Completed";
        if(self.state.selectedData.status=="1" ){
          status = "Cancelled";}

     // alert(status + " Quotation Cannot be Updated as Cancelled!");

        Swal.fire({
          position: 'center',
          icon: 'warning',
          text: status + " Quotation Cannot be Updated as Cancelled!",
          showConfirmButton: false,
          timer: 2000
        })
      
       }
    }
    self.state.selected=-1;
    self.state.rowIndexValue='';
    self.setState({selected:self.state.selected,rowIndexValue:self.state.rowIndexValue})
}
quotationComplete(){

    var self=this;
    if (self.state.rowIndexValue === undefined ||self.state.rowIndexValue === '' ) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        text: 'Kindly, Select the Quotation to Change Status! ',
        timer:2000
      })
    }else{
         if(self.state.selectedData.status=="0" || self.state.selectedData.status=="2" || self.state.selectedData.status=="5")
        {
      //  self.state.statusValue="Completed";Status=3 - Completed
        self.state.statusValue=3;
        self.state.completedDate=this.state.date;
        self.state.completedTime=this.state.time;
        self.setState({
            statusValue: self.state.statusValue,
            completedDate:self.state.completedDate,
            completedTime:self.state.completedTime
        })
        this.UpdateStatus();
      }
      else{
        var status = "Completed";
        if(self.state.selectedData.status=="1" ){
          status = "Cancelled";}
          else if(self.state.selectedData.status=="5" ){
            status = "Edited";
          }
          //alert(status + " Quotation Cannot be Updated as Completed!");

        Swal.fire({
          position: 'center',
          icon: 'warning',
          text: status + " Quotation Cannot be Updated as Completed!",
          showConfirmButton: false,
          timer: 2000
        })
      }
      self.state.selected = -1;
      self.state.rowIndexValue='';
      self.setState({selected:self.state.selected, rowIndexValue:self.state.rowIndexValue })
    }
}
CloseQuotationEdit() {
    this.state.isQuotationEditPaneOpen = false;
    this.setState({
        isQuotationEditPaneOpen: this.state.isQuotationEditPaneOpen,
    })
}
CloseCancelQuotationEditPaneSlide = (currentState) => {
  var self = this;
  self.state.isQuotationEditPaneOpen = false;
  self.setState({
    isQuotationEditPaneOpen: self.state.isQuotationEditPaneOpen
  })
}
CloseQuotationView() {
    this.state.isQuotationViewPaneOpen = false;
    this.setState({
        isQuotationViewPaneOpen: this.state.isQuotationViewPaneOpen,
    })
}
//METHOD FOR UPDATING STATUS AS COMPLETED/INPROGRESS/CENCELLED/SUBMITTED -ICON ONCLICK IS PERFORMED //-IMPLEMENTED BY DURGA 02-05-2022*/
UpdateStatus()
{
    var self = this;
//console.log("userid",GetLocalStorageData("UserId"),self.state.quotationNo,GetLocalStorageData("CompanyId"));
    $.ajax({
      type: 'POST',
      data: JSON.stringify({
        acceptedDate:self.state.acceptedDate,
        acceptedTime:self.state.acceptedTime,

        cancelledDate:self.state.cancelledDate,
        cancelledTime:self.state.cancelledTime,

        completedDate:self.state.completedDate,
        completedTime:self.state.completedTime,

       accepetedId_CancelledId_CompletedId_BilledId:GetLocalStorageData("UserId"),

        status: self.state.statusValue,
        quotationNo: self.state.quotationNo,
        companyId: GetLocalStorageData("CompanyId"),
      }),
         url:"http://15.206.129.105:8080/IceilLiveAPI/AdminQuotationWebService/UpdateQuotationStatus",

      contentType: "application/json",
      dataType: 'json',
      async: false,

      success: function (data, textStatus, jqXHR) {

        //console.log("update", data);
        StatusChangeAlert(self.state.statusValue, self.state.quotationNo);
        self.GetData();
      },
      error: function (data) {
        //console.log("update error");
    },

});


}
/*HANDLE DATEPICKER MONTH AND YEAR ONCHANGE-IMPLEMENTED BY DURGA 23-05-2022 */
onChangeYear(year)
{
  //console.log("year",year);
  this.state.currentYear=year;
  this.setState({ currentYear:this.state.currentYear})
  this.GetMonthData(this.state.currentMonthNumber, this.state.currentYear);
  
}
onChangeMonth(month)
{
this.state.currentMonthNumber=month;
this.state.currentMonth = moment(month, 'M').format('MMMM');
//console.log("onChangeMonth",month,"this.state.currentMonth",this.state.currentMonth);
this.setState({
  currentMonthNumber:this.state.currentMonthNumber,
  currentMonth:this.state.currentMonth})
this.GetMonthData(this.state.currentMonthNumber, this.state.currentYear);
}
 /*HANDLE THE STAUS BASED FILTER USED IN DROPDOWNCOMPONENTS.JS- IMPLEMENTED BY DURGA 06-04-2022 */
 StatusOnChange(e) 
 {
   var self = this;
   //console.log(e);
   self.state.propsSelectedStatus = e;

   self.setState({ propsSelectedStatus: self.state.propsSelectedStatus })
   //console.log("propsSelectedStatus", self.state.propsSelectedStatus);
   //console.log("propsSelectedFranchise", self.state.propsSelectedFranchise);
 }
/*HANDLE THE MEMBERSHIP STAUS  BASED FILTER  USED IN DROPDOWNCOMPONENTS.JS- IMPLEMENTED BY DURGA 06-04-2022 */
FranchiseOnChange(e) 
 {
   var self = this;
   //console.log(e);
   self.state.propsSelectedFranchise = e;

   self.setState({ propsSelectedFranchise: self.state.propsSelectedFranchise })
   //console.log("propsSelectedFranchise", self.state.propsSelectedFranchise);
   //console.log("propsSelectedStatus", self.state.propsSelectedStatus);
 }

render(){
    return(
        <div>
<div className="toptitle">
<h3>Quotation</h3>
</div>
<div className="container-fluid">
    <div className="text-center">
        <h3>{this.state.currentMonth} - <span> {this.state.currentYear} </span></h3>
    </div>
<div className="row mt-40">
<div class="top-menus">


{/* FIELD USED TO get the franchise */}
<FranchiseDropDown quotationList={quotationList} FranchiseOnChange={this.FranchiseOnChange} Status={this.state.propsSelectedStatus} PopulateQuotationData={this.PopulateQuotationData}  franchiseList={this.state.franchiseList}/>
{/* FIELD USED TO get the status */}
<StatusDropDown quotationList={quotationList} StatusOnChange={this.StatusOnChange} FranchiseStatus={this.state.propsSelectedFranchise} PopulateQuotationData={this.PopulateQuotationData}/>
 {/* FIELD USED TO get the month and year */}
 <div className="site_dropstyle">
              <label>Select Month</label>
              <div>
                <input className="form-control" value={this.state.currentMonth + " " + this.state.currentYear} type="text" id="monthselect" />
           
                <MonthYearPicker
                  selectedMonth={this.state.month}
                  selectedYear={this.state.currentYear}
                  minYear={2010}
                  maxYear={2030}
                  onChangeYear={this.onChangeYear.bind(this)}
                  onChangeMonth={this.onChangeMonth.bind(this)}
                />
              </div>
            </div>
<QuotationListIcons  onQuotationEdit={this.quotationEdit} onQuotationView={this.quotationView} onQuotationAccept={this.quotationAccept} onQuotationCancel={this.quotationCancel} onQuotationComplete={this.quotationComplete} />
</div>
<div id="tableOverflow1">
              <table style={{ margin: "auto" }} class="table table-bordered" id="tableHeadings">
              </table>
            </div>
  <ReactTable
    data={this.state.quotationData}
    columns={this.state.columns}
    noDataText="No Data Available"
    filterable
    defaultPageSize={10}
    className="-striped -highlight"
    defaultFilterMethod={(filter, row, column) => {
        const id = filter.pivotId || filter.id;
        return row[id] !== undefined
            ? String(row[id])
                .toLowerCase()
                .indexOf(filter.value.toLowerCase()) !== -1
            : true;
    }}
    showPaginationTop={false}
    showPaginationBottom={true}
    getTrProps={this.OnTrRowClick}
/>

<div style={{ marginBottom: "3%" }} className="pull-right" id="paginationdiv">
         
         <Pagination
           activePage={this.state.activePage}
           itemsCountPerPage={this.state.itemsPerPage}
           totalItemsCount={this.state.totlaItemCount}
           pageRangeDisplayed={5}
           itemClass="page-item"
           linkClass="page-link"
           onChange={this.handlePageChange.bind(this)}
         /></div>
</div>
</div>
                <SlidingPane
                    className="some-custom-class"
                    overlayClassName="some-custom-overlay-class"
                    isOpen={this.state.isQuotationEditPaneOpen}
                    title={"Quotation Edit"}
                    // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                    onRequestClose={() => {
                        // triggered on "<" on left top click or on outside click
                        // setState({ isPaneOpen: false });
                        this.CloseQuotationEdit()
                    }}
                >
                    {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
                    <QuotationEdit  selectedData={this.state.selectedData} CancelClicked={this.CloseCancelQuotationEditPaneSlide} AfterEditGetData={this.GetData}/>
                </SlidingPane>
                <SlidingPane
                    className="some-custom-class"
                    overlayClassName="some-custom-overlay-class"
                    isOpen={this.state.isQuotationViewPaneOpen}
                    title={"Quotation View"}
                    // subtitle="Can Add & Edit Payment Receivables Config Info Here" style={{ marginTop: '-20px' }}
                    onRequestClose={() => {
                        // triggered on "<" on left top click or on outside click
                        // setState({ isPaneOpen: false });
                        this.CloseQuotationView()
                    }}
                >
                    {/* {this.RenderUpdateComponenets(this.state.taskSelected)} */}
                    <QuotationView  selectedData={this.state.selectedData} />
                </SlidingPane>
        </div>
    )
}
}
export default Quotation;
