import React from "react";
import * as FaIcons from 'react-icons/fa';
import '../Help/HelpCss.css';
import $ from 'jquery';
import _ from 'underscore';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
import Compressor from 'compressorjs';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import * as FcIcons from 'react-icons/fc';
import * as AiIcons from 'react-icons/ai';
import { ErrorClass } from '../../Validation Components/Loginvalidation';
import { GetLocalStorageData, TimeZoneDateTime,GetVideoThumbNail} from "../../Common Components/CommonComponents";
import { GetFileName, UploadToAWS,UploadFileToAWS } from "../../AWS/AWSFunctionality";
// import pdfToBase64 from "pdf-to-base64";
import * as FileSaver from 'file-saver';
import uploadimg from '../../images/upload_img2.png'
import TextField from '@mui/material/TextField';
import { ThemeProvider, createTheme } from '@mui/material/styles';

// import pdfToBase64 from "pdf-to-base64";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022
const darkTheme = createTheme({
  palette: {
    mode: 'dark',
  },
});

var totalImages = [10];
var filearray = [];
var videoURL;
var imageArray = [];
var videoArray = [];
var documentArray = [];
var fileNameArray = [];
var standardFileSize = 1024.000;
var selectedNodesValid = false;
var videofiletype;


var videoThumbNailArray = [];
var uploadIdArray = [];

class Help extends React.Component {
  constructor() {
    super();
    this.state = {
      folderPath:'Help',
      title: '',
      description: '',
      convertedFileSize: 0,
      imageArrayLength: 0,
      videoArrayLength: 0,
      documentArrayLength: 0,
      imageArray: [],
      videoArray: [],
      documentArray: [],
      fileNameArray: [],
      formErrors: {
        title: '',
        description: '',
        imageslists: [],

      },
      titleValid: false,
      descriptionValid: false,
      uploadValid:false,
      fileSize: 1,
    };
    this.fileChangedHandler = this.fileChangedHandler.bind(this);
    this.handleVideo = this.handleVideo.bind(this);
    this.handleDocument = this.handleDocument.bind(this);
    this.RemoveData = this.RemoveData.bind(this);
    this.handleFileChange = this.handleFileChange.bind(this);
    this.handleImage = this.handleImage.bind(this);
  }
handleUserInput = (e) => {
  const name = e.target.name;
  const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
  this.setState({ [name]: value },
    () => { this.validateField(name, value) });
}
validateField(fieldName, value) {
  let fieldValidationErrors = this.state.formErrors;
  let titleValid = this.state.titleValid;
  let descriptionValid = this.state.descriptionValid;
  switch (fieldName) {
    case 'title':
      if(value.length==0)
      {        
        fieldValidationErrors.title = '';
        titleValid = false;
      }
     else if(value.length>4 && value.length<=50) {
        fieldValidationErrors.title = '';
        titleValid = true;
      }
      else if (value.length <=4) {
        fieldValidationErrors.title = 'Contain Atleast 5 Characters';
        titleValid = false;
      }
      else if (value.length >50) {
        fieldValidationErrors.title = 'Sorry! You are Exceeding the Limit';
        titleValid = false;
      }
   
      break;
    case 'description':
      if(value.length==0)
      {
        fieldValidationErrors.description = '';
        descriptionValid = false;
      }
      else if (value.length>4 && value.length<=50) {
        fieldValidationErrors.description = '';
        descriptionValid = true;
      }
      else if (value.length <=4) {
        fieldValidationErrors.description = 'Contain Atleast 5 Characters';
        descriptionValid = false;
      }
      else if (value.length >50) {
        fieldValidationErrors.description = 'Sorry! You are Exceeding the Limit';
        descriptionValid = false;
      }
      break;

    default:
      break;
  }
  this.setState({
    formErrors: fieldValidationErrors,
    titleValid: titleValid,
    descriptionValid: descriptionValid,
  }, this.validateForm)
}
validateForm() {
  this.setState({
    formValid:
      this.state.titleValid
      && this.state.descriptionValid
      && this.state.uploadValid
  });
}
componentDidMount() {

}
uploadfiles() {
document.getElementById("uploadall").click();
}
/*FUNCTION USED TO HANDLE FILE UPLOAD(IMAGE/VIDEO)- IMPLEMENTED BY PRIYANKA - 20-04-2022 [From MenuUpload.js Code Added by Durga-14-05-2022]*/
fileChangedHandler(event) {

    console.log(event, "event", "event.target.files[0] :", event.target.files,"length", event.target.files.length);
    var self = this;
    var fileInput = false;
    var files = event.target.files[0];
    videofiletype = event.target.files[0].type;
   // console.log("videofiletype", videofiletype,);

    if (event.target.files.length != 0) {
      fileInput = true;
    }

    if (fileInput) {

      for (var i = 0; i < event.target.files.length; i++) {

        var currentFileType = event.target.files[i].type.split("/")[0];
        console.log("currentFileType", currentFileType);
//alert("currentfiletype"+currentFileType);
          //UPLOADED FILE BEING IMAGE OR JPEG OR PNG
          console.log("imaglength",imageArray.length,"videoArray.length ", videoArray.length, "documentArray.length", documentArray.length);
        if (currentFileType == "image") {
          //alert("inside imfg1;");

          console.log("videoArray.length ", videoArray.length, "documentArray.length", documentArray.length);

          if (this.state.videoArrayLength != 0 || this.state.documentArrayLength != 0) {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Unique file only allowed!',
              showConfirmButton: true,
              timer: 2000
            })
            
           // fileNameArray = [];
          }
          else{
          console.log("IMAGE ARRAY :", imageArray,"VIDEO ARRAY :", videoArray);
          self.state.videoArray = [];
          self.state.documentArray = [];

          videoArray = []; documentArray = [];

          self.state.documentArrayLength = 0;
          self.state.videoArrayLength = 0;

          self.setState({
            videoArray: [],
            videoArrayArrayLength: 0,
            documentArrayLength: 0,
            documentArray: [],
          })
          this.setState({
            uploadValid: true
          }, this.validateForm)

          self.state.imageArrayLength = Number(self.state.imageArrayLength) + Number(1);
          self.setState({
            imageArrayLength: self.state.imageArrayLength
          })

          if (self.state.imageArrayLength <= 5) {

           
            
            fileNameArray.push({ name: event.target.files[i].name, type: "image" }); //adding filename into separate array to render
            
            self.handleImage(event.target.files[i], self.state.imageArrayLength);
          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Only 5 images can be uploaded at a time',
              showConfirmButton: false,
              timer: 2000
            })
          }
          }
        }
        else if (currentFileType == "video") {
          //alert("inside video;");
          console.log("imageArray.length ", imageArray.length, "documentArray.length", documentArray.length);

          if (this.state.imageArrayLength != 0 || this.state.documentArrayLength != 0) {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Unique file only allowed!',
              showConfirmButton: true,
              timer: 2000
            })
            // fileNameArray = [];
         
         
          }
         else{
             self.state.imageArray = [];
            self.state.documentArray = [];

            imageArray = []; documentArray = [];

            self.state.documentArrayLength = 0;
            self.state.imageArrayLength = 0;

             self.setState({
              imageArray: [],
              imageArrayLength: 0,
              documentArrayLength: 0,
              documentArray: [],
            })
          this.setState({
            uploadValid: true
          }, this.validateForm)

          self.state.videoArrayLength = Number(self.state.videoArrayLength) + Number(1);
          self.setState({
            videoArrayLength: self.state.videoArrayLength
          })

          $("#previewvideo").hide();
        
          //UPLOADED FILE BEING VIDEO 

          if (self.state.videoArrayLength <= 3) {
            //ONLY ONE VIDEO CAN BE UPLOADED AT A TIME
            $(".imagepreview").hide();
            $(".videopreview").show();

            console.log("IMAGE ARRAY :", self.state.imageArray);
            console.log("VIDEO ARRAY :", videoArray);

            fileNameArray.push({ name: event.target.files[i].name, type: "video" });

           

            self.handleVideo(event.target.files[i], self.state.videoArrayLength);
          }

          else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Only 3 video can be uploaded at a time',
              showConfirmButton: false,
              timer: 2000
            })
          }
        }
        }
        else if (currentFileType == "application") {
          //alert("inside pdf;");
          var fileType = event.target.files[i].type
          if (fileType == "application/pdf") {
            console.log("imageArray.length ", imageArray.length, "videoArray.length", videoArray.length);
            if (this.state.imageArrayLength != 0 || this.state.videoArrayLength != 0) {

              Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Unique file only allowed!',
                showConfirmButton: true,
                timer: 2000
              })
              // fileNameArray = [];
             
            }
            else{
              
              self.state.imageArray = [];
              self.state.videoArray = [];
  
              imageArray = []; videoArray = [];
  
              self.state.documentArrayLength = 0;
              self.state.videoArrayLength = 0;
               self.setState({
                imageArray: [],
                imageArrayLength: 0,
                videoArrayLength: 0,
                videoArray: [],
                
              })
            this.setState({
              uploadValid: true
            }, this.validateForm)
            self.state.documentArrayLength = Number(self.state.documentArrayLength) + Number(1);
            self.setState({
              documentArrayLength: self.state.documentArrayLength
            })
            if (self.state.documentArrayLength <= 5) {

              fileNameArray.push({ name: event.target.files[i].name, type: "application" }); //adding filename into separate array to render

              $(".imagepreview").hide();
              $(".videopreview").show();

              console.log("IMAGE ARRAY :", self.state.imageArray);
              console.log("VIDEO ARRAY :", videoArray);

              console.log("handleDocument b4 call", event.target.files[i]);
              self.handleDocument(event.target.files[i],self.state.documentArrayLength);
            }
            else {
              Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Only 5 Files can be Uploaded at a Time!',
                showConfirmButton: false,
                timer: 2000
              })
            }
          }
          }
          else {

            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Pdf type can be Uploaded!',
              showConfirmButton: false,
              timer: 2000
            })
          }
        }
        else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Image or Video or Pdf, Only Allowed!',
            showConfirmButton: false,
            timer: 2000
          })
        }

      }
      
      self.state.fileNameArray = fileNameArray;
      self.setState({ fileNameArray: self.state.fileNameArray })
      
    }

    $("#uploadall")[0].value = '';

}
handleFileChange(event) {
    var self = this;
    var files = event.target.files[0];
    videofiletype = event.target.files[0].type;
    console.log("videofiletype", videofiletype);
    console.log("files", files);
    //UploadFileToAWS(files,videofiletype);

    self.handleVideo(files);
}
/*FUNCTION USED TO HANDLE THE UPLOADED  DOCUMENT(PDF)
IMPLEMENTED BY DURGA - 14-05-2022 */
handleDocument = (file,count) => {
 
    var self = this;
      var documentData;
      console.log("***** file :", file);


      var fileSize_GB = (file.size / (1000 * 1000 * 1000)).toFixed(2);

      if (fileSize_GB <= 3) {
          var reader = new FileReader();
          reader.readAsDataURL(file);

          this.state.fileSize = Number(this.state.fileSize) + Number(fileSize_GB);
          this.setState({
              fileSize: this.state.fileSize
          })

          console.log("this.state.fileSize :", this.state.fileSize);

        //  //alert("file.type :"+file.type);
          reader.onloadend = function () {
              //  console.log('RESULT', reader.result)
              documentData = {
                  originalName: file.name,
                  name: count,
                  data: file,
                  src: reader.result,
                  size: fileSize_GB,
                  fileType: file.type
              },
                  console.log(" **** imageData : ", documentData);

              self.state.documentArray.push(documentData),
              documentArray.push(reader.result),
                  self.setState({ documentArray: self.state.documentArray })
              console.log("self.state.imageArray :", self.state.documentArray);

          }
      } else {
          Swal.fire({
              position: 'center',
              icon: 'warning',
              text: "Size of " + file.name + " is greater than 3 GB",
              timer: 3000,
              showConfirmButton: true,
          });
      }

};
/*FUNCTION USED TO HANDLE THE UPLOADED IMAGE(IMAGE/PNG/JPEG)
REPLACED & REMOVED THE HANDLE BLOB FUNCTION TO REMOVE THE COMPRESSION PART
APPLIED ON THE IMAGE
- IMPLEMENTED BY PRIYANKA - 02-07-2022
*/
handleImage = (file, count) => {

      var self = this;
      var imageData;
      console.log("***** file :", file);


      var fileSize_GB = (file.size / (1000 * 1000 * 1000)).toFixed(2);

      if (fileSize_GB <= 3) {
          var reader = new FileReader();
          reader.readAsDataURL(file);

          this.state.fileSize = Number(this.state.fileSize) + Number(fileSize_GB);
          this.setState({
              fileSize: this.state.fileSize
          })

          console.log("this.state.fileSize :", this.state.fileSize);

          ////alert("file.type :"+file.type);
          reader.onloadend = function () {
              //  console.log('RESULT', reader.result)
              imageData = {
                  originalName: file.name,
                  name: count,
                  data: file,
                  src: reader.result,
                  size: fileSize_GB,
                  fileType: file.type
              },
                  console.log(" **** imageData : ", imageData);

              self.state.imageArray.push(imageData),
                  imageArray.push(reader.result),
                  self.setState({ imageArray: self.state.imageArray })
              console.log("self.state.imageArray :", self.state.imageArray);

          }
      } else {
          Swal.fire({
              position: 'center',
              icon: 'warning',
              text: "Size of " + file.name + " is greater than 3 GB",
              timer: 3000,
              showConfirmButton: true,
          });
      }


}
/*FUNCTION USED TO HANDLE THE UPLOADED VIDEO- IMPLEMENTED BY PRIYANKA - 20-04-2022 [From MenuUpload.js Code Added by Durga-14-05-2022]*/
handleVideo = (file, count) => {
  
    var self = this;

    var videoData;

//    //alert("file.size :" + file.size);
    var fileSize_GB = (file.size / (1000 * 1000 * 1000)).toFixed(2);
   // alert("fileSize_GB :" + fileSize_GB);

    if (fileSize_GB <= 3) {

        const url = URL.createObjectURL(file);
        self.state.videoArray.push(url);
        self.setState({
           videoArray: self.state.videoArray,
        })

        var reader = new FileReader();
        reader.readAsDataURL(file);

        reader.onloadend = function () {
            //  console.log('RESULT', reader.result)
            videoData = {
                originalName: file.name,
                name: count,
                data: file,
                src:reader.result,
                size: fileSize_GB,
                fileType: file.type
            },
                console.log(" **** videoData : ", videoData);

            videoArray.push(videoData);

              var videoThumbNailData;
                
                GetVideoThumbNail(file, '').then(function (videoThumbNail) {
                  //  FileSaver.saveAs(videoThumbNail, "image.jpg"),
                        videoThumbNailData = {
                            name: count,
                            data: videoThumbNail,
                            fileType: videoThumbNail.type
                        },
                        videoThumbNailArray.push(videoThumbNailData)
                });
        }
        console.log("videoArray :", videoArray);
        // this.setState({ imageUploadValid: true }, this.validateForm);
        // $("#previewvideo").hide();

    } else {
        Swal.fire({
            position: 'center',
            icon: 'warning',
            text: "Size of " + file.name + " is greater than 3 GB",
            timer: 3000,
            showConfirmButton: true,
        });
    }

};
/*INSERT FUNCTION - IMPLEMENTED BY PRIYANKA - 20-04-2022[From MenuUpload.js Code Added by Durga-14-05-2022]*/
  Submit() {

    var self=this;
    var uploadData;
    var uploadType;

    if (this.state.imageArray.length > 0) {
        uploadData = this.state.imageArray;
        uploadType="Image";
    } else if (videoArray.length > 0) {
        uploadData = videoArray;
        uploadType="Video";
    }
    else if(this.state.documentArray.length>0)
    {
      uploadData = this.state.documentArray; 
      uploadType="Application";
    }

    var metaData = {
        description: this.state.description,
        title: this.state.title
    }


    GetFileName(this.state.folderPath).then(function (response) {
        console.log("** RESPONSE :", response)
        if (response !== "Error") {
            // self.UpdateProfileImage(fileName);
            console.log("** RESPONSE CONTENTS :", response.Contents)

            var contentsLength = (response.Contents.length) - 1;
            console.log("contentsLength :", contentsLength);
          
            var fileNameArray=response.Contents.map(function(el) { 
              
                console.log("filename",el);
                var splitData=(el.Key).split(/[\s/]+/);
                var onlyFilename=splitData[splitData.length - 1];
                return onlyFilename.split(".")[0] });
         
                var fileNameArrayInt = fileNameArray.map(Number);
          

            console.log("fileNameArrayInt :", fileNameArrayInt);
            
            var keyName = Math.max(...fileNameArrayInt);
           
            if (videoThumbNailArray.length > 0) {
              for (var i = 0; i < uploadData.length; i++) {
                console.log("keyName :",keyName);
                  keyName = Number(keyName) + Number(1);
                  uploadData[i].name = keyName.toString();
                  videoThumbNailArray[i].name = keyName.toString();
                  uploadIdArray.push(keyName.toString());
              }
              console.log(" **** uploadIdArray :", videoThumbNailArray);
          } else {
              for (var i = 0; i < uploadData.length; i++) {
                console.log("keyName :",keyName);
                
                  keyName = Number(keyName) + Number(1);

                  uploadData[i].name = keyName.toString();

                  uploadIdArray.push(keyName.toString());
              }
             
          }
          console.log(" **** uploadData :", uploadData);

            UploadToAWS(self.state.folderPath, uploadData, metaData).then(function (response) {
                console.log(" ***** UploadToAWS response :", response);
                if (response == "Uploaded") {

                  self.ServerSubmit(uploadType);

                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        text: 'Uploaded Successfully',
                        showConfirmButton: false,
                        timer: 2000
                    })

                } else if (response == "Error") {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Upload done partially, kindly try after sometime',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }

                $(".imagepreview").hide();
                $(".videopreview").hide();
                self.ClearFunc();

            })
            if (videoThumbNailArray.length > 0) {
              UploadToAWS(self.state.folderPath + "/ThumbNail", videoThumbNailArray, metaData).then(function (response) {
                  console.log(" ***** UploadToAWS THUMB NAIL :", response);

              });
            }

        }
    });
}

/*Notused--METHOD FOR  ADDING FILENAME FOR VIDEO ARRAY USED TO UPLOAD INTO AWS S3 IMPLEMENETED BY DURGA -  24-06-2022*/
AddUploadId(uploadIdList) {

    var companyId = GetLocalStorageData("CompanyId");
    var videofilenamearray = [];

    console.log("uploadIdList", uploadIdList, "len", uploadIdList.length);
    console.log("uploadIdList", companyId);
    var temp;

    for (var i = uploadIdList.length - 1; i >= 0; i--) {
      temp = companyId + uploadIdList[i];
      console.log("temp", temp)
      videofilenamearray.push(temp);
    }

    console.log(this.state.videoArray, "this.state.videoArray");
    console.log("videoArray", videoArray);
    console.log("videoArray[0]", videoArray[0]);

    UploadToAWS(self.state.folderPath, uploadData, metaData)


    Swal.fire({
      position: 'center',
      icon: 'success',
      text: 'Uploaded Successfully',
      showConfirmButton: false,
      timer: 2000
    })
   
    console.log("final line after call");

  }

/*FUNCTION USED TO UPLOAD FILENAME,TITLE,DESCRIPTION INTO DATABASE USED FOR *FRANCHISE HELP SEARCH FUNC()-IMPLEMENTED BY DURGA 14-07-2022 */
  ServerSubmit(uploadType) {
    var self=this;
     console.log("uploadIdArray",uploadIdArray,"title-", this.state.title, "description-", this.state.description);
    
     //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 29-04-2022
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.setState({date: this.state.date,time: this.state.time})
  
    $.ajax({
      type: 'POST',
      data: JSON.stringify({

        companyId: GetLocalStorageData("CompanyId"),
        fileNameArray: uploadIdArray,
        module: "Help",
        date: this.state.date,
        time: this.state.time,
        menuId: "Help",
        uploadType: uploadType,
        description: this.state.description,
        title: this.state.title,
       
      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/AdminUpload/FileNameUpload",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

        if (data.response == "Success") {
          Swal.fire({
            position: 'center',
            icon: 'success',
            text: 'Uploaded Successfully',
            showConfirmButton: false,
            timer: 2000
          })
        } else if (data.response == "Few Failed") {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Upload done partially, kindly try after sometime',
            showConfirmButton: false,
            timer: 2000
          })
        }


      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });
    self.ClearFunc();
  }

/*FUNCTION USED FOR Clear FIELDS - IMPLEMENETED BY DURGA -  24-05-2022*/
  ClearFunc() {

    videoThumbNailArray = [];
    uploadIdArray=[];
    fileNameArray = [];
    imageArray = [];
    videoArray = [];
    documentArray = [];
    var self = this;
    videoArray = [];
    self.state.moduleName = "";
    self.state.imageUploadType = "";
    self.state.menuId = "";
    self.state.title = "";
    self.state.description = "";

    self.state.uploadValid = false;
    
    self.state.fileNameArray = [];

    self.state.imageArray = [];
    self.state.documentArray = [];
    self.state.videoArray = [];

    self.state.imageArrayLength = 0;
    self.state.documentArrayLength = 0;
    self.state.videoArrayLength = 0;

    self.state.formValid = false;
    self.state.titleValid = false;

    self.state.descriptionValid = false;
    //  self.state.formErrors.descriptionValid= false;
    self.state.formErrors.title = '';
    self.state.formErrors.description = '';

    self.state.fileSize=0;

    console.log("  fileNameArray: self.state.fileNameArray,", self.state.fileNameArray);

    self.setState({
      fileNameArray: self.state.fileNameArray,
      menuId: self.state.menuId,
      moduleName: self.state.moduleName,
      imageUploadType: self.state.imageUploadType,
      title: self.state.title,
      description: self.state.description,
      imageArray: self.state.imageArray,
      imageArrayLength: self.state.imageArrayLength,
      videoArray: self.state.videoArray,
      videoArrayLength: self.state.videoArrayLength,
      documentArray: self.state.documentArray,
      documentArrayLength: self.state.documentArrayLength,
      uploadValid: self.state.uploadValid,
      titleValid: self.state.titleValid,
      descriptionValid: self.state.descriptionValid,
      formValid: false
    }, this.validateForm())

  }
/*FUNCTION USED FOR REMOVING AN IMAGE IMPLEMENETED BY DURGA -  24-05-2022*/
  RemoveData(displayData) {

    var self = this;
    self.state.fileSize=0;
    self.setState({
      fileSize:self.state.fileSize
    })

    console.log("image :", displayData.name, displayData.type);
    // console.log("fileNameArray :", fileNameArray);
    // console.log("removedata-imageArray ",imageArray); 
    console.log("removedata-self.state.videoArray ",self.state.videoArray);

    fileNameArray.splice(fileNameArray.findIndex(data => data.name === displayData.name), 1)

    
    self.state.fileNameArray = fileNameArray
    self.setState({ fileNameArray: self.state.fileNameArray })

    if (displayData.type == "image") {
      //originalName
      var index=self.state.imageArray.findIndex(data => data.originalName === displayData.name);
      console.log("index",index);
      imageArray.splice(index, 1)
      self.state.imageArray = imageArray;
      self.state.imageArrayLength = imageArray.length;
      console.log("removedata-self.state.imageArray",self.state.imageArray);
      self.setState({
        imageArray: self.state.imageArray,
        imageArrayLength: self.state.imageArrayLength,
        videoArray:[],
        videoArrayLength:0,
        documentArray:[],
        documentArrayLength:0
      })
      documentArray=[];videoArray=[];
      var presentFileData=_.pluck(self.state.imageArray, 'size');
      self.state.fileSize = presentFileData.reduce((fileSize, currentFileSize) => fileSize + currentFileSize, 0);

      self.setState({
        fileSize:self.state.fileSize,
      })

      $("#submitErrorMsg").empty();

      if(self.state.fileSize > 1){
        $("#submitErrorMsg").append("File Size is too long reduce the no.of files uploaded !!");
         // HideFieldErrorMsgs("submitErrorMsg");
  
          this.state.formValid=false;
          this.setState({
            formValid:false,
            uploadValid:false
          },this.validateForm())
      }
     
    }
    else if (displayData.type == "video") {
      var index=self.state.videoArray.findIndex(data => data.originalName === displayData.name);
      videoArray.splice(index, 1)
      self.state.videoArray = videoArray
      self.state.videoArrayLength = videoArray.length;
      self.setState({
        videoArray: self.state.videoArray,
        videoArrayLength: self.state.videoArrayLength,
        imageArray:[],
        imageArrayLength:0,
        documentArray:[],
        documentArrayLength:0
      })
      documentArray=[];
      imageArray=[];
    }
    else {
      var index=self.state.documentArray.findIndex(data => data.originalName === displayData.name);
      documentArray.splice(index, 1)
      self.state.documentArray = documentArray;
      self.state.documentArrayLength = documentArray.length;
      self.setState({
        documentArray: self.state.documentArray,
        documentArrayLength: self.state.documentArrayLength,
        imageArray: [],
        imageArrayLength:0,
        videoArray:[],
        videoArrayLength:0,
      })
      videoArray=[];
      imageArray=[];
    }
    if (self.state.imageArrayLength != 0 || self.state.documentArrayLength != 0 || self.state.videoArrayLength != 0) {
      this.setState({
        uploadValid: true,
      })
    }
    else {
      this.ClearFunc();
      // this.state.formValid = false;
      // this.setState({
      //   uploadValid: false,
      // }, this.validateForm) 
    }
    console.log("videoArray",videoArray,"selfvideoArray",self.state.videoArray);
    console.log("Length :", self.state.imageArrayLength,self.state.videoArrayLength,self.state.documentArrayLength);
    console.log("imageArray",self.state.imageArray,"vdoArray",self.state.videoArray,"doceArray",self.state.documentArray);

    console.log("this.state.imageArray :", this.state.imageArray);
  }
  render() {
    return (
      <div>
          <div className="toptitle">
            <h4>Technical Know-How</h4>
          </div>
       <div className="container-fluid">
        <ThemeProvider theme={darkTheme}>

          <div class="row">
            <div class="col-md-12 image-wrapper">
              <div className="text-center upload__image-wrapper">
                <a class="uploadicon" onClick={this.uploadfiles}>
                  {/* <FaIcons.FaUpload /> */} <img src={uploadimg} style={{width:'150px'}} />
                  {/* Field used to get files like images,video,pdf - it's mandatory field */}
                  <input type="file" name="imageUpload" id="uploadall" style={{ display: "none" }}
                    multiple onChange={this.fileChangedHandler} /> <p id="uploadtext">Upload</p></a></div>
            </div>
          </div>

          <div className="row"> {/*filename rendering part added by durga*/}
            <div className="naming">
              {
                (this.state.fileNameArray.map((data) => (
                  <span className="text-center">{data.name}<a className="remove" onClick={() => this.RemoveData(data)} ><AiIcons.AiFillCloseSquare /> </a>, </span>)))


              }
            </div>
          </div>
          <div class="input_wrapper row">
            <div className="col-md-6">
              {/* <label class="control-label">Title <span class="mandatoryfields">*</span></label> */}
              {/* Field used to get files title- it's mandatory field */}
               <TextField fullWidth   margin="normal"  size="small"  variant="outlined" label="Enter Title*"  name="title" value={this.state.title} onChange={this.handleUserInput} />

              {/* <input type="text" placeholder="Title" name="title" value={this.state.title} onChange={this.handleUserInput} className="textfield" /> */}
              <ErrorClass errorContent={this.state.formErrors.title} />
            </div>
            <div className="col-md-6">
              {/* <label>Description <span class="mandatoryfields">*</span></label> */}
              {/* Field used to get description - it's mandatory field */}
               <TextField fullWidth   margin="normal"  size="small"  variant="outlined" label="Enter Description*"   defaultValue="Normal" onChange={this.handleUserInput} name="description" value={this.state.description} />

              {/* <input type="text" className="textfield textfield_class " onChange={this.handleUserInput} name="description" placeholder="Description" value={this.state.description} required /> */}
              <ErrorClass errorContent={this.state.formErrors.description} />
            </div>
          </div>
          <span id="submitErrorMsg" style={{color:'red'}}></span>
          {/* disabled={!this.state.formValid} */}
          <div className="text-center">
            <button class="btn btn-primary btn-submit" disabled={!this.state.formValid} onClick={() => this.Submit()}>Submit</button>
            <button id="cancel" class="btn btn-primary btn-cancel" onClick={() => this.ClearFunc()}>Cancel</button>
          </div>
</ThemeProvider>
        </div>
      </div>
    );
  };
}
export default Help;
