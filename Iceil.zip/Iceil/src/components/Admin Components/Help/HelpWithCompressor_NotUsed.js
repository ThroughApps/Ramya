import React from "react";
import * as FaIcons from 'react-icons/fa';
import '../Help/HelpCss.css';
import $ from 'jquery';
import _ from 'underscore';
import { blobToURL, urlToBlob, fromBlob, fromURL } from 'image-resize-compress';
import Compressor from 'compressorjs';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import * as FcIcons from 'react-icons/fc';
import * as AiIcons from 'react-icons/ai';
import { ErrorClass } from '../../Validation Components/Loginvalidation';
import { GetLocalStorageData, TimeZoneDateTime } from "../../Common Components/CommonComponents";
// import pdfToBase64 from "pdf-to-base64";


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

var totalImages = [10];
var filearray = [];
var videoURL;
var imageArray = [];
var videoArray = [];
var documentArray = [];
var fileNameArray = [];
var standardFileSize = 1024.000;
var selectedNodesValid = false;

class Help extends React.Component {
  constructor() {
    super();
    this.state = {
      title: '',
      description: '',
      convertedFileSize: 0,
      imageArrayLength: 0,
      videoArrayLength: 0,
      documentArrayLength: 0,
      imageArray: [],
      videoURLArray: [],
      documentArray: [],
      fileNameArray: [],
      formErrors: {
        title: '',
        description: '',
        imageslists: [],

      },
      titleValid: false,
      descriptionValid: false,
    };
    this.fileChangedHandler = this.fileChangedHandler.bind(this);
    this.handleBlob = this.handleBlob.bind(this);
    this.handleVideo = this.handleVideo.bind(this);
    this.handleDocument = this.handleDocument.bind(this);
    this.RemoveData = this.RemoveData.bind(this);
  }
  handleUserInput = (e) => {
    const name = e.target.name;
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    this.setState({ [name]: value },
      () => { this.validateField(name, value) });
  }
  imageresponse() {
    //alert("Inside of image response");
    var MAX_FILE_SIZE = 5 * 1024 * 1024;

    imageArray = this.state.images;
    //console.log(imageArray,imageArray.length);

    var i = 0;
    var count = 0;
    filearray = [];
    var self = this;
    var filesizeIssue = false;
    var fileTypeIssue = false;
    while (i < imageArray.length) {
      if (imageArray[i].file.type.match(/.(jpg|jpeg|png)$/i)) {
        if (imageArray[i].file.size < MAX_FILE_SIZE) {
          var imageFile = dataURLtoFile(imageArray[i].data_url, imageArray[i].file.name);
          new Compressor(imageFile, {
            quality: 0.3,
            // 0.6 can also be used, but its not recommended to go below.  
            convertSize: 1500000,
            success: (compressedResult) => {
              // compressedResult has the compressed file. 
              // Use the compressed file to upload the images to your server.  
              self.getBase64(compressedResult).then(result => {
                // result is converted base64
                filearray[count] = result;
                count++;
              }).catch(err => { console.log(err); });
            }
          });
        } else {
          filesizeIssue = true;
          imageArray.splice(i, 1);
        }

      } else {

        fileTypeIssue = true;
        imageArray.splice(i, 1);
      }
      i++;// move to next image
    }
    if (fileTypeIssue) {
      Swal.fire({
        position: 'center',
        icon: 'error',
        text: 'Upload PNG,JPG or JPE file !!',
        timer: 3000
      });
    } else if (filesizeIssue) {
      Swal.fire({
        position: 'center',
        icon: 'error',
        text: 'Upload image  less than 5MB',
        timer: 3000
      });
    }
    //file array get value in reverse order
    this.setState({
      baseFiles: filearray,
      images: imageArray
    });
  }
  onChange = (imageList, addUpdateIndex) => {
    // data for submit
    //imageList.preventDefault();
    //alert("Changes happen here");
    if (imageList.length > 10) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Limit Exceeds',
        showConfirmButton: false,
        timer: 2000
      })
    }
    else {
      totalImages = imageList;
      //console.log(imageList,totalImages,totalImages.length);
      this.setState({ images: imageList });

      if (totalImages.length != 0) {
        ////console.log("photo Selected working",this.state.flag);
        this.setState({ flag: false });
        // //console.log("photo Selected working",this.state.flag);
      }
      else {
        this.setState({ flag: true });
      }

      //console.log(imageList, addUpdateIndex);
      this.imageresponse();
    }
  }
  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let titleValid = this.state.titleValid;
    let descriptionValid = this.state.descriptionValid;
    switch (fieldName) {
      case 'title':
        titleValid = value.trim().length >= 5;
        fieldValidationErrors.title = titleValid ? '' : 'Contain Atleast 5 Characters';
        break;
      case 'description':
        descriptionValid = value.trim().length >= 5;
        fieldValidationErrors.description = descriptionValid ? '' : 'Contain Atleast 5 Characters';
        break;

      default:
        break;
    }
    this.setState({
      formErrors: fieldValidationErrors,
      titleValid: titleValid,
      descriptionValid: descriptionValid,
    }, this.validateForm)
  }
  validateForm() {
    this.setState({
      formValid:
        this.state.titleValid
        && this.state.descriptionValid
        && this.state.imageUploadValid
    });
    // console.log("this.state.titleValid", this.state.titleValid);
    // console.log("this.state.descriptionValid", this.state.descriptionValid);
  }

  componentDidMount() {
  }
  uploadfiles() {
    document.getElementById("uploadall").click();

    // let upload = document.getElementById('uploadall');
    // let uploadfilename = document.getElementById('uploadtext');

    // upload.addEventListener('change', function (event) {

    //   let updatefile = event.target.files[0].name;
    //   uploadfilename.textContent = updatefile;
    //   console.log("uploadfilename", uploadfilename);
    // })
  }

  /*
  FUNCTION USED TO HANDLE FILE UPLOAD(IMAGE/VIDEO)
  - IMPLEMENTED BY PRIYANKA - 20-04-2022 [From MenuUpload.js Code Added by Durga-14-05-2022]
  */
  fileChangedHandler(event) {

  //  console.log(event, "event");

    var self = this;
    var fileInput = false;
    var files = event.target.files[0];
    // if (event.target.files[0]) {
    //   fileInput = true;
    // }
    // var fileType = event.target.files[0].type.split("/")[0];

    // console.log("filetype", fileType);
  //  console.log("event.target.files[0] :", event.target.files);
  //  console.log("length", event.target.files.length);


    if (event.target.files.length != 0) {
      fileInput = true;
    }

    if (fileInput) {

      for (var i = 0; i < event.target.files.length; i++) {

        var currentFileType = event.target.files[i].type.split("/")[0];

     //   console.log("currentFileType", currentFileType);
        // alert("currentFileType" + currentFileType);

        // this.validateField('titleValid', this.state.titleValid);   
        //  this.validateField('descriptionValid', this.state.descriptionValid); 
        /* var imageUploadValid = false;
         if (event.target.files.length != null) {
           imageUploadValid = true;
         }
         else {
           imageUploadValid = false;
         }
         this.setState({
           imageUploadValid: imageUploadValid
         }, this.validateForm)
         */

        if (currentFileType == "image") {

       //   console.log("videoArray.length ", videoArray.length, "documentArray.length", documentArray.length);

          if (videoArray.length != 0 || documentArray.length != 0) {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Unique file only allowed!',
              showConfirmButton: true,
              timer: 2000
            })
            fileNameArray = [];
          }
          //   else {

          //UPLOADED FILE BEING IMAGE OR JPEG OR PNG
       //   console.log("IMAGE ARRAY :", imageArray);
       //   console.log("VIDEO ARRAY :", videoArray);

          var imageUploadValid = false;
          if (event.target.files.length != null) {
            imageUploadValid = true;
          }
          else {
            imageUploadValid = false;
          }
          this.setState({
            imageUploadValid: imageUploadValid
          }, this.validateForm)


          self.state.imageArrayLength = Number(self.state.imageArrayLength) + Number(1);
          self.setState({
            imageArrayLength: self.state.imageArrayLength
          })

          if (self.state.imageArrayLength <= 10) {
            //ONLY 10 IMAGES CAN BE UPLOADED AT A TIME
            // $(".imagepreview").show();
            // $(".videopreview").hide();
            // $("#previewvideo").show();

            self.state.videoURL = "";
            videoArray = [];
            videoURL = "";

            self.setState({ videoURL: "", })

            //CONVERTING THE UPLOADED BLOB(IMAGE/JPEG/PNG) TO URL - IMPLEMENTED BY PRIYANKA - 20-04-2022
            blobToURL(event.target.files[i]).then((url) => (self.state.uploadedFileUrl = url, self.setState({ uploadedFileUrl: url })));

            fileNameArray.push({ name: event.target.files[i].name, type: "image" }); //adding filename into separate array to render

            //COMPRESING & CHECKING FOR THE SIZE OF THE UPLOADED & COMPRESSED FILE SIZE - IMPLEMENTED BY PRIYANKA - 20-04-2022
            self.handleBlob(event.target.files[i]);


          } else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Only 10 images can be uploaded at a time',
              showConfirmButton: false,
              timer: 2000
            })
          }
          //   }
          //  } else if (currentFileType == "video/mp4" || currentFileType == "video/x-m4v" || currentFileType == "video/*") {
        }
        else if (currentFileType == "video") {

       //   console.log("imageArray.length ", imageArray.length, "documentArray.length", documentArray.length);

          if (imageArray.length != 0 || documentArray.length != 0) {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Unique file only allowed!',
              showConfirmButton: true,
              timer: 2000
            })
            fileNameArray = [];


          }
          //   else {


          self.state.videoArrayLength = Number(self.state.videoArrayLength) + Number(1);
          self.setState({
            videoArrayLength: self.state.videoArrayLength
          })

          $("#previewvideo").hide();
          // //UPLOADED FILE BEING VIDEO 
          // let filename = document.getElementById('file-name');
          // let uploadfilename = event.target.files[0].name;
          // filename.textContent = uploadfilename;
          // console.log("uploadfilename", uploadfilename)

          //UPLOADED FILE BEING VIDEO 

          if (self.state.videoArrayLength == 1) {
            //ONLY ONE VIDEO CAN BE UPLOADED AT A TIME
            $(".imagepreview").hide();
            $(".videopreview").show();

          //  console.log("IMAGE ARRAY :", self.state.imageArray);
          //  console.log("VIDEO ARRAY :", videoArray);

            fileNameArray.push({ name: event.target.files[i].name, type: "video" });

            self.state.imageArray = [];
            imageArray = [];
            self.state.imageArrayLength = 0;

            self.state.documentArray = [];
            documentArray = [];
            self.state.documentArrayLength = 0;
            self.setState({
              imageArray: [],
              imageArrayLength: 0,
              documentArrayLength: 0,
              documentArray: [],
            })

            //   alert("event.target.files[i].size :" + event.target.files[i].size);
            var totalSizeKB = event.target.files[i].size / Math.pow(1024, 1);
            //   alert("totalSizeKB :" + totalSizeKB);

            var standardVideoFileSize = 5120.000; //5 MB IN TERMS OF KB

            if (totalSizeKB <= standardVideoFileSize) {
              self.handleVideo(event.target.files[i]);
            } else {

              self.state.videoArrayLength = 0;
              self.setState({
                videoArrayLength: self.state.videoArrayLength
              })

              Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Video of size greater than 5MB cannot be uploaded',
                showConfirmButton: false,
                timer: 2000
              })
            }

            // self.handleVideo(event.target.files[i]);
          }

          else {
            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Only 1 video can be uploaded at a time',
              showConfirmButton: false,
              timer: 2000
            })
          }
          //  }
        }
        else if (currentFileType == "application") {
          var fileType = event.target.files[i].type
          if (fileType == "application/pdf") {
       //     console.log("imageArray.length ", imageArray.length, "videoArray.length", videoArray.length);
            if (imageArray.length != 0 || videoArray.length != 0) {

              Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Unique file only allowed!',
                showConfirmButton: true,
                timer: 2000
              })
              fileNameArray = [];
            }
            //   else {

            self.state.documentArrayLength = Number(self.state.documentArrayLength) + Number(1);
            self.setState({
              documentArrayLength: self.state.documentArrayLength
            })

            //UPLOADED FILE BEING VIDEO 
            // let filename = document.getElementById('file-name');
            // let uploadfilename = event.target.files[0].name;
            // filename.textContent = uploadfilename;
            // console.log("uploadfilename", uploadfilename)

            //UPLOADED FILE BEING VIDEO 

            var imageUploadValid = false;
            if (event.target.files.length != null) {
              imageUploadValid = true;
            }
            else {
              imageUploadValid = false;
            }
            this.setState({
              imageUploadValid: imageUploadValid
            }, this.validateForm)

            if (self.state.documentArrayLength <= 3) {

              fileNameArray.push({ name: event.target.files[i].name, type: "application" }); //adding filename into separate array to render

              //ONLY ONE VIDEO CAN BE UPLOADED AT A TIME
              $(".imagepreview").hide();
              $(".videopreview").show();

          //    console.log("IMAGE ARRAY :", self.state.imageArray);
            //  console.log("VIDEO ARRAY :", videoArray);

              self.state.imageArray = [];
              imageArray = [];
              self.state.imageArrayLength = 0;
              self.setState({
                imageArray: [],
                imageArrayLength: 0,
              })
              self.state.videoArray = [];
              videoArray = [];
              self.state.videoArrayLength = 0;
              self.state.videoURL = "";
              videoURL = "";


              self.setState({
                imageArray: [],
                imageArrayLength: 0,
                videoArrayLength: 0,
                videoArray: [],
                videoURL: "",
              })
             // console.log("handleDocument b4 call", event.target.files[i]);
              self.handleDocument(event.target.files[i]);
            }
            else {
              Swal.fire({
                position: 'center',
                icon: 'warning',
                text: 'Only 5 Files can be uploaded at a time!',
                showConfirmButton: false,
                timer: 2000
              })
            }

            //   }
          }
          else {

            Swal.fire({
              position: 'center',
              icon: 'warning',
              text: 'Pdf type can be Uploaded!',
              showConfirmButton: false,
              timer: 2000
            })
          }
        }
        else {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Image,Video or Pdf,Either one type can be Uploaded!',
            showConfirmButton: false,
            timer: 2000
          })
        }

      }
   //   console.log("fileNameArray globe", fileNameArray);
      self.state.fileNameArray = fileNameArray;
      self.setState({ fileNameArray: self.state.fileNameArray })
   //   console.log("fileNameArray", self.state.fileNameArray);
    }

    $("#uploadall")[0].value = '';

  }
  /*
    FUNCTION USED TO HANDLE THE UPLOADED  DOCUMENT(PDF)
    - IMPLEMENTED BY DURGA - 14-05-2022 
    */
  handleDocument = (event) => {
    var self = this;
    var file = event;
    var fileSize = event.size;
    var reader = new FileReader();
    reader.onloadend = () => {
      // Use a regex to remove data url part
      const base64String = reader.result
        .replace('data:', '')
        .replace(/^.+,/, '');

    //  console.log(base64String);
      documentArray.push(base64String);

      var documentData = {
        data: base64String,
        size: fileSize
      };

      self.state.documentArray.push(documentData);
      //documentArray.push(base64String);//global variable
      self.setState({ documentArray: self.state.documentArray });

   //   console.log("self.state.documentArray  :", self.state.documentArray);
   //   console.log("documentArray :", documentArray);

    };

    reader.readAsDataURL(file);
  };

  /*
  FUNCTION USED TO HANDLE THE UPLOADED IMAGE(IMAGE/PNG/JPEG)
  - IMPLEMENTED BY PRIYANKA - 20-04-2022 [From MenuUpload.js Code Added by Durga-14-05-2022]
  */
  handleBlob = (blobFile) => {

    var self = this;

    // quality value for webp and jpeg formats.
    const quality = 80;
    // output width. 0 will keep its original width and 'auto' will calculate its scale from height.
    const width = 200;
    // output height. 0 will keep its original height and 'auto' will calculate its scale from width.
    const height = "auto";
    // file format: png, jpeg, bmp, gif, webp. If null, original format will be used.
    const format = 'png';

    var reducedFileSize = 0;
    self.state.convertedFileSize = 0;

    // console.log("HANDLE BLOB ************ blobFile :", blobFile);
    // note only the blobFile argument is required
    var originalImage;
    var finalImage;
    var imageData;


    fromBlob(blobFile, quality, width, height, format).then((blob) => {


      // will generate a url to the converted file
      blobToURL(blob).then((url) => (
        //  alert("then"),
        self.state.url = url,
        self.setState({ url: self.state.url }),


        reducedFileSize = getSize((Number(blobFile.size) - Number(blob.size))),
        self.state.convertedFileSize = getSize(blob.size),
        self.setState({
          convertedFileSize: self.state.convertedFileSize
        }),

        imageData = {
          data: self.state.url,
          size: self.state.convertedFileSize
        },

        self.state.imageArray.push(imageData),
        imageArray.push(self.state.url),
        self.setState({ imageArray: self.state.imageArray })


     //   console.log("self.state.imageArray :", self.state.imageArray),
     //   console.log("imageArray :", imageArray)
      ))

    });
  };

  /*
    FUNCTION USED TO HANDLE THE UPLOADED VIDEO
    - IMPLEMENTED BY PRIYANKA - 20-04-2022 [From MenuUpload.js Code Added by Durga-14-05-2022]
    */
  handleVideo = (event) => {
   // console.log("video handle");
    var file = event;
    // Encode the file using the FileReader API
    const reader = new FileReader();
    const url = URL.createObjectURL(file);
    this.state.videoURL = url;
    this.state.videoURLArray.push(url);
    this.setState({
      videoURL: this.state.videoURL,
      videoURLArray: this.state.videoURLArray,
    })
    reader.onloadend = () => {
      // Use a regex to remove data url part
      const base64String = reader.result;

      videoURL = base64String;

      var videoData = {
        data: videoURL
      }
      videoArray.push(videoURL);

    };
    reader.readAsDataURL(file);
  //  console.log("videoArray :", videoArray);
    this.setState({ imageUploadValid: true }, this.validateForm);

  };

  //INSERT FUNCTION - IMPLEMENTED BY PRIYANKA - 20-04-2022[From MenuUpload.js Code Added by Durga-14-05-2022]
  Submit() {

    var self = this;
    var uploadData;

    standardFileSize = 1024.000;
    var uploadType = "Image";
    var sizeCheck = "Yes";

  //  console.log("all length", videoArray.length, documentArray.length, imageArray.length);

    if (videoArray.length > 0) {
      uploadType = "Video";
      uploadData = videoArray;
    }
    else if (documentArray.length > 0) //CHECKING TOTAL DOCUMENT SIZE -BY DURGA 14-05-2022
    {
    //  console.log("this.state.documentArray", this.state.documentArray);
      uploadType = "Application";
      var total = 0, tempsize;
    //  console.log("this.state.documentArray", this.state.documentArray);

      for (var i = 0; i < documentArray.length; i++) {
        tempsize = (documentArray[i].size / 1024).toFixed(3); //KB

        total = total + tempsize;
      }
      if ((total / 1024) > standardFileSize) {
        sizeCheck = "No";
      } else {
        uploadData = documentArray;
      }

   //   console.log("totalsize", total, uploadData);
    } else {
      var imageData = this.state.imageArray.map(function (Img) {
        if (Img.size <= standardFileSize) {
          return Img.data;
        } else {
          sizeCheck = "No";
        }
      });
      uploadData = imageData;
    }

    if (sizeCheck == "No") {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        text: uploadType + ' of size greater than 1024 MB will not be uploaded',
        showConfirmButton: false,
        timer: 2000
      })
    }
    //else{}
 //   console.log("SUBMIT -uploadData :", uploadData);

 /*   console.log("SUBMIT DTA :", JSON.stringify({
      companyId: '1',
      uploadData: uploadData,
      module: this.state.moduleName, //help
      date: this.state.date,
      time: this.state.time,
      menuId: this.state.menuId,
      description: this.state.description,
      uploadType: uploadType,

    }));
    */

    //CURRENT DATE & TIME-- IMPLEMENTED BY DURGA 29-04-2022
    var timeZone = 'Asia/Kolkata';
    var dateTimeData = TimeZoneDateTime(timeZone);
    this.state.date = dateTimeData.date;
    this.state.time = dateTimeData.time;
    this.setState({
      date: this.state.date,
      time: this.state.time,
    })
  //  console.log("title-", this.state.title, "description-", this.state.description);
    $.ajax({
      type: 'POST',
      data: JSON.stringify({

        companyId: GetLocalStorageData("CompanyId"),
        uploadData: uploadData,
        module: "Help",
        date: this.state.date,
        time: this.state.time,
        menuId: "Help",
        uploadType: uploadType,
        description: this.state.description,
        title: this.state.title,
        printPreviewParameter: 1,

      }),

      url: "http://15.206.129.105:8080/IceilLiveAPI/AdminUpload/ItemsUpload",

      contentType: "application/json",
      dataType: 'json',
      async: false,
      success: function (data, textStatus, jqXHR) {

//        console.log("MENU UPLOAD DATA :", data);


        if (data.response == "Success") {
          Swal.fire({
            position: 'center',
            icon: 'success',
            text: 'Uploaded Successfully',
            showConfirmButton: false,
            timer: 2000
          })
        } else if (data.response == "Few Failed") {
          Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Upload done partially, kindly try after sometime',
            showConfirmButton: false,
            timer: 2000
          })
        }


      },
      error: function (data) {
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Network Connection Problem',
          showConfirmButton: false,
          timer: 2000
        })


      },
    });
    self.ClearFunc();
  }
  /*
    FUNCTION USED FOR Clear FIELDS 
    - IMPLEMENETED BY DURGA -  24-05-2022
    */

  ClearFunc() {

    fileNameArray = [];
    imageArray = [];
    videoArray = [];
    documentArray = [];
    var self = this;
    videoArray = [];
    self.state.moduleName = "";
    self.state.imageUploadType = "";
    self.state.menuId = "";
    self.state.title = "";
    self.state.description = "";
    self.state.imageUploadValid = false;
    self.state.fileNameArray = [];

    self.state.imageArray = [];
    self.state.documentArray = [];
    self.state.videoURLArray = [];

    self.state.imageArrayLength = 0;
    self.state.documentArrayLength = 0;
    self.state.videoArrayLength = 0;

    self.state.formValid = false;
    self.state.titleValid = false;

    self.state.descriptionValid = false;
    //  self.state.formErrors.descriptionValid= false;
    self.state.formErrors.title = '';
    self.state.formErrors.description = '';

  //  console.log("  fileNameArray: self.state.fileNameArray,", self.state.fileNameArray);

    self.setState({
      fileNameArray: self.state.fileNameArray,
      menuId: self.state.menuId,
      moduleName: self.state.moduleName,
      imageUploadType: self.state.imageUploadType,
      title: self.state.title,
      description: self.state.description,

      imageArray: self.state.imageArray,
      imageArrayLength: self.state.imageArrayLength,

      videoURLArray: self.state.videoURLArray,
      videoArrayLength: self.state.videoArrayLength,

      documentArray: self.state.documentArray,
      documentArrayLength: self.state.documentArrayLength,
      imageUploadValid: self.state.imageUploadValid,
      titleValid: self.state.titleValid,
      descriptionValid: self.state.descriptionValid,
      formValid: false
    }, this.validateForm())




  }

  /*
  FUNCTION USED FOR REMOVING AN IMAGE 
  - IMPLEMENETED BY DURGA -  24-05-2022
  */
  RemoveData(displayData) {

    var self = this;
 //   console.log("image :", displayData.name, displayData.type);
 //   console.log("fileNameArray :", fileNameArray);

    fileNameArray.splice(fileNameArray.findIndex(data => data.name === displayData.name), 1)

  //  console.log("image :", fileNameArray);
    self.state.fileNameArray = fileNameArray
    self.setState({ fileNameArray: self.state.fileNameArray })

    if (displayData.type == "image") {
      imageArray.splice(fileNameArray.findIndex(data => data === displayData.name), 1)
      self.state.imageArray = imageArray;
      self.state.imageArrayLength = self.state.imageArrayLength - 1;

      self.setState({
        imageArray: self.state.imageArray,
        imageArrayLength: self.state.imageArrayLength
      })
   //   console.log("self.state.imageArrayLength :", self.state.imageArrayLength);
    //  console.log("self.state.imageArray :", self.state.imageArray);
    }
    else if (displayData.type == "video") {
      videoArray.splice(fileNameArray.findIndex(data => data === displayData.name), 1)
      self.state.videoURLArray = videoArray
      self.state.videoArrayLength = self.state.videoURLArray.length;
      self.setState({
        videoURLArray: self.state.videoURLArray,
        videoArrayLength: self.state.videoArrayLength
      })
    }
    else {
      documentArray.splice(documentArray.findIndex(data => data === displayData.name), 1)
      self.state.documentArray = documentArray;
      self.state.documentArrayLength = self.state.documentArrayLength - 1;
      self.setState({
        documentArray: self.state.documentArray,
        documentArrayLength: self.state.documentArrayLength
      })
    }
    if (self.state.imageArrayLength != 0 || self.state.documentArrayLength != 0 || self.state.videoArrayLength != 0) {
      this.state.formValid = true;
      this.setState({
        formValid: true,
      })
    }
    else {
      this.state.imageUploadValid = false;
      this.state.formValid = false;
      this.setState({
        formValid: false,
        imageUploadValid: false
      }, this.validateForm)
    /*  console.log("self.state.imageArrayLength :", self.state.imageArrayLength);
      console.log("self.state.documentArrayLength :", self.state.documentArrayLength);
      console.log("self.state.videoArrayLength :", self.state.videoArrayLength);
      */
    }

    //  imageArray.splice(this.state.imageArray.findIndex(imageData => imageData.data === image), 1)
    //   this.setState({
    //       imageArray: this.state.imageArray,
    //   })

    //   this.state.imageArrayLength = this.state.imageArray.length;
    //   this.setState({
    //       imageArrayLength: this.state.imageArrayLength,
    //   })

  //  console.log("this.state.imageArray :", this.state.imageArray);
  }
  render() {
    return (
      <div>
        <div className="">
          <div className="toptitle">
            <h3>Technical Know-How</h3>
          </div>
        </div>
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-12 image-wrapper">
              <div className="text-center upload__image-wrapper">
                <a class="uploadicon" onClick={this.uploadfiles}><FaIcons.FaUpload />
                  {/* Field used to get files like images,video,pdf - it's mandatory field */}
                  <input type="file" name="imageUpload" id="uploadall" style={{ display: "none" }}
                    multiple onChange={this.fileChangedHandler} /> <p id="uploadtext">Upload</p></a></div>
            </div>
          </div>
          <div className="row"> {/*filename rendering part added by durga*/}
            <div className="naming">
              {
                (this.state.fileNameArray.map((data) => (
                  <span className="text-center">{data.name}<a className="remove" onClick={() => this.RemoveData(data)} ><AiIcons.AiFillCloseSquare /> </a>, </span>)))


              }
            </div>
          </div>
          <div class="row">
            <div className="col-md-6">
              <label class="control-label">Title <span class="mandatoryfields">*</span></label>
              {/* Field used to get files title- it's mandatory field */}
              <input type="text" placeholder="Title" name="title" value={this.state.title} onChange={this.handleUserInput} className="textfield" />
              <ErrorClass errorContent={this.state.formErrors.title} />
            </div>
            <div className="col-md-6">
              <label>Description <span class="mandatoryfields">*</span></label>
              {/* Field used to get description - it's mandatory field */}
              <input type="text" className="textfield textfield_class " onChange={this.handleUserInput} name="description" placeholder="Description" value={this.state.description} required />
              <ErrorClass errorContent={this.state.formErrors.description} />
            </div>
          </div>

          <div className="text-center">
            <button class="btn btn-primary btn-submit" disabled={!this.state.formValid} onClick={() => this.Submit()}>Submit</button>
            <button id="cancel" class="btn btn-primary btn-cancel" onClick={() => this.ClearFunc()}>Cancel</button>
          </div>

        </div>
      </div>
    );
  };
}
export default Help;

function dataURLtoFile(dataurl, filename) {

  var arr = dataurl.split(','),
    mime = arr[0].match(/:(.*?);/)[1],
    bstr = atob(arr[1]),
    n = bstr.length,
    u8arr = new Uint8Array(n);

  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }

  return new File([u8arr], filename, { type: mime });
}

const getSize = (size) => (console.log("GET SIZE :", size), (size / 1024).toFixed(3));


