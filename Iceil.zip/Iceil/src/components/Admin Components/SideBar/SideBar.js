//IMPORT STATEMENTS FOR REACT COMPONENT
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import $ from 'jquery';
import ReactDOM from "react-dom";
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from "react-icons/ai";
import * as BsIcons from "react-icons/bs";
import * as ImIcons from "react-icons/im";


import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';
 
// import statement for react component css
import "./SideBarCss.css";
// import statement for image
import iceillogo from '../../images/iceillogo.png';
// import statement for react class component
import MenuUpload from '../MenuUpload/MenuUpload';
import AddMenu from '../Configuration/Menu/AddMenu';
import FAQ from '../FAQ/FAQ';
import ProductMenu from '../Product/ProductMenu';
import AddUser from '../User Management/AddUser';
import UserManagementMenu from '../User Management/UserManagementMenu';
import LoginPage from '../../LoginComponents/LoginPage';
import Quotation from '../Quotation/Quotation';
import Help from '../Help/Help';
import { LogOut } from '../../Common Components/CommonComponents';
import Visitcount from '../Reports/Visit Count Report/Visitcount';
import AboutMe from '../About Me/AboutMe';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
THIS PAGE WAS DESIGNED BY RAMYA
WHERE AS THE ONCLICK FUNCTIONS FOR RENDERING 
THE PAGES BASED ON THE MENU CLICKED 
WAS IMPLEMENETED BY PRIYANKA
*/
class SideBar extends React.Component {

    constructor() {
        super()

        this.state = {
        }
    }


    componentDidMount() {

        //  alert("ADMIN  MENU");

        /*USED TO CLOSE THE SIDEBAR MENU INTO SMALL WHEVER CLICKS THE MENUBAR*/
        $(document).ready(function () {
            $(".menubars").click(function () {
                $(".wrapper").toggleClass("collapse");
            });
        });
        /*USED TO CLOSE THE SIDEBAR MENU INTO SMALL WHEVER CLICKS INSIDE THE PAGE*/
        $(document).ready(function () {
            $(".main_content").click(function () {
                $(".wrapper").addClass("collapse");
            });
        });
        /*USED TO CLOSE THE SIDEBAR MENU INTO SMALL WHEVER CLICKS THE MENU*/
        $(document).ready(function () {
            $(".sidebar-menu").click(function () {
                $(".wrapper").addClass("collapse");
            });
        });
        $(document).ready(function () {
            $(".sidebar-menu").click(function () {
                if(!$(this).hasClass('active'))
                {
                    $(".sidebar-menu.active").removeClass("active");
                    $(this).addClass("active");        
                }
            });
        });

        this.UserManagementMenuFunc();
    }

    /*
    USED TO CALL USER MANAGEMENT PAGES
    - IMPLEMENTED BY PRIYANKA - 29-04-2022
    */
    UserManagementMenuFunc() {

        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<UserManagementMenu />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        )

    }

    QuotationMenuFunc() {

        Swal.fire({
            position: 'center',
            icon: 'warning',
            text: 'Coming Soon',
            showConfirmButton: false,
            timer: 2000
          })
        /*
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Quotation />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );
        */
    }

    /*
    USED TO CALL ADD MENU PAGES
    - IMPLEMENTED BY PRIYANKA - 29-04-2022
    */
    ConfigurationMenuFunc() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<AddMenu />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );
    }

    ProductMenuFunc() {

        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<ProductMenu />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );
    }

    /*
    USED TO CALL MENU UPLOAD PAGES
    - IMPLEMENTED BY PRIYANKA - 29-04-2022
    */
    MenuUploadFunc() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<MenuUpload />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );
    }
    HelpMenuFunc() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Help />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );

    }
    FAQMenuFunc() {
        //  alert("FAQ");

        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<FAQ />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );
    }

    VisitCountMenuFunc() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Visitcount />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );
    }


    AboutMeFunc() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<AboutMe />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        );
    }

    LogOutFunc() {

        LogOut("AddToCart", "Admin");

        /* ReactDOM.render(
             <BrowserRouter>
                 <Routes>
                     <Route path="/" element={<LoginPage />} />
                 </Routes>
             </BrowserRouter>,
             document.getElementById("root")
         )
         */

    }


    render() {

        return (
            <div>
                <div class="wrapper" style={{ paddingBottom: '76px', overflowY: 'auto!important' }}>
                    <div class="topnavbar">
                        <div class="menus">
                            <div class="menubars">
                                <FaIcons.FaBars size={30} />
                            </div>
                            {/* <div class="comp_title">Iceil</div> */}
                        </div> 
                    </div>
                    <div className="sidebar">
                        <ul style={{ paddingBottom: "40px" }}>
                            <li class="logocolumn">
                                {/* <img class="logo" src={iceillogo} /> */}
                                <h3 class="logo">ICEIL</h3>
                                <h4 class="logo_sub">Franchise Management System</h4>
                            </li>
                            <li class="sidebar-menu active" onClick={() => this.UserManagementMenuFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><FaIcons.FaUserCircle /></span>
                                    <span class="menu-title">User Management</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.QuotationMenuFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><AiIcons.AiFillFile /></span>
                                    <span class="menu-title">Quotation</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.ConfigurationMenuFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><FaIcons.FaCog /></span>
                                    <span class="menu-title">Configuration</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.ProductMenuFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><FaIcons.FaBoxes /></span>
                                    <span class="menu-title">Product</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.MenuUploadFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><FaIcons.FaUpload /></span>
                                    <span class="menu-title">Upload</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.HelpMenuFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><BsIcons.BsFillExclamationDiamondFill /></span>
                                    <span class="menu-title">Technical Know-How</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.FAQMenuFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><FaIcons.FaQuestionCircle /></span>
                                    <span class="menu-title">FAQ</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.VisitCountMenuFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><ImIcons.ImEyePlus /></span>
                                    <span class="menu-title">Visit Count</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.AboutMeFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><FaIcons.FaUserAlt /></span>
                                    <span class="menu-title">AboutMe</span>
                                </a>
                            </li>
                            <li class="sidebar-menu" onClick={() => this.LogOutFunc()}>
                                <a href="#">
                                    <span class="menu-icon"><FaIcons.FaPowerOff /></span>
                                    <span class="menu-title">Logout</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="main_content" id="contentRender">

                    </div>
                </div>
            </div>
        );
    };

}
export default SideBar;
