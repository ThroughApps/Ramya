import React, { Component } from 'react';
import DropdownTreeSelect from 'react-dropdown-tree-select'
import 'react-dropdown-tree-select/dist/styles.css';
import _ from 'underscore';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import 'sweetalert2/src/sweetalert2.scss';
import CryptoJS from 'crypto-js';
import $ from 'jquery';

import "./AddMenucss.css";
import { CapitalCaseFunc, GetLocalStorageData, List_To_Tree_With_KeyNameChange_With_RootMenu, TimeZoneDateTime } from '../../../Common Components/CommonComponents';
import { TreeDropdownContainer } from '../../../Assets Components/DropdownComponents/DropdownComponent';
import { FormErrors } from '../../../Validation Components/FormErrors';
import { ErrorClass } from '../../../Validation Components/Loginvalidation';
import { CreateFolder, FolderExistCheck } from '../../../AWS/AWSFunctionality';


//CODE UPDATED AS PER DEPLOYMENT MADE ON 14/JUNE/2022

/*
UI WAY IMPLEMENTED BY NANDHINI.
THE FUNCTIONALITIES LIKE GETTING THE EXISTING MENU ITEMS, 
ADDING NEW MENU WERE IMPLEMENTED BY PRIYANKA - 19-04 2022
*/

var menuList = [];
var treeList;

class AddMenu extends Component {
    constructor() {
        super();
        this.state = {
            data: [],
            operation: 'refresh',
            newMenu: '',
            currentNodes: '',

            formErrors: {
                newMenu: '',
                currentNodes: '',
            },

            selectedNodesError: '',
            newMenuValid: false,
            folderPath: ""
        };

    }

    componentDidMount() {


        /*
        GETTING DATE & TIME FOR THE CURRENT LOGIN
        - IMPLEMENTED BY PRIYANKA - 20-04-2022
        */
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        //   console.log("dateTimeData :", dateTimeData);

        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.setState({
            date: this.state.date,
            time: this.state.time,
        })

        /*
        GETTING EXISTING MENU ADDED INTO THE SYSTEM
        IMPLEMENTED BY PRIYANKA - 19-04-2022
        */
        this.GetExistingMenu();

    }


    /* THIS FUCNTION USED FOR VALIDATION FOR NEWMENU IMPLEMENTED BY NANDHINI - 02-05-2022*/
    validateField(fieldName, value) {
        let fieldValidationErrors = this.state.formErrors;
        let newMenuValid = this.state.newMenuValid;



        //   console.log("value", value, "fieldName", fieldName);
        switch (fieldName) {
            // case 'newMenu':
            //     newMenuValid = value.length > 2;
            //     fieldValidationErrors.newMenu = newMenuValid ? '' : ' Should Contain Atleast 3 Characters';
            //     break;
            case 'menuName':
                if (value.length == 0) {
                    fieldValidationErrors.newMenu = '';
                    newMenuValid = false;
                }
                else {
                    newMenuValid = value.length > 2;
                    fieldValidationErrors.newMenu = newMenuValid ? '' : 'is InCorrect';
                }
                break;

        }

        this.setState({
            newMenuValid: newMenuValid,
        }, this.validateForm);
    }
    validateForm() {
        this.setState({
            formValid:
                this.state.newMenuValid
                && this.state.selectedNodesValid

        });
        //  console.log("this.state.newMenuValid", this.state.newMenuValid)
        //  console.log("this.state.selectedNodesValid", this.state.selectedNodesValid)
    }

    errorClass(error) {
        return (error.length === 0 ? '' : 'has-error');
    }

    /*
    FUNCTION USED FOR GETTING AN EXISTING MENU ITEMS ADDED INTO THE SYSTEM
    IMPLEMENTED BY PRIYANKA - 19-04-2022
    */
    GetExistingMenu() {

        var self = this;
        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("CompanyId"),
            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/Configuration/SelectExistingMenu",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                //     console.log("GET EXISTING MENU DATA :", data);

                menuList = data.menuList;

                //CONVERTING THE FLAT ARRAY OF OBJECTS INTO TREE LIST (PARENT - CHILD RELATIONSHIP)
                treeList = "";
                treeList = List_To_Tree_With_KeyNameChange_With_RootMenu(menuList);

                //     console.log("treeList :", JSON.stringify(treeList));

                self.state.data = treeList;
                self.setState({
                    data: self.state.data
                })



            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });
    }

    /*
    FUCNTION USED FOR RECORDING ONCHANGE (ON SELECTING AN MENU)
    IMPLEMENTED BY PRIYANKA - 19-04-2022
    */

    onDropDownTreeChange = (currentNode, selectedNodes) => {

        //    console.log("currentNode :", currentNode);
        console.log("selectedNodes :", selectedNodes);


        this.state.operation = "noRefresh";
        this.setState({
            operation: this.state.operation,
        })

        if (selectedNodes[0].label == "New Root Menu") {
            this.state.parentId = "";
            this.state.moduleName = "";
        }

        //    console.log("parentId :", this.state.parentId);

        /*
        ADDED BY NANDHINI FOR FORM VALIDATION 10-05-2022
        */
        var tempselectedNodesValid = false;
        var folderPath = "";

        console.log(" **** menuList :", menuList);
        if (selectedNodes != null) {


            folderPath = selectedNodes[0].label;
            var parentId = selectedNodes[0].parent;

            if (parentId != null) {

                do {

                    console.log(" *** parentId :", parentId);

                    var currentFolder = _.where(menuList, { menuId: parentId });

                    console.log(" *** currentFolder :", currentFolder);

                    if (currentFolder.length > 0) {
                        folderPath = currentFolder[0].menuName + "/" + folderPath;
                        parentId = currentFolder[0].parentMenuId;
                    }else{
                        parentId=null
                    }
                    console.log(" *** folderPath:", folderPath);
                } while (parentId != null)

            }

            console.log(" *** folderPath:", folderPath);

            this.state.parentId = selectedNodes[0].id;
            this.state.moduleName = selectedNodes[0].module;
            this.state.folderPath = folderPath;

            tempselectedNodesValid = true;
            // console.log("tempselectedNodesValid", tempselectedNodesValid);
        } else {

            this.state.parentId = "";
            this.state.moduleName = "";
            this.state.folderPath = "";

            tempselectedNodesValid = false;
            // console.log("tempselectedNodesValid", tempselectedNodesValid);
        }
        this.state.selectedNodesValid = tempselectedNodesValid;
        this.setState({
            selectedNodesValid: tempselectedNodesValid,
            parentId: this.state.parentId,
            moduleName: this.state.moduleName,
            folderPath: this.state.folderPath,
        }, this.validateForm)
        //   console.log("menuId :", this.state.menuId);

    };

    /*
       FUCNTION USED FOR SETTING NEW MENU NAME 
       IMPLEMENTED BY PRIYANKA - 19-04-2022
       */
    handleUserInputNewMenu = (e) => {

        //   console.log("handleUserInputNewMenu :", e.target.name, ": ", e.target.value);

        const name = e.target.name;
        const value = e.target.value;

        var camelcaseData = CapitalCaseFunc(value);
        this.state[name] = camelcaseData;
        this.setState({
            [name]: camelcaseData
        }, () => { this.validateField(name, camelcaseData) });


    }

    /*
    FUNCTION USED FOR SUBMITTING NEW MENU
    IMPLEMENTED BY PRIYANKA - 19-04-2022
    */
    Submit() {

        var self = this;

        var moduleName = this.state.moduleName;
        if (this.state.parentId == "") {
            moduleName = this.state.menuName;
        };

        console.log("SUBMIT DTA :", JSON.stringify({
            companyId: '1',
            parentMenuId: this.state.parentId,
            menuName: this.state.menuName,
            module: moduleName,
            date: this.state.date,
            time: this.state.time,
        }));


        this.state.data = [];
        this.setState({
            data: this.state.data,
        })

        //    FolderExistCheck("Image Gallery",self.state.menuName);

        //  CreateFolder("Image Gallery",self.state.menuName);

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                companyId: GetLocalStorageData("CompanyId"),
                parentMenuId: this.state.parentId,
                menuName: this.state.menuName,
                module: moduleName,
                date: this.state.date,
                time: this.state.time,
            }),

            url: "http://15.206.129.105:8080/IceilLiveAPI/Configuration/AddNewMenu",

            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                //   console.log("ADDING NEW MENU DATA :", data);


                if (data.response == "Success") {
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        text: 'Added the menu ' + self.state.menuName + ' successfully',
                        showConfirmButton: false,
                        timer: 2000
                    })

                    menuList = data.menuList;

                    //CONVERTING THE FLAT ARRAY OF OBJECTS INTO TREE LIST (PARENT - CHILD RELATIONSHIP)
                    treeList = "";
                    treeList = List_To_Tree_With_KeyNameChange_With_RootMenu(menuList);

                    //   console.log("treeList :", JSON.stringify(treeList));

                    self.state.data = [];
                    //    console.log("DATAE EMPTY SET :", self.state.data);

                    self.state.data = treeList;

                    //    console.log("DATAE NOT EMPTY SET :", self.state.data);
                    self.setState({
                        data: self.state.data,
                    })

                    CreateFolder(self.state.folderPath, self.state.menuName);

                    if(self.state.folderPath.split("/")[0]=="Video Gallery"){
                        CreateFolder(self.state.folderPath+"/"+self.state.menuName,"ThumbNail");
                    }

                    self.ClearFunc();

                } else if (data.response == "Already Exist") {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'The menu ' + self.state.menuName + ' already exist',
                        showConfirmButton: false,
                        timer: 2000
                    })

                } else {
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        text: 'Failed to add the menu ' + self.state.menuName + ' kindly try after some time',
                        showConfirmButton: false,
                        timer: 2000
                    })
                }

            },
            error: function (data) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Network Connection Problem',
                    showConfirmButton: false,
                    timer: 2000
                })


            },
        });


        this.state.data = treeList;
        this.state.operation = "refresh";
        this.setState({
            data: this.state.data,
            operation: this.state.operation
        })


    }



    /*
    FUNCTION FOR CANCELLING THE OPERATION OF ADDING AN NEW MENU
    IMPLEMENTED BY PRIYANKA - 19-04-2022
    */
    Cancel() {

        this.ClearFunc();

        this.state.data = [];
        this.setState({
            data: this.state.data
        })

        this.state.data = treeList;
        this.state.operation = "refresh";

        this.setState({
            data: this.state.data,
            operation: this.state.operation,
        })


    }

    /*
    FUNCTION USED FOR RESETTING THE FIELDS AS LIKE HOW IT'S LOADED FOR THE FIRST TIME
    IMPLEMENTED BY PRIYANKA - 19-04-2022
    */
    ClearFunc() {

        this.state.parentId = "";
        this.state.menuName = "";
        this.state.formValid = false;
        this.state.operation = "noRefresh";
        this.state.menuNameValid = false;
        this.state.selectedNodesValid = false;
        this.state.newMenuValid = false;
        this.state.folderPath = "",

            this.setState({
                parentId: this.state.parentId,
                menuName: this.state.menuName,
                formValid: this.state.formValid,
                operation: this.state.operation,
                menuNameValid: false,
                selectedNodesValid: false,
                newMenuValid: false,
                folderPath: this.state.folderPath,
            }, this.validateForm)


    }

    render() {
        return (
            <div class="">
                <div class="toptitle">
                    <h4>Add Menu</h4>
                </div>
                 {/* <hr/>  */}
                <div class="container-fluid">
                    <div class="container-wrapper">
                        {/* DROPDOWN SELECT FOR MENU - IT'S MANDATORY FIELD     */}

                        <div class="form-group">
                            <div class="row ">
                                <div class="col-md-6 control_label_text">
                                    <label for="currentNodes"> Existing Menu<span style={{ color: 'red' }}>*</span></label>


                                    <div class="add_input">
                                        {/* <DropdownTreeSelect data={this.state.featuresData} onChange={this.onDroDownTreeChange}
                                    onAction={this.onAction} onNodeToggle={this.onNodeToggle} value={this.state.selectedNodes} /> */}

                                        {/* FIELD USED TO GET DROPDOWN TREE - IT'S MANDATORY FIELD     */}
                                        {/* <DropdownTreeSelect
                                            data={this.state.data}
                                            onChange={this.onDroDownTreeChange}
                                          //  value={this.state.selectedMenu}
                                          //  keepOpenOnSelect={true}
                                            mode="radioSelect"
                                            showPartiallySelected={true}
                                         //   className="dropdownMenu" 
                                         />
                                         */}

                                        <TreeDropdownContainer data={this.state.data} operation={this.state.operation} onChange={this.onDropDownTreeChange} />

                                        <FormErrors formErrors={this.state.selectedNodesError} />
                                    </div>
                                </div>

                                <br />
                                {/*INPUT FIELD USED TO GET NEWMENU - IT'S MANDATORY FIELD     */}

                                <div class="col-md-6  control_label_text">
                                    <label class="control-label" for="newMenu"> New Menu<span style={{ color: 'red' }}>*</span></label>

                                    <div class="add_input" >
                                        {/* FIELD USED TO GET NEWMENU - IT'S MANDATORY FIELD     */}
                                        <input type="text" class="form-control textcolor_form " id="menuName" name="menuName" value={this.state.menuName} onChange={this.handleUserInputNewMenu} placeholder="Enter New Menu" />
                                        <ErrorClass errorContent={this.state.formErrors.newMenu} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br />
                        <div class="text-center">
                            {/* <button class="btn btn-primary btn_form" style={{ marginRight: '5px' }} onClick={() => this.Submit()} >Submit</button>
                            <button class="btn btn-primary btn_form" onClick={() => this.Cancel()} >Cancel</button>
                            */}
                            <button class="btn btn-primary btn-submit btn-cancel" disabled={!this.state.formValid} style={{ marginRight: '5px' }} onClick={() => this.Submit()} >Submit</button>
                            <button class="btn btn-primary btn-cancel" onClick={() => this.Cancel()} >Cancel</button>
                        </div>

                    </div>
                </div>

            </div>



        );
    }

}
export default AddMenu;
