//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import '../Styling Components/TopMenuCSS.css';
import '../Styling Components/styleCSS.css'
import { ButtonWithIconComponent, UploadButtonComponent } from '../Assets Components/Button Components/ButtonComponents';
import { FileInputTextField, InputTextField } from '../Assets Components/Input Components/InputComponents';
import '../Styling Components/AddBulletInCSS.css';
import { FileUploadOutlined, InsertDriveFile, PictureAsPdf, FileDownloadOutlined, ThirtyFpsSelect } from "@mui/icons-material";
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';
import FolderIcon from '@mui/icons-material/Folder';
import DeleteIcon from '@mui/icons-material/Delete';
import _ from 'underscore';
import { SpinnerCircular } from 'spinners-react';
import FilePreview from "react-file-preview-latest";
import $ from 'jquery';
// import PdfThumbnail from 'react-pdf-thumbnail';
// import { PDFToImage } from 'react-pdf-to-image-light'

// import GlobalSearch from '../Global Search/GlobalSearch';
//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';
import { TextAreaField } from '../Assets Components/Input Components/InputComponents';
import { CapitalCaseFunc, TextLengthFunc } from '../Validation Components/Validation';
import { Button } from '@mui/material';
import { InstantResponseMessage } from '../Assets Components/Alert Components/Alerts';
import DefaultAttachmentImage from '../Images/DefaultAttachmentImage.jpg';

const DeleteIcon_Style = {
    color: "red !important",
}

export class AttachLink extends Component {
    constructor() {
        super();
        this.state = {
            loaded: true,
            value: "",
            //  attachLink: "https://www.-just-style.com/news/crystal-inter-nation-al-seeks-collaboration-to-create-lo"
            defaultArticleImg: "https://d3h6ssrmm09ie.cloudfront.net/" + "article/DefaultArticleImage.jpg",
            attachLink: '',
            fileCount: 0,
            fileArray: [],

            messageTitle: "",
            message: "",
            messageSeverity: "",

            title: "",
            desscription: "",

            titleErrorStatus: false,
            descriptionErrorStatus: false,

            titleErrorMessage: "",
            descriptionErrorMessage: "",

            instantResponseMessageStatus: false,
        }
        this.handleUserInputAttachLink = this.handleUserInputAttachLink.bind(this);
        this.FileHandleCHange = this.FileHandleCHange.bind(this);
        this.DeleteFile = this.DeleteFile.bind(this);

    }
    onImageLoaded = () => {
        var self = this;
        self.state.loaded = false;
        self.setState({ loaded: self.state.loaded });
    };

    handleUserInputAttachLink = (e) => {
        this.onImageLoaded();
        const name = e.target.name;
        const value = e.target.value;

        var self = this;
        this.state.attachLink = value;
        this.setState({
            attachLink: this.state.attachLink,
        })


        this.DisableErrorMessage('titleErrorStatus', false, '', 'titleErrorMessage');
        this.DisableErrorMessage('descriptionErrorStatus', false, '', 'descriptionErrorMessage');


        if (this.state.attachLink != "") {

            $.ajax({
                url: "https://api.linkpreview.net",
                dataType: 'jsonp',
                data: { q: this.state.attachLink, key: 'e98682340f1460fded5517eb9f8cf4f0' },
                success: function (response, textStatus, jqXHR) {
                    console.log("response :", response);
                    console.log("textStatus :", textStatus);

                    if (response.url != "") {
                        //   self.state.articleDomain = response.domain;
                        self.state.articleTitle = response.title;
                        self.state.title = response.title;
                        self.state.articleDescription = response.description;
                        self.state.description = response.description;
                        self.state.articleImg = response.image;

                        self.state.titleDisableStatus = true;
                        self.state.descriptionDisableStatus = true;


                        self.setState({
                            articleTitle: self.state.articleTitle,
                            title: self.state.title,
                            articleDescription: self.state.articleDescription,
                            description: self.state.description,
                            articleImg: self.state.articleImg,

                            titleDisableStatus: self.state.titleDisableStatus,
                            descriptionDisableStatus: self.state.descriptionDisableStatus,
                        })

                        self.props.attachLinkFunc(self.state.attachLink, self.state.articleTitle, self.state.articleDescription, self.state.articleImg);


                    } else if (response.error != undefined || response.title == "" || response.description == "" || response.image == "") {


                        self.state.messageStatus = true;
                        self.state.messageSeverity = "error";
                        self.state.messageTitle = "Error";
                        self.state.message = "Hi, unable to fetch preview for the link shared. Default image will be used";
                        self.state.instantResponseMessageStatus = true;



                        self.setState({
                            userId: self.state.userId,
                            messageSeverity: self.state.messageSeverity,
                            messageTitle: self.state.messageTitle,
                            message: self.state.message,
                            instantResponseMessageStatus: self.state.instantResponseMessageStatus,
                        })
                        self.state.articleTitle = "";
                        self.state.title = "";
                        self.state.articleDescription = "";
                        self.state.description = "";
                        self.state.articleImg = self.state.defaultArticleImg;

                        self.state.titleDisableStatus = false;
                        self.state.descriptionDisableStatus = false;

                        self.setState({
                            articleTitle: self.state.articleTitle,
                            title: self.state.title,
                            articleDescription: self.state.articleDescription,
                            description: self.state.description,
                            articleImg: self.state.articleImg,

                            titleDisableStatus: self.state.titleDisableStatus,
                            descriptionDisableStatus: self.state.descriptionDisableStatus,
                        })
                        self.props.attachLinkFunc(self.state.attachLink, self.state.articleTitle, self.state.articleDescription, self.state.articleImg);
                        HideFieldErroeMsgs('instantResponseMessageStatus', self);
                    }


                }, error: function (data, textStatus, jqXHR) {

                    self.state.messageStatus = true;
                    self.state.messageSeverity = "error";
                    self.state.messageTitle = "Error";
                    self.state.message = "Hi, unable to fetch preview for the link shared. Default image will be used";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        userId: self.state.userId,
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,
                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                    self.state.articleTitle = "";
                    self.state.title = "";
                    self.state.articleDescription = "";
                    self.state.description = "";
                    self.state.articleImg = self.state.defaultArticleImg;

                    self.state.titleDisableStatus = false;
                    self.state.descriptionDisableStatus = false;

                    self.setState({
                        articleTitle: self.state.articleTitle,
                        title: self.state.title,
                        articleDescription: self.state.articleDescription,
                        description: self.state.description,
                        articleImg: self.state.articleImg,

                        titleDisableStatus: self.state.titleDisableStatus,
                        descriptionDisableStatus: self.state.descriptionDisableStatus,
                    })

                    self.props.attachLinkFunc(self.state.attachLink, self.state.articleTitle, self.state.articleDescription, self.state.articleImg);
                    HideFieldErroeMsgs('instantResponseMessageStatus', self);

                }
            });
            // this.props.attachLinkFunc(this.state.attachLink);
        } else {
            self.state.articleTitle = "";
            self.state.title = "";
            self.state.articleDescription = "";
            self.state.description = "";
            self.state.articleImg = "";

            self.state.titleDisableStatus = true;
            self.state.descriptionDisableStatus = true;

            self.setState({
                articleTitle: self.state.articleTitle,
                title: self.state.title,
                articleDescription: self.state.articleDescription,
                description: self.state.description,
                articleImg: self.state.articleImg,

                titleDisableStatus: self.state.titleDisableStatus,
                descriptionDisableStatus: self.state.descriptionDisableStatus,
            })

            self.props.attachLinkFunc(self.state.attachLink, self.state.articleTitle, self.state.articleDescription, self.state.articleImg);

        }
    }

    FileHandleCHange(event) {

        var self = this;

        if (this.state.fileCount < 2) {
            var fileInput = false;

            if (event.target.files[0]) {
                fileInput = true;
            }


            var files = event.target.files[0];


            console.log("files :", files);

            if (fileInput) {

                for (var i = 0; i < event.target.files.length; i++) {

                    this.state.fileCount = Number(this.state.fileCount) + Number(1);
                    this.setState({
                        fileCount: this.state.fileCount
                    })

                    var fileData;
                    var file = event.target.files[i];
                    var reader = new FileReader();
                    reader.readAsDataURL(file);

                    reader.onloadend = function () {
                        //  console.log('RESULT', reader.result)
                        fileData = {
                            originalName: file.name,
                            name: file.name,
                            data: file,
                            src: reader.result,
                            size: file.size,
                            fileType: file.type
                        },

                            self.state.fileArray.push(fileData);
                        self.setState({
                            fileArray: self.state.fileArray
                        })
                    }

                    this.props.FileHandleCHange(this.state.fileArray, this.state.fileCount);

                }

            }
        } else {
            this.state.messageSeverity = "warning";
            this.state.messageTitle = "Warning";
            this.state.message = "Hi, you can add only 2 secondary file per article";
            this.state.instantResponseMessageStatus = true;

            this.setState({
                messageSeverity: this.state.messageSeverity,
                messageTitle: this.state.messageTitle,
                message: this.state.message,

                instantResponseMessageStatus: this.state.instantResponseMessageStatus
            })

        }


        HideFieldErroeMsgs('instantResponseMessageStatus', this);

    }

    DeleteFile(fileName) {

        this.state.fileArray.splice(this.state.fileArray.findIndex(fileData => fileData.name === fileName), 1);
        this.state.fileCount = this.state.fileArray.length;

        this.setState({
            fileArray: this.state.fileArray,
            fileCount: this.state.fileCount
        })

        this.props.FileHandleCHange(this.state.fileArray, this.state.fileCount);

    }

    handleUserInputTitle = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        var camelcaseData = CapitalCaseFunc(value);
        var lengthValidation = TextLengthFunc(camelcaseData, 75);

        if (lengthValidation == true) {
            this.state.title = camelcaseData;
            this.setState({
                title: this.state.title
            })
            if (this.state.title != "") {
                this.props.titleFunc(this.state.title);
            }
            this.DisableErrorMessage('titleErrorStatus', false, '', 'titleErrorMessage');
        } else {
            this.EnableErrorMessage('titleErrorStatus', true, 'Title length Exceeds', 'titleErrorMessage');
        }


    }

    handleUserInputDescription = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        var camelcaseData = CapitalCaseFunc(value);
        var lengthValidation = TextLengthFunc(camelcaseData, 75);

        if (lengthValidation == true) {
            this.state.description = camelcaseData;
            this.setState({
                description: this.state.description
            })
            if (this.state.description != "") {
                this.props.descriptionFunc(this.state.description);
            }

            this.DisableErrorMessage('descriptionErrorStatus', false, '', 'descriptionErrorMessage');
        } else {
            this.EnableErrorMessage('descriptionErrorStatus', true, 'Description length Exceeds', 'descriptionErrorMessage');
        }


    }


    /*
   FUNCTION USED TO DISABLE ERROR MESSAGE - 101/16/09/2022
   */
    DisableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    /*
    FUNCTION USED TO ENABLE ERROR MESSAGE - 101/16/09/2022
    */
    EnableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    render() {
        return (
            <div className='flex_AttachMenus'>
                <div className="AttachMenu1">
                    {/* FIELD USED TO GET ATTACH LINK - IT'S MANDATORY FIELD  */}
                    <TextAreaField label="ATTACH LINK" onChange={this.handleUserInputAttachLink} value={this.state.attachLink} />
                    {/* FIELD USED TO UPLOAD DATA - IT'S MANDATORY FIELD  */}
                    {/* <InsertDriveFile /><ButtonWithIconComponent endIcon={<FileUploadOutlined />} buttonName="Add Secondary Files" >
                     
                    </ButtonWithIconComponent>
                    */}
                    {this.state.fileArray.map(file => (
                        <div className='Addedfilename'>
                            <h5><FolderIcon /> {file.name}  <DeleteIcon sx={DeleteIcon_Style} onClick={() => this.DeleteFile(file.name)} /></h5>
                        </div>
                    ))}
                    <UploadButtonComponent iconStart={""} iconEnd={<FileUploadOutlined />} buttonName={"ADD SECONDARY FILES"} onChange={this.FileHandleCHange} />
                </div>
                <div className='previewimage'>
                    {/* FIELD USED TO PREVIEW THE IMAGE  */}
                    <h5>PREVIEW</h5>

                    <InputTextField errorStatus={this.state.titleErrorStatus} disableStatus={this.state.titleDisableStatus} errorMessage={this.state.titleErrorMessage} onChange={this.handleUserInputTitle} value={this.state.title} label='Title' name='title' iconStart={""} />
                    <InputTextField errorStatus={this.state.descriptionErrorStatus} disableStatus={this.state.descriptionDisableStatus} errorMessage={this.state.descriptionErrorMessage} onChange={this.handleUserInputDescription} value={this.state.description} label='Description' name='description' iconStart={""} />
                    <div>
                    <CardMedia
                        component="img"
                        // onLoad={this.onImageLoaded}
                        //height="300"
                        image={this.state.articleImg} /> 
                        {!this.state.loaded && (
                            <div className="">
                                <SpinnerCircular />
                            </div>
                        )}
                        </div>
                    {/* <img src={this.state.articleImg} /> */}
                </div>
                {this.state.instantResponseMessageStatus ? <InstantResponseMessage messageTitle={this.state.messageTitle} message={this.state.message}
                    severity={this.state.messageSeverity} /> : ``}

            </div>
        )
    }

}

export class AttachBrowse extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loaded: true,
            defaultAttachmentImage: "https://d3h6ssrmm09ie.cloudfront.net/" + "article/DefaultAttachmentImage.jpg",
            fileCount: 0,
            attachFileCount: 0,

            attachFileArray: [],
            fileArray: [],

            attachFileThumbnail: "",
            pdfThumbnail: '',

            messageTitle: "",
            message: "",
            messageSeverity: "",

            title: "",
            desscription: "",

            titleErrorStatus: false,
            descriptionErrorStatus: false,

            titleErrorMessage: "",
            descriptionErrorMessage: "",

            instantResponseMessageStatus: false,

        }

        this.handleUserInputTitle = this.handleUserInputTitle.bind(this);
        this.handleUserInputDescription = this.handleUserInputDescription.bind(this);
        this.AttachFileHandleCHange = this.AttachFileHandleCHange.bind(this);
        this.FileHandleCHange = this.FileHandleCHange.bind(this);
        this.DeleteFile = this.DeleteFile.bind(this);

    }


    componentDidMount() {
        console.log("BROWSE PROPS DATA :", this.props);

    }

    handleUserInputTitle = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        var camelcaseData = CapitalCaseFunc(value);
        var lengthValidation = TextLengthFunc(camelcaseData, 75);

        if (lengthValidation == true) {
            this.state.title = camelcaseData;
            this.setState({
                title: this.state.title
            })
            if (this.state.title != "") {
                this.props.titleFunc(this.state.title);
            }
            this.DisableErrorMessage('titleErrorStatus', false, '', 'titleErrorMessage');
        } else {
            this.EnableErrorMessage('titleErrorStatus', true, 'Title length Exceeds', 'titleErrorMessage');
        }


    }

    handleUserInputDescription = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        var camelcaseData = CapitalCaseFunc(value);
        var lengthValidation = TextLengthFunc(camelcaseData, 75);

        if (lengthValidation == true) {
            this.state.description = camelcaseData;
            this.setState({
                description: this.state.description
            })
            if (this.state.description != "") {
                this.props.descriptionFunc(this.state.description);
            }

            this.DisableErrorMessage('descriptionErrorStatus', false, '', 'descriptionErrorMessage');
        } else {
            this.EnableErrorMessage('descriptionErrorStatus', true, 'Description length Exceeds', 'descriptionErrorMessage');
        }


    }
    onImageLoaded = () => {
        var self = this;
        self.state.loaded = false;
        self.setState({ loaded: self.state.loaded });
    };

    /*
   FUNCTION USED TO DISABLE ERROR MESSAGE - 101/16/09/2022
   */
    DisableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    /*
  FUNCTION USED TO ENABLE ERROR MESSAGE - 101/16/09/2022
  */
    EnableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    AttachFileHandleCHange(event) {

        var self = this;
        this.onImageLoaded();
        if (this.state.attachFileCount < 1) {
            var fileInput = false;

            if (event.target.files[0]) {
                fileInput = true;
            }


            var files = event.target.files[0];
            this.state.file = files;
            this.setState({
                file: this.state.file
            })

            console.log("files :", files);

            // generateThumbnails(files, 100);
            //  this.createThumb(event);


            var uploadedFile = event.target.files[0];
            console.log("FILE IN DID");

            var fileData;

            if (uploadedFile.type == "application/pdf") {
                FileToBase64(uploadedFile).then(base64 => PDFToImage({
                    blob: base64, // source pdf base64 string. need to be starting with the prefix "data:application/pdf;base64," 
                    scale: 1,
                }).then(result => {
                    console.log("result :", result);
                    var attachFileThumbnail = dataURLtoFile(result[0], 'hello.png');

                    self.state.pdfThumbnail = result[0];
                    self.state.attachFileThumbnail = attachFileThumbnail;
                    self.setState({
                        pdfThumbnail: self.state.pdfThumbnail,
                        attachFileThumbnail: self.state.attachFileThumbnail,
                    })

                    var thumbNailData;
                    var file = self.state.attachFileThumbnail;
                    var reader = new FileReader();
                    reader.readAsDataURL(file);

                    reader.onloadend = function () {
                        //  console.log('RESULT', reader.result)
                        thumbNailData = {
                            originalName: file.name,
                            name: file.name,
                            data: file,
                            src: reader.result,
                            size: file.size,
                            fileType: file.type
                        },

                            self.state.attachFileArray.push(thumbNailData);

                        self.setState({
                            attachFileArray: self.state.attachFileArray,
                        })
                        self.props.AttachFileHandleCHange(self.state.attachFileArray, self.state.attachFileCount);

                    }

                    console.log("self.state.attachFileThumbnail  :", self.state.attachFileThumbnail);
                }).catch(console.error)
                );

            } else {
                alert("else");
                self.state.pdfThumbnail = self.state.defaultAttachmentImage;
                self.state.attachFileThumbnail = self.state.defaultAttachmentImage;
                self.setState({
                    pdfThumbnail: self.state.pdfThumbnail,
                    attachFileThumbnail: self.state.attachFileThumbnail,
                })

                self.props.AttachFileDefaultImageURL(self.state.attachFileThumbnail);

            }

            fileData = {
                originalName: files.name,
                name: files.name,
                data: files,
                size: files.size,
                fileType: files.type
            }
            self.state.attachFileArray.push(fileData);
            self.setState({
                attachFileArray: self.state.attachFileArray,
            })
            self.props.AttachFileHandleCHange(self.state.attachFileArray, self.state.attachFileCount);


        } else {
            this.state.messageSeverity = "warning";
            this.state.messageTitle = "Warning";
            this.state.message = "Hi, you can add only 2 secondary file per article";
            this.state.instantResponseMessageStatus = true;

            this.setState({
                messageSeverity: this.state.messageSeverity,
                messageTitle: this.state.messageTitle,
                message: this.state.message,

                instantResponseMessageStatus: this.state.instantResponseMessageStatus
            })

        }


        HideFieldErroeMsgs('instantResponseMessageStatus', this);

    }

    FileHandleCHange(event) {

        var self = this;

        if (this.state.fileCount < 2) {
            var fileInput = false;

            if (event.target.files[0]) {
                fileInput = true;
            }


            var files = event.target.files[0];


            console.log("files :", files);

            if (fileInput) {

                for (var i = 0; i < event.target.files.length; i++) {

                    this.state.fileCount = Number(this.state.fileCount) + Number(1);
                    this.setState({
                        fileCount: this.state.fileCount
                    })

                    var fileData;
                    var file = event.target.files[i];
                    var reader = new FileReader();
                    reader.readAsDataURL(file);

                    reader.onloadend = function () {
                        //  console.log('RESULT', reader.result)
                        fileData = {
                            originalName: file.name,
                            name: file.name,
                            data: file,
                            src: reader.result,
                            size: file.size,
                            fileType: file.type
                        },

                            self.state.fileArray.push(fileData);
                        self.setState({
                            fileArray: self.state.fileArray
                        })
                    }

                    this.props.FileHandleCHange(this.state.fileArray, this.state.fileCount);

                }

            }
        } else {
            this.state.messageSeverity = "warning";
            this.state.messageTitle = "Warning";
            this.state.message = "Hi, you can add only 2 secondary file per article";
            this.state.instantResponseMessageStatus = true;

            this.setState({
                messageSeverity: this.state.messageSeverity,
                messageTitle: this.state.messageTitle,
                message: this.state.message,

                instantResponseMessageStatus: this.state.instantResponseMessageStatus
            })

        }


        HideFieldErroeMsgs('instantResponseMessageStatus', this);

    }

    DeleteFile(fileName) {

        this.state.fileArray.splice(this.state.fileArray.findIndex(fileData => fileData.name === fileName), 1);
        this.state.fileCount = this.state.fileArray.length;

        this.setState({
            fileArray: this.state.fileArray,
            fileCount: this.state.fileCount
        })

        this.props.FileHandleCHange(this.state.fileArray, this.state.fileCount);

    }

    render() {
        return (
            <div className='flex_AttachMenus'>
                <div className="AttachMenu1">
                    {/* FIELD USED TO GET TITLE- IT'S MANDATORY FIELD  */}
                    <InputTextField errorStatus={this.state.titleErrorStatus} disableStatus={this.state.titleDisableStatus} errorMessage={this.state.titleErrorMessage} onChange={this.handleUserInputTitle} value={this.state.title} label='Title' name='title' iconStart={""} />
                    {/* FIELD USED TO GET DESCRIPTION- IT'S MANDATORY FIELD  */}
                    <InputTextField errorStatus={this.state.descriptionErrorStatus} disableStatus={this.state.descriptionDisableStatus} errorMessage={this.state.descriptionErrorMessage} onChange={this.handleUserInputDescription} value={this.state.description} label='Description' name='description' iconStart={""} />

                    {/* UPLOADED FILE NAMES SHOWN HERE*/}
                    {/* <PictureAsPdf />
                        <div><h5>REPORT SNEAK PEAK</h5> <span>Uploaded By Mr XXX On 12th MAY-12:55</span></div> 
                        <FileDownloadOutlined onClick={this.FileDownload} /> */}
                    {/* <InsertDriveFile /><ButtonWithIconComponent onClick={this.FileUpload} endIcon={<FileUploadOutlined />} buttonName="Add Secondary Files" /> */}
                    {this.state.fileArray.map(file => (
                        <div className='Addedfilename'>
                            <h5><FolderIcon /> {file.name} <DeleteIcon sx={DeleteIcon_Style} onClick={() => this.DeleteFile(file.name)} /></h5>
                        </div>
                    ))}
                    <UploadButtonComponent iconStart={""} iconEnd={<FileUploadOutlined />} buttonName={"ADD SECONDARY FILES"} onChange={this.FileHandleCHange} />
                </div>

                <div className='previewimage'>
                    {/* FIELD USED TO UPLOAD DATA - IT'S MANDATORY FIELD  */}
                    <UploadButtonComponent id="inputfiles" iconStart={""} iconEnd={<FileUploadOutlined />} buttonName={"UPLOAD"} onChange={this.AttachFileHandleCHange} />
                    {/* FIELD USED TO PREVIEW THE IMAGE  */}
                    {/* <h5>PREVIEW</h5> */}
                    <div>
                    <CardMedia
                        component="img"
                        // onLoad={this.onImageLoaded}
                        // height="300"
                        image={this.state.pdfThumbnail}/>
                        {!this.state.loaded && (
                            <div className="">
                                <SpinnerCircular />
                            </div>
                        )}
                        </div>
                    {/* <img src={this.state.pdfThumbnail} alt='img' /> */}
                </div>
                {this.state.instantResponseMessageStatus ? <InstantResponseMessage messageTitle={this.state.messageTitle} message={this.state.message}
                    severity={this.state.messageSeverity} /> : ``}

            </div>
        )
    }

}


/*
USED FOR RESETTING THE INSTANT RESPONSE TO INITIAL STATE AFTER FEW SECONDS - 101/21/09/2022
*/
function HideFieldErroeMsgs(stateName, currentState) {
    setTimeout(function () {
        var self = currentState;
        self.state[stateName] = false;
        self.setState({
            [stateName]: self.state[stateName]
        })
    }, 4000);
}

const FileToBase64 = (file) => {
    var reader = new FileReader();
    reader.readAsDataURL(file);

    return new Promise(resolve => {
        reader.onloadend = () => {
            resolve(reader.result);
        };
    });

}

function dataURLtoFile(dataurl, filename) {

    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);

    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }

    return new File([u8arr], filename, { type: mime });
}

const toDataURL = url => fetch(url)
    .then(response => response.blob())
    .then(blob => new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(reader.result)
        reader.onerror = reject
        reader.readAsDataURL(blob)
    }))
