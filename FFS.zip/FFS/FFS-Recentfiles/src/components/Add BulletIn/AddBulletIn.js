//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import '../Styling Components/TopMenuCSS.css';
import '../Styling Components/styleCSS.css'
import { CancelButtonComponent, SaveButtonComponent } from '../Assets Components/Button Components/ButtonComponents';
import { AttachLink, AttachBrowse } from '../Add BulletIn/AddBulletInComponents';
import TextareaAutosize from '@mui/base/TextareaAutosize';
import $ from 'jquery';

import LinkPreview from '@ashwamegh/react-link-preview';
import '@ashwamegh/react-link-preview/dist/index.css';


//IMPORT IMAGE
import { MenuItem } from '@mui/material';
import { ArticleDropdownComponent, AttachDropdownComponent, DropdownComponent, SourceDropdownComponent } from '../Assets Components/Dropdown Components/DropdownComponent';
import { TimeZoneDateTime } from '../Common Components/CommonFunctionalComponents';
import { CapitalCaseFunc, TextLengthFunc } from '../Validation Components/Validation';
import { InstantResponseMessage } from '../Assets Components/Alert Components/Alerts';
import { UploadToAWS } from '../AWS/AWSFunctionality';
import axios from 'axios';


class AddBulletIn extends Component {
    constructor() {
        super();
        this.state = {

            articleTypeMenuItems: [],
            sourceMenuItems: [],
            attachTypeMenuItems: [],
            fileArray: [],
            fileCount: 0,

            attachFileArray: [],
            attachFileCount: 0,

            articleType: '',
            source: '',
            attachType: '',
            comments: '',

            link: '',
            title: '',
            description: '',

            articleTypeValid: false,
            sourceValid: false,
            attachTypeValid: false,
            commentsValid: false,

            linkValid: false,
            titleValid: false,
            descriptionValid: false,

            linkPreviewValid: false,
            articleTitleValid: false,
            articleDescriptionValid: false,

            articleTypeErrorMessage: '',
            sourceErrorMessage: '',
            attachTypeErrorMessage: '',
            commentsErrorMessage: '',

            articleTypeErrorStatus: false,
            sourceErrorStatus: false,
            attachTypeErrorStatus: false,
            commentsErrorStatus: false,

            submitButtonStatus: true,
            cancelButtonStatus: false,

            messageTitle: "",
            message: "",
            messageSeverity: "",

            instantResponseMessageStatus: false,

            articleDomain: "",
            articleTitle: "",
            articleDescription: "",
            articleImg: "",

        }

        this.EnableErrorMessage = this.EnableErrorMessage.bind(this);
        this.DisableErrorMessage = this.DisableErrorMessage.bind(this);
        this.EnableSubmitButton = this.EnableSubmitButton.bind(this);
        this.ClearFunc = this.ClearFunc.bind(this);
        this.handleUserInputAttachLink = this.handleUserInputAttachLink.bind(this);
        this.handleUserInputDescription = this.handleUserInputDescription.bind(this);
        this.handleUserInputTitle = this.handleUserInputTitle.bind(this);
        this.AddBulletInData = this.AddBulletInData.bind(this);
      //  this.CustomComponent = this.CustomComponent.bind(this);
        this.FileHandleCHange = this.FileHandleCHange.bind(this);
        this.upload_Data_To_AWS_S3 = this.upload_Data_To_AWS_S3.bind(this);
        this.handleUserInputLinkTitle = this.handleUserInputLinkTitle.bind(this);
        this.handleUserInputLinkDescription = this.handleUserInputLinkDescription.bind(this);
        this.AttachFileHandleCHange = this.AttachFileHandleCHange.bind(this);
        this.AttachFileDefaultImageURL = this.AttachFileDefaultImageURL.bind(this);
    }

    componentDidMount() {

        /*
     GETTING DATE & TIME FOR THE CURRENT LOGIN - 101/16/09/2022
     */
        var timeZone = 'Asia/Kolkata';
        var dateTimeData = TimeZoneDateTime(timeZone);
        // console.log("dateTimeData :", dateTimeData);

        this.state.date = dateTimeData.date;
        this.state.time = dateTimeData.time;
        this.setState({
            date: this.state.date,
            time: this.state.time,
        })

    }



    handleUserSelectArticleType = (event) => {

        this.state.articleType = event.target.value;
        this.setState({
            articleType: this.state.articleType
        })

        this.EnableSubmitButton("articleTypeValid", true);

    };

    handleUserSelectSource = (event) => {

        this.state.source = event.target.value;
        this.setState({
            source: this.state.source
        })

        this.EnableSubmitButton("sourceValid", true);

    };

    handleUserSelectAttachType = (event) => {

        this.state.attachType = event.target.value;
        this.setState({
            attachType: this.state.attachType
        })

        this.EnableSubmitButton("attachTypeValid", true);
    }

    handleUserInputAttachLink(attachLink, title, description, imgUrl) {

        var self = this;

        this.state.link = attachLink;
        this.setState({
            link: this.state.link
        })


        var linkValidStatus = true;
        var titleValidStatus = true;
        var descriptionValidStatus = true;

        if (attachLink == "") {
            linkValidStatus = false;
        }

        if (title == "") {
            titleValidStatus = false;
        }

        if (description == "") {
            descriptionValidStatus = false;
        }

        //  alert("validStatus :" + validStatus);
        this.state.articleTitle = title;
        this.state.articleDescription = description;
        this.state.articleImg = imgUrl;

        this.setState({
            articleTitle: this.state.articleTitle,
            articleDescription: this.state.articleDescription,
            articleImg: this.state.articleImg,
        })

        this.EnableSubmitButton("linkValid", linkValidStatus);
        this.EnableSubmitButton("linkPreviewValid", linkValidStatus);
        this.EnableSubmitButton("articleTitleValid", titleValidStatus);
        this.EnableSubmitButton("articleDescriptionValid", descriptionValidStatus);

    }


    handleUserInputComments = (event) => {
        console.log("COMMENTS EVENT :", event.target.value);

        const value = event.target.value;
        var camelcaseData = CapitalCaseFunc(value);
        var lengthValidation = TextLengthFunc(camelcaseData, 150);

        if (lengthValidation == true) {
            this.state.comments = camelcaseData;
            this.setState({
                comments: this.state.comments
            })
            this.DisableErrorMessage('commentsErrorStatus', false, '', 'commentsErrorMessage');
        } else {
            this.EnableErrorMessage('commentsErrorStatus', true, 'Comments length Exceeds', 'commentsErrorMessage');
        }


    }

    handleUserInputTitle(title) {
        console.log("title :", title);
        const value = title;

        this.state.title = value;
        this.setState({
            title: this.state.title
        })

        var validStatus = true;

        if (title == "") {
            validStatus = false;
        }

        this.EnableSubmitButton("titleValid", validStatus);


    }

    handleUserInputDescription(description) {

        const value = description;
        this.state.description = value;
        this.setState({
            description: this.state.description
        })

        var validStatus = true;

        if (description == "") {
            validStatus = false;
        }

        this.EnableSubmitButton("descriptionValid", validStatus);

    }

    handleUserInputLinkTitle(title) {
        console.log("title :", title);
        const value = title;

        this.state.articleTitle = value;
        this.setState({
            articleTitle: this.state.articleTitle
        })

        var validStatus = true;

        if (title == "") {
            validStatus = false;
        }


        this.EnableSubmitButton("articleTitleValid", validStatus);


    }

    handleUserInputLinkDescription(description) {

        const value = description;
        this.state.articleDescription = value;
        this.setState({
            articleDescription: this.state.articleDescription
        })

        var validStatus = true;

        if (description == "") {
            validStatus = false;
        }

        this.EnableSubmitButton("articleDescriptionValid", validStatus);

    }

    /*
  FUNCTION USED TO CLEAR THE FIELDS AFTER SUCCESSFUL SIGNUP - 101/10/09/2022
  */
    ClearFunc() {


        this.state.fileArray = [];
        this.state.fileCount = 0;

        this.state.attachFileArray = [];
        this.state.attachFileCount = 0;

        this.state.articleType = "";
        this.state.source = "";
        this.state.attachType = "";
        this.state.comments = "";

        this.state.link = "";
        this.state.title = "";
        this.state.description = "";

        this.state.articleTypeErrorStatus = false,
            this.state.sourceErrorStatus = false,
            this.state.attachTypeErrorStatus = false,
            this.state.commentsErrorStatus = false;

        this.state.articleTypeErrorMessage = "";
        this.state.sourceErrorMessage = "";
        this.state.attachTypeErrorMessage = "";
        this.state.commentsErrorMessage = "";

        this.state.submitButtonStatus = true;


        this.state.articleTypeValid = false;
        this.state.sourceValid = false;
        this.state.attachTypeValid = false;
        this.state.commentsValid = false;

        this.state.linkValid = false;
        this.state.titleValid = false;
        this.state.descriptionValid = false;

        this.state.linkPreviewValid = false;
        this.state.articleTitleValid = false;
        this.state.articleDescriptionValid = false;

        this.state.articleDomain = "";
        this.state.articleTitle = "";
        this.state.articleDescription = "";
        this.state.articleImg = "";

        this.setState({

            fileArray: this.state.fileArray,
            fileCount: this.state.fileCount,

            attachFileArray: this.state.attachFileArray,
            attachFileCount: this.state.attachFileCount,

            articleType: '',
            source: '',
            attachType: '',
            comments: this.state.comments,

            link: this.state.link,
            title: '',
            description: '',


            articleTypeErrorStatus: false,
            sourceErrorStatus: false,
            attachTypeErrorStatus: false,
            commentsErrorStatus: false,

            articleTypeErrorMessage: '',
            sourceErrorMessage: '',
            attachTypeErrorMessage: '',
            commentsErrorMessage: '',

            submitButtonStatus: this.state.submitButtonStatus,


            articleTypeValid: false,
            sourceValid: false,
            attachTypeValid: false,
            commentsValid: false,

            linkValid: false,
            titleValid: false,
            descriptionValid: false,

            linkPreviewValid: false,
            articleTitleValid: false,
            articleDescriptionValid: false,

            articleDomain: this.state.articleDomain,
            articleTitle: this.state.articleTitle,
            articleDescription: this.state.articleDescription,
            articleImg: this.state.articleImg,

        })
    }

    /*
 FUNCTION USED TO ENABLE SUBMIT BUTTON AFTER SUCCESSFUL FIELD ENTRY - 101/10/09/2022
 */
    EnableSubmitButton(fieldName, status) {


        this.state[fieldName] = status;
        this.setState({
            [fieldName]: this.state[fieldName]
        })

        if (this.state.attachType == "LINK") {

            if (this.state.articleTypeValid == true && this.state.sourceValid == true && this.state.attachTypeValid == true &&
                this.state.linkValid == true && this.state.linkPreviewValid == true && this.state.articleTitleValid == true && this.state.articleDescriptionValid == true) {

                this.state.submitButtonStatus = false;
                this.setState({
                    submitButtonStatus: this.state.submitButtonStatus
                })
            } else {
                this.state.submitButtonStatus = true;
                this.setState({
                    submitButtonStatus: this.state.submitButtonStatus
                })
            }
        } else if (this.state.attachType == "BROWSE") {

            if (this.state.articleTypeValid == true && this.state.sourceValid == true && this.state.attachTypeValid == true &&
                this.state.titleValid == true && this.state.descriptionValid == true && this.state.attachFileArray.length > 0) {
                this.state.submitButtonStatus = false;
                this.setState({
                    submitButtonStatus: this.state.submitButtonStatus
                })
            } else {
                this.state.submitButtonStatus = true;
                this.setState({
                    submitButtonStatus: this.state.submitButtonStatus
                })
            }
        }


    }

    RenderComponenets(articleTypeData) {

        var self = this;

        switch (articleTypeData) {
            case 'LINK':
                return <AttachLink attachLinkFunc={this.handleUserInputAttachLink} FileHandleCHange={this.FileHandleCHange} titleFunc={this.handleUserInputLinkTitle} descriptionFunc={this.handleUserInputLinkDescription} />
            case 'BROWSE':
                return <AttachBrowse AttachFileDefaultImageURL={this.AttachFileDefaultImageURL} FileHandleCHange={this.FileHandleCHange} AttachFileHandleCHange={this.AttachFileHandleCHange} titleFunc={this.handleUserInputTitle} descriptionFunc={this.handleUserInputDescription} />
            default:
                return;
        }

    }

    /*
    FUNCTION USED TO DISABLE ERROR MESSAGE - 101/16/09/2022
    */
    DisableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    /*
  FUNCTION USED TO ENABLE ERROR MESSAGE - 101/16/09/2022
  */
    EnableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    FileHandleCHange(fileArray, fileCount) {

        console.log("FileHandleCHange fileArray: ", fileArray);
        this.state.fileArray = fileArray;
        this.state.fileCount = fileCount;
        this.setState({
            fileArray: this.state.fileArray,
            fileCount: this.state.fileCount,
        })

        //  alert(" this.state.fileCount :" + this.state.fileCount);
    }

    AttachFileHandleCHange(attachFileArray, attachFileCount) {

        console.log("FileHandleCHange attachFileArray: ", attachFileArray);
        this.state.attachFileArray = attachFileArray;
        this.state.attachFileCount = attachFileCount;
        this.setState({
            attachFileArray: this.state.attachFileArray,
            attachFileCount: this.state.attachFileCount,
        })

        this.EnableSubmitButton("", "");
        //  alert(" this.state.attachFileCount :" + this.state.attachFileCount);
    }

    AttachFileDefaultImageURL(defaultAttachIamgeURL) {

        console.log(" *** AttachFileDefaultImageURL defaultAttachIamgeURL:", defaultAttachIamgeURL);

        this.state.articleImg = defaultAttachIamgeURL;
        this.setState({
            articleImg: this.state.articleImg
        })

    }

    AddBulletInData() {

        var self = this;



        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                userId: '1',
                articleType: this.state.articleType,
                source: this.state.source,
                attachType: this.state.attachType,
                comments: this.state.comments,

                link: this.state.link,
                title: this.state.title,
                description: this.state.description,
                date: this.state.date,
                time: this.state.time,

                articleDomain: this.state.articleDomain,
                articleTitle: this.state.articleTitle,
                articleDescription: this.state.articleDescription,

                url: this.state.articleImg,
                supportFiles: this.state.fileCount,
            }),

            url: "http://localhost:8080/FastFashionSolutionsAPI/AddBulletIn/AddBulletIn",
            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {

                console.log("DATA :", data);

                if (data.response == "Data_Added") {
                    self.state.messageSeverity = "success";
                    self.state.messageTitle = "Success";
                    self.state.message = "Hi, you have successfully added the article";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,

                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                    if (self.state.fileArray.length > 0 || self.state.attachFileArray.length > 0) {
                        self.upload_Data_To_AWS_S3(data.articleId);
                    }

                    self.ClearFunc();

                } else if (data.response == "Failed") {

                    self.state.messageSeverity = "warning";
                    self.state.messageTitle = "Warning";
                    self.state.message = "Adding article failed, try after sometime";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,

                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                }

                HideFieldErroeMsgs('instantResponseMessageStatus', self);

            },
            error: function (data) {

                self.state.messageSeverity = "error";
                self.state.messageTitle = "Network Error";
                self.state.message = "There is trouble in connecting you to server, kindly try after sometime";
                self.state.instantResponseMessageStatus = true;

                self.setState({
                    messageSeverity: self.state.messageSeverity,
                    messageTitle: self.state.messageTitle,
                    message: self.state.message,

                    instantResponseMessageStatus: self.state.instantResponseMessageStatus
                })

                HideFieldErroeMsgs('instantResponseMessageStatus', self);
            },

        });
    }



    upload_Data_To_AWS_S3(articleId) {

        // alert("articleId :" + articleId);
        console.log("FILE ARRAY BEFORE UPLOAD :", this.state.fileArray);

        var metaData = {};
        var totalFileArray = [...this.state.attachFileArray, ...this.state.fileArray];

        console.log("totalFileArray :", totalFileArray);

        for (var i = 0; i < totalFileArray.length; i++) {
            //  console.log("keyName :", keyName);
            // keyName = Number(keyName) + Number(1);
            var count = Number(i);
            var fileName = totalFileArray[i].name;

            totalFileArray[i].name = articleId.toString() + count.toString();

        }


        UploadToAWS("article", totalFileArray, metaData).then(function (response) {
            console.log(" ***** UploadToAWS ATTACH  FILE ARRAY :", response);
        });

        /*  if (this.state.attachFileArray.length > 0) {
  
              var totalFileArray = [...this.state.attachFileArray, ...this.state.fileArray];
  
              console.log("totalFileArray :", totalFileArray);
  
              for (var i = 0; i < totalFileArray.length; i++) {
                  //  console.log("keyName :", keyName);
                  // keyName = Number(keyName) + Number(1);
                  var count = Number(i);
                  var fileName = totalFileArray[i].name;
  
                  totalFileArray[i].name = articleId.toString() + count.toString();
  
              }
  
  
              UploadToAWS("article", totalFileArray, metaData).then(function (response) {
                  console.log(" ***** UploadToAWS ATTACH  FILE ARRAY :", response);
              });
          }
  */

        /*  if (this.state.fileArray.length > 0) {
              for (var i = 0; i < this.state.fileArray.length; i++) {
                  //  console.log("keyName :", keyName);
                  // keyName = Number(keyName) + Number(1);
                  var count = Number(i) + Number(1);
                  var fileName = this.state.fileArray[i].name;
  
                  this.state.fileArray[i].name = articleId.toString() + count.toString();
                  this.setState({
                      fileArray: this.state.fileArray
                  })
              }
  
              UploadToAWS("article", this.state.fileArray, metaData).then(function (response) {
                  console.log(" ***** UploadToAWS FILE ARRAY :", response);
              });
          }
          */

    }

    render() {
        return (
            <div className='container-fluid'>
                <div className='title'>
                    <h5>Add Bulletins</h5>
                </div>
                <div className='br-bot'>
                    <div className='row'>
                        <div className="col-md-2">
                            {/* FIELD USED TO GET ARTICLE TYPE - IT'S MANDATORY FIELD  */}
                            <div className="col-md-12">
                                <ArticleDropdownComponent onChange={this.handleUserSelectArticleType} value={this.state.articleType} errorStatus={this.state.articleTypeErrorStatus} errorMessage={this.state.articleTypeErrorMessage} label='ArticleType' name='articleTYpe' disableStatus={false} />

                            </div>
                            {/* FIELD USED TO GET ATTRIBUTE - IT'S MANDATORY FIELD  */}
                            <div className="col-md-12">
                                <DropdownComponent onChange={this.handleUserSelectAttribute1} value={this.state.arrtibute1} errorStatus={this.state.arrtibute1ErrorStatus} errorMessage={this.state.arrtibute1ErrorMessage} label='Attribute1' name='arrtibute1' menuItems={this.state.arrtibute1MenuItems} disableStatus={true} />

                            </div>
                        </div>
                        <div className="col-md-2">
                        <div className="col-md-12">
                                <AttachDropdownComponent onChange={this.handleUserSelectAttachType} value={this.state.attachType} errorStatus={this.state.attachTypeErrorStatus} errorMessage={this.state.attachTypeErrorMessage} label='Attach' name='attachType' disableStatus={false} />

                            </div>
                            {/* FIELD USED TO GET SOURCE - IT'S MANDATORY FIELD  */}
                            <div className="col-md-12">
                                <SourceDropdownComponent onChange={this.handleUserSelectSource} value={this.state.source} errorStatus={this.state.sourceErrorStatus} errorMessage={this.state.sourceErrorMessage} label='Source' name='source' disableStatus={false} />

                            </div>
                            {/* FIELD USED TO GET ATTRIBUTE - IT'S MANDATORY FIELD  */}
                            <div className="col-md-12">
                                <DropdownComponent onChange={this.handleUserSelectAttribute1} value={this.state.arrtibute1} errorStatus={this.state.arrtibute1ErrorStatus} errorMessage={this.state.arrtibute1ErrorMessage} label='Attribute1' name='arrtibute1' menuItems={this.state.arrtibute1MenuItems} disableStatus={true} />

                            </div>
                        </div>
                        <div className="col-md-8 text-render">
                            {/* RENDER COMPONENTS WHILE CHOOSING BROWSE AND LINK */}
                            {this.RenderComponenets(this.state.attachType)}
                        </div>
                    </div>
                </div>
                <div className='br-bot'>
                    <div className='row'>
                        <div className="col-md-4">
                            <h5>comments</h5>
                            {/* FIELD USED TO GET COMMENT SECTION - IT'S MANDATORY FIELD  */}
                            <TextareaAutosize
                                aria-label="minimum height"
                                minRows={3}
                                value={this.state.comments}
                                placeholder="Minimum 3 rows"
                                style={{ width: "100%" }}
                                onChange={this.handleUserInputComments}
                                error={this.state.commentsErrorStatus}
                                helperText={this.state.commentsErrorMessage}
                            />
                        </div>
                    </div>
                </div>
                <div className='text-right'>
                    <CancelButtonComponent onClick={this.ClearFunc} buttonStatus={this.state.cancelButtonStatus} buttonName={"Cancel"} />
                    <SaveButtonComponent onClick={this.AddBulletInData} buttonStatus={this.state.submitButtonStatus} buttonName={"Save"} />


                </div>

                {this.state.instantResponseMessageStatus ? <InstantResponseMessage messageTitle={this.state.messageTitle} message={this.state.message}
                    severity={this.state.messageSeverity} /> : ``}

                {/*  <LinkPreview url={this.state.link} render={this.CustomComponent} /> */}

            </div>
        )
    }

}
export default AddBulletIn;



/*
USED FOR RESETTING THE INSTANT RESPONSE TO INITIAL STATE AFTER FEW SECONDS - 101/16/09/2022
*/
function HideFieldErroeMsgs(stateName, currentState) {
    setTimeout(function () {
        var self = currentState;
        self.state[stateName] = false;
        self.setState({
            [stateName]: self.state[stateName]
        })
    }, 4000);
}

