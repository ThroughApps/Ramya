import React, { Component } from 'react';
// import PdfThumbnail from 'react-pdf-thumbnail';

class PdfThumbNailPage extends Component {

    constructor() {
        super();
        this.state = {
            file: "",
            viewImage: "",

        }
    }


    createThumb = async (event) => {
        const { File, error, imageUrl } = await PdfThumbnail(
            event.target.files[0],
            { // thumb image config
                fileName: 'mythumbimage.png', // thumb file name
                height: 200, // image height
                width: 200, // image width
                pageNo: 1  // pdf page number
            }
        );
        if (!error) {
            setViewImage(imageUrl);
        }
    };

    render() {
        return (
            <>
                <input type='file' accept='application/pdf' onChange={this.createThumb} />
                <img src={this.state.viewImage} alt='img' />
            </>
        );
    };

}

export default PdfThumbNailPage;
