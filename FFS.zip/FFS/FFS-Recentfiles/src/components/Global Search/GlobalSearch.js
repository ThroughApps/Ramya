//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import SearchComponent from "react-material-ui-searchbar";

class GlobalSearch extends Component {
  constructor() {
    super();
    this.state = {
    }
  }

  render() {
    return (
      <div className='GlobalSearch'>
   <SearchComponent />
      </div>
    )
  }

}
export default GlobalSearch;
