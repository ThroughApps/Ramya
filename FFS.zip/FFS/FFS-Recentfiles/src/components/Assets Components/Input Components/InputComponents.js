//IMPORT STATEMENTS FOR REACT COMPONENT
import TextField from '@mui/material/TextField';

import InputAdornment from "@mui/material/InputAdornment";
import { AccountCircle, LockRoundedIcon, Email, Smartphone } from '@material-ui/icons';
import FormControl from '@mui/material/FormControl';

import InputLabel from '@mui/material/InputLabel';
import Select, { SelectChangeEvent } from '@mui/material/Select';


const styles = {
    width: "80%",
    marginTop: "10px"
}

const Filefieldstyles = {
    width: "50%",
    marginBottom: "10px",
    '@media(maxWidth: 768px)': {
        width: '100%'
    }
}
const selectfieldstyle = {
    width: "100%",
    marginBottom: "20px",
}
const selectfieldstyle1 = {
    width: "100%",
    marginBottom: "20px",
}

const Buttonstyles = {
    backgroundColor: "#333d4b",
    color: "#fff",
    borderRadius: "5px",
    marginRight: "10px",
    '&:hover': { backgroundColor: "#333d4b" }
}

const textareastyles = {
    width: "100%",
    marginBottom: "20px",
}

const comment_para_commentDisplay = {
    fontSize: '24px'
}

const comment_para = {
    fontSize: "12px"
}

/*
USED FOR RENDERING USER-NAME TEXT FIELD - 101/07/09/2022
UPDATE WITH ICONS - 103/08/09/2022
*/
export const UserNameInputTextField = ({ onChange, value, label, name, errorStatus, errorMessage, iconStart }) => (
    <IconTextField error={errorStatus} sx={styles} required size="small" margin="normal" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} iconStart={iconStart} />
);

/*
USED FOR RENDERING EMAIL-ID TEXT FIELD - 101/07/09/2022
*/
export const EmailIdInputTextField = ({ onChange, value, label, name, errorStatus, errorMessage, iconStart }) => (
    <IconTextField error={errorStatus} sx={styles} required size="small" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} iconStart={iconStart} />
);

/*
USED FOR RENDERING CONTACTNO TEXT FIELD - 101/07/09/2022
*/
export const ContactNoInputTextField = ({ onChange, value, label, name, errorStatus, errorMessage, iconStart }) => (
    <IconTextField error={errorStatus} sx={styles} required size="small" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} iconStart={iconStart} />
);

/*
USED FOR RENDERING PASSWORD TEXT FIELD - 101/07/09/2022
UPDATE WITH ICONS - 103/08/09/2022
*/

/*export const PasswordInputTextField = ({ onChange, value, label, name, errorStatus, errorMessage, iconStart, iconEnd, InputProps,...props  }) => (
    <IconTextField error={errorStatus} id="outlined-password-input" size="small" type="password" autoComplete="current-password" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} iconStart={iconStart} iconEnd={iconEnd} {...props} InputProps={InputProps} />
);
*/



export const PasswordInputTextField = ({ onChange, value, label, name, errorStatus, errorMessage, iconStart, iconEnd, InputProps, ...props }) => (
    <TextField error={errorStatus} sx={styles} id="outlined-password-input" type="password" autoComplete="current-password" size="small" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} {...props}
        InputProps={{
            ...InputProps,
            startAdornment: iconStart ? (
                <InputAdornment position="start">{iconStart}</InputAdornment>
            ) : null,
            endAdornment: iconEnd ? (
                <InputAdornment position="end">{iconEnd}</InputAdornment>
            ) : null
        }} />
);



/*
USED FOR RENDERING ICONS BEFORE AND AFTER TEXT FIELD - 103/07/09/2022
*/
const IconTextField = ({ iconStart, iconEnd, InputProps, ...props }) => {
    return (
        <TextField
            {...props}
            InputProps={{
                ...InputProps,
                startAdornment: iconStart ? (
                    <InputAdornment position="start">{iconStart}</InputAdornment>
                ) : null,
                endAdornment: iconEnd ? (
                    <InputAdornment position="end">{iconEnd}</InputAdornment>
                ) : null
            }}
        />
    );
};

/*
TEXT AREA FIELD  - 103/13/09/2022
*/
export const TextAreaField = ({ onChange, value, label }) => (
    <TextField sx={textareastyles}
        required
        id="outlined-multiline-flexible"
        label={label}
        multiline
        value={value}
        onChange={onChange}
    />
);
/*
USED FOR RENDERING USER-NAME TEXT FIELD - 101/07/09/2022
*/
/*
TEXT FIELD WITH ICON ADDED FOR BEFORE AND AFTER - 103/07/09/2022
*/
export const FileInputTextField = ({ onChange, value, label, name, errorStatus, errorMessage, iconStart, iconEnd, InputProps, ...props }) => (
    <TextField required size="small" sx={Filefieldstyles} variant="outlined" label={label} name={name} onChange={onChange} value={value}
        {...props}
        InputProps={{
            ...InputProps,
            startAdornment: iconStart ? (
                <InputAdornment position="start">{iconStart}</InputAdornment>
            ) : null,
            endAdornment: iconEnd ? (
                <InputAdornment position="end">{iconEnd}</InputAdornment>
            ) : null
        }}
    />
);

/*
USED FOR RENDERING USER-NAME TEXT FIELD - 101/07/09/2022
UPDATE WITH ICONS - 103/08/09/2022
*/
export const InputTextField = ({ onChange, value, label, name, disableStatus, errorStatus, errorMessage, iconStart }) => (
    <IconTextField error={errorStatus} disabled={disableStatus} sx={styles} required size="small" margin="normal" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} iconStart={iconStart} />
);


export const SelectTextField = ({ onChange, error, value, label, labelname, submenu }) => (
    <FormControl required error={error} sx={selectfieldstyle}>
        <InputLabel id="demo-simple-select-disabled-label">{labelname}</InputLabel>
        <Select
            labelId="demo-simple-select-required-label"
            id="demo-simple-select-required"
            value={value}
            label={label}
            onClick={onChange}
        >
            {submenu}
        </Select>
    </FormControl>);




/*
USED FOR RENDERING COMMENT TEXTFIELD- 104/12/09/2022
*/
export const CommentsTextField = ({ onChange, value, label, name, iconStart, iconEnd, InputProps, ...props }) => (
    <TextField sx={styles} required size="small" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} {...props}
        InputProps={{
            ...InputProps,
            startAdornment: iconStart ? (
                <InputAdornment position="start">{iconStart}</InputAdornment>
            ) : null,
            endAdornment: iconEnd ? (
                <InputAdornment position="end">{iconEnd}</InputAdornment>
            ) : null
        }} />

);

/*
USED FOR RENDERING COMMENTS - 104/13/09/2022
*/
export const CommentParaComponent = ({ commentTag }) => (
    <p style={comment_para}>{commentTag}</p>
);

/*
USED FOR RENDERING COMMENTS - 104/13/09/2022
*/
export const CommentParaDisplayComponent = ({ commentTag }) => (
    <p style={comment_para_commentDisplay}>{commentTag}</p>
);
