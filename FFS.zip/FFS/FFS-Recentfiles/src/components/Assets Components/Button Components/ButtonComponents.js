//IMPORT STATEMENTS FOR REACT COMPONENT
import { InputAdornment } from '@mui/material';
import Button from '@mui/material/Button';
import Pagination from '@mui/material/Pagination';

/*
USED FOR STYLING THE LOGINBUTTON - 103/07/09/2022
*/
const styles = {
  marginTop: "10px",
  backgroundColor: "#689fd5",
  borderRadius: "25px",
  fontWeight: "bold",
  '&:hover': { backgroundColor: "#689fd5" }
}
const Buttonstyles = {
  backgroundColor: "#333d4b",
  color: "#fff",
  borderRadius: "5px",
  marginRight: "10px",
  '&:hover': { backgroundColor: "#333d4b" }
}
const saveButtonstyles = {
  backgroundColor: "#333d4b",
  color: "#fff",
  borderRadius: "5px",
  '&:hover': { backgroundColor: "#333d4b" }
}

const styles_Attachment = {
  fontSize: '10px',
  backgroundColor: '#0e3150',
  padding: '1px 9px 1px 9px',
  position: 'absolute',
  marginTop: '-15px',
  marginBottom: "10px",
  right: '0'
}
const styles_Secondary = {
  fontSize: '10px',
  backgroundColor: '#0e3150',
  padding: '1px 9px 1px 9px',
}

const stylesButtonDash = {
  backgroundColor: '#0e3150',
  padding: '10px',
  marginRight: '10px'
}


const ExploreStyles = {
  color: "#fff",
  border: "1px solid",
  '&:hover': { backgroundColor: "#689fd5" }
}
const BulletinButton = {
  borderBottom: "2px solid #689fd5",
  borderRadius: "0px !important",
  color: "#000",
  fontWeight: "bold",
  textTransform: "none",
  marginRight: "10px"
}

/*
USED FOR RENDERING SUBMIT BUTTON - 101/07/09/2022
*/
export const SubmitButtonComponent = ({ onClick, buttonStatus, buttonName }) => (
  <Button sx={styles} variant="contained" onClick={onClick} disabled={buttonStatus}>{buttonName}</Button>
);

export const LinkButtonComponent = ({ onClick, buttonName }) => (
  <Button onClick={onClick}>{buttonName}</Button>
);

/*
USED FOR RENDERING SAVE BUTTON - 103/09/09/2022
*/
export const SaveButtonComponent = ({ onClick, buttonStatus, buttonName }) => (
  <Button sx={saveButtonstyles} variant="contained" onClick={onClick} disabled={buttonStatus}>{buttonName}</Button>
);

/*
USED FOR RENDERING CANCEL BUTTON - 103/09/09/2022
*/
export const ButtonWithIconComponent = ({ onClick, buttonStatus, buttonName, iconStart, iconEnd, InputProps, ...props }) => (
  <Button sx={Buttonstyles} variant="contained" onClick={onClick} disabled={buttonStatus}   {...props}
    InputProps={{
      ...InputProps,
      startAdornment: iconStart ? (
        <InputAdornment position="start">{iconStart}</InputAdornment>
      ) : null,
      endAdornment: iconEnd ? (
        <InputAdornment position="end">{iconEnd}</InputAdornment>
      ) : null
    }}>{buttonName}</Button>
);

/*
USED FOR RENDERING CANCEL BUTTON - 103/09/09/2022
*/
export const CancelButtonComponent = ({ onClick, buttonStatus, buttonName }) => (
  <Button sx={Buttonstyles} variant="contained" onClick={onClick} disabled={buttonStatus}>{buttonName}</Button>
);

/*
BUTTON USED FOR ATTACHMENT IN COMMENT PAGE - 104/13/09/2022
*/
export const AttachmentButtonComponent = ({ onClick, buttonName }) => (
  <Button variant="contained" sx={styles_Attachment} onClick={onClick}>{buttonName}</Button>
);

// BUTTON USED IN ARTICLE COMMENT COMPONENT AND COMMENT DISPLAY PAGE 
export const SecondaryButtonComponent = ({ onClick, buttonName, endIcon }) => (
  <Button variant="contained" sx={styles_Secondary} onClick={onClick} endIcon={endIcon}>
    {buttonName}
  </Button>
);

export const DashboardButtonComponent = ({ onClick, buttonName }) => (
  <Button variant="contained" onClick={onClick} sx={stylesButtonDash}>{buttonName}</Button>
);

/*
USED FOR RENDERING EXPLOREBUTTON - 103/07/09/2022
*/
export const ExploreButtonComponent = ({ onClick, buttonStatus, buttonName }) => (
  <Button sx={ExploreStyles} variant="outlined" onClick={onClick}>{buttonName}</Button>
);

export const BulletinButtonComponent = ({ onClick, buttonName }) => (
  <Button sx={BulletinButton} onClick={onClick}>{buttonName}</Button>
);


export const UploadButtonComponent = ({ onChange, buttonStatus, buttonName, iconStart, iconEnd, InputProps, ...props }) => (
  <Button sx={Buttonstyles} variant="contained" component="label" {...props} InputProps={{
    ...InputProps,
    startAdornment: iconStart ? (
      <InputAdornment position="start">{iconStart}</InputAdornment>
    ) : null,
    endAdornment: iconEnd ? (
      <InputAdornment position="end">{iconEnd}</InputAdornment>
    ) : null
  }}
  >
    {buttonName}
    <input hidden accept=""  type="file" onChange={onChange} />
  </Button>
);

/*
USED FOR RENDERING PAGINATION BUTTON - 101/29/09/2022
*/
export const PaginationComponent = ({ onChange, activePage, itemsCountPerPage, totalItemsCount}) => (
 
  <Pagination
  activePage={activePage}
  itemsCountPerPage={itemsCountPerPage}
  totalItemsCount={totalItemsCount}
  pageRangeDisplayed={20}
  itemClass="page-item"
  linkClass="page-link"
  onChange={onChange}
  />
  );

