import React, { Component,useState } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import {$} from 'jquery';

// IMPORT COMPONENT
import TopMenu from '../../MenuBar/TopMenu';
import {CommentsTextField,CommentParaComponent} from '../../Asset Component/InputComponent/InputComponents'
import {AttachmentButtonComponent} from '../../Asset Component/Button Components/ButtonComponents'

// IMPORT CSS
import '../../Styling Components/ActivityComponentStyles.css'
import '../../Styling Components/TopMenuCSS.css'
// IMPORT ICON
import SendIcon from '@mui/icons-material/Send';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

const styles={
    cursor:'pointer',
}
// CSS FOR ATTACHMENT BUTTON
const styles_attach={
    cursor:'pointer',
    marginTop:'15px',
    
}
// CSS FOR DROPDOW ARROW 
const style_dropdownArrow={
    cursor:'pointer',
  fontSize:'40px'
}
// CSS FOR BUTTON
const style_button={
    fontSize:'10px',
    padding:'3px',
    
}
const cardstyle = {
    padding: "6px",
    
    }
    
class ArticleCommentComponent extends Component {
    constructor() {
        super()
       
        this.state = {
            comment:"",
        }
    }

           /*
   FUNCTION USED TO HANDLE COMMENT - 104/12/09/2022
   */
   handleUserInputComment = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    this.state.comment = value;
    this.setState({
        comment: this.state.comment
    })
}

Scrolldown(){
   
}
        /*
   FUNCTION USED TO HANDLE SEND MESSAE  - 104/15/09/2022
   */
handleSendMessage(){
 alert("Message Send")
}

    render(){
        return(
        <div>
            <div class="container-fluid">
 
            <div class="row">
                <div class="col-md-9">

                </div>
                <div class="col-md-3 part_comment" >
                 
                    <div class="section_comment_part commentsSection">
                    <h2 class="TopMenu_Second li">Comments</h2>

                    {/* FIELD USED TO GET COMMENTS - IT'S MANDATORY FIELD  */}
                    <CommentsTextField  onChange={this.handleUserInputComment}  value={this.state.comment} label='Type Your Comment' name='comment' 
                    iconEnd={<SendIcon sx={styles} onClick={this.handleSendMessage}/>}/>
                      {/*FIELD TO GET FILE UPLOAD  */}
                    <div class="image-upload">
                        <label for="file-input">
                            <AttachFileIcon sx={styles_attach} type="file" id="myfile" name="myfile" multiple/>
                        </label>
                        <input id="file-input" type="file" />
                    </div>



                    <ul class="article_comment_list">
                    {/* SHOW COMMENT LIST */}
                    <li>
                    <Card class="card_dashboard">
                    <CardContent sx={cardstyle}>
                        <div class="style_username"><span><AccountCircleIcon /></span><span><h3 class="commentUser_Name">User Name</h3></span><span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span></div>
                        <div>
                            {/* <p class="commentarea">Ms. Prerna please go the the article and find the link given in it for Sustainability Report 2021</p> */}
                            <CommentParaComponent commentTag={"Ms. Prerna please go the the article and find the link given in it for Sustainability Report 2021"}/>
                            <AttachmentButtonComponent sx={style_button} buttonName={"Attachment"}/>
                        </div>
                    </CardContent>
                    </Card>
                    </li>
                    <li>
                    <Card class="card_dashboard">
                    <CardContent sx={cardstyle}>
                        <div class="style_username"><span><AccountCircleIcon /></span><span><h3 class="commentUser_Name">User Name</h3>
                        </span><span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span></div>
                        <div>
                            <CommentParaComponent commentTag={"You could create a custom css class, and include it in the appearance section of your container under "}/>                            
                            <AttachmentButtonComponent sx={style_button} buttonName={"Attachment"}/>
                        </div>
                    </CardContent>
                    </Card>
                    </li>
                    <li>
                    <Card class="card">
                    <CardContent>
                        <div class="style_username"><span><AccountCircleIcon /></span><span><h3 class="commentUser_Name">User Name</h3></span>
                        <span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span></div>
                        <div>
                            <CommentParaComponent commentTag={"Using the overflow (Defined above), you can define if you want to scroll through your container if the content inside is to long."}/>
                            <AttachmentButtonComponent sx={style_button} buttonName={"Attachment"}/>
                        </div>
                    </CardContent>
                    </Card>
                    </li>
                    {/* <Card class="card">
                    <CardContent>
                        <div class="style_username"><span><AccountCircleIcon /></span><span><h3 class="commentUser_Name">User Name</h3></span>
                        <span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span></div>
                        <div>
                            <CommentParaComponent commentTag={"Using the overflow (Defined above), you can define if you want to scroll through your container if the content inside is to long."}/>
                            <AttachmentButtonComponent sx={style_button} buttonName={"Attachment"}/>
                        </div>
                    </CardContent>
                    </Card> */}
                    </ul>
                    </div>
                    {/* DROPDOWN ARROW */}
                    <div class="section">  
                            <a href="#section02" ><span class="dropdownArrow"><KeyboardArrowDownIcon onClick={()=> this.Scrolldown()} sx={style_dropdownArrow}/></span></a>
                    </div>
                </div>
                
            </div>

            </div>
        </div>
        );
    }
}
export default ArticleCommentComponent;

