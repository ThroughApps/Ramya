import React, { Component, useState } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { $ } from 'jquery';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
// IMPORT COMPONENT
import TopMenu from '../../MenuBar/TopMenu';
import { CommentsTextField, CommentParaComponent } from '../../Assets Components/Input Components/InputComponents';
import { AttachmentButtonComponent, SecondaryButtonComponent } from '../../Assets Components/Button Components/ButtonComponents';

import Article_img from '../../Images/Article_img2.png'
// IMPORT CSS
import '../../Styling Components/ArticleDisplayCss.css'
import '../../Styling Components/TopMenuCSS.css'
// IMPORT ICON
import SendIcon from '@mui/icons-material/Send';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import ShareIcon from '@mui/icons-material/Share';
import FavoriteIcon from '@mui/icons-material/Favorite';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import CommentDisplayComponent from './Comment Display';
import AddBulletIn from '../../Add BulletIn/AddBulletIn';

const styles = {
    cursor: 'pointer',
}
// CSS FOR ATTACHMENT BUTTON
const styles_attach = {
    cursor: 'pointer',
    marginTop: '15px',

}
// CSS FOR DROPDOW ARROW 
const style_dropdownArrow = {
    cursor: 'pointer',
    fontSize: '40px'
}
// CSS FOR BUTTON
const style_button = {
    fontSize: '10px',
    padding: '3px',
    boxShadow: ' 0 3px 10px rgb(0 0 0 / 0.2)'

}
const style_icon = {
    background: 'white',
    padding: '3px',
    borderRadius: '20px',
    boxShadow: ' 0 3px 10px rgb(0 0 0 / 0.2)',
    marginRight: '10px',

    marginBottom: '10px'
}
class ArticleCommentComponent extends Component {
    constructor() {
        super()

        this.state = {
            comment: "",
            source: "Just Style",
            Date: "11 May 2022",
            uploaderName: "Uploaded by Mr.xxxxx",
            articleType: "News",
            articleNo: "10002"


        }
    }

    /*
FUNCTION USED TO HANDLE COMMENT - 104/12/09/2022
*/
    handleUserInputComment = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        this.state.comment = value;
        this.setState({
            comment: this.state.comment
        })
    }

    Scrolldown() {

    }
    /*
FUNCTION USED TO HANDLE SEND MESSAE  - 104/15/09/2022
*/
    handleSendMessage() {
        alert("Message Send")
    }
    handleCommentDisplay() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<CommentDisplayComponent />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        )
    }
    AddNewBulletins() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<AddBulletIn />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        )
    }
    render() {
        return (
            <div class="container-fluid">
                <div class="row"style={{marginBottom:'60px'}}>
                    <div class="col-md-9">

                        <SecondaryButtonComponent buttonName={"Add New Bulletins"} onClick={this.AddNewBulletins} />
                        <div class="flex_part">
                            <div>
                                <p>Article-<span>{this.state.articleType}</span> </p>
                                <p>View-<span>{this.state.articleNo}</span> </p>
                            </div>
                            <div>
                                <h4> {this.state.source}</h4>
                            </div>
                            <div>
                                <p> {this.state.Date} </p>
                                <p> {this.state.uploaderName} </p>
                            </div>
                        </div>
                        <div class="flex_part">
                            <div>
                                <BookmarkIcon sx={style_icon} />
                                <LocalOfferIcon sx={style_icon} />
                                <FavoriteIcon sx={style_icon} />
                            </div>
                            <div>
                                <SendIcon sx={style_icon} />
                                <ShareIcon sx={style_icon} />
                            </div>
                        </div>
                        <img src={Article_img} class="image_Article" />
                    </div>
                    <div class="col-md-3 part_comment" >

                        <div class="section_comment_part commentsSection">
                            <h2 class="TopMenu_Second li">Comments</h2>

                            {/* FIELD USED TO GET COMMENTS - IT'S MANDATORY FIELD  */}
                            <CommentsTextField onChange={this.handleUserInputComment} value={this.state.comment} label='Type Your Comment' name='comment'
                                iconEnd={<SendIcon sx={styles} onClick={this.handleSendMessage} />} />
                            {/*FIELD TO GET FILE UPLOAD  */}
                            <div class="image-upload">
                                <label for="file-input">
                                    <AttachFileIcon sx={styles_attach} type="file" id="myfile" name="myfile" multiple />
                                </label>
                                <input id="file-input" type="file" />
                            </div>

                            <ul class="article_comment_list">
                                {/* SHOW COMMENT LIST */}
                                <li onClick={this.handleCommentDisplay}>
                                    <Card class="card">
                                        <CardContent>
                                            <div class="style_username"><span><AccountCircleIcon /></span><span><h3 class="commentUser_Name">User Name</h3></span><span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span></div>
                                            <div>
                                                {/* <p class="commentarea">Ms. Prerna please go the the article and find the link given in it for Sustainability Report 2021</p> */}
                                                <CommentParaComponent commentTag={"Ms. Prerna please go the the article and find the link given in it for Sustainability Report 2021"} />
                                                <AttachmentButtonComponent sx={style_button} buttonName={"Attachment"} />
                                            </div>
                                        </CardContent>
                                    </Card>
                                </li>
                                <li onClick={this.handleCommentDisplay}>
                                    <Card class="card">
                                        <CardContent>
                                            <div class="style_username"><span><AccountCircleIcon /></span><span><h3 class="commentUser_Name">User Name</h3>
                                            </span><span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span></div>
                                            <div>
                                                <CommentParaComponent commentTag={"You could create a custom css class, and include it in the appearance section of your container under "} />
                                                <AttachmentButtonComponent sx={style_button} buttonName={"Attachment"} />
                                            </div>
                                        </CardContent>
                                    </Card>
                                </li>
                                <li>
                                    <Card class="card">
                                        <CardContent>
                                            <div class="style_username"><span><AccountCircleIcon /></span><span><h3 class="commentUser_Name">User Name</h3></span>
                                                <span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span></div>
                                            <div>
                                                <CommentParaComponent commentTag={"Using the overflow (Defined above), you can define if you want to scroll through your container if the content inside is to long."} />
                                                <AttachmentButtonComponent sx={style_button} buttonName={"Attachment"} />
                                            </div>
                                        </CardContent>
                                    </Card>
                                </li>

                            </ul>
                        </div>
                        {/* DROPDOWN ARROW */}
                        {/* <div class="section">  
                            <a href="#section02" ><span class="dropdownArrow"><KeyboardArrowDownIcon onClick={()=> this.Scrolldown()} sx={style_dropdownArrow}/></span></a>
                    </div> */}
                    </div>

                </div>

            </div>

        );
    }
}
export default ArticleCommentComponent;

