import React, { Component,useState } from 'react';
import TopMenu from '../../MenuBar/TopMenu';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import {CommentParaDisplayComponent,CommentsTextField} from '../../Assets Components/Input Components/InputComponents';
import {SecondaryButtonComponent} from '../../Assets Components/Button Components/ButtonComponents';
import SendIcon from '@mui/icons-material/Send';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import SimCardDownloadOutlinedIcon from '@mui/icons-material/SimCardDownloadOutlined';
import GetAppIcon from '@mui/icons-material/GetApp';

import pdf from '../../Images/pdf.png'
const iconStyles={
    fontSize:'70px'
}
const coment_commentDisplay={
    fontSize:'26px'
}
const styles={
    cursor:'pointer',
}
// CSS FOR ATTACHMENT BUTTON
const styles_attach={
    cursor:'pointer',
    marginTop:'15px',
    
}
const download_icon={
    fontSize:'40px',
    marginRight:'20px'

}

class CommentDisplayComponent extends Component {
    constructor() {
        super()
       
        this.state = {
            comment:"",
        }
    }

            /*
   FUNCTION USED TO HANDLE COMMENT - 104/12/09/2022
   */
   handleUserInputComment = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    this.state.comment = value;
    this.setState({
        comment: this.state.comment
    })
}
render(){
    return(
            <div>
                <div class="container-fluid">
                    {/* <TopMenu></TopMenu> */}

                    <div class="comment-display">
                    <div class="style_username"><span><AccountCircleIcon sx={iconStyles}/></span><span><h3 class="userName_commentDisplay">User Name</h3></span>
                        <span><h3 class="timer_commentDisplay">12:45 / 5th May ‘22</h3></span>
                    </div>

                    <hr/>
                    <CommentParaDisplayComponent style={{fontSize:'30px'}}commentTag={"Ms. Prerna please go the the article and find the link given in it for Sustainability Report 2021"}/>

            {/* FIELD TO GET A SECONDARY BUTTON */}
                    <div class="comment_uploadbutton">
                        <img src={pdf} class="pdficon"/>
                        <div class="span">
                        <p>Report Sneak Peak </p>
                        <p> Uploaded By Mr XXX On 12th MAY-12:55 </p>
                        </div>
            {/* FIELD TO GET A DOWNLOAD BUTTON */}
                    <SimCardDownloadOutlinedIcon sx={download_icon}/>
            {/* FIELD TO GET A SECONDARY BUTTON */} 
                    <SecondaryButtonComponent  buttonName={"Secondary Files"} endIcon={<GetAppIcon/>}/>
                    </div>
            
            {/* FIELD TO GET A COMMENT TEXTFIELD AND ATTACH ICON */}
                    <div class="textfield_commentdisplay">
                    <CommentsTextField  onChange={this.handleUserInputComment}  value={this.state.comment} label='Type Your Comment' name='comment' 
                    iconEnd={<SendIcon sx={styles} onClick={this.handleSendMessage}/>}/>
            
            {/*FIELD TO GET FILE UPLOAD  */}
                      <div class="image-upload">
                        <label for="file-input">
                            <AttachFileIcon sx={styles_attach} type="file" id="myfile" name="myfile" multiple/>
                        </label>
                        <input id="file-input" type="file" />
                    </div>
                    </div>
                    </div>
                </div>
            </div>




    );
}
}
export default CommentDisplayComponent;
