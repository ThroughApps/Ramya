import React, { Component,useState } from 'react';
import ModeCommentIcon from '@mui/icons-material/ModeComment';

import ReactDOM from "react-dom";
import Card from '@mui/material/Card';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CardContent from '@mui/material/CardContent';
// IMPORT COMPONENT
import { CommentParaComponent } from '../../Assets Components/Input Components/InputComponents';

// IMPORT ICON
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
// IMPORT CSS
import '../../Styling Components/ActivityComponentStyles.css'
import { AttachmentButtonComponent } from '../../Assets Components/Button Components/ButtonComponents';


const cardstyle = {
padding: "6px",

}

class DashboardCommentComponent extends Component {

    constructor() {
        super();

    }
    
render(){
        return(

    <div class="container-fluid">
    {/* DASHBOARD COMMENT SECTION STARTS HERE */}
        <ul class="menu_sec_icon2">
        {/* LIST FOR SHOW A COMMENT */}
            <li >
                <Card class="card_dashboard">
                    <CardContent sx={cardstyle}>
                        <div class="style_username">
                            <span><AccountCircleIcon /></span>
                            <span><h3 class="commentUser_Name">User Name</h3></span>
                            <span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span>
                        </div>
                        <div>
                            <CommentParaComponent commentTag={"Using the overflow (Defined above), you can define if you want to scroll through your container if the content inside is to long."}/>
                            <AttachmentButtonComponent style={{position:'relative'}} buttonName={"Attachment"}/>
                        </div>
                    </CardContent>
                </Card>
            </li>
    {/* LIST FOR SHOW A COMMENT */}
            <li>
            <Card class="card_dashboard">
                <CardContent sx={cardstyle}>
                    <div class="style_username">
                        <span><AccountCircleIcon /></span>
                        <span><h3 class="commentUser_Name">User Name</h3></span>
                        <span><h3 class="comment_timer">12:45 / 5th May ‘22</h3></span>
                    </div>
                     <div>
                        <CommentParaComponent commentTag={"Using the overflow (Defined above), you can define if you want to scroll through your container if the content inside is to long."}/>
                        <AttachmentButtonComponent style={{position:'relative'}} buttonName={"Attachment"}/>
                    </div>
                </CardContent>
            </Card>
            </li>
        </ul>
    </div>

                

            
        );
    }
}
export default DashboardCommentComponent;

