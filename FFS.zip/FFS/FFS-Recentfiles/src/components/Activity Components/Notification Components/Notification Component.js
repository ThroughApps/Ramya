import React, { Component,useState } from 'react';
import ModeCommentIcon from '@mui/icons-material/ModeComment';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
// IMPORT COMPONENT
import { CommentParaComponent } from '../../Assets Components/Input Components/InputComponents';

// IMPORT ICON
import CardActions from '@mui/material/CardActions';
// IMPORT CSS
import '../../Styling Components/ActivityComponentStyles.css'

// CSS FOR CLOSE ICON IN SIDE MENU - 104/14/09/22
const closeIcon={
    position:'absolute',
    right:'0',
    marginBottom:'10px'
}
const Space={
    padding: "5px",
    justifyContent: "space-between"
              }
class NotificationComponent extends Component {

    render(){
        return(

          <div class="container-fluid">
              {/* DASHBOARD COMMENT SECTION STARTS HERE */}

                <ul class="menu_sec_icon2">
                   {/* LIST FOR SHOW A COMMENT */}
                    <li>
                        <Card class="card_dashboard">
                            <div class="noti_card">
                               
                                <CommentParaComponent commentTag={"Why Brands Are Racing Into Resale — in Five Charts"}/>
                                <CardActions sx={Space}>
                                <a size="small" class="UploadData">Today</a>
                                <a size="small" class="UploadData">Uploaded by Mr.xxxxxxxxx</a>
                            </CardActions>                                          
                                                
                               
                            </div>
                        </Card>
                    </li>
                                        {/* LIST FOR SHOW A COMMENT */}
                     <li>
                     <Card class="card_dashboard">
                        <div class="noti_card">
                        <div>
                            <CommentParaComponent commentTag={"Why Brands Are Racing Into Resale — in Five Charts"}/>
                            <CardActions sx={Space}>
                                <a size="small" class="UploadData">Today</a>
                                <a size="small" class="UploadData">Uploaded by Mr.xxxxxxxxx</a>
                            </CardActions>                                           
                                          
                        </div>
                        </div>
                    </Card>
                    </li>
                </ul>
                               
                           
                        
                     

                   
                </div>
            
        );
    }
}
export default NotificationComponent;
