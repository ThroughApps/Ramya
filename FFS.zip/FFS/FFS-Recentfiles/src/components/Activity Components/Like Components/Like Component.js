import React, { Component,useState } from 'react';


import Card from '@mui/material/Card';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CardContent from '@mui/material/CardContent';
// IMPORT COMPONENT
import { CommentParaComponent } from '../../Assets Components/Input Components/InputComponents';

// IMPORT ICON
import FavoriteIcon from '@mui/icons-material/Favorite';
import PersonIcon from '@mui/icons-material/Person';

// IMPORT CSS
import '../../Styling Components/ActivityComponentStyles.css'


// CSS FOR CLOSE ICON IN SIDE MENU - 104/14/09/22

const iconstyles={
    fontSize:'15px',
    color:'blue'
}

const cardstyle = {
    padding: "6px"
    }
    
class LikeCommentComponent extends Component {

    constructor() {
        super();

    }

    render(){
        return(

         <div class="container-fluid">
            {/* DASHBOARD COMMENT SECTION STARTS HERE */}
            <ul class="menu_sec_icon2">
            {/* LIST FOR SHOW A COMMENT */}
                <li>
                <Card class="card_dashboard">
                    <CardContent sx={cardstyle}>
                        <CommentParaComponent commentTag={"The Strategy Behind Balenciaga’s Destroyed Sneaker Stunt"}/>
                          <div class="like-icon-sec">
                           <PersonIcon sx={iconstyles}/><p class="like_text">1003</p>
                           <FavoriteIcon sx={iconstyles}/><p class="like_text">7</p>
                           </div>
                    </CardContent>
                </Card>
                </li>
                {/* LIST FOR SHOW A COMMENT */}
                <li>
                <Card class="card_dashboard">
                    <CardContent sx={cardstyle}>
                        <CommentParaComponent commentTag={"Meet Olaplex’s First AI Employee"}/>
                            <div class="like-icon-sec">
                            <PersonIcon sx={iconstyles}/><p class="like_text">1003</p>
                            <FavoriteIcon sx={iconstyles}/><p class="like_text">7</p>
                            </div>
                    </CardContent>
                </Card>
                </li>

                <li>
                <Card class="card_dashboard">
                    <CardContent sx={cardstyle}>
                    <CommentParaComponent commentTag={"Meet Olaplex’s First AI Employee"}/>
                          <div class="like-icon-sec">
                           <PersonIcon sx={iconstyles}/><p class="like_text">1003</p>
                           <FavoriteIcon sx={iconstyles}/><p class="like_text">7</p>
                           </div>
                    </CardContent>
                </Card>
                </li>
            </ul>
        </div>

                

          
        );
    }
}
export default LikeCommentComponent;

