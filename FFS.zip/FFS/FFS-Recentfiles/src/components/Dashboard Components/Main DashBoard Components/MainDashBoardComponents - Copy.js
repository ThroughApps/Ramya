//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import '../../Styling Components/TopMenuCSS.css';
import '../../Styling Components/styleCSS.css';
import '../../Styling Components/MainDashBoardCSS.css';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import logo from '../../Images/Cieltextilelogo.png';
import image1 from '../../Images/image1.jpg';
import image2 from '../../Images/image2.jpg';
import image3 from '../../Images/image3.jpg';
import image4 from '../../Images/image4.jpg';
import { AddBox, Person, Favorite } from '@mui/icons-material';
import Slider from "react-slick";
import { CommentParaDisplayComponent } from '../../Assets Components/Input Components/InputComponents';
import { CardActionArea } from 'material-ui-core';
import ButtonBase from '@material-ui/core/ButtonBase';
import { components } from 'react-select';



var settings = {
  dots: true,
  infinite: true,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  slickNext: true,
  slickPrevious: true,
  swipe: true
};
  const colorStyle={
    color: '#689fd5'
      }
    const Space={
    padding: "5px",
    justifyContent: "space-between"
              }
export default class SliderDashBoardComponents extends Component {

  constructor(props) {
    super(props)

    this.state = {
      images: [
        {
          Photo: image1,
          Label: "Report SS 20",
          StyleName: "just style",
          Date: "Latest 11/05/2022",
          ContentName: "News",
          UploadedBy: "Uploaded by mr.xxxxxxxxxxx",
          User: "1000",
          // UserIcon: <Person /> ,
          // FavIcon: <Favorite /> ,
          Likes: "5",
        },
        {
          Photo: image2,
          Label: "Report SS 22",
          StyleName: "just style new",
          Date: "Latest 16/11/2022",
          ContentName: "News new",
          UploadedBy: "Uploaded by mr.xxxxxxzzzzzzz",
          User: "1000",
          Likes: "5",
        },
        {
          Photo: image3,
          Label: " SS 22",
          StyleName: "new style ",
          Date: "Latest 12/11/2022",
          ContentName: "News new",
          UploadedBy: "Uploaded by mr.xxxxxxzzzzzzz",
          User: "10",
          Likes: "50",
        },
        {
          Photo: image1,
          Label: " SS 22",
          StyleName: "new style ",
          Date: "Latest 12/11/2022",
          ContentName: "News new",
          UploadedBy: "Uploaded by mr.xxxxxxzzzzzzz",
          User: "10",
          Likes: "50",
        },
        {
          Photo: image1,
          Label: " SS 22",
          StyleName: "new style ",
          Date: "Latest 12/11/2022",
          ContentName: "News new",
          UploadedBy: "Uploaded by mr.xxxxxxzzzzzzz",
          User: "10",
          Likes: "50",
        },
        {
          Photo: image2,
          Label: " SS 22",
          StyleName: "new style ",
          Date: "Latest 12/11/2022",
          ContentName: "News new",
          UploadedBy: "Uploaded by mr.xxxxxxzzzzzzz",
          User: "1",
          Likes: "5",
        }
      ]
    }
  }

    MoveToArticlePage() {
      ReactDOM.render(
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<CommentParaDisplayComponent />} />
          </Routes>
        </BrowserRouter>,
        document.getElementById("contentRender")
      )
    }

    render() {

      return (

      <div className='mt-50'>
        <Slider {...settings} >
          {this.state.images.map((step) => (
            <div key={step.Label} onClick={()=>this.MoveToArticlePage}>
              <img 
                src={step.Photo}
                alt={step.Label}
                style={{
                  // borderRadius: "15px",
                  height: "400px",
                  display: "block",
                  overflow: "hidden",
                  width: "100%"
                }}
              />
              <div className='Slider_Content'>
                <div className='Slider_MainContent'>
                  <h2>{step.Label}</h2>
                  <div className='Slider_MainContent'>
                    <a><Person /> {step.User}</a>
                    <a><Favorite /> {step.Likes}</a>
                  </div>
                </div>
                <div className='Slider_MainContent'>
                  <p>{step.StyleName}<br /> <span>{step.Date}</span></p>
                  <p className='text-right'>{step.ContentName}<br /> <span>{step.UploadedBy}</span></p>
                </div>
              </div>
            </div>
          ))}
        </Slider>
      </div>
    );
    
  };
}

export class EventBasedDashBoardComponents extends Component {
  constructor() {
    super()
    this.state = {
      data: [
        {
          "No": "1",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Today",
          image: image4,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "No": "2",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Yesterday",
          image: image1,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "No": "3",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Yesterday",
          image: image2,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "No": "4",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Yesterday",
          image: image3,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "No": "4",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Yesterday",
          image: image3,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "No": "4",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Yesterday",
          image: image3,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "No": "4",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Yesterday",
          image: image3,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }]
    }
  }



  render() {
    return (
      <div>
        <h3>Upcoming Events <AddBox /></h3>
        <div className='Upcoming_Events'>

          {this.state.data.map(data => (
            // console.log("data.UploadedBy",data.UploadedBy);
            // console.log("data.UploadedBy",data);
            // console.log("data.UploadedBy",data.UploadedBy);
            // console.log("data.UploadedBy",data);
            <Card sx={{ maxWidth: "45%" }}>
              <CardMedia
                component="img"
                height="100"
                image={data.image}
              />
              <CardContent sx={{ padding: "5px" }}>
                <Typography variant="h5" component="div" sx={colorStyle}>
                  {data.No}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {data.EventName}
                </Typography>
              </CardContent>
              <CardActions sx={Space}>
            <a size="small" class="UploadData">{data.Day}</a>
              <a size="small" class="UploadData">{data.UploadedBy}</a>
            </CardActions>
            </Card>
          ))}
        </div>
      </div >
    );
  }

}
