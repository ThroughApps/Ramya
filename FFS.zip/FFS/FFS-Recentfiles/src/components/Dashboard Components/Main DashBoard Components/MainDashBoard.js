//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import '../../Styling Components/TopMenuCSS.css';
import '../../Styling Components/styleCSS.css';
import SliderDashBoardComponents, { EventBasedDashBoardComponents } from './MainDashBoardComponents';
import SideMenuBar from '../../MenuBar/SideMenuBar';

class MainDashBoard extends Component {
    constructor(){
      super();
      this.state = {
      }
 }  

    render(){
      return(
        <div className='container-fluid height_fixed'>
          <div className='row'>
            <div className='col-md-7'>
              <SliderDashBoardComponents />
            </div>
            <div className='col-md-4'>
              <EventBasedDashBoardComponents/>
            </div>
            <div className='col-md-1'>
              <SideMenuBar />
            </div>
          </div>
        </div>
      )
    }
    
    }
export default MainDashBoard;
