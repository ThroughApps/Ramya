//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import '../../Styling Components/TopMenuCSS.css';
import '../../Styling Components/styleCSS.css';
import '../../Styling Components/MainDashBoardCSS.css';
import ReactDOM from "react-dom";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Card from '@mui/material/Card';
import EventBusySharpIcon from '@material-ui/icons/EventBusySharp';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import logo from '../../Images/Cieltextilelogo.png';
import image1 from '../../Images/image1.jpg';
import image2 from '../../Images/image2.jpg';
import image3 from '../../Images/image3.jpg';
import image4 from '../../Images/image4.jpg';
import { AddBox, Person, Favorite } from '@mui/icons-material';
import Slider from "react-slick";
import { CommentParaDisplayComponent } from '../../Assets Components/Input Components/InputComponents';
import { CardActionArea } from 'material-ui-core';
import ButtonBase from '@material-ui/core/ButtonBase';
import { components } from 'react-select';
import $ from 'jquery';
// import ArticleInShortDisplay from '../../View Components/Article/ArticleInShortDisplay';
var settings = {
  dots: true,
  infinite: true,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  slickNext: true,
  slickPrevious: true,
  swipe: true
};
const colorStyle = {
  color: '#689fd5'
}
const Space = {
  padding: "5px",
  justifyContent: "space-between"
}

const Nodataimage_comment = {
  top: "50%",
  left: "50%",
  width: "100%"
}
const Nodataimage_style = {
  transform: "translate(50%, 50%)",
  position: "absolute",
}
export default class SliderDashBoardComponents extends Component {

  constructor(props) {
    super(props)

    this.state = {
      userId: props.userId,
      userName: props.userName,
      articleList: [],
    }
    this.SelectArticleList = this.SelectArticleList.bind(this);
  }
  componentDidMount() {
    this.SelectArticleList();
  }
  /*
FUNCTION USED TO SELECT ARTICLE LIST BASED ON USER LOGIN - 102/26/09/2022
*/
  SelectArticleList() {
    var self = this;

    $.ajax({
      type: "POST",
      contentType: 'application/json',
      dataType: 'json',
      data: JSON.stringify({
        userId: this.state.userId
      }),
      url: "http://15.206.129.105:8080/FastFashionSolutionsAPI/Dashboard/SelectArticles",
      success: function (data) {

        var templist = data.articleList;
        //sorting basd on top likes
        templist = templist.sort((a, b) => b.likesCount - a.likesCount);

        self.state.articleList = templist;

        self.setState({ articleList: self.state.articleList })

      },
      error: function () {
        console.log("error");
      }
    })
  }

  render() {
    /*
    MOVE TO ARTICLE IN SHORT DISPLAY PAGE WHILE SLIDESHOW IMAGE CLICKED - 102/26/09/2022
    */
    const MoveToArticlePage = (data) => {
      ReactDOM.render(
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<ArticleInShortDisplay articleData={data} userId={this.state.userId} userName={this.state.userName} />} />
          </Routes>
        </BrowserRouter>,
        document.getElementById("contentRender")
      )
    }
    return (


      <div className='mt-50'>
        <Slider {...settings} >
          {this.state.articleList.map((data) => (
            <div key={data.title} >
              <img onClick={() => MoveToArticlePage(data)}
                src={data.thumbnailURL}
                alt={data.title}
                style={{
                  // borderRadius: "15px",
                  height: "400px",
                  display: "block",
                  overflow: "hidden",
                  width: "100%"
                }}

              />
              <div className='Slider_Content'>
                <div className='Slider_MainContent'>
                  <h2>{data.title}</h2>
                  <div className='Slider_MainContent'>
                    <a><Person /> {data.viewsCount}</a>
                    <a><Favorite /> {data.likesCount}</a>
                  </div>
                </div>
                <div className='Slider_MainContent'>
                  <p>{data.source}<br /> <span>{data.date}</span></p>
                  <p className='text-right'>{data.articleType}<br /> <span>{data.userName}</span></p>
                </div>
              </div>
            </div>
          ))}
        </Slider>
      </div>
    );

  };
}

export class EventBasedDashBoardComponents extends Component {
  constructor(props) {
    super(props)
    this.state = {
      userId: props.userId,
      data: [],
      /* data: [
         {
           "No": "1",
           "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
           "Day": "Today",
           image: image4,
           "UploadedBy": "Uploaded by Mr.xxxxx",
         }, {
           "No": "2",
           "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
           "Day": "Yesterday",
           image: image1,
           "UploadedBy": "Uploaded by Mr.xxxxx",
         }, {
           "No": "3",
           "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
           "Day": "Yesterday",
           image: image2,
           "UploadedBy": "Uploaded by Mr.xxxxx",
         }, {
           "No": "4",
           "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
           "Day": "Yesterday",
           image: image3,
           "UploadedBy": "Uploaded by Mr.xxxxx",
         }, {
           "No": "4",
           "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
           "Day": "Yesterday",
           image: image3,
           "UploadedBy": "Uploaded by Mr.xxxxx",
         }, {
           "No": "4",
           "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
           "Day": "Yesterday",
           image: image3,
           "UploadedBy": "Uploaded by Mr.xxxxx",
         }, {
           "No": "4",
           "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
           "Day": "Yesterday",
           image: image3,
           "UploadedBy": "Uploaded by Mr.xxxxx",
         }]
         */
    }
  }



  render() {
    return (
      <div>
        <h3>Upcoming Events <AddBox /></h3>
          {(this.state.data.length > 0) ?
            (this.state.data.map(data => (
              <div className='Upcoming_Events'>
              <Card sx={{ maxWidth: "45%" }}>
                <CardMedia
                  component="img"
                  height="100"
                  image={data.image}
                />
                <CardContent sx={{ padding: "5px" }}>
                  <Typography variant="h5" component="div" sx={colorStyle}>
                    {data.No}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {data.EventName}
                  </Typography>
                </CardContent>
                <CardActions sx={Space}>
                  <a size="small" class="UploadData">{data.Day}</a>
                  <a size="small" class="UploadData">{data.UploadedBy}</a>
                </CardActions>
              </Card>
              </div>
            ))) : (
              <div className='d-flex align-items-center justify-content-center height_fixed'> 
                <h6>
                <EventBusySharpIcon style={{ fontSize: 100 }} /><br />No Events
              </h6>
              </div>
            )}       
      </div >
    );
  }

}

