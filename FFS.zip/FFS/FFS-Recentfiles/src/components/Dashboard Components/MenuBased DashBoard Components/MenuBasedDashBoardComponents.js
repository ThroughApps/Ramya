import React, { Component,useState } from 'react';
// import Slider from "react-slick";
import SimpleImageSlider from "react-simple-image-slider";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import image1 from '../../Images/images1.png';
import image2 from '../../Images/image5.jpg';
import image3 from '../../Images/image7.jpg';
import image4 from '../../Images/image8.jpg';
import {AddBox,Person,Favorite} from '@mui/icons-material';
import '../../Styling Components/MainDashBoardCSS.css'
import $ from 'jquery';
import _ from 'underscore';
import { DashboardButtonComponent } from '../../Assets Components/Button Components/ButtonComponents';
import IndustryTrendsDashboard from './IndustryTrendsDashboard';

const images = [
    {
      url:image1,
      Header : "Industry Trends",
      SlideNo:0
    },
    {
      url:image2,
      Header : "Know Your Company",
      SubText: "ARTICLES AND REPORTS | PRESENTATION AND VIDEOS",
      SlideNo:1
    },
    {
      url:image3,
      Header : "Know Your Customer",   
      SubText: "ARTICLES AND REPORTS | PRESENTATION AND VIDEOS",
      SlideNo:2
    },
    {
      url:image4,
      Header : "Other Resources",
    SubText: "ARTICLES AND REPORTS | PRESENTATION AND VIDEOS",
    SlideNo:3
    },
    
  ];


  export class MenuBasedDashBoardSlider extends Component {

    constructor(){
      super();
      this.state = {
        settings : {
          dots: true,
          infinite: true,
          slidesToShow: 1,
          slidesToScroll: 1,
          slickNext: true,
          slickPrevious: true,
         
        },
        menuName:"Industry Trends",
      }
 }
 componentDidMount() {
  // setcurrentPage('Industry Trends');

 }


  handleSlider(idx){
        // alert((idx));
        

        var currentcontent=_.where(images,{SlideNo:idx});
        console.log("currentcontent :",currentcontent);
        this.state.menuName=currentcontent[0].Header;
        this.setState({
          menuName:this.state.menuName
        })
     
      }

      RenderComponenets(menuName) {

        var self = this;

        switch (menuName) {
            case 'Industry Trends':
                return <IndustryTrends/>
            case 'Know Your Company':
                return <KnowYourCompany/>
                case 'Know Your Customer':
                return <KnowYourCustomer/>
                case 'Other Resources':
                return <OtherResource/>
            default:
                return;
        }

    }

      render(){
    return(

      
        <div className='mt-50'>
         
<div class="row">
  <div class="col-md-7" style={{padding:'40px',margin:'auto'}} >
  {this.RenderComponenets(this.state.menuName)}

  </div>
  <div class="col-md-5">
             <SimpleImageSlider 
              width={500}
              height={400}
              images={images} 
              showBullets={true}
              onClickBullets = {(idx) => this.handleSlider(idx) }>
        </SimpleImageSlider>
        </div>

      </div>
      </div>
    );
    }
  };


export class IndustryTrends extends Component {
  constructor() {
      super();
      this.state = {
         
      }
   
  }

  ExploreMore(){
    ReactDOM.render(
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<IndustryTrendsDashboard />} />
          </Routes>
        </BrowserRouter>,
      
        document.getElementById('contentRender'));
  }

  render() {
      return (
        <div class=" "   >
          
            <h1 class="para_head">Industry Trends</h1>
            <p class="para_text">ARTICLES AND REPORTS | PRESENTATION AND VIDEOS</p>
            <DashboardButtonComponent onClick={this.ExploreMore} buttonName="Explore More"/>
            <DashboardButtonComponent buttonName="Add Article/Videos"/>
         
         
          </div>
      )
  }

}

export class KnowYourCompany extends Component {
  constructor() {
      super();
      this.state = {
         
      }
   
  }
  render() {
      return (
          <div>
              <div class=""   >
            <h1 class="para_head">Know Your Company</h1>
            <p class="para_text">FMR (FUTURE MARGIN REPORT) | BILAN</p>
            <DashboardButtonComponent buttonName="Explore More"/>
            <DashboardButtonComponent buttonName="Add Files"/>
          </div>
          </div>
      )
  }

}
export class KnowYourCustomer extends Component {
  constructor() {
      super();
      this.state = {
         
      }
   
  }
  render() {
      return (
          <div>
       <div class=""  >
            <h1 class="para_head">Know Your Customer</h1>
            <p class="para_text">MUTILEVEL ORGANIGRAM | HISTORY OF SALES AND MARGINS</p>
            <DashboardButtonComponent buttonName="Explore More"/>
            <DashboardButtonComponent buttonName="Add Files"/>
          </div>
          </div>
      )
  }

}
export class OtherResource extends Component {
  constructor() {
      super();
      this.state = {
         
      }
   
  }
  render() {
      return (
          <div>
             <div class=""  >
            <h1 class="para_head">Other Resources</h1>
            <p class="para_text">SUSTAINABILITY | MARKETING | TRAINING MATERIALS</p>
            <DashboardButtonComponent buttonName="Explore More"/>
            <DashboardButtonComponent buttonName="Add Files"/>
          </div>
          </div>
      )
  }

}
