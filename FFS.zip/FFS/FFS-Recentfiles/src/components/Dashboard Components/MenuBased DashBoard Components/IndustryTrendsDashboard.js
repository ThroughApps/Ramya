//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import {ImageContentComponent,ArticlesComponent} from './IndustryTrendsDashboardComponents';

export class IndustryTrendsDashboard extends Component { 
  constructor(){
    super();
    this.state = {
    }
}  
render(){
      return(
        <div>
          <ImageContentComponent />
          <ArticlesComponent />
      </div>
)
        }
      }
export default IndustryTrendsDashboard;
