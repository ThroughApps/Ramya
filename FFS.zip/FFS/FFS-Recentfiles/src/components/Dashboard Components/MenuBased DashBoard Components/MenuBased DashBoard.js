import React, { Component,useState } from 'react';
import '../../Styling Components/MainDashBoardCSS.css'
import { MenuBasedDashBoardSlider } from './MenuBasedDashBoardComponents';


class MenuBasedDashboard extends Component {

    render(){
        return(
            <div class="container-fluid">
                <div class="SubDashboard">
               <MenuBasedDashBoardSlider/>
                </div>
            </div>
        );
    }
}
export default MenuBasedDashboard;
