//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import { ArticleDropdownComponent, DropdownComponent, SortByDropdownComponent, SourceDropdownComponent, UploadedByDropdownComponent } from '../../Assets Components/Dropdown Components/DropdownComponent';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import image1 from '../../Images/image1.jpg';
import image2 from '../../Images/image2.jpg';
import image3 from '../../Images/image3.jpg';
import { CancelButtonComponent,PaginationComponent } from '../../Assets Components/Button Components/ButtonComponents';
import AddBulletIn from '../../Add BulletIn/AddBulletIn';
const cardContent = {
  boxShadow: "none",
  width: "60%"
}
const cardimgContent = {
  width: "20%"
}
const Space = {
  padding: "0px",
  justifyContent: "space-between"
}
class AllBulletInComponents extends Component {
  constructor() {
    super();
    this.state = {
      data: [
        {
          "Event": "JUST STYLE - NEWS",
          "EventQues": "Why Lady Gaga’s Haus Beauty Needed a Rebrand",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic Kim Kardashian draws flak for sporting Marilyn Monroe’s iconicKim Kardashian draws flak for sporting Marilyn Monroe’s iconicKim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
          "Day": "Today",
          image: image2,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "Event": "THE ECONOMICS TIMES - REPORTS",
          "EventQues": "Ferragamo’s Plan to Double Sales Under a New",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic ",
          "Day": "Yesterday",
          image: image1,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "Event": "THE ECONOMICS TIMES - REPORTS",
          "EventQues": "Ferragamo’s Plan to Double Sales Under a New",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic ",
          "Day": "Yesterday",
          image: image1,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }, {
          "Event": "FABRIC 2 FASHION - NEWS",
          "EventQues": "Ferragamo’s Plan to Double Sales Under a New",
          "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic ",
          "Day": "Yesterday",
          image: image1,
          "UploadedBy": "Uploaded by Mr.xxxxx",
        }]
    }
  }

  AddBulletInFunc() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AddBulletIn />} />
        </Routes>
      </BrowserRouter>,

      document.getElementById('contentRender'));
  }

  render() {
    return (
      <div className='container'>
        <div className='flex-Mob'>
          <div class="col-md-2">
            <SourceDropdownComponent onChange={this.handleUserSelectSource} value={this.state.source} errorStatus={this.state.sourceErrorStatus} errorMessage={this.state.sourceErrorMessage} label='Source' name='source' disableStatus={false} />
          </div>
          <div class="col-md-3">
            <UploadedByDropdownComponent onChange={this.handleUserSelectUploadedBy} value={this.state.UploadedBy} errorStatus={this.state.UploadedByErrorStatus} errorMessage={this.state.UploadedByErrorMessage} label='Uploaded By' name='UploadedBy' UploadedByMenuItems={this.state.UploadedByMenuItems} disableStatus={false} />
          </div>
          <div class="col-md-2">
            <ArticleDropdownComponent onChange={this.handleUserSelectArticleType} value={this.state.articleType} errorStatus={this.state.articleTypeErrorStatus} errorMessage={this.state.articleTypeErrorMessage} label='ArticleType' name='articleTYpe' disableStatus={false} />
          </div>
          <div class="col-md-2">
            <SortByDropdownComponent onChange={this.handleUserSelectSortby} value={this.state.Sortby} errorStatus={this.state.SortbyErrorStatus} errorMessage={this.state.SortbyErrorMessage} label='Sort by' name='Sortby' disableStatus={false} />
          </div>
          <div class="col-md-2 btn-align">
            <CancelButtonComponent onClick={this.AddBulletInFunc} buttonName="add new bulletin" />
          </div>
        </div>
        <div className='text-right'>
          <PaginationComponent activePage="3" itemsCountPerPage= "12" />
        </div>
        {this.state.data.map(data => (
          <div class="Slider_MainContent AllBulletin">
            <Card sx={cardContent}>
              <CardContent sx={{ padding: "5px" }}>
                <Typography variant="p" component="div">
                  {data.Event}
                </Typography>
                <Typography variant="h5" component="div">
                  {data.EventQues}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {data.EventName}
                </Typography>
              </CardContent>
              <CardActions sx={Space}>
                <a size="small" class="UploadData">{data.Day}</a>
                <a size="small" class="UploadData">{data.UploadedBy}</a>
              </CardActions>
            </Card>
            <CardMedia sx={cardimgContent}
              component="img"
              height="100"
              image={data.image}
            />
          </div>
        ))}
      </div>
    )
  }

}
export default AllBulletInComponents;
