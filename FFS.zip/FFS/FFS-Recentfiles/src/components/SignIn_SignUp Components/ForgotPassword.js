
import React, { Component, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import PasswordStrengthBar from 'react-password-strength-bar';
import $ from 'jquery';
//IMPORT CLASS COMPONENT CSS
import '../Styling Components/SignIn_SignUpCSS.css';
//IMPORT ICON
import { AccountCircle, LockRounded, Email, Smartphone } from '@material-ui/icons';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';
//IMPORT CLASS COMPONENT
import { InstantResponseMessage } from '../Assets Components/Alert Components/Alerts';
import { CapitalCaseFunc, ContactNoValidationFunc, EmailIdValidationFunc, TextLengthFunc } from '../Validation Components/Validation';
import { EmailIdInputTextField, PasswordInputTextField } from '../Assets Components/Input Components/InputComponents';
import { SubmitButtonComponent, LinkButtonComponent } from '../Assets Components/Button Components/ButtonComponents';
import SignIn from './SignIn';

class ForgotPassword extends Component {

    constructor() {
        super()

        this.state = {
            emailId: "",
            newPassword: "",
            confirmPassword: "",

            showconfirmPassword: false,
            shownewPassword: false,

            submitButtonStatus: true,

            instantResponseMessageStatus: false,
        }
    }

    componentDidMount() {

    }

    /*
      FUNCTION USED TO HANDLE EMAIL-ID - 102/10/09/2022
      */
    handleUserInputEmailId = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        this.state.emailId = value;
        this.setState({
            emailId: this.state.emailId
        })
        if (value.length > 0) {
            this.EnableSubmitButton("emailIdValid", true);
        }
        else {
            this.EnableSubmitButton("emailIdValid", false);
        }
    }

    /*
    FUNCTION USED TO HANDLE CONFIRMPASSWORD - 104/11/09/2022
    */
    handleUserInputConfirmPassword = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        this.state.confirmPassword = value;
        this.setState({
            confirmPassword: this.state.confirmPassword
        })

        if (value.length > 0) {
            this.EnableSubmitButton("confirmPasswordValid", true);
        }
        else {
            this.EnableSubmitButton("confirmPasswordValid", false);
        }

    }

    /*
    FUNCTION USED TO HANDLE NEW PASSWORD - 102/10/09/2022
    */
    handleUserInputNewPassword = (e) => {

        const name = e.target.name;
        const value = e.target.value;

        this.state.newPassword = value;
        this.setState({
            newPassword: this.state.newPassword
        })

        if (value.length > 0) {
            this.EnableSubmitButton("newPasswordValid", true);
        }
        else {
            this.EnableSubmitButton("newPasswordValid", false);
        }
    }

    /* 
    FUNCTION USED TO ENABLE SUBMIT BUTTON AFTER SUCCESSFUL FIELD ENTRY - 102/11/09/2022
      */
    EnableSubmitButton(fieldName, status) {

        this.state[fieldName] = status;
        this.setState({
            [fieldName]: this.state[fieldName]
        })
        if (this.state.emailIdValid && this.state.newPasswordValid && this.state.confirmPasswordValid) {
            this.state.submitButtonStatus = false;
        }
        else {
            this.state.submitButtonStatus = true;
        }
        this.setState({ submitButtonStatus: this.state.submitButtonStatus })
    }

    /*
        FUNCTION USED TO SHOW NEW PASSWORD - 104/11/09/2022
        */
    handleClickShowNewPassword = (e) => {
        var passwordInput = document.getElementById('newPassword');
        var passStatus = document.getElementById('togglenewPassword');
        if (passwordInput.type == 'password') {
            passwordInput.type = 'text';
            this.state.shownewPassword = true;
            this.setState({
                shownewPassword: this.state.shownewPassword
            })
        }
        else {
            passwordInput.type = 'password';
            this.state.shownewPassword = false;
            this.setState({
                shownewPassword: this.state.shownewPassword
            })
        }

    }

    /*
  FUNCTION USED TO SHOW CONFIRM  PASSWORD - 104/11/09/2022
  */
    handleClickShowConfirmPassword = (e) => {
        var passwordInput = document.getElementById('confirmPassword');
        var passStatus = document.getElementById('toggleconfirmPassword');
        if (passwordInput.type == 'password') {
            passwordInput.type = 'text';
            this.state.showconfirmPassword = true;
            this.setState({
                showconfirmPassword: this.state.showconfirmPassword
            })
        }
        else {
            passwordInput.type = 'password';
            this.state.showconfirmPassword = false;
            this.setState({
                showconfirmPassword: this.state.showconfirmPassword
            })
        }
    }
    /*
    FUNCTION USED TO ENABLE/DISABLE SUBMIT BTN BASED ON PASSWORD STRENGTH VALIDATOR - 102/10/09/2022
    */
    HandleStrength = (event) => {
        if (event == '4' || event == '3') {
            this.EnableSubmitButton("newPasswordValid", true);
        }
        else {
            this.EnableSubmitButton("newPasswordValid", false);
        }
    }
    /*
    FUNCTION USED TO CLEAR THE FIELDS AFTER RESET THE PASSWORD  - 102/10/09/2022
    */
    ClearFunc() {


        this.state.emailId = "";
        this.state.newPassword = "";
        this.state.confirmPassword = "";
        this.state.submitButtonStatus = true;
        this.state.showconfirmPassword = false;
        this.state.shownewPassword = false;
        this.setState({
            emailId: this.state.emailId,
            newPassword: this.state.newPassword,
            confirmPassword: this.state.confirmPassword,
            submitButtonStatus: this.state.submitButtonStatus,
            showconfirmPassword: this.state.showconfirmPassword,
            shownewPassword: this.state.shownewPassword
        })
    }
    /*
      FUNCTION USED RESET THE PASSWORD  - 102/10/09/2022
      */
    HandleSubmit = () => {
        var self = this;
        //The confirm Password  must match with New Password ."

        if (this.state.newPassword !== this.state.confirmPassword) {

            self.state.messageSeverity = "warning";
            self.state.messageTitle = "Mis-match!";
            self.state.message = "New Password And Confirm Password Should Be Same!";
            self.state.instantResponseMessageStatus = true;

            self.setState({

                messageSeverity: self.state.messageSeverity,
                messageTitle: self.state.messageTitle,
                message: self.state.message,
                instantResponseMessageStatus: self.state.instantResponseMessageStatus
            })
        }
        else {
            $.ajax({
                type: 'POST',
                data: JSON.stringify({
                    emailId: this.state.emailId,
                    password: this.state.newPassword,
                    //confirmPassword:this.state.confirmPassword,
                }),
                contentType: "application/json",
                dataType: 'json',
                url: "http://15.206.129.105:8080/FastFashionSolutionsAPI/SignIn_SignUp/ForgotPassword",
                success: function (data, textStatus, jqXHR) {

                    if (data.response === "Password_Updated") {
                        self.state.messageSeverity = "success";
                        self.state.messageTitle = "Success";
                    }
                    else {
                        //Password_Update_Failed
                        self.state.messageSeverity = "warning";
                        self.state.messageTitle = "Warning";
                    }

                    self.state.messageStatus = true;
                    self.state.message = data.response;
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageStatus: self.state.messageStatus,
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,
                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                    ReactDOM.render(
                        <BrowserRouter>
                            <Routes>
                                <Route path="/" element={<SignIn pageCalledFrom="ForgotPassword" userName={self.state.userName} />} />
                            </Routes>
                        </BrowserRouter>,
                        document.getElementById("root")
                    )
                },
                error: function (data, textStatus, jqXHR) {

                    self.state.messageSeverity = "error";
                    self.state.messageTitle = "Network Error";
                    self.state.message = "There is trouble in connecting you to server, kindly try after sometime";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,
                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                }
            })

        }

        self.ClearFunc();
        HideFieldErroeMsgs('instantResponseMessageStatus', this);
    }
    handleuserBackButton() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<SignIn />} />
                </Routes>
            </BrowserRouter>,

            document.getElementById('root'));
    }


    render() {
        return (
            <div className="SignIn_Bg">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">
                            <div className='SignIn_Logo'>
                                <img src={logo} />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div class="SignIn_InBox">
                                <div className=" text-center">
                                    <div class="Bg_Img">

                                        <h1 >Welcome</h1>
                                    </div>
                                    <div class="inputField-components">

                                        {/* FIELD USED TO GET EMAIL - IT'S MANDATORY FIELD  */}
                                        <EmailIdInputTextField onChange={this.handleUserInputEmailId} value={this.state.emailId} label='EmailId' name='emailid' errorStatus={this.state.emailIdErrorStatus} errorMessage={this.state.emailIdErrorMessage} iconStart={<Email />} />
                                        {/* FIELD USED TO GET NEW PASSWORD - IT'S MANDATORY FIELD  */}
                                        <PasswordInputTextField errorStatus={this.state.passwordErrorStatus} id="newPassword" errorMessage={this.state.passwordErrorMessage} onChange={this.handleUserInputNewPassword} value={this.state.newPassword} label='New Password' name='newPassword'
                                            iconStart={<LockRounded />} iconEnd={this.state.shownewPassword ? <Visibility onClick={this.handleClickShowNewPassword} id="togglenewpassword" /> : <VisibilityOffIcon onClick={this.handleClickShowNewPassword} id="togglenewpassword" />} />
                                        <div class="password-meter" >
                                            <PasswordStrengthBar password={this.state.newPassword} onChangeScore={(event) => this.HandleStrength(event)} />
                                        </div>
                                        {/* FIELD USED TO GET CONFIRM PASSWORD - IT'S MANDATORY FIELD  */}
                                        <PasswordInputTextField errorStatus={this.state.passwordErrorStatus} id="confirmPassword"
                                            errorMessage={this.state.passwordErrorMessage} onChange={this.handleUserInputConfirmPassword} value={this.state.confirmPassword} label='Confirm Password' name='confirmPassword'
                                            iconEnd={this.state.showconfirmPassword ? <Visibility onClick={this.handleClickShowConfirmPassword} id="toggleconfirmPassword" /> : <VisibilityOffIcon onClick={this.handleClickShowConfirmPassword} id="toggleconfirmPassword" />} />
                                        {/* BUTTON USED TO SIGNUP - IT'S MANDATORY FIELD  */}
                                        <SubmitButtonComponent onClick={this.HandleSubmit} buttonStatus={this.state.submitButtonStatus} buttonName={"Submit"} />
                                        {this.state.instantResponseMessageStatus ? <InstantResponseMessage messageTitle={this.state.messageTitle} message={this.state.message}
                                            severity={this.state.messageSeverity} /> : ''}
                                        <br />
                                        <LinkButtonComponent onClick={this.handleuserBackButton} buttonName={"Back to SignIn"} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}
export default ForgotPassword;

/*
USED FOR RESETTING THE INSTANT RESPONSE TO INITIAL STATE AFTER FEW SECONDS - 101/07/09/2022
*/
function HideFieldErroeMsgs(stateName, currentState) {
    setTimeout(function () {
        var self = currentState;
        self.state[stateName] = false;
        self.setState({
            [stateName]: self.state[stateName]
        })
    }, 4000);
}




