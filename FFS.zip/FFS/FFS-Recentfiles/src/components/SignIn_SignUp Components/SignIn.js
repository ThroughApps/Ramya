//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import PasswordStrengthBar from 'react-password-strength-bar';
import $ from 'jquery';
//IMPORT CLASS COMPONENT CSS
import '../Styling Components/SignIn_SignUpCSS.css';
//IMPORT CLASS COMPONENT
import { SubmitButtonComponent } from '../Assets Components/Button Components/ButtonComponents';
import { UserNameInputTextField, PasswordInputTextField } from '../Assets Components/Input Components/InputComponents';
import { CapitalCaseFunc, PasswordValidationFunc, TextLengthFunc } from '../Validation Components/Validation';
import { InstantResponseMessage } from '../Assets Components/Alert Components/Alerts';
//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';
import SignUp from '../SignIn_SignUp Components/SignUp';
import { AccountCircle, LockRounded } from '@material-ui/icons';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import ForgotPassword from '../SignIn_SignUp Components/ForgotPassword';
import MainDashBoardComponents from '../Dashboard Components/Main DashBoard Components/MainDashBoardComponents';
import TopMenu from '../MenuBar/TopMenu';

class SignIn extends Component {

    constructor(props) {
        super(props)

        this.state = {
            userName: "",
            password: "",
            showPassword: false,
            submitButtonStatus: true,

            userNameValid: false,
            passwordValid: false,

            messageTitle: "",
            message: "",
            messageSeverity: "",
            messageStatus: false,

            userId: "",
        }
        this.SignIn = this.SignIn.bind(this);
        this.EnableSubmitButton = this.EnableSubmitButton.bind(this);
        this.ClearFunc = this.ClearFunc.bind(this);

    }

    componentDidMount() {

        /*
        RENDERING THE SUCCESS MESSAGE IMMEDIATELY AFTER RETURNING FROM SUCCESSFUL SIGNUP
        */
        if (this.props.pageCalledFrom != undefined) {
            if (this.props.pageCalledFrom == "SignUp") {
                this.state.messageSeverity = "success";
                this.state.messageTitle = "Success";
                this.state.message = "Hi, " + this.props.userName + " you have successfully completed the signup";
                this.state.instantResponseMessageStatus = true;

                this.setState({
                    messageSeverity: this.state.messageSeverity,
                    messageTitle: this.state.messageTitle,
                    message: this.state.message,

                    instantResponseMessageStatus: this.state.instantResponseMessageStatus
                })

                HideFieldErroeMsgs('instantResponseMessageStatus', this);

            } else if (this.props.pageCalledFrom == "ForgotPassword") {
                this.state.messageSeverity = "success";
                this.state.messageTitle = "Success";
                this.state.message = "Hi, your password has been updated successfully. Try login with new password";
                this.state.instantResponseMessageStatus = true;

                this.setState({
                    messageSeverity: this.state.messageSeverity,
                    messageTitle: this.state.messageTitle,
                    message: this.state.message,

                    instantResponseMessageStatus: this.state.instantResponseMessageStatus
                })

                HideFieldErroeMsgs('instantResponseMessageStatus', this);

            }
        }
    }
    /*
    FUNCTION USED TO HANDLE USER NAME - 103/07/09/2022
    */
    handleUserInputUserName = (e) => {
        const value = e.target.value;

        // var camelcaseData = CapitalCaseFunc(value);
        this.state.userName = value;

        this.setState({ userName: this.state.userName })

        if (value.length > 0) {
            this.EnableSubmitButton("userNameValid", true);
        }
        else {
            this.EnableSubmitButton("userNameValid", false);
        }
    }

    /*
    FUNCTION USED TO HANDLE PASSWORD - 102/07/09/2022
    */
    handleUserInputPassword = (e) => {

        const value = e.target.value;

        this.state.password = value;

        this.setState({
            password: this.state.password
        })

        if (value.length > 0) {
            this.EnableSubmitButton("passwordValid", true);
        }
        else {
            this.EnableSubmitButton("passwordValid", false);
        }

    }

    /*
     FUNCTION USED TO ENABLE SUBMIT BUTTON AFTER SUCCESSFUL FIELD ENTRY - 101/07/09/2022
     */
    EnableSubmitButton(fieldName, status) {


        this.state[fieldName] = status;
        this.setState({
            [fieldName]: this.state[fieldName]
        })

        if (this.state.userNameValid && this.state.passwordValid) {
            this.state.submitButtonStatus = false;
        }
        else {
            this.state.submitButtonStatus = true;
        }

        this.setState({
            submitButtonStatus: this.state.submitButtonStatus
        })

    }

    /*
 FUNCTION USED TO HANDLE PASSWORD TO SHOW AND HIDE WHENEVER IT IS NECCESSARY - 103/09/09/2022
 */
    handleClickShowPassword = (e) => {
        var passwordInput = document.getElementById('password');
        var passStatus = document.getElementById('togglePassword');
        if (passwordInput.type == 'password') {
            passwordInput.type = 'text';
            this.state.showPassword = true;
            this.setState({
                showPassword: this.state.showPassword
            })
        }
        else {
            passwordInput.type = 'password';
            this.state.showPassword = false;
            this.setState({
                showPassword: this.state.showPassword
            })
        }

    }

    /*
     FUNCTION USED TO SEND DATA TO BACKEND - 101/07/09/2022
     */
    SignIn() {

        var self = this;

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                emailId: this.state.userName,
                password: this.state.password
            }),
            contentType: "application/json",
            dataType: 'json',
            url: "http://15.206.129.105:8080/FastFashionSolutionsAPI/SignIn_SignUp/SignIn",
            success: function (data, textStatus, jqXHR) {

                if (data.response === "Login_Success") {

                    self.state.userId = data.userId;
                    self.state.messageStatus = true;
                    self.state.messageSeverity = "success";
                    self.state.messageTitle = "Success";
                    self.state.message = "Hi, " + data.userName + " welcome to Ceil Textile";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        userId: self.state.userId,
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,
                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                    ReactDOM.render(
                        <BrowserRouter>
                            <Routes>
                                <Route path="/" element={<TopMenu />} />
                                <Route path="/" element={<MainDashBoardComponents />} />
                            </Routes>
                        </BrowserRouter>,
                        document.getElementById("root")
                    )


                } else if (data.response == "Password_Mismatch") {

                    self.state.messageStatus = true;
                    self.state.messageSeverity = "warning";
                    self.state.messageTitle = "Warning";
                    self.state.message = "Hi, your password is not matched";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageStatus: self.state.messageStatus,
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,

                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })
                } else if (data.response == "Not_Registered") {

                    self.state.messageStatus = true;
                    self.state.messageSeverity = "warning";
                    self.state.messageTitle = "Warning";
                    self.state.message = "Hi, the emai-id you are trying to signin is not registered";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageStatus: self.state.messageStatus,
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,

                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })
                }


            },
            error: function (data, textStatus, jqXHR) {

                self.state.messageSeverity = "error";
                self.state.messageTitle = "Network Error";
                self.state.message = "There is trouble in connecting you to server, kindly try after sometime";
                self.state.instantResponseMessageStatus = true;

                self.setState({
                    messageSeverity: self.state.messageSeverity,
                    messageTitle: self.state.messageTitle,
                    message: self.state.message,

                    instantResponseMessageStatus: self.state.instantResponseMessageStatus
                })
            }
        })

        this.ClearFunc();
        HideFieldErroeMsgs('instantResponseMessageStatus', self);

    }
    /*
      FUNCTION USED TO GO FORGOT PASSWORD PAGE WHENEVER CLICK FORGOT PASSWORD - 103/08/09/2022
      */
    ForgotPassword() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<ForgotPassword />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("root")
        )
    }
    /*
     FUNCTION USED TO GO SIGNUP PAGE WHENVER CLICK SIGNUP - 103/08/09/2022
     */
    SignUp() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<SignUp />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("root")
        )
    }
    /*
   FUNCTION USED TO CLEAR THE FIELDS AFTER SUCCESSFUL SIGNIN - 102/07/09/2022
   */
    ClearFunc() {
        this.state.userName = "";
        this.state.password = "";

        this.state.submitButtonStatus = true;

        this.state.userNameValid = false;
        this.state.passwordValid = false;

        this.setState({
            userName: this.state.userName,
            password: this.state.password,

            submitButtonStatus: this.state.submitButtonStatus,

            userNameValid: this.state.userNameValid,
            passwordValid: this.state.passwordValid,
        })
    }

    render() {

        return (
            <div className="SignIn_Bg">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">
                            <div className='SignIn_Logo'>
                                <img src={logo} />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="SignIn_InBox">
                                <div className="text-center">
                                    <div class="Bg_Img">
                                        <h1>Welcome</h1>
                                    </div>

                                    {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
                                    <UserNameInputTextField errorStatus={this.state.userNameErrorStatus} errorMessage={this.state.userNameErrorMessage} onChange={this.handleUserInputUserName} value={this.state.userName} label='User Name' name='userName' iconStart={<AccountCircle />} />
                                    {/* FIELD USED TO GET PASSWORD - IT'S MANDATORY FIELD  */}
                                    <PasswordInputTextField errorStatus={this.state.passwordErrorStatus} errorMessage={this.state.passwordErrorMessage} onChange={this.handleUserInputPassword} value={this.state.password} label='Password' name='password' iconStart={<LockRounded />} id="password"
                                        iconEnd={this.state.showPassword ? <Visibility onClick={this.handleClickShowPassword} id="togglepassword" /> : <VisibilityOff onClick={this.handleClickShowPassword} id="togglepassword" />} />
                                    <SubmitButtonComponent onClick={this.SignIn} buttonStatus={this.state.submitButtonStatus} buttonName={"SignIn"} />
                                    {this.state.instantResponseMessageStatus ? <InstantResponseMessage messageTitle={this.state.messageTitle} message={this.state.message}
                                        severity={this.state.messageSeverity} /> : ``}  </div>

                                <div className='SignIn_BotBontent'>
                                    <a onClick={() => this.ForgotPassword()}>Forgot Your Password?</a>
                                    <a onClick={() => this.SignUp()}>Sign Up</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default SignIn;

/*
USED FOR RESETTING THE INSTANT RESPONSE TO INITIAL STATE AFTER FEW SECONDS - 101/08/09/2022
*/
function HideFieldErroeMsgs(stateName, currentState) {
    setTimeout(function () {
        var self = currentState;
        self.state[stateName] = false;
        self.setState({
            [stateName]: self.state[stateName]
        })
    }, 4000);
}
