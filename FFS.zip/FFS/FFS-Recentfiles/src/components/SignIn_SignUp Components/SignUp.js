//IMPORT STATEMENTS FOR REACT COMPONENT
import { Button } from '@mui/material';
import React, { lazy, Component, Suspense } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import $ from 'jquery';
import PasswordStrengthBar from 'react-password-strength-bar';

//IMPORT MATERIAL-UI ICON
import Visibility from '@mui/icons-material/Visibility';
import { AccountCircle, LockRounded, Email, Smartphone } from '@material-ui/icons';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

//IMPORT STATEMENTS FOR CLASS COMPONENTS
import InstantMessage, { InstantResponseMessage } from '../Assets Components/Alert Components/Alerts';
import { SubmitButtonComponent, LinkButtonComponent } from '../Assets Components/Button Components/ButtonComponents';
import { ContactNoInputTextField, EmailIdInputTextField, PasswordInputTextField, UserNameInputTextField } from '../Assets Components/Input Components/InputComponents';
import { CapitalCaseFunc, ContactNoValidationFunc, EmailIdValidationFunc, TextLengthFunc } from '../Validation Components/Validation';


//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';

//IMPORT STATEMENTS FOR CSS COMPONENTS
import '../Styling Components/SignIn_SignUpCSS.css';
import SignIn from './SignIn';




class SignUp extends Component {

    constructor() {
        super()

        this.state = {
            userName: "",
            emailId: "",
            contactNo: "",
            password: "",

            userNameErrorStatus: false,
            emailIdErrorStatus: false,
            contactNoErrorStatus: false,
            passwordErrorStatus: false,

            userNameErrorMessage: "",
            emailIdErrorMessage: "",
            contactNoErrorMessage: "",
            passwordErrorMessage: "",

            submitButtonStatus: true,

            userNameValid: false,
            emailIdValid: false,
            contactNoValid: false,
            passwordValid: false,

            messageTitle: "",
            message: "",
            messageSeverity: "",

            instantResponseMessageStatus: false,
        }

        this.EnableErrorMessage = this.EnableErrorMessage.bind(this);
        this.DisableErrorMessage = this.DisableErrorMessage.bind(this);
        this.EnableSubmitButton = this.EnableSubmitButton.bind(this);
        this.ClearFunc = this.ClearFunc.bind(this);
        this.SignUp = this.SignUp.bind(this);
    }

    /*
    FUNCTION USED TO HANDLE USER NAME - 101/07/09/2022
    */
    handleUserInputUserName = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        var camelcaseData = CapitalCaseFunc(value);
        var lengthValidation = TextLengthFunc(camelcaseData, 75);

        if (lengthValidation == true) {
            this.state.userName = camelcaseData;
            this.setState({
                userName: this.state.userName,
            })
            this.DisableErrorMessage('userNameErrorStatus', false, '', 'userNameErrorMessage');
            this.EnableSubmitButton("userNameValid", true);
        } else {
            this.EnableErrorMessage('userNameErrorStatus', true, 'User Name length Exceeds', 'userNameErrorMessage');
            this.EnableSubmitButton("userNameValid", false);
        }


    }

    /*
   FUNCTION USED TO HANDLE EMAIL-ID - 101/07/09/2022
   */
    handleUserInputEmailId = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        this.state.emailId = value;
        this.setState({
            emailId: this.state.emailId,
        })
        var emailIdValidation = EmailIdValidationFunc(value);
        if (emailIdValidation == true) {
            this.DisableErrorMessage('emailIdErrorStatus', false, '', 'emailIdErrorMessage');
            this.EnableSubmitButton("emailIdValid", true);
        } else {
            this.EnableErrorMessage('emailIdErrorStatus', true, 'Invalid EmailId', 'emailIdErrorMessage');
            this.EnableSubmitButton("emailIdValid", false);
        }

    }

    /*
   FUNCTION USED TO HANDLE CONTACTNO - 101/07/09/2022
   */
    handleUserInputContactNo = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        this.state.contactNo = value;
        this.setState({
            contactNo: this.state.contactNo
        })
        var contactNoValidation = ContactNoValidationFunc(value);
        if (contactNoValidation == true) {
            this.DisableErrorMessage('contactNoErrorStatus', false, '', 'contactNoErrorMessage');
            this.EnableSubmitButton("contactNoValid", true);
        } else {
            this.EnableErrorMessage('contactNoErrorStatus', true, 'Incorrect ContactNo', 'contactNoErrorMessage');
            this.EnableSubmitButton("contactNoValid", false);
        }
    }

    /*
   FUNCTION USED TO HANDLE PASSWORD - 101/07/09/2022
   */
    handleUserInputPassword = (e) => {
        const name = e.target.name;
        const value = e.target.value;

        //  var camelcaseData = CapitalCaseFunc(value);
        this.state.password = value;
        this.setState({
            password: this.state.password
        })
        this.DisableErrorMessage('passwordErrorStatus', false, '', 'passwordErrorMessage');

        this.EnableSubmitButton("passwordValid", true);
    }

    /*
  FUNCTION USED TO DISABLE ERROR MESSAGE - 101/07/09/2022
  */
    DisableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    /*
  FUNCTION USED TO ENABLE ERROR MESSAGE - 101/07/09/2022
  */
    EnableErrorMessage(errorstatusName, status, errorMessage, errorMessageName) {
        this.state[errorstatusName] = status;
        this.state[errorMessageName] = errorMessage;
        this.setState({
            [errorstatusName]: this.state[errorstatusName],
            [errorMessageName]: this.state[errorMessageName],
        })
    }

    /*
   FUNCTION USED TO CLEAR THE FIELDS AFTER SUCCESSFUL SIGNUP - 101/07/09/2022
   */
    ClearFunc() {

        this.state.userName = "";
        this.state.emailId = "";
        this.state.contactNo = "";
        this.state.password = "";

        this.state.userNameErrorStatus = false;
        this.state.emailIdErrorStatus = false;
        this.state.contactNoErrorStatus = false;
        this.state.passwordErrorStatus = false;

        this.state.userNameErrorMessage = "";
        this.state.emailIdErrorMessage = "";
        this.state.contactNoErrorMessage = "";
        this.state.passwordErrorMessage = "";

        this.state.submitButtonStatus = true;

        this.state.userNameValid = false;
        this.state.emailIdValid = false;
        this.state.contactNoValid = false;
        this.state.passwordValid = false;


        this.setState({
            userName: this.state.userName,
            emailId: this.state.emailId,
            contactNo: this.state.contactNo,
            password: this.state.password,

            userNameErrorStatus: this.state.userNameErrorStatus,
            emailIdErrorStatus: this.state.emailIdErrorStatus,
            contactNoErrorStatus: this.state.contactNoErrorStatus,
            passwordErrorStatus: this.state.passwordErrorStatus,

            userNameErrorMessage: this.state.userNameErrorMessage,
            emailIdErrorMessage: this.state.emailIdErrorMessage,
            contactNoErrorMessage: this.state.contactNoErrorMessage,
            passwordErrorMessage: this.state.passwordErrorMessage,

            submitButtonStatus: this.state.submitButtonStatus,

            userNameValid: this.state.userNameValid,
            emailIdValid: this.state.emailIdValid,
            contactNoValid: this.state.contactNoValid,
            passwordValid: this.state.passwordValid,

        })
    }

    /*
   FUNCTION USED TO ENABLE SUBMIT BUTTON AFTER SUCCESSFUL FIELD ENTRY - 101/07/09/2022
   */
    EnableSubmitButton(fieldName, status) {


        this.state[fieldName] = status;
        this.setState({
            [fieldName]: this.state[fieldName]
        })

        if (this.state.userNameValid == true && this.state.emailIdValid == true && this.state.contactNoValid == true &&
            this.state.passwordValid == true) {
            this.state.submitButtonStatus = false;
            this.setState({
                submitButtonStatus: this.state.submitButtonStatus
            })
        } else {
            this.state.submitButtonStatus = true;
            this.setState({
                submitButtonStatus: this.state.submitButtonStatus
            })
        }
    }

    /*
   FUNCTION USED TO HANDLE PASSWORD TO SHOW AND HIDE WHENEVER IT IS NECCESSARY - 103/09/09/2022
   */
    handleClickShowPassword = (e) => {
        var passwordInput = document.getElementById('password');
        var passStatus = document.getElementById('togglePassword');
        if (passwordInput.type == 'password') {
            passwordInput.type = 'text';
            this.state.showPassword = true;
            this.setState({
                showPassword: this.state.showPassword
            })
        }
        else {
            passwordInput.type = 'password';
            this.state.showPassword = false;
            this.setState({
                showPassword: this.state.showPassword
            })
        }

    }

    handleuserBackButton() {
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<SignIn />} />
                </Routes>
            </BrowserRouter>,

            document.getElementById('root'));
    }


    /*
  FUNCTION USED TO SEND DATA TO BACKEND - 101/07/09/2022 
  UPDATED WITH AJAX CALL - 101/08/09/2022
  */
    SignUp() {

        var self = this;

        $.ajax({
            type: 'POST',
            data: JSON.stringify({
                userName: this.state.userName,
                emailId: this.state.emailId,
                contactNo: this.state.contactNo,
                password: this.state.password
            }),

            url: "http://15.206.129.105:8080/FastFashionSolutionsAPI/SignIn_SignUp/SignUp",
            contentType: "application/json",
            dataType: 'json',
            async: false,
            success: function (data, textStatus, jqXHR) {


                if (data.response == "SignUp_Success") {
                    self.state.messageSeverity = "success";
                    self.state.messageTitle = "Success";
                    self.state.message = "Hi, " + self.state.userName + " you have successfully completed the signup";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,

                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                    ReactDOM.render(
                        <BrowserRouter>
                            <Routes>
                                <Route path="/" element={<SignIn pageCalledFrom="SignUp" userName={self.state.userName} />} />
                            </Routes>
                        </BrowserRouter>,
                        document.getElementById("root")
                    )
                    self.ClearFunc();

                } else if (data.response == "Failed") {

                    self.state.messageSeverity = "warning";
                    self.state.messageTitle = "Warning";
                    self.state.message = "SignUp failed, kindly try after sometime";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,

                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })

                } else if (data.response == "Already_Exist") {
                    self.state.messageSeverity = "warning";
                    self.state.messageTitle = "Warning";
                    self.state.message = "Email-Id or Contactno already exist";
                    self.state.instantResponseMessageStatus = true;

                    self.setState({
                        messageSeverity: self.state.messageSeverity,
                        messageTitle: self.state.messageTitle,
                        message: self.state.message,

                        instantResponseMessageStatus: self.state.instantResponseMessageStatus
                    })
                }

                HideFieldErroeMsgs('instantResponseMessageStatus', self);

            },
            error: function (data) {

                self.state.messageSeverity = "error";
                self.state.messageTitle = "Network Error";
                self.state.message = "There is trouble in connecting you to server, kindly try after sometime";
                self.state.instantResponseMessageStatus = true;

                self.setState({
                    messageSeverity: self.state.messageSeverity,
                    messageTitle: self.state.messageTitle,
                    message: self.state.message,

                    instantResponseMessageStatus: self.state.instantResponseMessageStatus
                })

                HideFieldErroeMsgs('instantResponseMessageStatus', self);
            },

        });

    }

    render() {
        return (
            <div className="SignIn_Bg">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">
                            <div className='SignIn_Logo'>
                                <img src={logo} />
                            </div>
                        </div>

                        <div className="col-md-4">
                            <div class="SignIn_InBox">
                                <div className=" text-center">
                                    <div class="Bg_Img">
                                        <h1 class="te">Welcome</h1>
                                    </div>
                                    <div class="inputField-components">
                                        {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}

                                        <UserNameInputTextField onChange={this.handleUserInputUserName} value={this.state.userName} errorStatus={this.state.userNameErrorStatus} errorMessage={this.state.userNameErrorMessage} label='User Name' name='userName' iconStart={<AccountCircle />} />


                                        <EmailIdInputTextField onChange={this.handleUserInputEmailId} value={this.state.emailId} errorStatus={this.state.emailIdErrorStatus} errorMessage={this.state.emailIdErrorMessage} label='EmailId' name='emailid' iconStart={<Email />} />
                                        <ContactNoInputTextField onChange={this.handleUserInputContactNo} value={this.state.contactNo} errorStatus={this.state.contactNoErrorStatus} errorMessage={this.state.contactNoErrorMessage} label='ContactNo' name='contactNo' iconStart={<Smartphone />} />

                                        {/*  <PasswordInputTextField onChange={this.handleUserInputPassword} value={this.state.password} errorStatus={this.state.passwordErrorStatus} errorMessage={this.state.passwordErrorMessage} label='Password' name='password' iconStart="" />
                                        */}

                                        {/*  <PasswordInputTextField errorStatus={this.state.passwordErrorStatus} id="password" errorMessage={this.state.passwordErrorMessage} onChange={this.handleUserInputPassword} value={this.state.password} label='Password' name='password' iconStart={<LockRounded aria-label="toggle password visibility" onClick={this.handleClickShowPassword} />}
                                            iconEnd={<Visibility onClick={this.handleClickShowPassword} id="togglepassword" />} />
                                    */}

                                        <PasswordInputTextField errorStatus={this.state.passwordErrorStatus}
                                            id="password"
                                            errorMessage={this.state.passwordErrorMessage} onChange={this.handleUserInputPassword} value={this.state.password} label='Password' name='password' iconStart={<LockRounded />}
                                            iconEnd={this.state.showPassword ? <Visibility onClick={this.handleClickShowPassword} id="togglepassword" /> : <VisibilityOff onClick={this.handleClickShowPassword} id="togglepassword" />} />

                                        <div class="password-meter" >
                                            <PasswordStrengthBar password={this.state.password} />
                                        </div>
                                        <SubmitButtonComponent onClick={this.SignUp} buttonStatus={this.state.submitButtonStatus} buttonName={"SignUp"} />

                                        {this.state.instantResponseMessageStatus ? <InstantResponseMessage messageTitle={this.state.messageTitle} message={this.state.message}
                                            severity={this.state.messageSeverity} /> : ``}

                                        <h4 class="back-button">Already a User? <LinkButtonComponent onClick={this.handleuserBackButton} buttonName={"SignIn"} /> </h4>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}
export default SignUp;

/*
USED FOR RESETTING THE INSTANT RESPONSE TO INITIAL STATE AFTER FEW SECONDS - 101/08/09/2022
*/
function HideFieldErroeMsgs(stateName, currentState) {
    setTimeout(function () {
        var self = currentState;
        self.state[stateName] = false;
        self.setState({
            [stateName]: self.state[stateName]
        })
    }, 4000);
}
