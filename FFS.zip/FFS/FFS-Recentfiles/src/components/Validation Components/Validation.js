//IMPORT STATEMENTS FOR REACT COMPONENT
import { titleCase } from "title-case";

/*
FUNCTION USED TO CONVERT THE 
ENTERED TEXT INTO CAMEL CASE - 101/07/09/2022
*/
export const CapitalCaseFunc = function (textValue) {

    var lowerval = textValue.toLowerCase();
    var capitalCase = titleCase(lowerval);

    return capitalCase;

}

/*
FUNCTION USED TO CHECK LENGTH OF THE TEXT 
ENTERED - 101/07/09/2022 
*/
export const TextLengthFunc = function (textValue, lengthValue) {

    var lengthValidationData = false;
    if (textValue.length <= lengthValue) {
        lengthValidationData = true;
    }
    return lengthValidationData;

}

/*
FUNCTION USED TO CHECK CONTACTNO
ENTERED - 101/07/09/2022 
*/
export const ContactNoValidationFunc = function (contactNo) {

    var validationData = false;

    var contactNoRegExp = /^\d{10}$/;
    if ((contactNo.match(contactNoRegExp))) {
        validationData = true;
    }
    return validationData;

}

/*
FUNCTION USED TO CHECK EMAILID
ENTERED - 101/07/09/2022 
*/
export const EmailIdValidationFunc = function (emailId) {

    var validationData = false;

    var emailIdRegExp = /^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i;
    if ((emailId.match(emailIdRegExp))) {
        validationData = true;
    }

    return validationData;

}
