//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import '../Styling Components/TopMenuCSS.css';
import '../Styling Components/styleCSS.css'
// import {CancelButtonComponent,SaveButtonComponent} from '../Assets Components/ButtonComponents/ButtonComponents';
// import AddBulletin from '../Add BulletIn/AddBulletin.js';
import $ from "jquery";
import { Facebook, LinkedIn, YouTube } from '@mui/icons-material';
import { AccountCircle, InsertLink, Assessment,Menu, PowerSettingsNew} from '@mui/icons-material';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ModeCommentIcon from '@mui/icons-material/ModeComment';
import '../Styling Components/ActivityComponentStyles.css'
import NotificationComponent from '../Activity Components/Notification Components/Notification Component';
//import DashboardCommentComponent from '../Activity Components/Comments Components/Comment Component';
// import GlobalSearch from '../Global Search/GlobalSearch';
//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';
// import {SelectTextField} from '../Assets Components/InputComponents/InputComponents';
import { MenuItem } from '@mui/material';
import SideMenuBar from './SideMenuBar';
import SignIn from '../SignIn_SignUp Components/SignIn';
import MainDashBoard from '../Dashboard Components/Main DashBoard Components/MainDashBoard';
import MenuBasedDashboard from '../Dashboard Components/MenuBased DashBoard Components/MenuBased DashBoard';
// import { QuickLink } from '../Activity Components/QuickLink Components/QuickLinkComponent';
import AllBulletIn from '../View Components/BulletIn/AllBulletIn';
// import { GetUserInfo } from '../Common Components/CommonFunctionalComponents';

class TopMenu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userId: props.userId,
      anchorEl: null,
    }
    this.DashboardPage = this.DashboardPage.bind(this);
    this.IndustryTrendsMenuFunc = this.IndustryTrendsMenuFunc.bind(this);
  }


  SideMenuBar() {
    //console.log("3333");
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SideMenuBar userId={this.state.userId} />} />
        </Routes>
      </BrowserRouter>,

      document.getElementById('contentRender'));

  }
  componentDidMount() {

    /* ONCLICK ON ANYWHERE OUTSIDE THE PAGE */
    $("#contentRender").click(function () {
      // alert("CONTENT RENDER");
      $("#notification_sec").hide(); // WHEN COMMENT ICON CLICK NOTIFICATION GET HIDE
      $("#like_sec").hide();
      $("#comment_sec").hide(); // WHEN COMMENT ICON CLICK COMMENT GET HIDE // WHEN COMMENT ICON CLICK LIKE GET HIDE
      $("#quickLink_sec").hide(); // WHEN COMMENT ICON CLICK COMMENT GET HIDE // WHEN COMMENT ICON CLICK LIKE GET HIDE

    })

    /*
USED TO SHOW THE HIDDEN CONTENTS MENU WHILE CLICKING THE HAMBURGER IN MOBILE VIEW
- IMPLEMENTED BY 103 - 13-09-2022
*/
    $(document).ready(function () {
      $(".menuIcon").click(function () {
        $(".TopMenu_Second").toggleClass("active");
      })
      $("#contentRender").click(function () {
        $(".TopMenu_Second").removeClass("active");
      })
      $("#profile").click(function () {
        $(".Submenu").toggleClass("active");
      })
      $("#contentRender").click(function () {
        $(".Submenu").removeClass("active");
      })
      $(".Menu-link").click(function () {
        $(".TopMenu_Second").removeClass("active");
      })
    });

    alert("userId :" + this.state.userId);
    console.log("**** TOP MENU userinfo :", this.state.userId);


  }

  IndustryTrendsMenuFunc() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MenuBasedDashboard userId={this.state.userId} />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    )
  }

      /*
USED TO logout the page - IMPLEMENTED BY 103 - 30-09-2022
*/
  LogOut(){
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SignIn />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("root")
    )
  }

  DashboardPage() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MainDashBoard userId={this.state.userId} />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    )
  }

  ReportArchiveFunc() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AllBulletIn userId={this.state.userId} />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    )
  }

  QuickLinksMenuOpen() {
    document.getElementById("quickLink_sec").style.display = "block";
  }
  handleClick = event => this.setState({ anchorEl: event.currentTarget })
  handleClose = () => this.setState({ anchorEl: null })
  render() {  
    return (
      <div className='wrapper'>
        <div className="TopMenu" id="menus" onClick={this.closeOption}>
          <div className="container-fluid TopMenu_First">
            <div className='TopMenu_Logo'  >
              <img src={logo} onClick={this.DashboardPage} />
            </div>
            <div></div>
            <ul className="TopMenu_RightContent">
              <li className='MobileView icon'><InsertLink /></li>
              <li className='MobileView icon'><Assessment /></li>
              <li className='DesktopView' onClick={this.ReportArchiveFunc}>Report Archives</li>
              {/*<li className='DesktopView' onClick={this.QuickLinsFunc}>Quick Links</li> */}
              <li className="DesktopView" onClick={() => this.QuickLinksMenuOpen()} >Quick Links</li>

              <li className='icon'><AccountCircle aria-controls="demo-customized-button"
        aria-haspopup="true" onClick={this.handleClick}/>
              </li>
                        <MenuItem
        id="demo-customized-button"
        anchorEl={this.state.anchorEl}
        open={Boolean(this.state.anchorEl)}
        onClose={this.handleClose}
      >
        <MenuItem onClick={this.handleClose}>
        <PowerSettingsNew />
          LogOut
        </MenuItem>
      </MenuItem>
            </ul>

            <div className='MobileView menuIcon'>
              <Menu />
            </div>
          </div>  
          <ul className="TopMenu_Second">
            <li className='Menu-link' onClick={this.IndustryTrendsMenuFunc}>INDUSTRY TRENDS</li>
            <li className='Menu-link'>KNOW YOUR COMPANY</li>
            <li className='Menu-link'>KNOW YOUR CUSTOMER</li>
            <li className='Menu-link'>OTHER RESOURCES</li>
          </ul>

          {/* <ul className='Submenu'>
            <li onClick={this.LogOut}><PowerSettingsNew /> LogOut</li>
          </ul>     */}
        </div>
        {/* QUICKLINK COMPONENT RENDER */}
        <div id="quickLink_sec" class="quickLinkClass " style={{ display: 'none' }}>
          {/* <QuickLink /> */}
        </div>
        <div id="contentRender"  >
          {/* IMPORT DASHBOARD  */}
          <MainDashBoard />
        </div>
        <div className='footer'>
          <p>Copyright © 2020-2022 CIEL GROUP. All rights reserved. Design by FRCI | Privacy policy</p>
          <div className='Footer-Icons'>
            <Facebook />
            <LinkedIn />
            <YouTube />
          </div>
        </div>



      </div>
    )
  }

}
export default TopMenu;