//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import '../Styling Components/TopMenuCSS.css';
import '../Styling Components/styleCSS.css'
import {ButtonWithIconComponent} from '../Assets Components/ButtonComponents/ButtonComponents';
import {FileInputTextField} from '../Assets Components/InputComponents/InputComponents';
import '../Styling Components/AddBulletInCSS.css';
import {FileUploadOutlined,InsertDriveFile,PictureAsPdf,FileDownloadOutlined} from "@mui/icons-material";
// import GlobalSearch from '../Global Search/GlobalSearch';
//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';
import {SelectTextField,TextAreaField} from '../Assets Components/InputComponents/InputComponents';
export class AttachLink extends Component {
    constructor(){
      super();
      this.state = {
        value:"",
        AttachLink: "https://www.-just-style.com/news/crystal-inter-nation-al-seeks-collaboration-to-create-lo"
      }
 }  
 FileUpload(){
  alert("file upload");
 }
 FileDownload(){
  alert("file upload");
 }
    render(){
      return(
        <div>
                  {/* FIELD USED TO GET ATTACH LINK - IT'S MANDATORY FIELD  */}
            <div className="col-md-4">
        <TextAreaField label="ATTACH LINK" value={this.state.AttachLink} />
            </div>
            <div className="col-md-4">
            <div className='Addedfilename'>
        {/* UPLOADED FILE NAMES SHOWN HERE*/}
            <PictureAsPdf />
            <div><h5>REPORT SNEAK PEAK</h5> <span>Uploaded By Mr XXX On 12th MAY-12:55</span></div> <FileDownloadOutlined onClick={this.FileDownload} /></div>
            </div>
            <div className="col-md-4">
                      {/* FIELD USED TO UPLOAD DATA - IT'S MANDATORY FIELD  */}
              <InsertDriveFile /><ButtonWithIconComponent onClick={this.FileUpload} endIcon={<FileUploadOutlined />} buttonName="Add Secondary Files" />
            </div>
            <div className='previewimage'>
                      {/* FIELD USED TO PREVIEW THE IMAGE  */}
              <h5>PREVIEW</h5>
              <img src={logo} />
            </div>
        </div>
      )
    }
    
    }

export class AttachBrowse extends Component {
      constructor(){
        super();
        this.state = {
          FileName:"Report Chart",
        }
   }  
      render(){
        return(
          <div>
              <div className="col-md-4">
                 {/* FIELD USED TO GET TITLE- IT'S MANDATORY FIELD  */}
              <SelectTextField
            labelname="TITLE"
            value={this.state.AttachLink}
            onChange={this.handleChange}
          />
              </div>
              <div className="col-md-4">
              {/* FIELD USED TO GET DESCRIPTION- IT'S MANDATORY FIELD  */}      
              <SelectTextField
            labelname="DESCRIPTION"
            value={this.state.AttachLink}
            onChange={this.handleChange}
          />
          </div>    
              <div className="col-md-4">
            <div className='Addedfilename'>
        {/* UPLOADED FILE NAMES SHOWN HERE*/}
            <PictureAsPdf />
            <div><h5>REPORT SNEAK PEAK</h5> <span>Uploaded By Mr XXX On 12th MAY-12:55</span></div> <FileDownloadOutlined onClick={this.FileDownload} /></div>
            </div>
            <div className="col-md-4">
              <InsertDriveFile /><ButtonWithIconComponent onClick={this.FileUpload} endIcon={<FileUploadOutlined />} buttonName="Add Secondary Files" />
            </div>
            <div className='previewimage'>
      {/* FIELD USED TO UPLOAD DATA - IT'S MANDATORY FIELD  */}
            <FileInputTextField  
            label="FILE"
            value={this.state.FileName}
            onChange={this.handleChange} iconStart={<PictureAsPdf />}
          />
                {/* FIELD USED TO PREVIEW THE IMAGE  */}
              {/* <h5>PREVIEW</h5> */}
              <img src={logo} />
            </div>
          </div>
        )
      }
      
      }