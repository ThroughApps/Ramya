//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import '../Styling Components/TopMenuCSS.css';
import '../Styling Components/styleCSS.css'
import {CancelButtonComponent,SaveButtonComponent} from '../Assets Components/ButtonComponents/ButtonComponents';
import {AttachLink,AttachBrowse} from '../Add BulletIn/AddBulletInComponents';
import TextareaAutosize from '@mui/base/TextareaAutosize';
//IMPORT IMAGE
import {SelectTextField} from '../Assets Components/InputComponents/InputComponents';
import { MenuItem } from '@mui/material';
class AddBulletIn extends Component {
    constructor(){
      super();
      this.state = {
        // AttachData: "Attach",
        AttachData: "Link"
      }
 }
         /*
    USED TO SELECT THE MENUS LISTED IN DROPDOWN
    - IMPLEMENTED BY 103 - 10-09-2022
    */
 SubMenuChange = (e) => {
  //  console.log("e", e);
   // const name = e.target.name;
   //const name = e.target.name;
   const value = e.target.value;

//    this.state.age = value;
//    this.setState({
//     age: this.state.age
//    })
    console.log("age", this.state.age);
    console.log("e.target.value", e.target.value);
    // const name = e.target.name;
    // const value = e.target.value;
    console.log("e.props.value", e.props);
    this.state.Selectedsubmenu = e;
    console.log("Selectedsubmenu", this.state.Selectedsubmenu);
    this.state.submenuname = e.value;
    this.setState({
        Selectedsubmenu: this.state.Selectedsubmenu,
        submenuname: this.state.submenuname
    })
 }
 componentDidMount(){
    var submenu = [];
    console.log("Selectedsubmenu", this.state.Selectedsubmenu);
    submenu.push(<MenuItem value={"submenu 1"}>submenu 1</MenuItem>)
    submenu.push(<MenuItem value={"submenu 2"}>submenu 2</MenuItem>)
    submenu.push(<MenuItem value={"submenu 3"}>submenu 3</MenuItem>)
    submenu.push(<MenuItem value={"submenu 4"}>submenu 4</MenuItem>)
    this.state.submenu = submenu;
    this.setState({
        submenu: this.state.submenu,
    })
console.log("submenu", this.state.submenu);
}
RenderComponenets(UserData) {

  var self = this;

  switch (UserData) {
    case 'Attach':
      return <AttachLink />
    case 'Link':
      return <AttachBrowse />
    default:
      return ;
  }

}

    render(){
      return(
        <div className='container-fluid'>
        <div className='title'>
            <h5>Add Bulletins</h5>
        </div>
        <div className='br-bot'>
        <div className='row'>
        <div className="col-md-2">
                {/* FIELD USED TO GET ARTICLE TYPE - IT'S MANDATORY FIELD  */}
            <div className="col-md-12">
        <SelectTextField value={this.state.Selectedsubmenu} error={this.state.error} onChange={this.SubMenuChange} name="submenuname" labelname="ARTICLE TYPE" submenu={this.state.submenu}>
            </SelectTextField>
            </div>
             {/* FIELD USED TO GET ATTRIBUTE - IT'S MANDATORY FIELD  */}
            <div className="col-md-12">
            <SelectTextField value={this.state.Selectedsubmenu} error={this.state.error} onChange={this.SubMenuChange} name="submenuname" labelname="ATTRIBUTE" submenu={this.state.Attribute}>
            </SelectTextField>
            </div>
            </div>
            <div className="col-md-2">   
             {/* FIELD USED TO GET SOURCE - IT'S MANDATORY FIELD  */}          
            <div className="col-md-12">
            <SelectTextField value={this.state.Selectedsubmenu} error={this.state.error} onChange={this.SubMenuChange} name="submenuname" labelname="SOURCE" submenu={this.state.Source}>
            </SelectTextField>
            </div>
             {/* FIELD USED TO GET ATTRIBUTE - IT'S MANDATORY FIELD  */}
            <div className="col-md-12">
            <SelectTextField value={this.state.Selectedsubmenu} error={this.state.error} onChange={this.SubMenuChange} name="submenuname" labelname="ATTRIBUTE" submenu={this.state.Attribute}>
            </SelectTextField>
            </div>
            </div>
            <div className="col-md-8 text-render">    
            <div className="col-md-4">
            <SelectTextField value={this.state.Selectedsubmenu} error={this.state.error} onChange={this.SubMenuChange} name="submenuname" labelname="ATTATCH" submenu={this.state.Attach}>
            </SelectTextField>
            </div>
              {/* RENDER COMPONENTS WHILE CHOOSING BROWSE AND LINK */}
            {this.RenderComponenets(this.state.AttachData)}
       </div>
       </div>
       </div>
       <div className='br-bot'>
        <div className='row'>
       <div className="col-md-4">
        <h5>comments</h5>
          {/* FIELD USED TO GET COMMENT SECTION - IT'S MANDATORY FIELD  */}
       <TextareaAutosize
  aria-label="minimum height"
  minRows={3}
  defaultValue={this.state.CommentArea}
  placeholder="Minimum 3 rows"
  style={{ width: "100%"}}
/>
</div>
       </div>
       </div>
       <div className='text-right'>
       <CancelButtonComponent buttonName="Cancel" />
       <SaveButtonComponent buttonName="Save" />
       </div>
</div>   
      )
    }
    
    }
export default AddBulletIn;