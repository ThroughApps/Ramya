//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import $ from 'jquery';
import MenuItem from '@mui/material/MenuItem';

//IMPORT CLASS COMPONENT CSS

//IMPORT CLASS COMPONENT
import { SubmitButtonComponent } from '../Assets Components/ButtonComponents/ButtonComponents';
import { InstantResponseMessage } from '../Assets Components/Alert Components/Alerts';
import { DropdownComponent } from '../Assets Components/DropdownComponents/DropdownComponent';



class AddBulletIn extends Component {

    constructor(props) {
        super(props)

        this.state = {

            articleTypeMenuItems: [],
            sourceMenuItems: [],
            attachTypeMenuItems: [],

            articleType: '',
            source: '',
            attachType: '',
            comments: '',

            link: '',
            title: '',
            description: '',

            submitButtonStatus: true,

            messageTitle: "",
            message: "",
            messageSeverity: "",

            instantResponseMessageStatus: false,

        }

        this.SetUpInitialData_To_Fields = this.SetUpInitialData_To_Fields.bind(this);
        this.EnableSubmitButton = this.EnableSubmitButton.bind(this);
        this.ClearFunc = this.ClearFunc.bind(this);


    }

    componentDidMount() {

        this.SetUpInitialData_To_Fields();


    }

    SetUpInitialData_To_Fields() {

        this.state.articleTypeMenuItems = [];
        this.state.sourceMenuItems = [];
        this.state.attachTypeMenuItems = [];

        this.state.articleTypeMenuItems.push(<MenuItem value="News">News</MenuItem>);
        this.state.articleTypeMenuItems.push(<MenuItem value="Report">Report</MenuItem>);
        this.state.articleTypeMenuItems.push(<MenuItem value="Analysis">Analysis</MenuItem>);


        this.state.sourceMenuItems.push(<MenuItem value="Just Style">Just Style</MenuItem>);
        this.state.sourceMenuItems.push(<MenuItem value="Business of Fashion">Business of Fashion</MenuItem>);
        this.state.sourceMenuItems.push(<MenuItem value="The Hindu">The Hindu</MenuItem>);
        this.state.sourceMenuItems.push(<MenuItem value="Fibre 2 Fashion">Fibre 2 Fashion</MenuItem>);
        this.state.sourceMenuItems.push(<MenuItem value="Apparel Resources">Apparel Resources</MenuItem>);
        this.state.sourceMenuItems.push(<MenuItem value="The Economic Times">The Economic Times</MenuItem>);


        this.state.attachTypeMenuItems.push(<MenuItem value="LINK">LINK</MenuItem>);
        this.state.attachTypeMenuItems.push(<MenuItem value="BROWSE">BROWSE</MenuItem>);


        this.setState({
            articleTypeMenuItems: this.state.articleTypeMenuItems,
            sourceMenuItems: this.state.sourceMenuItems,
            attachTypeMenuItems: this.state.attachTypeMenuItems,
        })
    }

    handleUserSelectArticleType = (event) => {
        alert("ARTICLE TYPE :" + event.target.value);
        this.state.articleType=event.target.value;
        this.setState({
            articleType:this.state.articleType
        })
    };

    handleUserSelectSource = (event) => {
        alert("SOURCE : " + event.target.value);
        this.state.articleType=event.target.value;
        this.setState({
            articleType:this.state.articleType
        })
    };

    handleUserSelectAttachType = (event) => {
        alert("ATTACH TYPE : " + event.target.value);
    }

    /*
  FUNCTION USED TO CLEAR THE FIELDS AFTER SUCCESSFUL SIGNUP - 101/10/09/2022
  */
    ClearFunc() {


        this.state.submitButtonStatus = true;



        this.setState({





            submitButtonStatus: this.state.submitButtonStatus,



        })
    }

    /*
 FUNCTION USED TO ENABLE SUBMIT BUTTON AFTER SUCCESSFUL FIELD ENTRY - 101/10/09/2022
 */
    EnableSubmitButton(fieldName, status) {


        this.state[fieldName] = status;
        this.setState({
            [fieldName]: this.state[fieldName]
        })

        if (this.state.userNameValid == true && this.state.emailIdValid == true && this.state.contactNoValid == true &&
            this.state.passwordValid == true) {
            this.state.submitButtonStatus = false;
            this.setState({
                submitButtonStatus: this.state.submitButtonStatus
            })
        } else {
            this.state.submitButtonStatus = true;
            this.setState({
                submitButtonStatus: this.state.submitButtonStatus
            })
        }
    }



    render() {

        return (
            <div className="SignIn_Bg">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">

                        </div>
                        <div className="col-md-4">
                            <div className="SignIn_InBox">
                                <div className="text-center">
                                    <div class="Bg_Img">
                                        <h1>Add BulletIn</h1>
                                    </div>

                                    <DropdownComponent onChange={this.handleUserSelectArticleType} value={this.state.articleType} errorStatus={this.state.articleTypeErrorStatus} errorMessage={this.state.articleTypeErrorMessage} label='ArticleType' name='articleTYpe' menuItems={this.state.articleTypeMenuItems} disableStatus={false} />
                                    <DropdownComponent onChange={this.handleUserSelectSource} value={this.state.source} errorStatus={this.state.sourceErrorStatus} errorMessage={this.state.sourceErrorMessage} label='Source' name='source' menuItems={this.state.sourceMenuItems} disableStatus={false} />
                                    <DropdownComponent onChange={this.handleUserSelectAttachType} value={this.state.attachType} errorStatus={this.state.attachTypeErrorStatus} errorMessage={this.state.attachTypeErrorMessage} label='Attach' name='attachType' menuItems={this.state.attachTypeMenuItems} disableStatus={false} />
                                    <DropdownComponent onChange={this.handleUserSelectAttribute1} value={this.state.arrtibute1} errorStatus={this.state.arrtibute1ErrorStatus} errorMessage={this.state.arrtibute1ErrorMessage} label='Attribute1' name='arrtibute1' menuItems={this.state.arrtibute1MenuItems} disableStatus={true} />

                                    <SubmitButtonComponent onClick={this.AddBulletInData} buttonStatus={this.state.submitButtonStatus} buttonName={"SignIn"} />
                                    {this.state.instantResponseMessageStatus ? <InstantResponseMessage messageTitle={this.state.messageTitle} message={this.state.message}
                                        severity={this.state.messageSeverity} /> : ``}  </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default AddBulletIn;

/*
USED FOR RESETTING THE INSTANT RESPONSE TO INITIAL STATE AFTER FEW SECONDS - 101/08/09/2022
*/
function HideFieldErroeMsgs(stateName, currentState) {
    setTimeout(function () {
        var self = currentState;
        self.state[stateName] = false;
        self.setState({
            [stateName]: self.state[stateName]
        })
    }, 4000);
}
