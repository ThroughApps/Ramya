//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
//IMPORT CLASS COMPONENT CSS
import '../Styling Components/SignIn_SignUpCSS.css';
//IMPORT CLASS COMPONENT
import { SubmitButtonComponent} from '../Assets Components/ButtonComponents/ButtonComponents';
import { UserNameInputTextField,PasswordInputTextField } from '../Assets Components/InputComponents/InputComponents';
import { CapitalCaseFunc, TextLengthFunc } from '../Validation Components/Validation';
//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';
import ForgortPassword from '../SignIn_SignUp Components/ForgotPassword';
import SignUp from '../SignIn_SignUp Components/SignUp';
//IMPORT STATEMENTS FOR ICON COMPONENT
import AccountCircle from "@mui/icons-material/AccountCircle";
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
class SignIn extends Component {
constructor(){
  super();
  this.state = {
    userName: "",
    password: "",
    showPassword: false,
    userNameErrorStatus: false,
    userNameErrorStatus: false,
    userNameErrorMessage: "User Name length Exceeds",
    passwordErrorMessage: "",
}
}
 /*
    FUNCTION USED TO HANDLE USER NAME - 103/07/09/2022
    */
    handleUserInputUserName = (e) => {
      const name = e.target.name;
      const value = e.target.value;

      var camelcaseData = CapitalCaseFunc(value);
      var lengthValidation = TextLengthFunc(camelcaseData, 75);

      if (lengthValidation == true) {
          this.state.userName = camelcaseData;
          this.state.userNameErrorStatus = true;
              this.setState({
                  userName: this.state.userName,
                  userNameErrorStatus: this.state.userNameErrorStatus
              })
          this.DisableErrorMessage('userNameErrorStatus', false, '', 'userNameErrorMessage');
      } else {
          this.EnableErrorMessage('userNameErrorStatus', true, 'User Name length Exceeds', 'userNameErrorMessage');
      }
  }
      /*
   FUNCTION USED TO HANDLE PASSWORD TO SHOW AND HIDE WHENEVER IT IS NECCESSARY - 103/09/09/2022
   */
  handleClickShowPassword = (e) => {
    var passwordInput = document.getElementById('password');
    var passStatus = document.getElementById('togglePassword');
    if (passwordInput.type == 'password') {
      passwordInput.type = 'text';
      this.state.showPassword = true;
      this.setState({
        showPassword: this.state.showPassword
      })
    }
    else {
      passwordInput.type = 'password';
      this.state.showPassword = false;
      this.setState({
        showPassword: this.state.showPassword
      })
    }

  }
    /*
   FUNCTION USED TO HANDLE PASSWORD - 103/07/09/2022
   */
   handleUserInputPassword = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    this.state.password = value;
    this.setState({
        password: this.state.password
    })
}
  /*
   FUNCTION USED TO GO FORGOT PASSWORD PAGE WHENEVER CLICK FORGOT PASSWORD - 103/08/09/2022
   */
ForgotPassword(){
  ReactDOM.render(
  <BrowserRouter>
  <Routes>
      <Route path="/" component={ForgortPassword} />
  </Routes>
</BrowserRouter>,
   document.getElementById("contentRender")
  )
}
  /*
   FUNCTION USED TO GO SIGNUP PAGE WHENVER CLICK SIGNUP - 103/08/09/2022
   */
SignUp(){
  ReactDOM.render(
  <BrowserRouter>
  <Routes>
      <Route path="/" element={<SignUp />} />
  </Routes>
</BrowserRouter>,
   document.getElementById("contentRender")
  )
}
render(){
  return(
    <div className="SignIn_Bg">
    <div className="container">
      <div className="row">
        <div className="col-md-8">
          <div className='SignIn_Logo'>
          <img src={logo} />
          </div>
        </div>
        <div className="col-md-4">
          <div className="SignIn_InBox">
          <div className="text-center">
            <div class="Bg_Img">
      <h1>Welcome</h1>
      </div>
       {/* FIELD USED TO GET USERNAME - IT'S MANDATORY FIELD  */}
       <UserNameInputTextField errorStatus={this.state.userNameErrorStatus} errorMessage={this.state.userNameErrorMessage} onChange={this.handleUserInputUserName} value={this.state.userName} label='User Name' name='userName' iconStart={<AccountCircle />}/>
       {/* FIELD USED TO GET PASSWORD - IT'S MANDATORY FIELD  */}
       <PasswordInputTextField errorStatus={this.state.passwordErrorStatus}
        id="password"
         errorMessage={this.state.passwordErrorMessage} onChange={this.handleUserInputPassword} value={this.state.password} label='Password' name='password' iconStart={<LockRoundedIcon/>}
         iconEnd={this.state.showPassword ? <VisibilityOff onClick={this.handleClickShowPassword} id="togglepassword" /> : <Visibility onClick={this.handleClickShowPassword} id="togglepassword" />} /> 
      <SubmitButtonComponent buttonName={"Login"}></SubmitButtonComponent>
        </div>
        <div className='SignIn_BotBontent'>
          <a onClick={()=> this.ForgotPassword()}>Forgot Your Password?</a>
          <a onClick={()=> this.SignUp()}>Sign Up</a>
        </div>
        </div>
        </div>
        </div>
        </div>
    </div>
  )
}

}
export default SignIn;