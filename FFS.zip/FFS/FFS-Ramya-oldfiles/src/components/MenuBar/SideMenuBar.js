import React, { Component, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from 'react-dom';
import $ from "jquery";
import _ from 'underscore';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import FavoriteIcon from '@mui/icons-material/Favorite';
import MapsUgcSharpIcon from '@mui/icons-material/MapsUgcSharp';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import ModeCommentIcon from '@mui/icons-material/ModeComment';
import NotificationComponent from '../Activity Components/Notification Components/Notification Component';
import DashboardCommentComponent from '../Activity Components/Comments Components/Comment Component';
import TopMenu from './TopMenu';
import LikeCommentComponent from '../Activity Components/Like Components/Like Component';
import SignUp from '../SignIn_SignUp Components/SignUp';
import AddBulletIn from '../Add BulletIn/AddBulletIn';
import ArticleCommentComponent from '../Activity Components/Comments Components/Article Comments Component';

const closeIcon = {
  position: 'absolute',
  right: '0',
  marginBottom: '10px'
}
class SideMenuBar extends Component {




  //   componentDidMount(){

  //      /* ONCLICK ON ANYWHERE OUTSIDE THE PAGE */
  //      $("#contentRender").click(function () {
  //       //  alert("CONTENT RENDER");
  //        $("#notification_sec").hide(); // WHEN COMMENT ICON CLICK NOTIFICATION GET HIDE
  //        $("#like_sec").hide();
  //        $("#comment_sec").hide(); // WHEN COMMENT ICON CLICK COMMENT GET HIDE // WHEN COMMENT ICON CLICK LIKE GET HIDE

  //   })

  //  }
  // ONCLICK FUNCTION FOR COMMENT OPEN 
  commentMenuOpen() {
    $("#notification_sec").hide(); // WHEN COMMENT ICON CLICK NOTIFICATION GET HIDE
    $("#like_sec").hide(); // WHEN COMMENT ICON CLICK LIKE GET HIDE
    document.getElementById("comment_sec").style.display = "block";
  }

  // ONCLICK FUNCTION FOR NOTIFICATION OPEN 
  NotificationMenuOpen() {
    $("#comment_sec").hide(); // WHEN COMMENT ICON CLICK COMMENT GET HIDE
    $("#like_sec").hide(); // WHEN COMMENT ICON CLICK LIKE GET HIDE
    document.getElementById("notification_sec").style.display = "block";
  }

  // ONCLICK FUNCTION FOR LIKE OPEN 
  LikeMenuOpen() {
    $("#comment_sec").hide(); // WHEN COMMENT ICON CLICK COMMENT GET HIDE
    $("#notification_sec").hide();// WHEN COMMENT ICON CLICK NOTIFICATION GET HIDE
    document.getElementById("like_sec").style.display = "block";
  }

  AddBulletIn() {
    ReactDOM.render(
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<ArticleCommentComponent />} />
        </Routes>
      </BrowserRouter>,
      document.getElementById("contentRender")
    )
  }

  render() {
    return (
      <div>

        <div class="container-fluid">
          {/* <TopMenu/>  */}

          <div class="row">
            <div class="col-md-11" id="main_contentSidebar" >
            </div>
            <div class="col-md-1">
              <div class="menu_sec" >
                {/* LIST FOR SIDE PANE MENU ICON*/}
                <ul class="menu_sec_icon">
                  <li class="comment_icon"><ModeCommentIcon onClick={() => this.commentMenuOpen()} /></li>
                  <li class="notification_icon"><NotificationsActiveIcon onClick={() => this.NotificationMenuOpen()} /></li>
                  <li class="like_icon" onClick={() => this.LikeMenuOpen()}><FavoriteIcon /></li>
                  <li class="like_icon" onClick={() => this.AddBulletIn()}><MapsUgcSharpIcon /></li>

                </ul>

              </div>
            </div>
          </div>
        </div>
        {/* DASHBOARD COMPONENT RENDER */}
        <div id="comment_sec" class="commentClass " style={{ display: 'none' }}>

          <DashboardCommentComponent />
        </div>
        {/* NOTIFICATION COMPONENT RENDER */}
        <div id="notification_sec" class="notificationClass" style={{ display: 'none' }}>
          <NotificationComponent />
        </div>
        {/* LIKE COMPONENT RENDER */}
        <div id="like_sec" class="likeClass" style={{ display: 'none' }}>
          <LikeCommentComponent />
        </div>

        {/* <div class="contentRender">

        <h3>hello</h3>
       </div> */}
      </div>
    );
  }
}

export default SideMenuBar;
