//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReactDOM from "react-dom";
import $ from "jquery";
import {Facebook,LinkedIn,YouTube} from '@mui/icons-material';
import {AccountCircle,InsertLink,Assessment,Menu} from '@mui/icons-material';
import '../Styling Components/TopMenuCSS.css';
import '../Styling Components/styleCSS.css'
import AddBulletIn from '../Add BulletIn/AddBulletIn.js';
import AllBulletIn from '../View Components/BulletIn/AllBulletIn';
import {IndustryTrendsDashboard} from '../DashBoard Components/IndustryTrendsDashboard';
import GlobalSearch from '../Global Search/GlobalSearch';
import MainDashBoardComponents from '../DashBoard Components/MainDashBoardComponents'
//IMPORT IMAGE
import logo from '../Images/Cieltextilelogo.png';
class TopMenu extends Component {
    constructor(){
      super();
      this.state = {
      }
 }
 IndustryTrends(){
    ReactDOM.render(
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<IndustryTrendsDashboard />} />
            </Routes>
        </BrowserRouter>,
        document.getElementById("contentRender")
    )
 }
    /*
    USED TO CALL ADD BULLETIN PAGE
    - IMPLEMENTED BY 103 - 10-09-2022
    */
    AddBulletIn() {

        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<AddBulletIn />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        )

    }
    MainDashBoardComponent(){
        ReactDOM.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<MainDashBoardComponents />} />
                </Routes>
            </BrowserRouter>,
            document.getElementById("contentRender")
        )  
    }
        /*
    USED TO SHOW THE HIDDEN CONTENTS MENU WHILE CLICKING THE HAMBURGER IN MOBILE VIEW
    - IMPLEMENTED BY 103 - 13-09-2022
    */
    componentDidMount(){
        $(document).ready(function () {
$(".menuIcon").click(function()
{
    $(".TopMenu_Second").addClass("active");
})
$("#contentRender").click(function()
{
    $(".TopMenu_Second").removeClass("active");
})
$(".Menu-link").click(function()
{
    $(".TopMenu_Second").removeClass("active");
})
});
    }
    render(){
      return(
        <div className='wrapper'>
        <div className="TopMenu">
        <div className="container-fluid TopMenu_First">
            <div className='TopMenu_Logo'>
          <img src={logo} />
          </div> 
          <GlobalSearch />
            <ul className="TopMenu_RightContent">
                <li className='MobileView icon'><InsertLink /></li>
                <li className='MobileView icon'><Assessment /></li>
                <li className='DesktopView'>Report Archives</li>
                <li className='DesktopView'>Quick Links</li>
                <li className='icon'><AccountCircle /></li>                
            </ul>
            <div className='MobileView menuIcon'>
                <Menu />
            </div>
            </div>
            <ul className="TopMenu_Second">
                <li className='Menu-link' onClick={this.AddBulletIn}>INDUSTRY TRENDS</li>
                <li className='Menu-link' onClick={this.MainDashBoardComponent}>KNOW YOUR COMPANY</li>
                <li className='Menu-link' onClick={this.IndustryTrends}>KNOW YOUR CUSTOMER</li> 
                <li className='Menu-link'>OTHER RESOURCES</li>               
            </ul>
        </div>
            <div class="main_content" id="contentRender">
            <AllBulletIn />
            </div>
            <div className='footer'>
            <p>Copyright © 2020-2022 CIEL GROUP. All rights reserved. Design by FRCI | Privacy policy</p>
            <div className='Footer-Icons'>
            <Facebook />
            <LinkedIn />
            <YouTube />
            </div>
            </div>
            </div>
      )
    }
    
    }
    export default TopMenu;