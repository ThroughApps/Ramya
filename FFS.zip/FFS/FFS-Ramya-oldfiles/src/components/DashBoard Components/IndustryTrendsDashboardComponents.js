//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import {ExploreButtonComponent,BulletinButtonComponent} from '../Assets Components/ButtonComponents/ButtonComponents';
import '../Styling Components/TopMenuCSS.css';
import '../Styling Components/styleCSS.css';
import '../Styling Components/MainDashBoardCSS.css';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import logo from '../Images/Cieltextilelogo.png';
import image1 from '../Images/image1.jpg';
import image2 from '../Images/image2.jpg';
import image3 from '../Images/image3.jpg';
import hindu from '../Images/hindu.PNG';
import hindu1 from '../Images/hindu1.PNG';
import times from '../Images/times.PNG';
import Carousel from "react-multi-carousel";
import { Image } from "semantic-ui-react";
import "react-multi-carousel/lib/styles.css";
import {ArrowForwardIos,ArrowBackIosNew} from '@mui/icons-material';
export function ImageContentComponent() { 
const AlignContent={
position: "absolute",
top: "20%",
left: "50%",
transform: "translate(-50%, -50%)",
padding: "10px !important",
color: "#fff",
textAlign: "center",
}
const imgAlign={
  position: "relative",
  '&:hover': {  opacity: "0.8"}
} 
return(
        <Card sx={{ maxWidth: "100%"}}>
            <CardMedia sx={imgAlign}
              component="img"
              height="300"
              image={image1}
            />
              <Typography variant="h5" component="div" sx={AlignContent}>
                <h3>Giorgio Armani SS'21 Show Review | British GQ</h3>
              <ExploreButtonComponent buttonName="Explore More" />
              </Typography>
          </Card>
);
        };

        
export function ArticlesComponent({data}) { 
  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3,
      paritialVisibilityGutter: 60
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      paritialVisibilityGutter: 50
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      paritialVisibilityGutter: 30
    }
  };
 
  const card={
    maxWidth: "100%",
    borderRadius: "0px !important",
    margin: "10px"
  }
 const imgBorder={
  borderTop: "3px solid #689fd5",
  borderBottom: "10px solid #689fd5"
 }
  const Space={
    padding: "5px",
    justifyContent: "space-between"
              }   
    var data= [
          {
              "EventName": "Just Style",
              "Event": "News",
              "Day": "Latest 11/05/202",
              image: hindu1,
              "UploadedBy": "Uploaded by Mr.xxxxx",
           },    {
            "EventName": "The Hindu",
            "Event": "News",
            "Day": "Latest 11/05/202",
            image: times,
            "UploadedBy": "Uploaded by Mr.xxxxx",
         },
         {
          "EventName": "The Economic Times",
          "Event": "Analysis",
          "Day": "Latest 11/05/202",
          image: hindu1,
          "UploadedBy": "Uploaded by Mr.xxxxx",
       },
       {
        "EventName": "Fibre 2 Fashion",
        "Event": "News",
        "Day": "Latest 11/05/202",
        image: times,
        "UploadedBy": "Uploaded by Mr.xxxxx",
     },
     {
      "EventName": "Fibre 2 Fashion",
      "Event": "News",
      "Day": "Latest 11/05/202",
      image: hindu,
      "UploadedBy": "Uploaded by Mr.xxxxx",
   },{
    "EventName": "Fibre 2 Fashion",
    "Event": "News",
    "Day": "Latest 11/05/202",
    image: hindu1,
    "UploadedBy": "Uploaded by Mr.xxxxx",
 }
]; 
        return(
            <div className='container-fluid'>
              <div className='flex-Mob'>
                <h3>Articles/Reports</h3>
                <div>
                <BulletinButtonComponent buttonName="Add Bulletins" />
                <BulletinButtonComponent buttonName="See All in Bulletins " />
                </div>
                </div>
            <div className='row'>
        <Carousel
      ssr
      partialVisbile
      // deviceType={deviceType}
      itemClass="image-item"
      responsive={responsive}
    >
      {data.slice(0, 10).map(data => {
        return (
          <Card sx={card}>
              <CardMedia sx={imgBorder}
                component="img"
                height="200"
                image={data.image}
              />
              <CardActions sx={Space}>
                <p className='article'>{data.EventName}<br />
                <a size="small" class="UploadData1">{data.Day}</a></p>
                <p class="text-right article">{data.Event}<br />
                <a size="small" class="UploadData1">{data.UploadedBy}</a></p>
              </CardActions>
            </Card>
        );
      })}
    </Carousel>
            </div>
            </div>
  );
          };