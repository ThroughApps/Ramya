//IMPORT STATEMENTS FOR REACT COMPONENT
import { titleCase } from "title-case";

/*
FUNCTION USED TO CONVERT THE 
ENTERED TEXT INTO CAMEL CASE - 101/07/09/2022
*/
export const CapitalCaseFunc = function (textValue) {

    var lowerval = textValue.toLowerCase();
    var capitalCase = titleCase(lowerval);

    return capitalCase;

}

/*
FUNCTION USED TO CHECK LENGTH OF THE TEXT 
ENTERED - 101/07/09/2022 
*/
export const TextLengthFunc = function (textValue, lengthValue) {

    var lengthValidationData = false;
    if (textValue.length <= lengthValue) {
        lengthValidationData = true;
    }
    return lengthValidationData;

}
