//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import AllBulletInComponents from './AllBulletInComponents';
//IMPORT IMAGE

class AllBulletIn extends Component {
    constructor(){
      super();
      this.state = {
      }
 }
    render(){
      return(
<div><AllBulletInComponents /></div>  
      )
    }
    
    }
export default AllBulletIn;