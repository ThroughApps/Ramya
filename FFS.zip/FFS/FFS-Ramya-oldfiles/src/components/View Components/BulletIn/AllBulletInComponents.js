//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import { DropdownComponent } from '../../Assets Components/Dropdown Components/DropdownComponent';
import {CancelButtonComponent} from '../../Assets Components/ButtonComponents/ButtonComponents';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import image1 from '../../Images/image1.jpg';
import image2 from '../../Images/image2.jpg';
import image3 from '../../Images/image3.jpg';
import {SocialMediaShare,ShareWithinOrganization} from '../BulletIn/ModalComponent';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import FavoriteIcon from '@mui/icons-material/Favorite';
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
const modalScroll ={
  height: '200px',
  overflowY: 'scroll'
}
const cardContent={
  boxShadow: "none",
  width: "60%"
    }
const cardimgContent={
      width: "20%"
    }
  const Space={
  padding: "0px",
  justifyContent: "space-between"
            }   
class AllBulletInComponents extends Component {
    constructor(){
      super();
      this.state = {
        favoriteIcon: false,
open: false,
handleClose: true,
modalType: "InternalShare",
data: [
  {
    "Event": "JUST STYLE - NEWS",
    "EventQues": "Why Lady Gaga’s Haus Beauty Needed a Rebrand",
    "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic Kim Kardashian draws flak for sporting Marilyn Monroe’s iconicKim Kardashian draws flak for sporting Marilyn Monroe’s iconicKim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress",
    "Day": "Today",
    image: image2,
    "UploadedBy": "Uploaded by Mr.xxxxx",
  }, {
    "Event": "THE ECONOMICS TIMES - REPORTS",
    "EventQues": "Ferragamo’s Plan to Double Sales Under a New",
    "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic ",
    "Day": "Yesterday",
    image: image1,
    "UploadedBy": "Uploaded by Mr.xxxxx",
  }, {
    "Event": "THE ECONOMICS TIMES - REPORTS",
    "EventQues": "Ferragamo’s Plan to Double Sales Under a New",
    "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic ",
    "Day": "Yesterday",
    image: image1,
    "UploadedBy": "Uploaded by Mr.xxxxx",
  }, {
    "Event": "FABRIC 2 FASHION - NEWS",
    "EventQues": "Ferragamo’s Plan to Double Sales Under a New",
    "EventName": "Kim Kardashian draws flak for sporting Marilyn Monroe’s iconic dress draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic draws flak for sporting Marilyn Monroe’s iconic ",
    "Day": "Yesterday",
    image: image1,
    "UploadedBy": "Uploaded by Mr.xxxxx",
  }]
      }

        this.handleOpen = this.handleOpen.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.FavoriteIcon = this.FavoriteIcon.bind(this);
      }
          /*
  FUNCTION USED TO CHANGE THE ICON LIKE AND DISLIKE  - 103/27/09/2022
  */
FavoriteIcon = (e) => {
this.setState(state => ({
 FavoriteIcon: !state.FavoriteIcon
}))
 }
    /*
  FUNCTION USED TO CLOSE THE MODAL  - 103/27/09/2022
  */
 handleClose(){
  var self = this;
  self.state.open = false;
self.state.handleClose = true;
self.setState({
 open: self.state.open,
 handleClose: self.state.handleClose
 })
}
    /*
  FUNCTION USED TO OPEN THE MODAL - 103/27/09/2022
  */
 handleOpen(){
  alert("handle open page");
  var self = this;
self.state.open = true;
self.state.handleClose = false;
self.setState({
open: self.state.open,
 handleClose: self.state.handleClose
})
  }
    /*
  FUNCTION USED TO RENDERCOMPONENTS OF THE MODAL CONTENT - 103/27/09/2022
  */
  RenderComponents(ModalData) {

    var self = this;

    switch (ModalData) {
        case 'ExternalShare':
            return <SocialMediaShare />
        case 'InternalShare':
            return <ShareWithinOrganization />
        default:
            return;
    }

}
    render(){
      return(
        <div className='container'>
          <div>
          {this.state.FavoriteIcon ? <FavoriteIcon onClick={this.FavoriteIcon} /> : <FavoriteBorderIcon onClick={this.FavoriteIcon} />}
            </div>
          <h5 onClick={this.handleOpen}>Check </h5>
          <div className='flex-Mob'>
            <div class="col-md-2">
          <DropdownComponent onChange={this.handleUserSelectSource} value={this.state.source} errorStatus={this.state.sourceErrorStatus} errorMessage={this.state.sourceErrorMessage} label='Source' name='source' menuItems={this.state.sourceMenuItems} disableStatus={false} />
          </div>
          <div class="col-md-3">
           <DropdownComponent onChange={this.handleUserSelectUploadedBy} value={this.state.UploadedBy} errorStatus={this.state.UploadedByErrorStatus} errorMessage={this.state.UploadedByErrorMessage} label='Uploaded By' name='UploadedBy' menuItems={this.state.UploadedByMenuItems} disableStatus={false} />
           </div>
           <div class="col-md-2">
           <DropdownComponent onChange={this.handleUserSelectArticleType} value={this.state.ArticleType} errorStatus={this.state.ArticleTypeErrorStatus} errorMessage={this.state.ArticleTypeErrorMessage} label='Article Type' name='ArticleType' menuItems={this.state.ArticleTypeMenuItems} disableStatus={false} />
           </div>
           <div class="col-md-2">
           <DropdownComponent onChange={this.handleUserSelectSortby} value={this.state.Sortby} errorStatus={this.state.SortbyErrorStatus} errorMessage={this.state.SortbyErrorMessage} label='Sort by' name='Sortby' menuItems={this.state.SortbyMenuItems} disableStatus={false} />
           </div>
           <div class="col-md-2 btn-align">
            <CancelButtonComponent buttonName="add new bulletin" />
           </div>
      </div>
      {this.state.data.map(data => (
        <div class="Slider_MainContent AllBulletin">
      <Card sx={cardContent}>
              <CardContent sx={{ padding: "5px" }}>
              <Typography variant="p" component="div">
                  {data.Event}
                </Typography>
                <Typography variant="h5" component="div">
                  {data.EventQues}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {data.EventName}
                </Typography>
              </CardContent>
              <CardActions sx={Space}>
            <a size="small" class="UploadData">{data.Day}</a>
              <a size="small" class="UploadData">{data.UploadedBy}</a>
            </CardActions>
            </Card>
            <CardMedia sx={cardimgContent}
                component="img"
                height="100"
                image={data.image}
              />
            </div>
                  ))}
                         <Modal
        keepMounted
        open={this.state.open}
        onClose={this.handleClose}
        aria-labelledby="keep-mounted-modal-title"
        aria-describedby="keep-mounted-modal-description"
      >
         <Box sx={style}>
          {this.RenderComponents(this.state.modalType)}
          </Box>
         
      </Modal>      
      </div>
      
      )
    }

    
    }
export default AllBulletInComponents;