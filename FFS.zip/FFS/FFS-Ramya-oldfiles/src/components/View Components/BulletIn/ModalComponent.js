//IMPORT STATEMENTS FOR REACT COMPONENT
import React, { Component} from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import {FacebookShareButton,FacebookIcon,WhatsappShareButton,WhatsappIcon,LinkedinShareButton,LinkedinIcon,
  EmailShareButton,EmailIcon} from 'next-share';
  import Multiselect from 'multiselect-react-dropdown';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
const modalScroll ={
  height: '300px'
}
const cardContent={
  boxShadow: "none",
  width: "60%"
    }
export class SocialMediaShare extends Component {
constructor(){
  super();
  this.state={

  }
}
    render(){
      return(
        <Card>
              <CardContent>
                      <FacebookShareButton
                    url={'https://github.com/next-share'}
                    quote={'next-share is a social share buttons for your next React apps.'}
                    hashtag={'#nextshare'}
                    >
                    <FacebookIcon size={32} round />
                    </FacebookShareButton>
                    <WhatsappShareButton
                    url={'https://github.com/next-share'}
                    title={'next-share is a social share buttons for your next React apps.'}
                    separator=":: "
                    >
                    <WhatsappIcon size={32} round />
                    </WhatsappShareButton>
                    <LinkedinShareButton url={'https://github.com/next-share'}>
                    <LinkedinIcon size={32} round />
                    </LinkedinShareButton>
                    <EmailShareButton
                    url={'https://github.com/next-share'}
                    subject={'Next Share'}
                    body="body"
                    >
                    <EmailIcon size={32} round />
                    </EmailShareButton>
          </CardContent>
          </Card>
      )
    }

    }

export class ShareWithinOrganization extends Component {
      constructor(){
        super();
        this.state={
      
        }
      }
          render(){
            return(
              <Card>
                    <CardContent sx={modalScroll}>                     
                    <Multiselect
  displayValue="key"
  onKeyPressFn={function noRefCheck(){}}
  onRemove={function noRefCheck(){}}
  onSearch={function noRefCheck(){}}
  onSelect={function noRefCheck(){}}
  options={[
    {
      cat: 'Group 1',
      key: 'Option 1'
    },
    {
      cat: 'Group 1',
      key: 'Option 2'
    },
    {
      cat: 'Group 1',
      key: 'Option 3'
    },
    {
      cat: 'Group 2',
      key: 'Option 4'
    },
    {
      cat: 'Group 2',
      key: 'Option 5'
    },
    {
      cat: 'Group 2',
      key: 'Option 6'
    },
    {
      cat: 'Group 2',
      key: 'Option 7'
    }
  ]}
  showCheckbox
  iconRenderer
/>     
                </CardContent>
                </Card>
            )
          }
      
          }