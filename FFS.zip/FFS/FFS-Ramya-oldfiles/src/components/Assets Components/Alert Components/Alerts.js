//IMPORT STATEMENTS FOR REACT COMPONENT
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import Snackbar from '@mui/material/Snackbar';

import React, { useState, forwardRef } from 'react'
import MuiAlert from '@mui/material/Alert';


/*
USED FOR RENDERING RESPONSE MESSAGES LIKE INFO,WARNING,SUCCESS,ERROR - 101/08/09/2022
*/
export const InstantResponseMessage = ({ messageTitle, message, severity }) => {

    const [open, setOpen] = useState(true);
    //Leave this true since we are not using a button

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    return (
        <Snackbar open={open} autoHideDuration={6000} onClose={handleClose} anchorOrigin={{ vertical: "top", horizontal: "right" }}>
            <Alert onClose={handleClose} severity={severity} sx={{ width: '100%' }}>
                <AlertTitle>{messageTitle}</AlertTitle>
                {message}
            </Alert>
        </Snackbar>
    )
}

