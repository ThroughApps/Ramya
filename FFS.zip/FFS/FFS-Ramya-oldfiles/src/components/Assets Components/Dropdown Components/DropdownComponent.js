import * as React from 'react';
import MenuItem from '@mui/material/MenuItem';
import TextField from '@mui/material/TextField';

/*
USED FOR RENDERING USER-NAME TEXT FIELD - 101/13/09/2022
*/

const selectfieldstyle = {
    width: "100%",
    marginBottom: "20px",
}


var articleTypeMenuItems = [];
var sourceMenuItems = [];
var attachTypeMenuItems = [];
var sortByMenuItems=[];

articleTypeMenuItems.push(<MenuItem value="News">News</MenuItem>);
articleTypeMenuItems.push(<MenuItem value="Report">Report</MenuItem>);
articleTypeMenuItems.push(<MenuItem value="Analysis">Analysis</MenuItem>);


sourceMenuItems.push(<MenuItem value="Just Style">Just Style</MenuItem>);
sourceMenuItems.push(<MenuItem value="Business of Fashion">Business of Fashion</MenuItem>);
sourceMenuItems.push(<MenuItem value="The Hindu">The Hindu</MenuItem>);
sourceMenuItems.push(<MenuItem value="Fibre 2 Fashion">Fibre 2 Fashion</MenuItem>);
sourceMenuItems.push(<MenuItem value="Apparel Resources">Apparel Resources</MenuItem>);
sourceMenuItems.push(<MenuItem value="The Economic Times">The Economic Times</MenuItem>);


attachTypeMenuItems.push(<MenuItem value="LINK">LINK</MenuItem>);
attachTypeMenuItems.push(<MenuItem value="BROWSE">BROWSE</MenuItem>);

sortByMenuItems.push(<MenuItem value="Date Asc">Date Asc</MenuItem>);
sortByMenuItems.push(<MenuItem value="Date Desc">Date Desc</MenuItem>);
sortByMenuItems.push(<MenuItem value="A-Z">A-Z</MenuItem>);
sortByMenuItems.push(<MenuItem value="Z-A">Z-A</MenuItem>);


export const DropdownComponent = ({ onChange, value, label, name, errorStatus, errorMessage, menuItems, disableStatus }) => (
    <TextField sx={selectfieldstyle} required disabled={disableStatus} onChange={onChange} error={errorStatus} helperText={errorMessage} id="select" label={label} value={value} name={name} select>
        {menuItems}
    </TextField>);

export const ArticleDropdownComponent = ({ onChange, value, label, name, errorStatus, errorMessage, disableStatus }) => (
    <TextField sx={selectfieldstyle} required disabled={disableStatus} onChange={onChange} error={errorStatus} helperText={errorMessage} id="select" label={label} value={value} name={name} select>
        {articleTypeMenuItems}
    </TextField>);

export const SourceDropdownComponent = ({ onChange, value, label, name, errorStatus, errorMessage, disableStatus }) => (
    <TextField sx={selectfieldstyle} required disabled={disableStatus} onChange={onChange} error={errorStatus} helperText={errorMessage} id="select" label={label} value={value} name={name} select>
        {sourceMenuItems}
    </TextField>);

export const AttachDropdownComponent = ({ onChange, value, label, name, errorStatus, errorMessage, disableStatus }) => (
    <TextField sx={selectfieldstyle} required disabled={disableStatus} onChange={onChange} error={errorStatus} helperText={errorMessage} id="select" label={label} value={value} name={name} select>
        {attachTypeMenuItems}
    </TextField>);

export const UploadedByDropdownComponent = ({ onChange, value, label, UploadedByMenuItems, name, errorStatus, errorMessage, disableStatus }) => (
    <TextField sx={selectfieldstyle} required disabled={disableStatus} onChange={onChange} error={errorStatus} helperText={errorMessage} id="select" label={label} value={value} name={name} select>
        {UploadedByMenuItems}
    </TextField>);

export const SortByDropdownComponent = ({ onChange, value, label, name, errorStatus, errorMessage, disableStatus }) => (
    <TextField sx={selectfieldstyle} required disabled={disableStatus} onChange={onChange} error={errorStatus} helperText={errorMessage} id="select" label={label} value={value} name={name} select>
        {sortByMenuItems}
    </TextField>);
