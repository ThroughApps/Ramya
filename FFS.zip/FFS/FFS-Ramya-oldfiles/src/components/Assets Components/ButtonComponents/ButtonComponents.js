import Button from '@mui/material/Button';
import '../../Styling Components/styleCSS.css'
import InputAdornment from "@mui/material/InputAdornment";
import { Transform } from '@mui/icons-material';

/*
USED FOR STYLING THE LOGINBUTTON - 103/07/09/2022
*/
const styles={
  marginTop: "10px",
  backgroundColor: "#689fd5",
  borderRadius: "25px",
  fontWeight: "bold",
  '&:hover': {  backgroundColor: "#689fd5"}
}
const Buttonstyles={
  backgroundColor: "#333d4b",
  color: "#fff",
  borderRadius: "5px",
  marginRight: "10px",
  '&:hover': {  backgroundColor: "#333d4b"}
}
const saveButtonstyles={
  backgroundColor: "#333d4b",
  color: "#fff",
  borderRadius: "5px",
  '&:hover': {  backgroundColor: "#333d4b"}
}
const ExploreStyles={
  color: "#fff",
  border: "1px solid",
  '&:hover': {  backgroundColor: "#689fd5"}
}
const BulletinButton = {
  borderBottom: "2px solid #689fd5",
  borderRadius: "0px !important",
  color: "#000",
  fontWeight: "bold",
  textTransform: "none",
  marginRight: "10px"
}

/*
USED FOR RENDERING LOGINBUTTON - 103/07/09/2022
*/
export  const  SubmitButtonComponent = ({ onClick,buttonStatus, buttonName }) => (
  <Button sx={styles} variant="contained" onClick={onClick} disabled={buttonStatus}>{buttonName}</Button>
);

export const LinkButtonComponent = ({ onClick, buttonName }) => (
  <Button onClick={onClick}>{buttonName}</Button>
);

/*
USED FOR RENDERING CANCEL BUTTON - 103/09/09/2022
*/
export  const  CancelButtonComponent = ({ onClick,buttonStatus, buttonName }) => (
  <Button sx={Buttonstyles} variant="contained" onClick={onClick} disabled={buttonStatus}>{buttonName}</Button>
);

/*
USED FOR RENDERING SAVE BUTTON - 103/09/09/2022
*/
export  const  SaveButtonComponent = ({ onClick,buttonStatus, buttonName }) => (
  <Button sx={saveButtonstyles} variant="contained" onClick={onClick} disabled={buttonStatus}>{buttonName}</Button>
);

/*
USED FOR RENDERING CANCEL BUTTON - 103/09/09/2022
*/
export const ButtonWithIconComponent = ({ onClick,buttonStatus, buttonName,iconStart, iconEnd, InputProps, ...props }) => (
  <Button sx={Buttonstyles} variant="contained" onClick={onClick} disabled={buttonStatus}   {...props}
  InputProps={{
    ...InputProps,
    startAdornment: iconStart ? (
      <InputAdornment position="start">{iconStart}</InputAdornment>
    ) : null,
    endAdornment: iconEnd ? (
      <InputAdornment position="end">{iconEnd}</InputAdornment>
    ) : null
  }}>{buttonName}</Button>
);

/*
USED FOR RENDERING EXPLOREBUTTON - 103/07/09/2022
*/
export  const  ExploreButtonComponent = ({ onClick,buttonStatus, buttonName }) => (
  <Button sx={ExploreStyles} variant="outlined" onClick={onClick}>{buttonName}</Button>
);

export const BulletinButtonComponent = ({ onClick, buttonName }) => (
  <Button sx={BulletinButton} onClick={onClick}>{buttonName}</Button>
);