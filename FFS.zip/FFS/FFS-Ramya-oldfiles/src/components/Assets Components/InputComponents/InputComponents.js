//IMPORT STATEMENTS FOR REACT COMPONENT
import TextField from '@mui/material/TextField';
import InputAdornment from "@mui/material/InputAdornment";
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select, { SelectChangeEvent } from '@mui/material/Select';

const styles={
  width: "80%", 
  marginBottom: "10px",
  '@media(maxWidth: 768px)' : {
    width: '100%'
  }
}
const Filefieldstyles={
  width: "50%",
  marginBottom: "10px",
  '@media(maxWidth: 768px)' : {
    width: '100%'
  }
}
const selectfieldstyle={
  width: "100%",
  marginBottom: "20px",
  }
const selectfieldstyle1={
    width: "100%",
    marginBottom: "20px",
    }
const textareastyles={
  width: "100%",
  marginBottom: "20px",
}
/*
USED FOR RENDERING USER-NAME TEXT FIELD - 101/07/09/2022
*/
/*
TEXT FIELD WITH ICON ADDED FOR BEFORE AND AFTER - 103/07/09/2022
*/
export const UserNameInputTextField = ({ onChange,value,label,name,errorStatus,errorMessage,iconStart, iconEnd, InputProps, ...props }) => (
  <TextField required size="small" sx={styles} margin="normal" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} 
  {...props}
  InputProps={{
    ...InputProps,
    startAdornment: iconStart ? (
      <InputAdornment position="start">{iconStart}</InputAdornment>
    ) : null,
    endAdornment: iconEnd ? (
      <InputAdornment position="end">{iconEnd}</InputAdornment>
    ) : null
  }}
  />
);

/*
USED FOR RENDERING PASSWORD TEXT FIELD - 101/07/09/2022
*/
/*
TEXT FIELD WITH ICON ADDED FOR BEFORE AND AFTER - 103/07/09/2022
*/
export const  PasswordInputTextField = ({ onChange,value,label,name,errorStatus,errorMessage,iconStart, iconEnd, InputProps, ...props }) => (
  <TextField error={errorStatus} id="outlined-password-input" type="password" autoComplete="current-password" size="small" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} {...props}
    InputProps={{
      ...InputProps,
      startAdornment: iconStart ? (
        <InputAdornment position="start">{iconStart}</InputAdornment>
      ) : null,
      endAdornment: iconEnd ? (
        <InputAdornment position="end">{iconEnd}</InputAdornment>
      ) : null
    }}/>
);

/*
TEXT AREA FIELD  - 103/13/09/2022
*/
export const TextAreaField = ({ onChange,value,label }) => (
  <TextField sx={textareastyles}
  required
id="outlined-multiline-flexible"
label={label}
multiline
value={value}
onChange={onChange}
/>
);


/*
USED FOR RENDERING USER-NAME TEXT FIELD - 101/07/09/2022
UPDATE WITH ICONS - 103/08/09/2022
*/
export const InputTextField = ({ onChange, value, label, name, errorStatus, errorMessage, iconStart }) => (
    <IconTextField error={errorStatus} sx={styles} required size="small" margin="normal" multiline variant="outlined" label={label} name={name} onChange={onChange} value={value} helperText={errorMessage} iconStart={iconStart} />
);
/*
USED FOR RENDERING ICONS BEFORE AND AFTER TEXT FIELD - 103/07/09/2022
*/
const IconTextField = ({ iconStart, iconEnd, InputProps, ...props }) => {
  return (
      <TextField
          {...props}
          InputProps={{
              ...InputProps,
              startAdornment: iconStart ? (
                  <InputAdornment position="start">{iconStart}</InputAdornment>
              ) : null,
              endAdornment: iconEnd ? (
                  <InputAdornment position="end">{iconEnd}</InputAdornment>
              ) : null
          }}
      />
  );
};

/*
USED FOR RENDERING USER-NAME TEXT FIELD - 101/07/09/2022
*/
/*
TEXT FIELD WITH ICON ADDED FOR BEFORE AND AFTER - 103/07/09/2022
*/
export const FileInputTextField = ({ onChange,value,label,name,errorStatus,errorMessage,iconStart, iconEnd, InputProps, ...props }) => (
  <TextField required size="small" sx={Filefieldstyles} variant="outlined" label={label} name={name} onChange={onChange} value={value} 
  {...props}
  InputProps={{
    ...InputProps,
    startAdornment: iconStart ? (
      <InputAdornment position="start">{iconStart}</InputAdornment>
    ) : null,
    endAdornment: iconEnd ? (
      <InputAdornment position="end">{iconEnd}</InputAdornment>
    ) : null
  }}
  />
);
export const SelectTextField =({onChange,error,value,label,labelname,submenu}) => (
  <FormControl required error={error} sx={selectfieldstyle}>
     <InputLabel id="demo-simple-select-disabled-label">{labelname}</InputLabel>
<Select
  labelId="demo-simple-select-required-label"
  id="demo-simple-select-required"
  value={value}
  label={label}
  onClick={onChange}
>
  {submenu}
</Select>
</FormControl>);
