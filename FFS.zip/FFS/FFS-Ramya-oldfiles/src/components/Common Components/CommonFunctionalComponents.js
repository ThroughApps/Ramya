
import moment from 'moment-timezone';

/*
FUNCTION USED FOR GETTING DATE & TIME FOR A TIMEZONE
USED IN ALL THE PAGES - 101/16/09/2022 */

export const TimeZoneDateTime = (timeZone) => {


    var empZone = timeZone;
    //console.log("empZone :", empZone);


    var offset = moment.tz(moment.utc(), empZone).utcOffset();
    var offsetValue = Number(offset) / 60; //CONVERTING MIN INTO HRS
    var timings = CalcTime(empZone, offsetValue);
    var todayDate = GetTimeZoneDate(offsetValue);
    var currenttime = timings.toLocaleTimeString([], { hour12: false });

    var date_Time = {
        date: todayDate,
        time: currenttime,
    }

    return date_Time;
}

export const CalcTime = (city, offset) => {
    // create Date object for current location
    var d = new Date();


    // convert to msec
    // subtract local time zone offset
    // get UTC time in msec
    var utc = d.getTime() + (d.getTimezoneOffset() * 60000);

    // create new Date object for different city
    // using supplied offset
    var nd = new Date(utc + (3600000 * offset));

    // return time as a string
    return nd;
}


export const GetTimeZoneDate = (offset) => {
    //  var offset = -8;
    var todayDate = new Date(new Date().getTime() + offset * 3600 * 1000).toUTCString().replace(/ GMT$/, "")


    var d1 = new Date(todayDate);
    var d2 = d1.getFullYear() + "-"
        + ('0' + (d1.getMonth() + 1)).slice(-2) + "-"
        + ('0' + d1.getDate()).slice(-2);


    return d2;

}
